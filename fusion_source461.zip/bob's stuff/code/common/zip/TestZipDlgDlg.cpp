// TestZipDlgDlg.cpp : implementation file
///////////////////////////////////////////////////////////////
//   Copyright (C) 2000 Tadeusz Dracz
///////////////////////////////////////////////////////////////


#include "stdafx.h"
#include "TestZipDlg.h"
#include "TestZipDlgDlg.h"
#include "OptionsDlg.h"
#include "BrowseForFolder.h"
#include "AboutDlg.h"
#include "CommentDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestZipDlgDlg dialog

CTestZipDlgDlg::CTestZipDlgDlg(CWnd* pParent /*=NULL*/)
	: CResizableDialog(CTestZipDlgDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestZipDlgDlg)
	m_szComment = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestZipDlgDlg::DoDataExchange(CDataExchange* pDX)
{
	CResizableDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestZipDlgDlg)
	DDX_Control(pDX, IDC_CONTENTS, m_files);
	DDX_Text(pDX, IDC_EDIT1, m_szComment);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestZipDlgDlg, CResizableDialog)
	//{{AFX_MSG_MAP(CTestZipDlgDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DESTROY()
	ON_COMMAND(ID_ACTION_ADD_FILES, OnActionAddFiles)
	ON_COMMAND(ID_ACTION_ADD_FOLODER, OnActionAddFoloder)
	ON_COMMAND(ID_ACTION_DELETE, OnActionDelete)
	ON_COMMAND(ID_ACTION_EXTRACT, OnActionExtract)
	ON_COMMAND(ID_ARCHIVE_CLOSE, OnArchiveClose)
	ON_COMMAND(ID_ARCHIVE_EXIT, OnArchiveExit)
	ON_COMMAND(ID_ARCHIVE_NEW, OnArchiveNew)
	ON_COMMAND(ID_ARCHIVE_OPEN, OnArchiveOpen)
	ON_COMMAND(ID_ARCHIVE_OPTIONS, OnArchiveOptions)
	ON_COMMAND(ID_HELP_ABOUT, OnHelpAbout)
	ON_UPDATE_COMMAND_UI(ID_ACTION_ADD_FILES, OnUpdateActionAdd)
	ON_UPDATE_COMMAND_UI(ID_ACTION_DELETE, OnUpdateActionDelete)
	ON_UPDATE_COMMAND_UI(ID_ACTION_EXTRACT, OnUpdateActionExtract)
	ON_UPDATE_COMMAND_UI(ID_ARCHIVE_CLOSE, OnUpdateArchiveClose)
	ON_EN_CHANGE(IDC_EDIT1, OnChangeEdit1)
	ON_NOTIFY(NM_DBLCLK, IDC_CONTENTS, OnDblclkContents)
	ON_UPDATE_COMMAND_UI(ID_ACTION_ADD_FOLODER, OnUpdateActionAdd)
	ON_WM_INITMENU()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestZipDlgDlg message handlers

BOOL CTestZipDlgDlg::OnInitDialog()
{
	m_zip.SetSpanCallback(ChangeDisk, this);
	m_zip.SetAdvanced(1500000);
	if (!m_options.m_reg.Load())
		m_options.SetDefaults();

	CResizableDialog::OnInitDialog();
	UpdateDialogControls(this, FALSE);

	m_files.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	m_files.InsertColumn(0, IDS_COL1);
	m_files.InsertColumn(1, IDS_COL2);
	m_files.InsertColumn(2, IDS_COL3, LVCFMT_RIGHT);
	m_files.InsertColumn(3, IDS_COL4);
	m_files.InsertColumn(4, IDS_COL6);
	m_files.InsertColumn(5, IDS_COL7);
	m_files.InsertColumn(6, IDS_COL5, LVCFMT_RIGHT);
	m_files.InsertColumn(7, IDS_COL8);
	m_files.UpdateColumnWidths();
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	AddAnchor(IDC_EDIT1, MIDDLE_LEFT, BOTTOM_RIGHT);
	AddAnchor(IDC_COMM_TXT, MIDDLE_LEFT, BOTTOM_RIGHT);
	AddAnchor(IDC_CONTENTS, TOP_LEFT, MIDDLE_RIGHT);
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestZipDlgDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CResizableDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestZipDlgDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

bool CTestZipDlgDlg::GetFileName(CString &szFile, bool bOpen)
{
	CFileDialog fd(bOpen, "zip", bOpen ? NULL : "archive", OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "Zip Files (*.zip)|*.zip|All Files (*.*)|*.*||");
	if (fd.DoModal() != IDOK)
		return false;
	szFile = fd.GetPathName();
	return true;
}

void CTestZipDlgDlg::Redisplay()
{
	DisplayLabel();
	m_files.DeleteAllItems();
	for (int i = 0; i < m_zip.GetNoEntries(); i++)
	{
		CFileHeader fh;
		m_zip.GetFileInfo(fh, (WORD)i);
		int iItem = m_files.GetItemCount();
		m_files.InsertItem(iItem, fh.m_szFileName);
		m_files.SetItemText(iItem, 1, m_zip.IsFileDirectory((WORD)i) ? "YES" : "NO");
		CString sz;
		sz.Format("%d", fh.m_uUncomprSize);
		m_files.SetItemText(iItem, 2, sz);
		m_files.SetItemText(iItem, 3, fh.GetTime().FormatGmt("%d %b %Y, %X"));
		sz = fh.m_uExternalAttr & FILE_ATTRIBUTE_READONLY ? 'r' : '-';
		sz += fh.m_uExternalAttr & FILE_ATTRIBUTE_ARCHIVE ? 'a' : '-';
		sz += fh.m_uExternalAttr & FILE_ATTRIBUTE_HIDDEN ? 'h' : '-';
		sz += fh.m_uExternalAttr & FILE_ATTRIBUTE_SYSTEM ? 's' : '-';
		m_files.SetItemText(iItem, 4, sz);
		sz.Format("%d%%", fh.m_uUncomprSize ? fh.m_uComprSize * 100 / fh.m_uUncomprSize : 0);
		m_files.SetItemText(iItem, 5, sz);
		sz.Format("%lu", fh.m_uCrc32);
		m_files.SetItemText(iItem, 6, sz);
		sz = (fh.m_szComment.GetLength() > 1024) ? fh.m_szComment.Left(1024) +"..." : fh.m_szComment;
		m_files.SetItemText(iItem, 7, sz);
	}
	m_files.UpdateColumnWidths();
}

void CTestZipDlgDlg::OnDestroy() 
{
	OnArchiveClose();
	CResizableDialog::OnDestroy();
}

bool CTestZipDlgDlg::ChangeDisk(int iNumber, int iCode, void* pData)
{
	CTestZipDlgDlg* p = (CTestZipDlgDlg*)pData;
	p->DisplayLabel();
	CString sz;
	sz.Format("Insert disk number %d.", iNumber);
	return AfxMessageBox(sz, MB_OKCANCEL) == IDOK;
}

void CTestZipDlgDlg::DisplayLabel()
{
	SetWindowText(m_zip.GetArchivePath().IsEmpty() ? "Zip" : m_zip.GetArchivePath());
}


void CTestZipDlgDlg::AddFolder(CString szFolder)
{
	szFolder.TrimRight("\\");
	CFileFind ff;
	BOOL b = ff.FindFile(szFolder + "\\*");
	CStringArray folders;
	while (b)
	{
		b = ff.FindNextFile();
		if (ff.IsDots())
			continue;
		if (ff.IsDirectory())
		{
			if  (!m_options.m_bRecurse)
				continue;
			folders.Add(ff.GetFilePath());
		}
		else
			m_zip.AddNewFile(ff.GetFilePath(),m_options.m_iLevel);

	}
	for (int i = 0; i < folders.GetSize(); i++)
	{
		m_zip.AddNewFile(folders[i]); // add the folder before adding its files
												// it is not needed to add the root folder
		AddFolder(folders[i]);
	}
}

void CTestZipDlgDlg::OnActionAddFiles() 
{
	CFileDialog fd(TRUE, NULL, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "All Files (*.*)|*.*||");
	fd.m_ofn.Flags |= OFN_ALLOWMULTISELECT;
	if (fd.DoModal() != IDOK)
		return;
	POSITION p = fd.GetStartPosition();
	while (p)
		m_zip.AddNewFile(fd.GetNextPathName(p), m_options.m_iLevel);
	Redisplay();
	
}

void CTestZipDlgDlg::OnActionAddFoloder() 
{
	CBrowseForFolder bf;	
	bf.hWndOwner = this->m_hWnd;
	bf.strTitle = "Select directory to add to the archive";
	CString sz;
	if (!bf.GetFolder(sz))
		return;
	AddFolder(sz);
	Redisplay();	
	
}

void CTestZipDlgDlg::OnActionDelete() 
{
	CDWordArray da;
	m_files.BuildSelectedArray(da);
	CWordArray wa;
	for (int i = 0; i < da.GetSize(); i++)
		wa.Add((WORD)da[i]);

	m_zip.DeleteFiles(wa);
	Redisplay();	
	
}

void CTestZipDlgDlg::OnActionExtract() 
{
	CBrowseForFolder bf;	
	bf.hWndOwner = this->m_hWnd;
	bf.strTitle = "Select directory to extract files";
	CString sz;
	if (!bf.GetFolder(sz))
		return;
	CDWordArray da;
	m_files.BuildSelectedArray(da);
	for (int i = 0; i < da.GetSize(); i++)
		m_zip.ExtractFile((WORD)da[i], sz);
	
}

void CTestZipDlgDlg::OnArchiveClose() 
{
	if (m_bCommentModified)
	{
		UpdateData();
		m_zip.SetGlobalComment(m_szComment);
		m_bCommentModified = false;
	}
	m_zip.Close();	
	GetDlgItem(IDC_EDIT1)->EnableWindow(FALSE);
	m_szComment.Empty();
	UpdateData(FALSE);

	Redisplay();
	
}

void CTestZipDlgDlg::OnArchiveExit() 
{
	EndDialog(IDOK);
	
}

void CTestZipDlgDlg::OnArchiveNew() 
{
	CString sz;
	if (!GetFileName(sz, false))
		return;
	OnArchiveClose();

	m_bCommentModified = false;
	m_szComment.Empty();
	UpdateData(FALSE);
	GetDlgItem(IDC_EDIT1)->EnableWindow();

	m_zip.Open(sz, m_options.m_iSpan == 0 ? CZipArchive::create : CZipArchive::createSpan,
		m_options.m_iSpan == 1 ? 0 : m_options.m_uVolumeSize);
	Redisplay();
	
}

void CTestZipDlgDlg::OnArchiveOpen() 
{
	CString sz;
	if (!GetFileName(sz, true))
		return;
	OnArchiveClose();

	m_zip.Open(sz, CZipArchive::open, m_options.m_bTdComp ? 1 : 0 );

	m_bCommentModified = false;
	m_szComment = m_zip.GetGlobalComment();
	UpdateData(FALSE);
	if (!m_zip.GetSpanMode())
		GetDlgItem(IDC_EDIT1)->EnableWindow();

	Redisplay();

	
}

void CTestZipDlgDlg::OnArchiveOptions() 
{
	COptionsDlg dlg;
	dlg.m_pOptions = &m_options;
	dlg.DoModal();
	
}

void CTestZipDlgDlg::OnHelpAbout() 
{
	CAboutDlg dlg;
	dlg.DoModal();
	
}

void CTestZipDlgDlg::OnUpdateActionAdd(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!m_zip.IsClosed() && (m_zip.GetSpanMode() >= 0));
}

void CTestZipDlgDlg::OnUpdateActionDelete(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!m_zip.IsClosed() && !m_zip.GetSpanMode() && m_files.GetSelectedCount());
	
}

void CTestZipDlgDlg::OnUpdateActionExtract(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!m_zip.IsClosed() && (m_zip.GetSpanMode() <= 0)&& m_files.GetSelectedCount());
	
}

void CTestZipDlgDlg::OnUpdateArchiveClose(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(!m_zip.IsClosed());
	
}

void CTestZipDlgDlg::OnChangeEdit1() 
{
	m_bCommentModified = true;	
}

void CTestZipDlgDlg::OnDblclkContents(NMHDR* pNMHDR, LRESULT* pResult) 
{
	if (m_zip.IsClosed() || (m_zip.GetSpanMode() < 0))
		return;
	int i = m_files.GetFirstSelectedItem();
	if (i == -1)
		return;
	CCommentDlg dlg;
	CFileHeader fh;
	m_zip.GetFileInfo(fh, (WORD)i);
	dlg.m_szComment = fh.m_szComment;
	if (dlg.DoModal() == IDOK)
	{
		if (fh.m_szComment.Collate(dlg.m_szComment))
		{
			m_zip.SetFileComment((WORD)i, dlg.m_szComment);
			Redisplay();
		}
	}

	*pResult = 0;
}

void CTestZipDlgDlg::UpdateMenu(CMenu *pMenu)
{
	CCmdUI cmd;
	cmd.m_nIndexMax = pMenu->GetMenuItemCount();
	cmd.m_pMenu = pMenu;
	int s = 0;
	for (UINT i = 0; i < cmd.m_nIndexMax; i++)
	{
		cmd.m_nIndex = i;
		MENUITEMINFO mi;
		mi.cbSize = sizeof(MENUITEMINFO);
		mi.fMask = MIIM_SUBMENU
#ifndef NO_CHECK_FOR_SEPARATOR
	#if(WINVER >= 0x0500)
				| MIIM_FTYPE
	#else
				| MIIM_TYPE
	#endif /* WINVER >= 0x0500 */
#endif //NO_CHECK_FOR_SEPARATOR
;
		if (!pMenu->GetMenuItemInfo(cmd.m_nIndex, &mi, TRUE))
			return;
#ifndef NO_CHECK_FOR_SEPARATOR
		if (mi.fType & MFT_SEPARATOR)
			continue;
#endif //NO_CHECK_FOR_SEPARATOR
		if (mi.hSubMenu)
			UpdateMenu(pMenu->GetSubMenu(s++));
		else
		{
			cmd.m_nID = pMenu->GetMenuItemID(i);
			OnCmdMsg(cmd.m_nID, CN_UPDATE_COMMAND_UI, &cmd, NULL);
		}
		
	}

}

void CTestZipDlgDlg::OnInitMenu(CMenu* pMenu) 
{
	CResizableDialog::OnInitMenu(pMenu);
	UpdateMenu(pMenu);	
}
