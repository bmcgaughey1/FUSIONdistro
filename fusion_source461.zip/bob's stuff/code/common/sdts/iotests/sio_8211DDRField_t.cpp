//
//		sio_8211DDRField_t.cpp   
//

#include <cassert>
#include <memory.h>

#include <string>

#include <iostream>

#ifdef WIN32
using namespace std;
#endif

#include "io/sio_8211DDRField.h"
#include "io/sio_8211Field.h"
#include "io/sio_8211DDRLeader.h"
#include "io/sio_Buffer.h"


const char   data_struct_code = '0';
const char   data_type_code   = '1';
const string field_name       = "FIELD NAME";
const string subfield_array   = "SUBFIELD";
const string format_string    = "(2A(10))";



//
// The field's attributes should be the same as the 
// global variables that were used to set it.
// We use a copy of the field to exercise the copy ctor.
//
void
test_field( sio_8211DDRField field )
{
   assert( field.getDataStructCode()   == data_struct_code );
   assert( field.getDataTypeCode()     == data_type_code );
   assert( field.getDataFieldName()    == field_name );
   assert( field.getArrayDescriptor()  == subfield_array );
   assert( field.getFormatControls()   == format_string );

} // test_field



int 
main( int argc, char** argv )
{

   cout << argv[0] << " ... " << flush;

   sio_8211DDRField ddr_field;

   // insure that the data field name, array descriptors, and format control
   // strings start out with nothing in them

   assert( ddr_field.getDataFieldName() == "" );
   assert( ddr_field.getArrayDescriptor() == "" );
   assert( ddr_field.getFormatControls() == "" );


   // now set them; test_field insures that you get what you set

   ddr_field.setDataStructCode( data_struct_code );
   ddr_field.setDataTypeCode( data_type_code );
   ddr_field.setDataFieldName( field_name );
   ddr_field.setArrayDescriptor( subfield_array );
   ddr_field.setFormatControls( format_string );

   test_field( ddr_field );


   // now do the same thing, except the DDR field will get its
   // values from a leader and a field

   sio_8211DDRLeader    ddr_leader;
   sio_8211Field        field;

   const string data =  "0100;&" +
                        field_name + sio_8211UnitTerminator + 
                        subfield_array + sio_8211UnitTerminator + 
                        format_string;

   //  add some bogus data to the field
   field.setData( data.c_str(), data.length() );

   //  create a DDR field with the given leader and field
   sio_8211DDRField ddr_field2( ddr_leader, field );

   test_field( ddr_field2 );


   // Now check out that the raw sio_Buffer you get from the 
   // DDR field is ok -- it should be in synch with the raw data
   // that was used to create the DDR field in the first place.

   //  Grab a raw buffer of the DDR field contents
   sio_Buffer test_buffer = ddr_field2.getField();

   // The buffer should be identical to the string that was used to
   // build the DDR field.
   assert( 0 == memcmp( test_buffer.data(), data.c_str(), data.length() ) );


   cout << "ok\n";

   return 0;

}


