#if !defined(AFX_ASCIIGRDIMPORT_H__83AF534E_F6F6_40B7_951C_144D22920AD3__INCLUDED_)
#define AFX_ASCIIGRDIMPORT_H__83AF534E_F6F6_40B7_951C_144D22920AD3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ASCIIGrdImport.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CASCIIGrdImport dialog

class CASCIIGrdImport : public CDialog
{
// Construction
public:
	CASCIIGrdImport(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CASCIIGrdImport)
	enum { IDD = IDD_CONVERTASCIIGRD };
	CString	m_InputFileName;
	CString	m_OutputFileName;
	int		m_PlanimetricIn;
	int		m_PlanimetricOut;
	int		m_ElevationIn;
	int		m_ElevationOut;
	int		m_Projection;
	int		m_ProjectionZone;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CASCIIGrdImport)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CASCIIGrdImport)
	virtual BOOL OnInitDialog();
	afx_msg void OnImport();
	afx_msg void OnImportInputbrowse();
	afx_msg void OnImportOutputbrowse();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void AddToStatusText(CEdit* EditCtrl, LPCTSTR Text);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ASCIIGRDIMPORT_H__83AF534E_F6F6_40B7_951C_144D22920AD3__INCLUDED_)
