// LPPTrajectoryFile.cpp: implementation of the CLPPTrajectoryFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LPPTrajectoryFile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLPPTrajectoryFile::CLPPTrajectoryFile(LPCTSTR FileName)
{
	m_Valid = FALSE;

	// defaults for terrascan arboretum flight
	SetIMUToLaserOffset(-0.088, 0.239, 0.04);
	SetBoresightCorrection(0.010008, -0.061615, 89.707251);

	Open(FileName);
}

CLPPTrajectoryFile::CLPPTrajectoryFile()
{
	// defaults for terrascan arboretum flight
	SetIMUToLaserOffset(-0.088, 0.239, 0.04);
	SetBoresightCorrection(0.010008, -0.061615, 89.707251);

	m_Valid = FALSE;
}

CLPPTrajectoryFile::~CLPPTrajectoryFile()
{
	Close();
}

BOOL CLPPTrajectoryFile::IsValid()
{
	return(m_Valid);
}

BOOL CLPPTrajectoryFile::Open(LPCTSTR FileName)
{
	Close();

	// try to open file
	m_FileHandle = fopen(FileName, "rb");
	if (m_FileHandle) {
		// read header and verify Sync value
		fread(&m_Header, sizeof(LPPHeader), 1, m_FileHandle);

//		if (m_Header.MagicNumber[0] == 0xaa && m_Header.MagicNumber[1] == 0x44 && m_Header.MagicNumber[2] == 0x14 && m_Header.MagicNumber[3] == 0x88) {
		if (m_Header.MagicNumber[0] == 0xaa && m_Header.MagicNumber[1] == 0x44 && m_Header.MagicNumber[2] == 0x15 && m_Header.MagicNumber[3] == 0x88) {
			// position file access to first record of position data
			Rewind();

			m_Valid = TRUE;
		}
	}

	return(m_Valid);
}

void CLPPTrajectoryFile::SetIMUToLaserOffset(double XOffset, double YOffset, double ZOffset)
{
	m_IMUToLaserXOffset = XOffset;
	m_IMUToLaserYOffset = YOffset;
	m_IMUToLaserZOffset = ZOffset;
}

void CLPPTrajectoryFile::SetBoresightCorrection(double RollCorrection, double PitchCorrection, double HeadingCorrection)
{
	m_BoresightCorrectionRoll = RollCorrection;
	m_BoresightCorrectionPitch = PitchCorrection;
	m_BoresightCorrectionHeading = HeadingCorrection;
}

void CLPPTrajectoryFile::Close()
{
	if (m_Valid)
		fclose(m_FileHandle);

	m_Valid = FALSE;
}

void CLPPTrajectoryFile::Rewind()
{
	if (m_Valid)
		fseek(m_FileHandle, m_Header.HeaderSize, SEEK_SET);
}

BOOL CLPPTrajectoryFile::ReadPosition(LPPRecord &Position)
{
	if (m_Valid) {
		if (fread(&Position, sizeof(LPPRecord), 1, m_FileHandle) == 1)
			return(TRUE);
	}
	return(FALSE);
}

long CLPPTrajectoryFile::GetRecordCount()
{
	// return number of records from file header
	if (m_Valid)
		return(m_Header.NumberOfRecords);
	
	// return 0 if file isn't valid
	return(0);
}
