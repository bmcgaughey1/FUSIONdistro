// combine.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "combine.h"
#include "datafile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		if (argc < 4) {
			printf("Syntax: Combine inputfile1 inputfile2 outputfile\n");
			printf("   inputfile1    XYZ text file\n");
			printf("   inputfile2    XYZ text file\n");
			printf("   outputfile    text file for output\n");
		}
		else {
			BOOL	m_Index = TRUE;
			CString	m_InputFile1Name(argv[1]);
			CString	m_InputFile2Name(argv[2]);
			CString	m_OutputFileName(argv[3]);

			float Nadir, Intensity;

			char buf1[1024];
			char buf2[1024];

			// open input files
			CDataFile dat1(m_InputFile1Name);
			CDataFile dat2(m_InputFile2Name);

			FILE* f = fopen(m_OutputFileName, "wt");
			if (f) {
				while (dat1.ReadDataLine(buf1, SKIPCOMMENTSCOMMANDS)) {
					if (dat2.ReadDataLine(buf2, SKIPCOMMENTSCOMMANDS)) {
						fprintf(f, "%s", buf1);

						// get last 2 columns from file 2
						strtok(buf2, " ,\t");
						strtok(NULL, " ,\t");
						strtok(NULL, " ,\t");
						strtok(NULL, " ,\t");
						strtok(NULL, " ,\t");
						Nadir = (float) atof(strtok(NULL, " ,\t"));
						Intensity = (float) atof(strtok(NULL, " ,\t"));

						fprintf(f, " %.4f %.4f\n", Nadir, Intensity);
					}
				}
				fclose(f);
			}
		}
	}

	return nRetCode;
}


