// WorldFile.h: interface for the CWorldFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WORLDFILE_H__F859B2E4_7E2A_402F_877B_1E19FA3E09FC__INCLUDED_)
#define AFX_WORLDFILE_H__F859B2E4_7E2A_402F_877B_1E19FA3E09FC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CWorldFile
{
public:
	BOOL WriteValues(LPCTSTR FileName);
	double m_Aterm;
	double m_Bterm;
	double m_Cterm;
	double m_Dterm;
	double m_Eterm;
	double m_Fterm;
	BOOL FindAndRead(LPCTSTR BaseFileName);
	CWorldFile();
	virtual ~CWorldFile();
	CString m_FileName;

private:
	BOOL ReadValues();
};

#endif // !defined(AFX_WORLDFILE_H__F859B2E4_7E2A_402F_877B_1E19FA3E09FC__INCLUDED_)
