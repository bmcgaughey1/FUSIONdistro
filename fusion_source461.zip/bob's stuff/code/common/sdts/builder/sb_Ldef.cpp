//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//
// $Id: sb_Ldef.cpp,v 1.4 1998/09/01 22:10:14 mcoletti Exp $
//

#include "builder/sb_Ldef.h"



#include <iostream>
#include <strstream>

#include <limits.h>
#include <float.h>

#ifndef INCLUDED_SB_UTILS_H
#include "builder/sb_Utils.h"
#endif

#ifndef INCLUDED_SB_FOREIGNID_H
#include "builder/sb_ForeignID.h"
#endif

#ifndef INCLUDED_SC_RECORD_H
#include "container/sc_Record.h"
#endif

#ifndef INCLUDED_SC_FIELD_H
#include "container/sc_Field.h"
#endif

#ifndef INCLUDED_SC_SUBFIELD_H
#include "container/sc_Subfield.h"
#endif

#ifndef INCLUDED_SIO_8211CONVERTER_H
#include "io/sio_8211Converter.h"
#endif



static const char* _ident = "$Id: sb_Ldef.cpp,v 1.4 1998/09/01 22:10:14 mcoletti Exp $";

// Strings and integers are initialized with these values; they are used
// to indicate whether a given module value has been assigned a value or not.

// (XXX I arbitrarily chose 0x4 as the sentinal value.  I hate ad hoc crap.)

static const string  UNVALUED_STRING(1, static_cast<string::value_type>(0x4) );

static const long    UNVALUED_LONG   = INT_MIN;

static const double  UNVALUED_DOUBLE = DBL_MAX;

struct sb_Ldef_Imp
{
  string   _CellModuleName;
  string   _LayerLabel;
  string   _CellCode;
  string   _Bitmask;
  long     _NumberRows;
  long     _NumberColumns;
  long     _NumberPlanes;
  long     _ScanOriginRow;
  long     _ScanOriginColumn;
  long     _ScanOriginPlane;
  long     _RowOffsetOrigin;
  long     _ColumnOffsetOrigin;
  long     _PlaneOffsetOrigin;
  string   _IntracellReferenceLocation;
  string   _Comment;


  sb_Ldef_Imp()
    : 
    _CellModuleName( UNVALUED_STRING ),
    _LayerLabel( UNVALUED_STRING ),
    _CellCode( UNVALUED_STRING ),
    _Bitmask( UNVALUED_STRING ),
    _NumberRows( UNVALUED_LONG ),
    _NumberColumns( UNVALUED_LONG ),
    _NumberPlanes( UNVALUED_LONG ),
    _ScanOriginRow( UNVALUED_LONG ),
    _ScanOriginColumn( UNVALUED_LONG ),
    _ScanOriginPlane( UNVALUED_LONG ),
    _RowOffsetOrigin( UNVALUED_LONG ),
    _ColumnOffsetOrigin( UNVALUED_LONG ),
    _PlaneOffsetOrigin( UNVALUED_LONG ),
    _IntracellReferenceLocation( UNVALUED_STRING ),
    _Comment( UNVALUED_STRING )
  {}

};


sb_Ldef::sb_Ldef()
  : _imp( new sb_Ldef_Imp() )
{
  setMnemonic("LDEF");
  setID( 1 );


  // insert static initializers

} // Ldef ctor


sb_Ldef::~sb_Ldef()
{
  delete _imp;
} // Ldef dtor




static sio_8211Converter_I converter_I; // XXX should define these in
static sio_8211Converter_A converter_A; // XXX sio_8211Converter.h
static sio_8211Converter_R converter_R;
static sio_8211Converter_C converter_C;

static sio_8211Schema _schema; // module specific schema

static
void
_build_schema( sio_8211Schema& schema )
{
  schema.clear();               // make sure we are starting with clean schema

  schema.push_back( sio_8211FieldFormat() );

  sio_8211FieldFormat& field_format = schema.back();

  field_format.setDataStructCode( sio_8211FieldFormat::vector );
  field_format.setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  field_format.setName( "Layer Definition" );
  field_format.setTag( "LDEF" );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "MODN" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "RCID" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "CMNM" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "LLBL" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "CODE" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

//  field_format.back().setLabel( "BMSK" );
//  field_format.back().setType( sio_8211SubfieldFormat::C );
//  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
//  field_format.back().setConverter( &converter_C );

//  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "NROW" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "NCOL" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );


  field_format.push_back( sio_8211SubfieldFormat() );

//  field_format.back().setLabel( "NPLA" );
//  field_format.back().setType( sio_8211SubfieldFormat::I );
//  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
//  field_format.back().setConverter( &converter_I );

//  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "SORI" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "SOCI" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );


  field_format.push_back( sio_8211SubfieldFormat() );

//  field_format.back().setLabel( "SOPI" );
//  field_format.back().setType( sio_8211SubfieldFormat::I );
//  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
//  field_format.back().setConverter( &converter_I );

//  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "RWOO" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "CLOO" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );


  field_format.push_back( sio_8211SubfieldFormat() );

//  field_format.back().setLabel( "PLOO" );
//  field_format.back().setType( sio_8211SubfieldFormat::I );
//  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
//  field_format.back().setConverter( &converter_I );

//  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "INTR" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


//  field_format.push_back( sio_8211SubfieldFormat() );

//  field_format.back().setLabel( "COMT" );
//  field_format.back().setType( sio_8211SubfieldFormat::A );
//  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
//  field_format.back().setConverter( &converter_A );


} // _build_schema


static
bool
_ingest_record( sb_Ldef& ldef, sb_Ldef_Imp &ldef_imp, sc_Record const& record )
{

  // Make sure we have a record from an
  // External Spatial Reference module.

  sc_FieldCntr::const_iterator curfield;

  if ( ! sb_Utils::getFieldByMnem( record,"LDEF",curfield) )
  {
#ifdef SDTSXX_DEBUG
    cerr << "sb_Ldef::sb_Ldef(sc_Record const&): "
	 << "Not an layer definition record.";
    cerr << endl;
#endif
    return false;
  }


  // We have a primary field from a  module. Start// picking it apart.

  sc_SubfieldCntr::const_iterator cursubfield;

  string tmp_str;
  long   tmp_int;


  // MODN
  if (sb_Utils::getSubfieldByMnem(*curfield,"MODN",cursubfield))
  {
    cursubfield->getA( tmp_str );
    ldef.setMnemonic( tmp_str );
  }


  // RCID
  if (sb_Utils::getSubfieldByMnem(*curfield,"RCID",cursubfield))
  {
    cursubfield->getI( tmp_int );
    ldef.setID( tmp_int );
  }


  // CMNM
  if (sb_Utils::getSubfieldByMnem(*curfield,"CMNM",cursubfield))
  {
    cursubfield->getA( ldef_imp._CellModuleName);
  }
  else
  {
    return false;
  }


  // LLBL
  if (sb_Utils::getSubfieldByMnem(*curfield,"LLBL",cursubfield))
  {
    cursubfield->getA( ldef_imp._LayerLabel);
  }
  else
  {
    return false;
  }


  // CODE
  if (sb_Utils::getSubfieldByMnem(*curfield,"CODE",cursubfield))
  {
    cursubfield->getA( ldef_imp._CellCode);
  }
  else
  {
    return false;
  }


  // BMSK
  // if (sb_Utils::getSubfieldByMnem(*curfield,"BMSK",cursubfield))
  // {
  //  cursubfield->getC( ldef_imp._Bitmask);
  // }
  // else
  // {
  //  return false;
  // }


  // NROW
  if (sb_Utils::getSubfieldByMnem(*curfield,"NROW",cursubfield))
  {
    cursubfield->getI( ldef_imp._NumberRows);
  }
  else
  {
    return false;
  }


  // NCOL
  if (sb_Utils::getSubfieldByMnem(*curfield,"NCOL",cursubfield))
  {
    cursubfield->getI( ldef_imp._NumberColumns);
  }
  else
  {
    return false;
  }


  // NPLA
  // if (sb_Utils::getSubfieldByMnem(*curfield,"NPLA",cursubfield))
  // {
  //  cursubfield->getI( ldef_imp._NumberPlanes);
  // }
  // else
  // {
  //  return false;
  // }


  // SORI
  if (sb_Utils::getSubfieldByMnem(*curfield,"SORI",cursubfield))
  {
    cursubfield->getI( ldef_imp._ScanOriginRow);
  }
  else
  {
    return false;
  }


  // SOCI
  if (sb_Utils::getSubfieldByMnem(*curfield,"SOCI",cursubfield))
  {
    cursubfield->getI( ldef_imp._ScanOriginColumn);
  }
  else
  {
    return false;
  }


  // SOPI
  // if (sb_Utils::getSubfieldByMnem(*curfield,"SOPI",cursubfield))
  // {
  //  cursubfield->getI( ldef_imp._ScanOriginPlane);
  // }
  // else
  // {
  //  return false;
  // }


  // RWOO
  if (sb_Utils::getSubfieldByMnem(*curfield,"RWOO",cursubfield))
  {
    cursubfield->getI( ldef_imp._RowOffsetOrigin);
  }
  else
  {
    return false;
  }


  // CLOO
  if (sb_Utils::getSubfieldByMnem(*curfield,"CLOO",cursubfield))
  {
    cursubfield->getI( ldef_imp._ColumnOffsetOrigin);
  }
  else
  {
    return false;
  }


  // PLOO
  // if (sb_Utils::getSubfieldByMnem(*curfield,"PLOO",cursubfield))
  // {
  //  cursubfield->getI( ldef_imp._PlaneOffsetOrigin);
  // }
  // else
  // {
  //   return false;
  // }


  // INTR
  if (sb_Utils::getSubfieldByMnem(*curfield,"INTR",cursubfield))
  {
    cursubfield->getA( ldef_imp._IntracellReferenceLocation);
  }
  else
  {
    return false;
  }


  // COMT
  // if (sb_Utils::getSubfieldByMnem(*curfield,"COMT",cursubfield))
  // {
  //   cursubfield->getA( ldef_imp._Comment);
  // }
  // else
  // {
  //   return false;
  // }


  return true;


} // _ingest_record




bool
sb_Ldef::getCellModuleName( string& val ) const
{
  if ( _imp->_CellModuleName == UNVALUED_STRING )
    return false;

  val = _imp->_CellModuleName;

  return true;
} // sb_Ldef::getCellModuleName


bool
sb_Ldef::getLayerLabel( string& val ) const
{
  if ( _imp->_LayerLabel == UNVALUED_STRING )
    return false;

  val = _imp->_LayerLabel;

  return true;
} // sb_Ldef::getLayerLabel


bool
sb_Ldef::getCellCode( string& val ) const
{
  if ( _imp->_CellCode == UNVALUED_STRING )
    return false;

  val = _imp->_CellCode;

  return true;
} // sb_Ldef::getCellCode


// bool
// sb_Ldef::getBitmask( string& val ) const
// {
//  if ( _imp->_Bitmask == UNVALUED_STRING )
//    return false;
//
//  val = _imp->_Bitmask;
//
//  return true;
// } // sb_Ldef::getBitmask


bool
sb_Ldef::getNumberRows( long& val ) const
{
  if ( _imp->_NumberRows == UNVALUED_LONG )
    return false;

  val = _imp->_NumberRows;

  return true;
} // sb_Ldef::getNumberRows


bool
sb_Ldef::getNumberColumns( long& val ) const
{
  if ( _imp->_NumberColumns == UNVALUED_LONG )
    return false;

  val = _imp->_NumberColumns;

  return true;
} // sb_Ldef::getNumberColumns


// bool
// sb_Ldef::getNumberPlanes( long& val ) const
// {
//  if ( _imp->_NumberPlanes == UNVALUED_LONG )
//    return false;
//
//  val = _imp->_NumberPlanes;
//
//  return true;
// } // sb_Ldef::getNumberPlanes


bool
sb_Ldef::getScanOriginRow( long& val ) const
{
  if ( _imp->_ScanOriginRow == UNVALUED_LONG )
    return false;

  val = _imp->_ScanOriginRow;

  return true;
} // sb_Ldef::getScanOriginRow


bool
sb_Ldef::getScanOriginColumn( long& val ) const
{
  if ( _imp->_ScanOriginColumn == UNVALUED_LONG )
    return false;

  val = _imp->_ScanOriginColumn;

  return true;
} // sb_Ldef::getScanOriginColumn


// bool
// sb_Ldef::getScanOriginPlane( long& val ) const
// {
//  if ( _imp->_ScanOriginPlane == UNVALUED_LONG )
//    return false;
//
//  val = _imp->_ScanOriginPlane;
//
//  return true;
// } // sb_Ldef::getScanOriginPlane


bool
sb_Ldef::getRowOffsetOrigin( long& val ) const
{
  if ( _imp->_RowOffsetOrigin == UNVALUED_LONG )
    return false;

  val = _imp->_RowOffsetOrigin;

  return true;
} // sb_Ldef::getRowOffsetOrigin


bool
sb_Ldef::getColumnOffsetOrigin( long& val ) const
{
  if ( _imp->_ColumnOffsetOrigin == UNVALUED_LONG )
    return false;

  val = _imp->_ColumnOffsetOrigin;

  return true;
} // sb_Ldef::getColumnOffsetOrigin


// bool
// sb_Ldef::getPlaneOffsetOrigin( long& val ) const
// {
//  if ( _imp->_PlaneOffsetOrigin == UNVALUED_LONG )
//    return false;
//
//  val = _imp->_PlaneOffsetOrigin;
//
//  return true;
// } // sb_Ldef::getPlaneOffsetOrigin


bool
sb_Ldef::getIntracellReferenceLocation( string& val ) const
{
  if ( _imp->_IntracellReferenceLocation == UNVALUED_STRING )
    return false;

  val = _imp->_IntracellReferenceLocation;

  return true;
} // sb_Ldef::getIntracellReferenceLocation


// bool
// sb_Ldef::getComment( string& val ) const
// {
//  if ( _imp->_Comment == UNVALUED_STRING )
//    return false;
//
//  val = _imp->_Comment;
//
//  return true;
// } // sb_Ldef::getComment


bool
sb_Ldef::getSchema( sio_8211Schema& schema ) const
{
  // If the schema hasn't been
  // initialized, please do so.

  if ( _schema.empty() )
  {
    _build_schema( _schema );
  }

  if ( _schema.empty() )   // oops ... something screwed up
  {
    return false;
  }

  schema = _schema;

  return true;

} // sb_Ldef::getSchema




bool
sb_Ldef::getRecord( sc_Record & record ) const
{
  record.clear();               // start with a clean slate

  // first field, which contains module name and record number

  record.push_back( sc_Field() );

  record.back().setMnemonic( "LDEF" );

  record.back().setName( "Layer Definition" );

  string tmp_str;
  long   tmp_long;

  getMnemonic( tmp_str );
  sb_Utils::add_subfield( record.back(), "MODN", tmp_str );
  sb_Utils::add_subfield( record.back(), "RCID", getID() );

  if ( getCellModuleName( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"CMNM", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "CMNM", sc_Subfield::is_A );
  }


  if ( getLayerLabel( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"LLBL", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "LLBL", sc_Subfield::is_A );
  }


  if ( getCellCode( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"CODE", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "CODE", sc_Subfield::is_A );
  }


//  if ( getBitmask( tmp_str ) )
//  {
//    sb_Utils::add_subfield( record.back(),"BMSK", tmp_str );
//  }
//  else
//  {
//    sb_Utils::add_empty_subfield( record.back(), "BMSK", sc_Subfield::is_C );
//  }


  if ( getNumberRows( tmp_long ) )
  {
    sb_Utils::add_subfield( record.back(),"NROW", tmp_long );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "NROW", sc_Subfield::is_I );
  }


  if ( getNumberColumns( tmp_long ) )
  {
    sb_Utils::add_subfield( record.back(),"NCOL", tmp_long );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "NCOL", sc_Subfield::is_I );
  }


//  if ( getNumberPlanes( tmp_long ) )
//  {
//    sb_Utils::add_subfield( record.back(),"NPLA", tmp_long );
//  }
//  else
//  {
//    sb_Utils::add_empty_subfield( record.back(), "NPLA", sc_Subfield::is_I );
//  }


  if ( getScanOriginRow( tmp_long ) )
  {
    sb_Utils::add_subfield( record.back(),"SORI", tmp_long );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "SORI", sc_Subfield::is_I );
  }


  if ( getScanOriginColumn( tmp_long ) )
  {
    sb_Utils::add_subfield( record.back(),"SOCI", tmp_long );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "SOCI", sc_Subfield::is_I );
  }


  // if ( getScanOriginPlane( tmp_long ) )
  // {
  //  sb_Utils::add_subfield( record.back(),"SOPI", tmp_long );
  // }
  // else
  // {
  //  sb_Utils::add_empty_subfield( record.back(), "SOPI", sc_Subfield::is_I );
  // }


  if ( getRowOffsetOrigin( tmp_long ) )
  {
    sb_Utils::add_subfield( record.back(),"RWOO", tmp_long );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "RWOO", sc_Subfield::is_I );
  }


  if ( getColumnOffsetOrigin( tmp_long ) )
  {
    sb_Utils::add_subfield( record.back(),"CLOO", tmp_long );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "CLOO", sc_Subfield::is_I );
  }


  // if ( getPlaneOffsetOrigin( tmp_long ) )
  // {
  //   sb_Utils::add_subfield( record.back(),"PLOO", tmp_long );
  // }
  // else
  // {
  //   sb_Utils::add_empty_subfield( record.back(), "PLOO", sc_Subfield::is_I );
  // }


  if ( getIntracellReferenceLocation( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"INTR", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "INTR", sc_Subfield::is_A );
  }


  // if ( getComment( tmp_str ) )
  // {
  //  sb_Utils::add_subfield( record.back(),"COMT", tmp_str );
  // }
  // else
  // {
  //   sb_Utils::add_empty_subfield( record.back(), "COMT", sc_Subfield::is_A );
  // }


  return true;


} // Ldef::getRecord




bool
sb_Ldef::setCellModuleName( string const& val )
{
  _imp->_CellModuleName = val;

  return true;
} // sb_Ldef::setCellModuleName


bool
sb_Ldef::setLayerLabel( string const& val )
{
  _imp->_LayerLabel = val;

  return true;
} // sb_Ldef::setLayerLabel


bool
sb_Ldef::setCellCode( string const& val )
{
  _imp->_CellCode = val;

  return true;
} // sb_Ldef::setCellCode


// bool
// sb_Ldef::setBitmask( string const& val )
// {
// _imp->_Bitmask = val;
//
//  return true;
// } // sb_Ldef::setBitmask


bool
sb_Ldef::setNumberRows( long val )
{
  _imp->_NumberRows = val;

  return true;
} // sb_Ldef::setNumberRows


bool
sb_Ldef::setNumberColumns( long val )
{
  _imp->_NumberColumns = val;

  return true;
} // sb_Ldef::setNumberColumns


// bool
// sb_Ldef::setNumberPlanes( long val )
// {
//  _imp->_NumberPlanes = val;
//
//  return true;
// } // sb_Ldef::setNumberPlanes


bool
sb_Ldef::setScanOriginRow( long val )
{
  _imp->_ScanOriginRow = val;

  return true;
} // sb_Ldef::setScanOriginRow


bool
sb_Ldef::setScanOriginColumn( long val )
{
  _imp->_ScanOriginColumn = val;

  return true;
} // sb_Ldef::setScanOriginColumn


// bool
// sb_Ldef::setScanOriginPlane( long val )
// {
//   _imp->_ScanOriginPlane = val;
//
//   return true;
// } // sb_Ldef::setScanOriginPlane


bool
sb_Ldef::setRowOffsetOrigin( long val )
{
  _imp->_RowOffsetOrigin = val;

  return true;
} // sb_Ldef::setRowOffsetOrigin


bool
sb_Ldef::setColumnOffsetOrigin( long val )
{
  _imp->_ColumnOffsetOrigin = val;

  return true;
} // sb_Ldef::setColumnOffsetOrigin


// bool
// sb_Ldef::setPlaneOffsetOrigin( long val )
// {
//  _imp->_PlaneOffsetOrigin = val;
//
//  return true;
// } // sb_Ldef::setPlaneOffsetOrigin


bool
sb_Ldef::setIntracellReferenceLocation( string const& val )
{
  _imp->_IntracellReferenceLocation = val;

  return true;
} // sb_Ldef::setIntracellReferenceLocation


// bool
// sb_Ldef::setComment( string const& val )
// {
//   _imp->_Comment = val;
//
//   return true;
// } // sb_Ldef::setComment


bool
sb_Ldef::setRecord( sc_Record const& record )
{
  return _ingest_record( *this, *_imp, record );
} // sb_Ldef::setRecord




void
sb_Ldef::unDefineCellModuleName( )
{
  _imp->_CellModuleName = UNVALUED_STRING;
} // sb_Ldef::unDefineCellModuleName


void
sb_Ldef::unDefineLayerLabel( )
{
  _imp->_LayerLabel = UNVALUED_STRING;
} // sb_Ldef::unDefineLayerLabel


void
sb_Ldef::unDefineCellCode( )
{
  _imp->_CellCode = UNVALUED_STRING;
} // sb_Ldef::unDefineCellCode


// void
// sb_Ldef::unDefineBitmask( )
// {
//  _imp->_Bitmask = UNVALUED_STRING;
// } // sb_Ldef::unDefineBitmask


void
sb_Ldef::unDefineNumberRows( )
{
  _imp->_NumberRows = UNVALUED_LONG;
} // sb_Ldef::unDefineNumberRows


void
sb_Ldef::unDefineNumberColumns( )
{
  _imp->_NumberColumns = UNVALUED_LONG;
} // sb_Ldef::unDefineNumberColumns


// void
// sb_Ldef::unDefineNumberPlanes( )
// {
//  _imp->_NumberPlanes = UNVALUED_LONG;
// } // sb_Ldef::unDefineNumberPlanes


void
sb_Ldef::unDefineScanOriginRow( )
{
  _imp->_ScanOriginRow = UNVALUED_LONG;
} // sb_Ldef::unDefineScanOriginRow


void
sb_Ldef::unDefineScanOriginColumn( )
{
  _imp->_ScanOriginColumn = UNVALUED_LONG;
} // sb_Ldef::unDefineScanOriginColumn


// void
// sb_Ldef::unDefineScanOriginPlane( )
// {
//   _imp->_ScanOriginPlane = UNVALUED_LONG;
// } // sb_Ldef::unDefineScanOriginPlane


void
sb_Ldef::unDefineRowOffsetOrigin( )
{
  _imp->_RowOffsetOrigin = UNVALUED_LONG;
} // sb_Ldef::unDefineRowOffsetOrigin


void
sb_Ldef::unDefineColumnOffsetOrigin( )
{
  _imp->_ColumnOffsetOrigin = UNVALUED_LONG;
} // sb_Ldef::unDefineColumnOffsetOrigin


// void
// sb_Ldef::unDefinePlaneOffsetOrigin( )
// {
//   _imp->_PlaneOffsetOrigin = UNVALUED_LONG;
// } // sb_Ldef::unDefinePlaneOffsetOrigin


void
sb_Ldef::unDefineIntracellReferenceLocation( )
{
  _imp->_IntracellReferenceLocation = UNVALUED_STRING;
} // sb_Ldef::unDefineIntracellReferenceLocation


// void
// sb_Ldef::unDefineComment( )
// {
//   _imp->_Comment = UNVALUED_STRING;
// } // sb_Ldef::unDefineComment


