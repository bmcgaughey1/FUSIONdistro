//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//

#ifdef WIN32
#pragma warning(disable: 4786)	// stupid warning that debug string exceeds 255
#endif

#include <string>

#include <cstring>

#ifdef _WIN32
#include <algorithm>
#include <functional>
using namespace std;
#else
#include <algo.h>
#include <function.h>
#endif

#ifndef INCLUDED_SB_UTILS_H
#include "builder/sb_Utils.h"
#endif


static const char* _ident = "$Id: sb_Utils.cpp,v 1.11 1998/09/01 22:10:16 mcoletti Exp $";


//
// Support Functions for sb_Utils 
//


// Generic utility things.
//
// XXX You better _believe_ this is temporary.

// This algorithm is used in find_if calls to locate fields
// or subfields that have a given mnemonic.

// Q.v., sc_Record:getRecordID() for an example of its use.

template< class T >
struct equalMnemonic : binary_function<T, const string, bool>
{
  bool operator()( const T& x, const string& y ) const
    { return x.getMnemonic() == y; }

};
// comparison class equalMnemonic

template< class T >
struct equalName : binary_function<T, const string, bool>
{
  bool operator()( const T& x, const string& y ) const
    { return x.getName() == y; }

};
// comparison class equalName

// This algorithm is used in find_if calls to locate modules with a 
// given module type.

template< class T >
struct equalModuleType : binary_function<T, const string, bool>
{
  bool operator()( const T& x, const string& y ) const
    { return x.getModuleType() == y; }

}; 
// comparison class equalModuleType

/*
 * Implimentation of the sb_Utils functions.
 */

bool
sb_Utils::getFieldByMnem(sc_Record const& rec,
                         string const& mnemonic,
                         sc_Record::const_iterator& thefield)
{
  list<sc_Field> const& fields = rec; // ->getFields();
  thefield = find_if(fields.begin(),fields.end(),
                     bind2nd(equalMnemonic<sc_Field>(), mnemonic));
  if (thefield != fields.end())
    return true;

  return false;
}

bool
sb_Utils::getSubfieldByMnem(sc_Field const& field,
                            string const& mnemonic,
                            sc_Field::const_iterator& thesubf)
{
  list<sc_Subfield> const& subfields = field; // .getSubfields();
  thesubf = find_if(subfields.begin(),subfields.end(),
                    bind2nd(equalMnemonic<sc_Subfield>(), mnemonic));
  if (thesubf != subfields.end())
    return true;

  return false;
}

bool
sb_Utils::getSubfieldByName(sc_Field const& field,
                            string const& name,
                            sc_Field::const_iterator& thesubf)
{
  list<sc_Subfield> const& subfields = field; // .getSubfields();
  thesubf = find_if(subfields.begin(),subfields.end(),
                    bind2nd(equalName<sc_Subfield>(), name));
  if (thesubf != subfields.end())
    return true;

  return false;
}

// Tries to convert a subfield into a double.
// If it succeeds returns True, else False.
// Place the convert value into the dataTo passed in parameter
bool
sb_Utils::getDoubleFromSubfield(sc_SubfieldCntr::const_iterator const& subf, //sc_Subfield const& subf,
                                double& dataOut )
{

  bool rc;
  unsigned long tempULong;
  long tempLong;
  sc_Subfield::SubfieldType sType = subf->getSubfieldType();

  switch(sType) {

    // Not supported at this time.
    // convert string class to double
  case(sc_Subfield::is_A):
  case(sc_Subfield::is_C):
    return false;
    break;

    // convert long to double
  case(sc_Subfield::is_I):
    rc = subf->getI( tempLong );
    dataOut = double(tempLong);
    break;
  case(sc_Subfield::is_BI8):
    rc = subf->getBI8( tempLong );
    dataOut = double(tempLong);
    break;
  case(sc_Subfield::is_BI16):
    rc = subf->getBI16( tempLong );
    dataOut = double(tempLong);
    break;
  case(sc_Subfield::is_BI24):
    rc = subf->getBI24( tempLong );
    dataOut = double(tempLong);
    break;
  case(sc_Subfield::is_BI32):
    rc = subf->getBI32( tempLong );
    dataOut = double(tempLong);
    break;

    // Convert unsigned long to double
  case(sc_Subfield::is_BUI8):
    rc = subf->getBUI8( tempULong );
    dataOut = double(tempULong );
    break;
  case(sc_Subfield::is_BUI16):
    rc = subf->getBUI16( tempULong );
    dataOut = double(tempULong );
    break;
  case(sc_Subfield::is_BUI24):
    rc = subf->getBUI24( tempULong );
    dataOut = double(tempULong );
    break;
  case(sc_Subfield::is_BUI32):
    rc = subf->getBUI32( tempULong );
    dataOut = double(tempULong );
    break;

    //convert double to double
  case(sc_Subfield::is_R):
    rc = subf->getR( dataOut );
    break;
  case(sc_Subfield::is_S):
    rc = subf->getS( dataOut );
    break;

    // non-implimented return false
  case(sc_Subfield::is_B):
  case(sc_Subfield::is_BUI):
  case(sc_Subfield::is_BFP32):
  case(sc_Subfield::is_BFP64):
    rc = false;
    break;
		
    // Shouldn't get here, except in an error situation
  default:
    rc = false;
  }

  return rc;


}
/* Numberic -> optionalSign Digits FrationalPart ExponentPart
 */
/*
 *
 *  <number>    ->  [ <sign> ] <digit> { <digit> } [ <deciaml> ] [ <exponent> ]
 *
 *  <sign>       ->  '+' | '-'
 *
 *  <decimal>   ->  '.' { <digit> }
 *
 *  <exponent>  ->  'E' [ <sign> ] <digit> { <digit> }
 *
 *  <digits>    ->  1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 0
 *
 */

// bool String2double(sc_SubfieldCntr::const_iterator const& subf, double &dataOut );

inline
bool
String2double( sc_SubfieldCntr::const_iterator const& subf,
               double &dataOut )
{
  sc_Subfield::SubfieldType sType = subf->getSubfieldType();
  string tempString;
  bool rc;
  switch(sType){
  case(sc_Subfield::is_A):
    rc = subf->getA( tempString );
    break;
  case(sc_Subfield::is_C):
    rc = subf->getC( tempString );
    break;
  default:
    // Error!
    // Illegal subfield type passed to function.
    return false;
  }
  if ( rc == false ) // get on subfield failed pass it on.
    return false;
  // Verfiy string is only digits,
  // convert
  return true;
}




/// XXX Should sc_Field have an addSubfield that does this instead?
void
sb_Utils::add_subfield( sc_Field& field, 
                        string const& mnemonic,
                        string const& value ) 
{ field.push_back( sc_Subfield() );

 field.back().setMnemonic( mnemonic );
 field.back().setA( value );
} // add_subfield



void
sb_Utils::add_subfield( sc_Field& field, string const& mnemonic, int value )
{
  field.push_back( sc_Subfield() );

  field.back().setMnemonic( mnemonic );
  field.back().setI( (long) value );
} // add_subfield



void
sb_Utils::add_subfield( sc_Field& field, string const& mnemonic, long value )
{
  field.push_back( sc_Subfield() );

  field.back().setMnemonic( mnemonic );
  field.back().setI( value );
} // add_subfield



void
sb_Utils::add_subfield( sc_Field& field, string const& mnemonic, double value )
{
  field.push_back( sc_Subfield() );

  field.back().setMnemonic( mnemonic );
  field.back().setR( value );
} // add_subfield




void
sb_Utils::add_empty_subfield( sc_Field& field, 
			       string const& mnemonic,
			       sc_Subfield::SubfieldType type )
{
  field.push_back( sc_Subfield() );

  field.back().setMnemonic( mnemonic );

				// XXX this switch statement could be
				// XXX eliminated if the setUnvalued()
				// XXX took a type parameter, or was
				// XXX defined for each subfield type
  switch ( type )
  {
  case sc_Subfield::is_A :
    field.back().setA( "" );
    break;
  case sc_Subfield::is_I :
    field.back().setI( (long) 0 );
    break;
  case sc_Subfield::is_R :
    field.back().setR( 0.0 );
    break;
  case sc_Subfield::is_S :
    field.back().setS( 0.0 );
    break;
  default :
    // non of the other fields can be variable, so this function is irrelevent
    // (or they're inherently bogus, like the 'C' type subfields
    break;
  }

  field.back().setUnvalued();	// explicitly state that it ain't got nothin'

} // add_subfield





bool
sb_Utils::valid_domain( string const & str, string const & values )
{
  if ( str.length() != 1 ) return false; // single character comparison only

  if ( strpbrk( str.c_str(), values.c_str() ) == NULL )
    return false;

  return true;
} // valid_domain




// XXX These two could probably be made a template function of some sort.

bool
sb_Utils::valid_domain( long val, set<long> const & domain_values )
{
  set<long> tmp_set;
  tmp_set.insert( val );
  return includes( domain_values.begin(), domain_values.end(),
                   tmp_set.begin(), tmp_set.end() );
} // valid_domain






bool
sb_Utils::valid_domain( string const& val, set<string> const & domain_values )
{
  set<string> tmp_set;
  tmp_set.insert( val );
  return includes( domain_values.begin(), domain_values.end(),
                   tmp_set.begin(), tmp_set.end() );
} // valid_domain



