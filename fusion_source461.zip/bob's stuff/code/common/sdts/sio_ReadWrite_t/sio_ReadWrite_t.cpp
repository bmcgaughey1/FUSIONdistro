//
// sio_ReadWrite.cpp
//

#include <iostream>
#include <fstream>

#include <cstdlib>

#ifdef WIN32
#include "sio_ReadWrite_t/getopt.h"
#endif

#include "io/sio_Reader.h"
#include "io/sio_Writer.h"
#include "io/sio_8211Converter.h"



#include "container/sc_Record.h"
#include "container/sc_Field.h"
#include "container/sc_Subfield.h"

#ifdef WIN32
using namespace std;
#endif


static const char* _ident = "$Id: sio_ReadWrite_t.cpp,v 1.16 1998/09/01 22:38:57 mcoletti Exp $";






void
usage( const char * name )
{
  cerr << name << ": [flags] -i in_8211_file -o out_8211_file\n"
       << "  flags:\n"
       << "\t-v\tverbose\n"
       << "\t-r\treuse 8211 leaders and directories\n"
       << "\t-s mnemonic -b (b(u)?i(8|16|24|32))|(bfp(32|64))\n"
       << "\t\tassign binary converter to subfield mnemonic\n";
} // usage()




sio_8211Converter_BI8   converter_bi8;
sio_8211Converter_BI16  converter_bi16;
sio_8211Converter_BI24  converter_bi24;
sio_8211Converter_BI32  converter_bi32;
sio_8211Converter_BUI8  converter_bui8;
sio_8211Converter_BUI16 converter_bui16;
sio_8211Converter_BUI24 converter_bui24;
sio_8211Converter_BUI32 converter_bui32;
sio_8211Converter_BFP32 converter_bfp32;
sio_8211Converter_BFP64 converter_bfp64;




void
dump_converter_dictionary( converter_dictionary const & cd )
{
  if ( ! cd.empty() )
  {
    cout << "converter dictionary:\n";
  }


  for ( converter_dictionary::const_iterator i = cd.begin();
        i != cd.end();
        i++ )
  {
    cout << "\t" << (*i).first << " : ";

    if ( &converter_bi8 == (*i).second)
    {
      cout << "BI8\n";
    }
    else if ( &converter_bi16 == (*i).second)
    {
      cout << "BI16\n";
    }
    else if ( &converter_bi24 == (*i).second)
    {
      cout << "BI24\n";
    }
    else if ( &converter_bi32 == (*i).second)
    {
      cout << "BI32\n";
    }
    else if ( &converter_bui8 == (*i).second)
    {
      cout << "BUI8\n";
    }
    else if ( &converter_bui16 == (*i).second)
    {
      cout << "BUI16\n";
    }
    else if ( &converter_bui24 == (*i).second)
    {
      cout << "BUI24\n";
    }
    else if ( &converter_bui32 == (*i).second)
    {
      cout << "BUI32\n";
    }
    else if ( &converter_bfp32 == (*i).second)
    {
      cout << "BFP32\n";
    }
    else if ( &converter_bfp64 == (*i).second)
    {
      cout << "BFP64\n";
    }
    else
      cout << "unknown\n";

  }

} // dump_converter_dictionary




void
assign_converter( converter_dictionary & cd,
                  string const & mnemonic, 
                  string const & converter_type )
{
  if ( mnemonic.empty() )
  {
    cerr << "binary type without a subfield\n";
  }

  if ( 'b' == converter_type[0] ) // is binary
  {
    if ( 'i' == converter_type[1] ) // signed
    {
      switch( converter_type[2] )
      {
      case '8' :
        cd[mnemonic] = &converter_bi8;
        break;
      case '1' :
        cd[mnemonic] = &converter_bi16;
        break;
      case '2' :
        cd[mnemonic] = &converter_bi24;
        break;
      case '3' :
        cd[mnemonic] = &converter_bi32;
        break;
      default :
        cerr << converter_type << " unknown binary type\n";
        exit(-9);
      }
      return;
    }
    else if ( 'u' == converter_type[1] && // unsigned
              'i' == converter_type[2] )
    {
      switch( converter_type[3] )
      {
      case '8' :
        cd[mnemonic] = &converter_bui8;
        break;
      case '1' :
        cd[mnemonic] = &converter_bui16;
        break;
      case '2' :
        cd[mnemonic] = &converter_bui24;
        break;
      case '3' :
        cd[mnemonic] = &converter_bui32;
        break;
      default :
        cerr << converter_type << " unknown binary type\n";
        exit(-9);
      }
      return;
    }
    else if ( 'f' == converter_type[1] && // floating point
              'p' == converter_type[2] )
    {
      switch( converter_type[3] )
      {
      case '6' :
        cd[mnemonic] = &converter_bfp64;
        break;
      case '3' :
        cd[mnemonic] = &converter_bfp32;
        break;
      default :
        cerr << converter_type << " unknown binary type\n";
        exit(-9);
      }
      return;
    }
  }

  cerr << converter_type << " unknown binary type\n";

  exit(-9);

} // assign_converter



bool verbose = false;


int
main( int argc, char** argv )
{

#ifndef WIN32
  extern char *optarg;
  extern int   optind;
#endif

  bool         reuse_flag = false;
  string       subfield_mnemonic;

  ifstream     iddf;
  ofstream     oddf;

  string       infile;
  char*        outfile;

  converter_dictionary converters;

                                // set up some reasonable defaults

  converters["ELEVATION"] = &converter_bi16;
  converters["X"]         = &converter_bi32;
  converters["Y"]         = &converter_bi32;

  string last_mnemonic;

  int ch;

  while ((ch = getopt(argc, argv, "rvi:o:s:b:")) != EOF)
    switch(ch) 
    {
    case 'r':
      reuse_flag = true;	// reuse directories
      break;

    case 'v':
      verbose = true;		// verbose output
      break;

    case 'i':
      infile = optarg;
#ifdef WIN32
      iddf.open( optarg, ios::binary );
#else
      iddf.open( optarg );
#endif
      if ( ! iddf )
      {
	cerr << "couldn't open " << optarg << "\n";
	return -2;
      }
      break;

    case 'o':
      outfile = optarg;
#ifdef WIN32
      oddf.open( optarg, ios::binary );
#else
      oddf.open( optarg );
#endif
      if ( ! oddf )
      {
	cerr << "couldn't open " << optarg << "\n";
	return -3;
      }
      break;

    case 's' :
      converters[optarg] = 0x0;	// initialize it to null
      last_mnemonic = optarg;   // save the mnemonic
      break;

    case 'b' :
      assign_converter( converters, last_mnemonic, optarg );
      break;
  
    case '?':
    default:
      usage( argv[0] );
      return -4;
    }

//   argc -= optind;
//   argv += optind;

  if ( infile.empty() || 0 == outfile )
    {
      usage( argv[0] );
      exit(-5);
    }


  sio_8211Reader  reader( iddf, &converters );
  sio_8211ForwardIterator i ( reader );

  sio_8211Schema const& schema = reader.getSchema();
  sio_8211Writer writer( oddf, outfile, schema );

  writer.emitDDR();             // blat out the DDR based on the file name and
                                // schema information

  sc_Record record;


  int records = 0;


  if ( verbose )
  {
    dump_converter_dictionary( converters );
  }

  if ( reuse_flag )
  {
    writer.reuseLeaderAndDirectory(); // use dropped leaders and directories
  }


  while ( i )
    {
      i.get( record );

      if ( verbose )
	{
	  cout << record << "\n";
	}

      writer.put( record );

      ++i;
      ++records;
    }


  iddf.close();
  oddf.close();

  cout << "wrote " << records << " record(s) to " << outfile << "\n";

  return 0;
}
