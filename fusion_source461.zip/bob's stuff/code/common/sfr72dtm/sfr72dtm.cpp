// sfr72dtm.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#define	PROGRAM_VERSION		1.0

#define	TRUE				1
#define	FALSE				0

#define	NONE				0
#define	UTM					1
#define	SP					2

#define	FEET				0
#define	METERS				1
#define	OTHER				2

#define	FEETTOMETERS	0.3048
#define	METERSTOFEET	3.280839895

#define	SURFER7				1
#define	SURFER6BIN			2
#define	SURFER6ASC			3
#define	INVALID				0

#define	HEADER_SECTION		0x42525344
#define	GRID_SECTION		0x44495247
#define	DATA_SECTION		0x41544144
#define	FAULTINFO_SECTION	0x49544c46

typedef int MYlong;

typedef struct {
	MYlong		Id;
	MYlong		Size;
} S7TAG;

typedef struct {
	MYlong		Version;
} S7HEADER;

typedef struct {
	MYlong		nRow;
	MYlong		nCol;
	double		xLL;
	double		yLL;
	double		xSize;
	double		ySize;
	double		zMin;
	double		zMax;
	double		Rotation;
	double		BlankValue;
} S7GRID;


typedef struct {
	char signature[21];
	char name[61];
	float version;
	double origin_x;
	double origin_y;
	double min_z;
	double max_z;
	double rotation;
	double column_spacing;
	double point_spacing;
	long columns;
	long points;
	short xy_units;
	short z_units;
	short z_bytes;
	short coord_sys;
	short coord_zone;
} BIN_HEADER;

void print_status_message(char *message);
void print_error_message(char *message);
void print_debug_message(char *message);
void print_status_summary(void);
void initialize_program(void);
int bad_command_line(int argc, char *argv[]);
void usage(void);
void quit_program(int exit_flag);
void cleanup(double** data);
int read_data(int format, double** data, FILE* infile);
void set_header_values(void);
int read_grid_description(int format, FILE* infile);
int detect_format(void);
int verify_disk_space(BIN_HEADER *bin);
int write_dest_header(BIN_HEADER *bin, FILE* file);
void set_conversion_factors(void);

char		source_dtm[_MAX_PATH];		// source file name
char		dest_dtm[_MAX_PATH];		// destination file name
int			dbg_messages;				// flag to control output of debugging messages
int			quiet;						// flag to control status messages to screen

S7TAG		tag;
S7HEADER	header;
S7GRID		grid;

BIN_HEADER	planshdr;

long		dataoffset;					// used for ASCII format to mark start of grid data

int			xyunits;
int			zunits;
int			coord_sys;
int			coord_zone;

int			out_xyunits;
int			out_zunits;

double		xyfactor;
double		zfactor;

int main(int argc, char* argv[])
{
	FILE* infile;
	char ts[256];

	// initialize
	initialize_program();

	// check command line
	if (bad_command_line(argc, argv))
		usage();

	// print opening message
	sprintf(ts, "\nSurfer GRD Import Utility -- Version %.2lf\n\n", PROGRAM_VERSION);
	print_status_message(ts);

	// set up unit conversion multipliers
	set_conversion_factors();

	// try to read surfer header to determine format
	int format = detect_format();
	if (format != INVALID) {
		// have valid surfer file
		// open input file
		if (format == SURFER7 || format == SURFER6BIN)
			infile = fopen(source_dtm, "rb");
		else
			infile = fopen(source_dtm, "rt");

		// read grid description
		if (!read_grid_description(format, infile)) {
			fclose(infile);
			print_error_message("Could not read source grid information");
			quit_program(1);
		}

		// fill out PLANS header
		set_header_values();

		// check for disk space for destination file
		if (!verify_disk_space(&planshdr)) {
			fclose(infile);
			print_error_message("Not enough disk space for destination file");
			quit_program(1);
		}

		print_status_summary();

		// have grid description, file is ready to read grid data
		// for new format, we should be poistioned just after the GRID section so next tag should be DATA

		// allocate space for entire grid
		double** data = new double* [grid.nRow];

		if (data) {
			for (int i = 0; i < grid.nRow; i ++) {
				data[i] = new double [grid.nCol];
				if (!data[i]) {
					for (int j = i - 1; j >= 0; j --)
						delete [] data[j];
					delete [] data;
					data = NULL;
					break;
				}
			}
		}
		
		if (!data) {
			fclose(infile);
			print_error_message("Could not allocate memory for source grid data");
			quit_program(1);
		}

		// read all elevations
		if (!read_data(format, data, infile)) {
			fclose(infile);
			cleanup(data);
			print_error_message("Could not read source grid data");
			quit_program(1);
		}

		// write PLANS model
		FILE* outfile = fopen(dest_dtm, "wb");
		if (!outfile) {
			fclose(infile);
			cleanup(data);
			print_error_message("Could not create destination dtm file");
			quit_program(1);
		}

		// write header
		write_dest_header(&planshdr, outfile);

		// write data...convert elevation data on the fly
		float felev;
		for (int j = 0; j < grid.nCol; j ++) {
			for (int i = 0; i < grid.nRow; i ++) {
				if (data[i][j] < grid.BlankValue)
					felev = (float) (data[i][j] * zfactor);
				else
					felev = -32767.0;
				fwrite(&felev, sizeof(float), 1, outfile);
			}
		}
		fclose(outfile);

		// clean up
		cleanup(data);
	}
	else {
		print_error_message("Source file does not appear to be a SURFER model");
		print_error_message("SFR2DTM recognizes SURFER V6 ASCII and binary and V7 binary formats");
		quit_program(1);
	}

	print_status_message("Done!\n");
	quit_program(0);
	return(0);
}

int write_dest_header(BIN_HEADER *bin, FILE* file)
{
	int noitems = 0;

	noitems += fwrite(&bin->signature, sizeof(char), 21, file);
	noitems += fwrite(&bin->name, sizeof(char), 61, file);
	noitems += fwrite(&bin->version, sizeof(float), 1, file);
	noitems += fwrite(&bin->origin_x, sizeof(double), 1, file);
	noitems += fwrite(&bin->origin_y, sizeof(double), 1, file);
	noitems += fwrite(&bin->min_z, sizeof(double), 1, file);
	noitems += fwrite(&bin->max_z, sizeof(double), 1, file);
	noitems += fwrite(&bin->rotation, sizeof(double), 1, file);
	noitems += fwrite(&bin->column_spacing, sizeof(double), 1, file);
	noitems += fwrite(&bin->point_spacing, sizeof(double), 1, file);
	noitems += fwrite(&bin->columns, sizeof(long), 1, file);
	noitems += fwrite(&bin->points, sizeof(long), 1, file);
	noitems += fwrite(&bin->xy_units, sizeof(short), 1, file);
	noitems += fwrite(&bin->z_units, sizeof(short), 1, file);
	noitems += fwrite(&bin->z_bytes, sizeof(short), 1, file);
	noitems += fwrite(&bin->coord_sys, sizeof(short), 1, file);
	noitems += fwrite(&bin->coord_zone, sizeof(short), 1, file);

	if (noitems != 97) {
		return(FALSE);
	}

	fseek(file, 200, SEEK_SET);

	return(TRUE);
}

void set_conversion_factors(void)
{
	xyfactor = 1.0;
	zfactor = 1.0;

	if (xyunits == FEET && out_xyunits == METERS)
		xyfactor = FEETTOMETERS;
	else if (xyunits == METERS && out_xyunits == FEET)
		xyfactor = METERSTOFEET;
	else
		xyfactor = 1.0;

	if (zunits == FEET && out_zunits == METERS)
		zfactor = FEETTOMETERS;
	else if (zunits == METERS && out_zunits == FEET)
		zfactor = METERSTOFEET;
	else
		zfactor = 1.0;
}

void cleanup(double** data)
{
	for (int i = 0; i < grid.nRow; i ++)
		delete [] data[i];
	delete [] data;
}

int read_data(int format, double** data, FILE* infile)
{
	int retcode = FALSE;
	int cnt = 0;
	if (format == SURFER7) {
		// look for data tag
		while (fread(&tag, sizeof(S7TAG), 1, infile) == 1) {
			if (tag.Id == DATA_SECTION) {
				for (int i = 0; i < grid.nRow; i ++)
					cnt += fread(data[i], sizeof(double), grid.nCol, infile);

				if (cnt == grid.nCol * grid.nRow)
					retcode = TRUE;

				break;
			}
			else {
				fseek(infile, tag.Size, SEEK_CUR);
			}
		}
	}
	else if (format == SURFER6BIN) {
		float elev;
		for (int i = 0; i < grid.nRow; i ++) {
			for (int j = 0; j < grid.nCol; j ++) {
				cnt += fread(&elev, sizeof(float), 1, infile);
				data[i][j] = (double) elev;
			}
		}

		if (cnt == grid.nCol * grid.nRow)
			retcode = TRUE;
	}
	else if (format == SURFER6ASC) {
		for (int i = 0; i < grid.nRow; i ++) {
			for (int j = 0; j < grid.nCol; j ++) {
				cnt += fscanf(infile, "%lf ", &data[i][j]);
			}
		}

		if (cnt == grid.nCol * grid.nRow)
			retcode = TRUE;
	}
	return(retcode);
}

void set_header_values(void)
{
	strcpy(planshdr.signature, "PLANS-PC BINARY .DTM");
	strncpy(planshdr.name, source_dtm, 60);
	planshdr.version = 3.0;
	planshdr.origin_x = grid.xLL * xyfactor;
	planshdr.origin_y = grid.yLL * xyfactor;
	planshdr.min_z = grid.zMin * zfactor;
	planshdr.max_z = grid.zMax * zfactor;
	planshdr.rotation = grid.Rotation;
	planshdr.column_spacing = grid.xSize * xyfactor;
	planshdr.point_spacing = grid.ySize * xyfactor;
	planshdr.columns = grid.nCol;
	planshdr.points = grid.nRow;
	planshdr.xy_units = out_xyunits;
	planshdr.z_bytes = 2;
	planshdr.z_units = out_zunits;
	planshdr.coord_sys = coord_sys;
	planshdr.coord_zone = coord_zone;

	// if no coordinate system and zone, set format to 1.0 to indicate no coord sys info in PLANS DTM
//	if (coord_sys == 0 && coord_zone == 0)
//		planshdr.version = 1.0;
}

int read_grid_description(int format, FILE* infile)
{
	int retcode = FALSE;
	short sval;
	double dval;
	char tstr[32];
	int cnt = 0;

	rewind(infile);
	if (format == SURFER7) {
		// look for grid tag
		while (fread(&tag, sizeof(S7TAG), 1, infile) == 1) {
			if (tag.Id == GRID_SECTION) {
				fread(&grid, sizeof(S7GRID), 1, infile);
				retcode = TRUE;
				break;
			}
			else {
				fseek(infile, tag.Size, SEEK_CUR);
			}
		}
	}
	else if (format == SURFER6BIN) {
		fseek(infile, 4, SEEK_SET);
		cnt += fread(&sval, sizeof(short), 1, infile);
		grid.nCol = sval;
		cnt += fread(&sval, sizeof(short), 1, infile);
		grid.nRow = sval;
		cnt += fread(&grid.xLL, sizeof(double), 1, infile);
		cnt += fread(&dval, sizeof(double), 1, infile);
		grid.xSize = (dval - grid.xLL) / (double) (grid.nCol - 1);
		cnt += fread(&grid.yLL, sizeof(double), 1, infile);
		cnt += fread(&dval, sizeof(double), 1, infile);
		grid.ySize = (dval - grid.yLL) / (double) (grid.nRow - 1);
		cnt += fread(&grid.zMin, sizeof(double), 1, infile);
		cnt += fread(&grid.zMax, sizeof(double), 1, infile);
		grid.BlankValue = 1.70141e+38f;

		if (cnt == 8)
			retcode = TRUE;
	}
	else if (format == SURFER6ASC) {
		cnt += fscanf(infile, "%s ", tstr);
		cnt += fscanf(infile, "%i %i ", &grid.nCol, &grid.nRow);
		cnt += fscanf(infile, "%lf %lf ", &grid.xLL, &dval);
		grid.xSize = (dval - grid.xLL) / (double) (grid.nCol - 1);
		cnt += fscanf(infile, "%lf %lf ", &grid.yLL, &dval);
		grid.ySize = (dval - grid.yLL) / (double) (grid.nRow - 1);
		cnt += fscanf(infile, "%lf %lf ", &grid.zMin, &grid.zMax);
		grid.BlankValue = 1.70141e+38f;

		if (cnt == 9) {
			dataoffset = ftell(infile);
			retcode = TRUE;
		}
	}
	return(retcode);
}

int detect_format(void)
{
	char tstr[5];

	FILE* f = fopen(source_dtm, "rb");
	if (f) {
		// try to read 4-byte long and check for header signature
		if (fread(&tag, sizeof(S7TAG), 1, f) != 1) {
			fclose(f);
			return(INVALID);
		}
		else {
			if (tag.Id == HEADER_SECTION) {
				// read header and verify version
				if (fread(&header, sizeof(S7HEADER), 1, f) != 1) {
					fclose(f);
					return(INVALID);
				}
				else {
					if (header.Version == 1) {
						fclose(f);
						return(SURFER7);
					}
					else {
						fclose(f);
						return(INVALID);
					}
				}
			}
		}
		rewind(f);

		// read first 4 bytes from input file
		if (fread(tstr, sizeof(char), 4, f) != 4) {
			fclose(f);
			return(INVALID);
		}
		else {
			tstr[4] = '\0';
			if (strcmp(tstr, "DSAA") == 0) {
				fclose(f);
				return(SURFER6ASC);
			}
			else if (strcmp(tstr, "DSBB") == 0) {
				fclose(f);
				return(SURFER6BIN);
			}
		}
		fclose(f);
	}
	return(INVALID);
}

//==========================================================================
//==========================================================================

int verify_disk_space(BIN_HEADER *bin)
{
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	char dest_copy[144];
	char path[_MAX_PATH];
	unsigned long avail_clusters, sectors_per_cluster, bytes_per_sector, total_clusters;
	double required_space;
	double avail_space;

	strcpy(dest_copy, dest_dtm);

	_splitpath(dest_copy, drive, dir, fname, ext);
	sprintf(path, "%s%s", drive, dir);

//	GetDiskFreeSpace(path, &sectors_per_cluster, &bytes_per_sector, &avail_clusters, &total_clusters);
	GetDiskFreeSpace(NULL, &sectors_per_cluster, &bytes_per_sector, &avail_clusters, &total_clusters);
	avail_space = (double) avail_clusters * (double) sectors_per_cluster * (double) bytes_per_sector;

	required_space = (double) (bin->columns * bin->points);
	switch (bin->z_bytes) {
		case 0:
			required_space += required_space;
			break;
		case 1:
			required_space = required_space * 4.0;
			break;
		case 2:
			required_space = required_space * 6.0;
			break;
		case 3:
			required_space = required_space * 8.0;
			break;
	}

	required_space += 200.0;           /* add the header */

	if (required_space <= avail_space)
		return(TRUE);

	return(FALSE);
}

void print_status_summary(void)
{
	char ts[144];

	sprintf(ts, "Source Surfer GRD file: %s\n", source_dtm);
	print_status_message(ts);
	sprintf(ts, "Destination DTM file: %s\n", dest_dtm);
	print_status_message(ts);
	sprintf(ts, "Model grid is %i rows and %i columns\n", grid.nRow, grid.nCol);
	print_status_message(ts);
}

void print_status_message(char *message)
{
	if (!quiet)
		fprintf(stdout, "%s", message);
}

void print_debug_message(char *message)
{
	if (dbg_messages)
		fprintf(stdout, "%s\n", message);
}

void print_error_message(char *message)
{
	fprintf(stdout, "ERROR: %s\n", message);
}

void usage(void)
{
	fprintf(stdout, "SFR2DTM usage:\n");
	fprintf(stdout, "   SFR2DTM source dest xyunits zunits [/Scoordsys /Zzone /Punits /Eunits /Q /H]\n");
	fprintf(stdout, "   source   name of source SURFER GRD data file\n");
	fprintf(stdout, "   dest     name of reformatted PLANS DTM data file\n");
	fprintf(stdout, "   xyunits  units in source file for XY data (F=feet, M=meters)\n");
	fprintf(stdout, "   zunits   units in source file for elevation data (F=feet, M=meters)\n");
	fprintf(stdout, "   /Ssys    coordinate system (UTM or SP)\n");
	fprintf(stdout, "   /Zzone   coordinate system zone\n");
	fprintf(stdout, "   /Punits  units for XY data in output DTM\n");
	fprintf(stdout, "   /Eunits  units for elevation data in output DTM\n");
	fprintf(stdout, "   /Q       suppress all output to the screen\n");
	fprintf(stdout, "Example command line:\n");
	fprintf(stdout, "   SFR2DTM helens2.grd helens.dtm f f /sutm /z10\n");
	fprintf(stdout, "Notes:\n");
	fprintf(stdout, "   - source and destination file names must be different\n");
	fprintf(stdout, "   - existing destination file will be overwritten\n");

	quit_program(1);
}

void quit_program(int exit_arg)
{
	exit(exit_arg);
}

void initialize_program(void)
{
	dbg_messages = TRUE;
	quiet = FALSE;

	xyunits = FEET;
	zunits = FEET;
	coord_sys = 0;
	coord_zone = 0;
	out_xyunits = FEET;
	out_zunits = FEET;

	xyfactor = 1.0;
	zfactor = 1.0;
}

//==========================================================================

int bad_command_line(int argc, char *argv[])
{
	//*************************************************************************
	//*
	//*  function name:		bad_command_line()
	//*
	//*  description:		Validates command line parameters.  Expects a minimum
	//*					of 4 parameters...source and destination file names.
	//*
	//*  return value:	Returns 0 if command line is OK, 1 otherwise.
	//*
	//*************************************************************************

	int i;
	int err = 0;
	char ts[256];
	char *c;

	if (argc < 5)
		return(1);

	// read source and destination file names
	strcpy(source_dtm, argv[1]);
	strcpy(dest_dtm, argv[2]);

	// replace quotation marks
	if (argv[1][0] == '\"')
		strcpy(source_dtm, &argv[1][1]);

	if (argv[2][0] == '\"')
		strcpy(dest_dtm, &argv[2][1]);

	c = source_dtm;
	while (*c != '\0') {
		if (*c == '\"')
			*c = ' ';
		c ++;
	}

	c = dest_dtm;
	while (*c != '\0') {
		if (*c == '\"')
			*c = ' ';
		c ++;
	}

	strlwr(source_dtm);
	strlwr(dest_dtm);

	// check for existence of source file
	if (access(source_dtm, 0)) {
		sprintf(ts, "Source file not found: %s", source_dtm);
		print_error_message(ts);
		err = 1;
	}
	else {		// can the file be opened for read?
		if (access(source_dtm, 4)) {
			sprintf(ts, "Source file found but not available for read access.\n Source file: %s", source_dtm);
			print_error_message(ts);
			err = 1;
		}
	}

	// destination and source cannot be the same...
	if (!strcmp(source_dtm, dest_dtm)) {
		print_error_message("Source file name and destination file name cannot be the same");
		err = 1;
	}

	// read units for xy
	if (argv[3][0] == 'f' || argv[3][0] == 'F')
		xyunits = FEET;
	else if (argv[3][0] == 'm' || argv[3][0] == 'M')
		xyunits = METERS;
	else {
		print_error_message("Invalid units for planimetric measurements");
		err = 1;
	}

	// elevation
	if (argv[4][0] == 'f' || argv[4][0] == 'F')
		zunits = FEET;
	else if (argv[4][0] == 'm' || argv[4][0] == 'M')
		zunits = METERS;
	else {
		print_error_message("Invalid units for elevations");
		err = 1;
	}

	// process command line parameters
	for (i = 5; i < argc; i ++) {
		if (argv[i][0] == '-' || argv[i][0] == '/') {
			switch (argv[i][1]) {
				case 'q':			// quiet mode...no screen output...except errors
				case 'Q':
					quiet = TRUE;
					break;
				case 's':
				case 'S':
					strupr(argv[i]);
					if (argv[i][2] == 'U')
						coord_sys = UTM;
					else if (argv[i][2] == 'S')
						coord_sys = SP;
					else {
						sprintf(ts, "Bad command line argument: %s", argv[i]);
						print_error_message(ts);
						err = 1;
					}
					break;
				case 'e':
				case 'E':
					strupr(argv[i]);
					if (argv[i][2] == 'F')
						out_zunits = FEET;
					else if (argv[i][2] == 'M')
						out_zunits = METERS;
					else {
						sprintf(ts, "Bad command line argument: %s", argv[i]);
						print_error_message(ts);
						err = 1;
					}
					break;
				case 'p':
				case 'P':
					strupr(argv[i]);
					if (argv[i][2] == 'F')
						out_xyunits = FEET;
					else if (argv[i][2] == 'M')
						out_xyunits = METERS;
					else {
						sprintf(ts, "Bad command line argument: %s", argv[i]);
						print_error_message(ts);
						err = 1;
					}
					break;
				case 'z':
				case 'Z':
					coord_zone = atoi(&argv[i][2]);
					break;
				case '?':			// help
				case 'h':
				case 'H':
					err = 1;
					break;
				default:
					sprintf(ts, "Bad command line argument: %s", argv[i]);
					print_error_message(ts);
					err = 1;
					break;
			}
		}
		else {
			print_error_message("Bad command line");
			err = 1;
		}
	}

	// check for existence of destination file
	if (!access(dest_dtm, 0)) {
		sprintf(ts, "Destination file will be overwritten: %s\n\n", dest_dtm);
		print_status_message(ts);
	}

	return(err);
}

