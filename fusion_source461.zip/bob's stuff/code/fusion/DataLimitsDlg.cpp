// DataLimitsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "fusion.h"
#include "DataLimitsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDataLimitsDlg dialog


CDataLimitsDlg::CDataLimitsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDataLimitsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDataLimitsDlg)
	m_MaxIntensity = 0.0;
	m_MaxX = 0.0;
	m_MaxY = 0.0;
	m_MaxZ = 0.0;
	m_MinIntensity = 0.0;
	m_MinX = 0.0;
	m_MinY = 0.0;
	m_MinZ = 0.0;
	m_BinLabel1 = _T("");
	m_BinLabel2 = _T("");
	m_BinLabel3 = _T("");
	m_BinLabel4 = _T("");
	m_BinLabel5 = _T("");
	m_BinLabel6 = _T("");
	m_BinLabel7 = _T("");
	m_BinLabel8 = _T("");
	m_BinLabel9 = _T("");
	m_BinLabel10 = _T("");
	m_BinLabel11 = _T("");
	m_BinLabel12 = _T("");
	m_BinLabel13 = _T("");
	m_BinLabel14 = _T("");
	m_BinLabel15 = _T("");
	m_BinLabel16 = _T("");
	m_BinCount1 = 0;
	m_BinCount2 = 0;
	m_BinCount3 = 0;
	m_BinCount4 = 0;
	m_BinCount5 = 0;
	m_BinCount6 = 0;
	m_BinCount7 = 0;
	m_BinCount8 = 0;
	m_BinCount9 = 0;
	m_BinCount10 = 0;
	m_BinCount11 = 0;
	m_BinCount12 = 0;
	m_BinCount13 = 0;
	m_BinCount14 = 0;
	m_BinCount15 = 0;
	m_BinCount16 = 0;
	//}}AFX_DATA_INIT
	m_MaxBin = 0;
	m_BigBin = -1;
	m_Bins = NULL;
}


void CDataLimitsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDataLimitsDlg)
	DDX_Control(pDX, IDC_BIN1, m_Bin1);
	DDX_Control(pDX, IDC_BIN2, m_Bin2);
	DDX_Control(pDX, IDC_BIN3, m_Bin3);
	DDX_Control(pDX, IDC_BIN4, m_Bin4);
	DDX_Control(pDX, IDC_BIN5, m_Bin5);
	DDX_Control(pDX, IDC_BIN6, m_Bin6);
	DDX_Control(pDX, IDC_BIN7, m_Bin7);
	DDX_Control(pDX, IDC_BIN8, m_Bin8);
	DDX_Control(pDX, IDC_BIN9, m_Bin9);
	DDX_Control(pDX, IDC_BIN10, m_Bin10);
	DDX_Control(pDX, IDC_BIN11, m_Bin11);
	DDX_Control(pDX, IDC_BIN12, m_Bin12);
	DDX_Control(pDX, IDC_BIN13, m_Bin13);
	DDX_Control(pDX, IDC_BIN14, m_Bin14);
	DDX_Control(pDX, IDC_BIN15, m_Bin15);
	DDX_Control(pDX, IDC_BIN16, m_Bin16);
	DDX_Text(pDX, IDC_MAXI, m_MaxIntensity);
	DDX_Text(pDX, IDC_MAXX, m_MaxX);
	DDX_Text(pDX, IDC_MAXY, m_MaxY);
	DDX_Text(pDX, IDC_MAXZ, m_MaxZ);
	DDX_Text(pDX, IDC_MINI, m_MinIntensity);
	DDX_Text(pDX, IDC_MINX, m_MinX);
	DDX_Text(pDX, IDC_MINY, m_MinY);
	DDX_Text(pDX, IDC_MINZ, m_MinZ);
	DDX_Text(pDX, IDC_BINLABEL1, m_BinLabel1);
	DDX_Text(pDX, IDC_BINLABEL2, m_BinLabel2);
	DDX_Text(pDX, IDC_BINLABEL3, m_BinLabel3);
	DDX_Text(pDX, IDC_BINLABEL4, m_BinLabel4);
	DDX_Text(pDX, IDC_BINLABEL5, m_BinLabel5);
	DDX_Text(pDX, IDC_BINLABEL6, m_BinLabel6);
	DDX_Text(pDX, IDC_BINLABEL7, m_BinLabel7);
	DDX_Text(pDX, IDC_BINLABEL8, m_BinLabel8);
	DDX_Text(pDX, IDC_BINLABEL9, m_BinLabel9);
	DDX_Text(pDX, IDC_BINLABEL10, m_BinLabel10);
	DDX_Text(pDX, IDC_BINLABEL11, m_BinLabel11);
	DDX_Text(pDX, IDC_BINLABEL12, m_BinLabel12);
	DDX_Text(pDX, IDC_BINLABEL13, m_BinLabel13);
	DDX_Text(pDX, IDC_BINLABEL14, m_BinLabel14);
	DDX_Text(pDX, IDC_BINLABEL15, m_BinLabel15);
	DDX_Text(pDX, IDC_BINLABEL16, m_BinLabel16);
	DDX_Text(pDX, IDC_BINCOUNT1, m_BinCount1);
	DDX_Text(pDX, IDC_BINCOUNT2, m_BinCount2);
	DDX_Text(pDX, IDC_BINCOUNT3, m_BinCount3);
	DDX_Text(pDX, IDC_BINCOUNT4, m_BinCount4);
	DDX_Text(pDX, IDC_BINCOUNT5, m_BinCount5);
	DDX_Text(pDX, IDC_BINCOUNT6, m_BinCount6);
	DDX_Text(pDX, IDC_BINCOUNT7, m_BinCount7);
	DDX_Text(pDX, IDC_BINCOUNT8, m_BinCount8);
	DDX_Text(pDX, IDC_BINCOUNT9, m_BinCount9);
	DDX_Text(pDX, IDC_BINCOUNT10, m_BinCount10);
	DDX_Text(pDX, IDC_BINCOUNT11, m_BinCount11);
	DDX_Text(pDX, IDC_BINCOUNT12, m_BinCount12);
	DDX_Text(pDX, IDC_BINCOUNT13, m_BinCount13);
	DDX_Text(pDX, IDC_BINCOUNT14, m_BinCount14);
	DDX_Text(pDX, IDC_BINCOUNT15, m_BinCount15);
	DDX_Text(pDX, IDC_BINCOUNT16, m_BinCount16);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDataLimitsDlg, CDialog)
	//{{AFX_MSG_MAP(CDataLimitsDlg)
	ON_WM_SYSCOMMAND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDataLimitsDlg message handlers

BOOL CDataLimitsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_Bin1.SetRange(0, 100);
	m_Bin2.SetRange(0, 100);
	m_Bin3.SetRange(0, 100);
	m_Bin4.SetRange(0, 100);
	m_Bin5.SetRange(0, 100);
	m_Bin6.SetRange(0, 100);
	m_Bin7.SetRange(0, 100);
	m_Bin8.SetRange(0, 100);
	m_Bin9.SetRange(0, 100);
	m_Bin10.SetRange(0, 100);
	m_Bin11.SetRange(0, 100);
	m_Bin12.SetRange(0, 100);
	m_Bin13.SetRange(0, 100);
	m_Bin14.SetRange(0, 100);
	m_Bin15.SetRange(0, 100);
	m_Bin16.SetRange(0, 100);
	
	m_Bin1.SetPos((int) ((double) m_Bins[0] / (double) m_MaxBin * 100.0));
	m_Bin2.SetPos((int) ((double) m_Bins[1] / (double) m_MaxBin * 100.0));
	m_Bin3.SetPos((int) ((double) m_Bins[2] / (double) m_MaxBin * 100.0));
	m_Bin4.SetPos((int) ((double) m_Bins[3] / (double) m_MaxBin * 100.0));
	m_Bin5.SetPos((int) ((double) m_Bins[4] / (double) m_MaxBin * 100.0));
	m_Bin6.SetPos((int) ((double) m_Bins[5] / (double) m_MaxBin * 100.0));
	m_Bin7.SetPos((int) ((double) m_Bins[6] / (double) m_MaxBin * 100.0));
	m_Bin8.SetPos((int) ((double) m_Bins[7] / (double) m_MaxBin * 100.0));
	m_Bin9.SetPos((int) ((double) m_Bins[8] / (double) m_MaxBin * 100.0));
	m_Bin10.SetPos((int) ((double) m_Bins[9] / (double) m_MaxBin * 100.0));
	m_Bin11.SetPos((int) ((double) m_Bins[10] / (double) m_MaxBin * 100.0));
	m_Bin12.SetPos((int) ((double) m_Bins[11] / (double) m_MaxBin * 100.0));
	m_Bin13.SetPos((int) ((double) m_Bins[12] / (double) m_MaxBin * 100.0));
	m_Bin14.SetPos((int) ((double) m_Bins[13] / (double) m_MaxBin * 100.0));
	m_Bin15.SetPos((int) ((double) m_Bins[14] / (double) m_MaxBin * 100.0));
	m_Bin16.SetPos((int) ((double) m_Bins[15] / (double) m_MaxBin * 100.0));

	m_BinCount1 = m_Bins[0];
	m_BinCount2 = m_Bins[1];
	m_BinCount3 = m_Bins[2];
	m_BinCount4 = m_Bins[3];
	m_BinCount5 = m_Bins[4];
	m_BinCount6 = m_Bins[5];
	m_BinCount7 = m_Bins[6];
	m_BinCount8 = m_Bins[7];
	m_BinCount9 = m_Bins[8];
	m_BinCount10 = m_Bins[9];
	m_BinCount11 = m_Bins[10];
	m_BinCount12 = m_Bins[11];
	m_BinCount13 = m_Bins[12];
	m_BinCount14 = m_Bins[13];
	m_BinCount15 = m_Bins[14];
	m_BinCount16 = m_Bins[15];

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDataLimitsDlg::OnSysCommand(UINT nID, LPARAM lParam) 
{
	// make dialog close when user closes using "X" or window menu...close goes through OnOK()
	if ((nID & 0xFFF0) == SC_CLOSE) {
		OnCancel();
	}
	else {
		CDialog::OnSysCommand(nID, lParam);
	}
}
