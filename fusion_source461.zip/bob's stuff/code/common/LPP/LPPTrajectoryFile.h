// LPPTrajectoryFile.h: interface for the CLPPTrajectoryFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LPPTRAJECTORYFILE_H__4A2E0AF9_61E7_4D30_9643_97CD03E3814C__INCLUDED_)
#define AFX_LPPTRAJECTORYFILE_H__4A2E0AF9_61E7_4D30_9643_97CD03E3814C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifdef _MSC_VER
#pragma pack(push)
#pragma pack(1)
#endif

typedef struct {
	unsigned char			MagicNumber[4];		// must be 0xaa441488
	unsigned short			HeaderSize;
	int						HeaderVersion;		// documented as int
	long					RecordSize;
	long					NumberOfRecords;
	int						RecordVersion;		// documented as int
	bool					TimeReversed;		// 0=time increasing, 1=time decreasing
} LPPHeader;

typedef struct {
	long					GPSWeek;
	double					GPSTime;
	double					Latitude;
	double					LatitudeVariance;
	double					Longitude;
	double					LongitudeVariance;
	double					EllipsoidHeight;
	double					EllipsoidHeightVariance;
	double					Roll;
	double					RollVariance;
	double					Pitch;
	double					PitchVariance;
	double					Heading;
	double					HeadingVariance;
} LPPRecord;

#ifdef _MSC_VER
#pragma pack(pop)
#endif

class CLPPTrajectoryFile  
{
public:
	long GetRecordCount();
	BOOL ReadPosition(LPPRecord& Position);
	void Rewind();
	void Close();
	void SetBoresightCorrection(double RollCorrection, double PitchCorrection, double HeadingCorrection);
	void SetIMUToLaserOffset(double XOffset, double YOffset, double ZOffset);
	BOOL Open(LPCTSTR FileName);
	BOOL IsValid();
	CLPPTrajectoryFile();
	CLPPTrajectoryFile(LPCTSTR FileName);
	virtual ~CLPPTrajectoryFile();

	double m_IMUToLaserXOffset;
	double m_IMUToLaserYOffset;
	double m_IMUToLaserZOffset;
	double m_BoresightCorrectionRoll;
	double m_BoresightCorrectionPitch;
	double m_BoresightCorrectionHeading;

	LPPRecord m_Position;

private:
	FILE* m_FileHandle;
	BOOL m_Valid;
	LPPHeader m_Header;
};

#endif // !defined(AFX_LPPTRAJECTORYFILE_H__4A2E0AF9_61E7_4D30_9643_97CD03E3814C__INCLUDED_)
