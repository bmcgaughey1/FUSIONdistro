// INIFile.h: interface for the CINIFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INIFILE_H__4A424EA3_0631_11D3_A124_100E08C10B02__INCLUDED_)
#define AFX_INIFILE_H__4A424EA3_0631_11D3_A124_100E08C10B02__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CINIFile  
{
public:
	void SetFileName(LPCTSTR FileName);
	CINIFile(LPCTSTR csFileName);
	CINIFile();
	virtual ~CINIFile();

	void WriteSetting(int section, int key, LPCTSTR lpszStr);
	void WriteSetting(int section, int key, CString csStr);
	void WriteSetting(int section, int key, int intval);
	void WriteSetting(int section, int key, DWORD longval);
	void WriteSetting(int section, int key, double dblval);

	void WriteSetting(int section, LPCTSTR csKey, LPCTSTR lpszStr);
	void WriteSetting(int section, LPCTSTR csKey, CString csStr);
	void WriteSetting(int section, LPCTSTR csKey, int intval);
	void WriteSetting(int section, LPCTSTR csKey, DWORD longval);
	void WriteSetting(int section, LPCTSTR csKey, double dblval);

	void WriteSetting(LPCTSTR csSection, int key, LPCTSTR lpszStr);
	void WriteSetting(LPCTSTR csSection, int key, CString csStr);
	void WriteSetting(LPCTSTR csSection, int key, int intval);
	void WriteSetting(LPCTSTR csSection, int key, DWORD longval);
	void WriteSetting(LPCTSTR csSection, int key, double dblval);

	void WriteSetting(LPCTSTR csSection, LPCTSTR csKey, LPCTSTR lpszStr);
	void WriteSetting(LPCTSTR csSection, LPCTSTR csKey, CString csStr);
	void WriteSetting(LPCTSTR csSection, LPCTSTR csKey, int intval);
	void WriteSetting(LPCTSTR csSection, LPCTSTR csKey, DWORD longval);
	void WriteSetting(LPCTSTR csSection, LPCTSTR csKey, double dblval);

	void ReadSetting(int section, int key, LPSTR lpszStr, int maxlen, LPCTSTR lpszDef);
	void ReadSetting(int section, int key, CString& csStr, LPCTSTR lpszDef);
	int ReadSetting(int section, int key, int defval);
	DWORD ReadSetting(int section, int key, DWORD defval);
	double ReadSetting(int section, int key, double defval);

	void ReadSetting(int section, LPCTSTR csKey, LPSTR lpszStr, int maxlen, LPCTSTR lpszDef);
	void ReadSetting(int section, LPCTSTR csKey, CString& csStr, LPCTSTR lpszDef);
	int ReadSetting(int section, LPCTSTR csKey, int defval);
	DWORD ReadSetting(int section, LPCTSTR csKey, DWORD defval);
	double ReadSetting(int section, LPCTSTR csKey, double defval);

	void ReadSetting(LPCTSTR csSection, int key, LPSTR lpszStr, int maxlen, LPCTSTR lpszDef);
	void ReadSetting(LPCTSTR csSection, int key, CString& csStr, LPCTSTR lpszDef);
	int ReadSetting(LPCTSTR csSection, int key, int defval);
	DWORD ReadSetting(LPCTSTR csSection, int key, DWORD defval);
	double ReadSetting(LPCTSTR csSection, int key, double defval);

	void ReadSetting(LPCTSTR csSection, LPCTSTR csKey, LPSTR lpszStr, int maxlen, LPCTSTR lpszDef);
	void ReadSetting(LPCTSTR csSection, LPCTSTR csKey, CString& csStr, LPCTSTR lpszDef);
	int ReadSetting(LPCTSTR csSection, LPCTSTR csKey, int defval);
	DWORD ReadSetting(LPCTSTR csSection, LPCTSTR csKey, DWORD defval);
	double ReadSetting(LPCTSTR csSection, LPCTSTR csKey, double defval);

	void DeleteKey(LPCTSTR szSection, LPCTSTR szKey);
	void DeleteKey(int section, int key);
	void DeleteSection(LPCTSTR szSection);
	void DeleteSection(int section);

private:
	CString m_FileName;
};

#endif // !defined(AFX_INIFILE_H__4A424EA3_0631_11D3_A124_100E08C10B02__INCLUDED_)
