// A quick-and-dirty test of the SDTS++ converters.

#ifndef INCLUDED_CONVERTTEST_H
#define INCLUDED_CONVERTTEST_H

#include <iostream>
#include <iomanip>
#include <stdlib.h>
#ifdef WIN32
#include <string>
#include <strstream>
   using namespace std;
#else
#include <string.h>
#include <strstream.h>
#include <sys/types.h>
#include <netinet/in.h>
#endif

int main(void);

#endif
