// DataFileListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "fusion.h"
#include "DataFileListDlg.h"
#include "POIPropertiesDlg.h"
#include "polygonlayer.h"
#include "cderr.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDataFileListDlg dialog


CDataFileListDlg::CDataFileListDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDataFileListDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDataFileListDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_DataLayers = 0;
	m_DlgType = DATALAYERS;

	// allocate memory for list of items
	m_DataLayerInfo = new CLayerDisplayObject[MAX_LAYERS];
}

CDataFileListDlg::~CDataFileListDlg()
{
	// delete memory for list of items
	delete[] m_DataLayerInfo;
}

void CDataFileListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDataFileListDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDataFileListDlg, CDialog)
	//{{AFX_MSG_MAP(CDataFileListDlg)
	ON_BN_CLICKED(IDC_ADDFILE, OnAddfile)
	ON_BN_CLICKED(IDC_DELETEFILES, OnDeletefiles)
	ON_BN_CLICKED(IDC_DELETEALL, OnDeleteall)
	ON_BN_CLICKED(IDC_PROPERTIES, OnProperties)
	ON_NOTIFY(NM_DBLCLK, IDC_FILELIST, OnDblclkFilelist)
	ON_NOTIFY(NM_CLICK, IDC_FILELIST, OnClickFilelist)
	ON_BN_CLICKED(IDC_SETTOMATCH, OnSettomatch)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDataFileListDlg message handlers

void CDataFileListDlg::OnAddfile() 
{
	UpdateData();

	CString csFilter;
	CString csExt;

	// load strings that specify the file types for the file...open dialog
	if (m_DlgType == DATALAYERS)
		csFilter.LoadString(IDS_DATAFILEFILTER);
	else if (m_DlgType == POILAYERS)
		csFilter.LoadString(IDS_ALLOVERLAYFILEFILTER);
	else if (m_DlgType == HOTSPOTLAYERS)
		csFilter.LoadString(IDS_HOTSPOTFILEFILTER);
	else if (m_DlgType == TREELAYERS)
		csFilter.LoadString(IDS_TREELISTFILTER);

	csExt.LoadString(IDS_DATAFILEEXT);

	// create an instance of the file...open dialog
	CFileDialog fd(TRUE, csExt, NULL, OFN_HIDEREADONLY | OFN_ALLOWMULTISELECT, csFilter, (CWnd*) this);

	// set up large buffer to allow multiple file selection
	char* bigbuf = new char[16384];
	int Format;
	bigbuf[0] = '\0';
	fd.m_ofn.lpstrFile = bigbuf;
	fd.m_ofn.nMaxFile = 16384;

	// use the file...open dialog to get an image file name
	if (fd.DoModal() == IDOK) {
		// retrieve the name for the file...open dialog
		POSITION pos = fd.GetStartPosition();
		CString csPath;

		while (pos) {
			csPath = fd.GetNextPathName(pos);
			m_DataLayerInfo[m_DataLayers].m_LineColor = RGB(255, 0, 0);
			m_DataLayerInfo[m_DataLayers].m_FillColor = RGB(255, 255, 0);
			m_DataLayerInfo[m_DataLayers].m_FileName = csPath;
			m_DataLayerInfo[m_DataLayers].m_Symbol = 1;
			m_DataLayerInfo[m_DataLayers].m_SymbolSize = 25.0;
			m_DataLayerInfo[m_DataLayers].m_Label = FALSE;		// turn off labels
			if (m_DlgType == DATALAYERS) {
				if (fd.m_ofn.nFilterIndex == 1)				// LDA and LAS and LAZ
					m_DataLayerInfo[m_DataLayers].m_Format = LIDARRAW_FORMAT;
				else if (fd.m_ofn.nFilterIndex == 2)		// XYZ ASCII
					m_DataLayerInfo[m_DataLayers].m_Format = GENERICXYZ;
				else {
					// All files option selected so we need to figure out the format
					m_DataLayerInfo[m_DataLayers].m_Format = GENERICXYZ;
				}

				Format = DetermineFileFormat(csPath);
				if (Format >= 0)
					m_DataLayerInfo[m_DataLayers].m_Format = Format;

				// set default symbol to non to force extents rectangle when data is displayed
				m_DataLayerInfo[m_DataLayers].m_Symbol = 0;
				m_DataLayerInfo[m_DataLayers].m_Label = TRUE;		// label the extents box with the filename
			}
			else if (m_DlgType == POILAYERS) {
				// set default symbol to dot
				m_DataLayerInfo[m_DataLayers].m_Symbol = 5;

				if (fd.m_ofn.nFilterIndex == 1) {
					// find out if this is a point file
					CESRIShapefile tmp(csPath);
					if (tmp.IsValid()) {
						if (tmp.GetShapefileType() == POLYLINE || tmp.GetShapefileType() == POLYGON ||
						    tmp.GetShapefileType() == POLYLINEZ || tmp.GetShapefileType() == POLYGONZ ||
						    tmp.GetShapefileType() == POLYLINEM || tmp.GetShapefileType() == POLYGONM)
							m_DataLayerInfo[m_DataLayers].m_Symbol = 0;		// no symbol
					}
					m_DataLayerInfo[m_DataLayers].m_Format = ARCSHAPEFILE_FORMAT;
				}
				else if (fd.m_ofn.nFilterIndex == 2) {
					m_DataLayerInfo[m_DataLayers].m_Symbol = 0;		// no symbol
					m_DataLayerInfo[m_DataLayers].m_Format = MOSSLINE_FORMAT;
				}
				else if (fd.m_ofn.nFilterIndex == 3) {
					m_DataLayerInfo[m_DataLayers].m_Symbol = 7;		// asterisk
					m_DataLayerInfo[m_DataLayers].m_Format = ARCGENPOINT_FORMAT;
				}
				else if (fd.m_ofn.nFilterIndex == 4) {
					m_DataLayerInfo[m_DataLayers].m_Symbol = 0;		// no symbol
					m_DataLayerInfo[m_DataLayers].m_Format = ARCGENLINE_FORMAT;
				}
				else if (fd.m_ofn.nFilterIndex == 5)
					m_DataLayerInfo[m_DataLayers].m_Format = LIDARRAW_FORMAT;
				else if (fd.m_ofn.nFilterIndex == 6)
					m_DataLayerInfo[m_DataLayers].m_Format = GENERICXYZ;
				else if (fd.m_ofn.nFilterIndex == 7)
					m_DataLayerInfo[m_DataLayers].m_Format = HOTSPOT_FILE;
				else
					m_DataLayerInfo[m_DataLayers].m_Format = GENERICXYZ;

				Format = DetermineFileFormat(csPath);
				if (Format >= 0)
					m_DataLayerInfo[m_DataLayers].m_Format = Format;
			}
			else if (m_DlgType == HOTSPOTLAYERS) {
				if (fd.m_ofn.nFilterIndex == 1)
					m_DataLayerInfo[m_DataLayers].m_Format = HOTSPOT_FILE;
				else
					m_DataLayerInfo[m_DataLayers].m_Format = GENERICXYZ;

				Format = DetermineFileFormat(csPath);
				if (Format >= 0)
					m_DataLayerInfo[m_DataLayers].m_Format = Format;
			}
			else if (m_DlgType == TREELAYERS) {
				if (fd.m_ofn.nFilterIndex == 1) {
					m_DataLayerInfo[m_DataLayers].m_Format = TREELIST_FILE;
					m_DataLayerInfo[m_DataLayers].m_LineColor = RGB(0, 255, 0);
					m_DataLayerInfo[m_DataLayers].m_Symbol = 6;
				}
				else
					m_DataLayerInfo[m_DataLayers].m_Format = GENERICXYZ;

				Format = DetermineFileFormat(csPath);
				if (Format >= 0)
					m_DataLayerInfo[m_DataLayers].m_Format = Format;
			}
			m_DataLayerInfo[m_DataLayers].m_Active = TRUE;

			AddListItem(m_DataLayerInfo[m_DataLayers].m_LineColor, m_DataLayerInfo[m_DataLayers].m_FillColor, m_DataLayerInfo[m_DataLayers].m_FileName, m_DataLayerInfo[m_DataLayers].m_Format, m_DataLayerInfo[m_DataLayers].m_Symbol, m_DataLayerInfo[m_DataLayers].m_SymbolSize, m_DataLayerInfo[m_DataLayers].m_Label);

			m_DataLayers ++;
		}
	}
	else {
		if (CommDlgExtendedError() == FNERR_BUFFERTOOSMALL) {
			AfxMessageBox("Too many files selected...try adding files in several batches", MB_OK | MB_ICONEXCLAMATION);
		}
	}
	
	delete[] bigbuf;

	EnableButtons();
}

void CDataFileListDlg::OnDeletefiles() 
{
	if (!m_FileList.GetSelectedCount())
		return;

	POSITION pos = m_FileList.GetFirstSelectedItemPosition();
	int Item = m_FileList.GetNextSelectedItem(pos);

	// delete selected item
	if (Item < m_DataLayers - 1) {
		m_FileList.DeleteItem(Item);
		for (int i = Item; i < m_DataLayers - 1; i ++)
			m_DataLayerInfo[i] = m_DataLayerInfo[i + 1];

		m_DataLayers --;
	}
	else {
		// last item
		m_FileList.DeleteItem(Item);
		m_DataLayers --;
	}

	EnableButtons();
}

void CDataFileListDlg::OnDeleteall() 
{
	m_FileList.DeleteAllItems();
	m_DataLayers = 0;

	EnableButtons();
}

void CDataFileListDlg::OnProperties() 
{
	if (!m_FileList.GetSelectedCount())
		return;

	POSITION pos = m_FileList.GetFirstSelectedItemPosition();
	int Item = m_FileList.GetNextSelectedItem(pos);

	int FieldCount = -1;

	CPOIPropertiesDlg dlg;

	dlg.m_LineColor = m_DataLayerInfo[Item].m_LineColor;
	dlg.m_FillColor = m_DataLayerInfo[Item].m_FillColor;
	dlg.m_SymbolType = m_DataLayerInfo[Item].m_Symbol;
	dlg.m_SymbolSize = m_DataLayerInfo[Item].m_SymbolSize;
	dlg.m_Label = m_DataLayerInfo[Item].m_Label;
	dlg.m_LabelColumnIndex = m_DataLayerInfo[Item].m_LabelColumnIndex;
	dlg.m_ShapefileName.Empty();

	if (m_DlgType == TREELAYERS)
		dlg.m_SizeActive = FALSE;

	// see if we have a shapefile
	if (m_DataLayerInfo[Item].m_Format >= ARCGENPOLY_FORMAT && m_DataLayerInfo[Item].m_Format <= ARCSHAPEFILE_FORMAT) {
		dlg.m_ShapefileName = m_DataLayerInfo[Item].m_FileName;
	}

	if (dlg.DoModal() == IDOK) {
		// pick up new colors and symbol type
		m_DataLayerInfo[Item].m_LineColor = dlg.m_LineColor;
		m_DataLayerInfo[Item].m_FillColor = dlg.m_FillColor;
		m_DataLayerInfo[Item].m_Symbol = dlg.m_SymbolType;
		m_DataLayerInfo[Item].m_SymbolSize = dlg.m_SymbolSize;
		m_DataLayerInfo[Item].m_Label = dlg.m_Label;
		m_DataLayerInfo[Item].m_LabelColumnIndex = dlg.m_LabelColumnIndex;

		// update list fields
		AddListItem(m_DataLayerInfo[Item].m_LineColor, m_DataLayerInfo[Item].m_FillColor, m_DataLayerInfo[Item].m_FileName, m_DataLayerInfo[Item].m_Format, m_DataLayerInfo[Item].m_Symbol, m_DataLayerInfo[Item].m_SymbolSize, m_DataLayerInfo[Item].m_Label, Item);
	}
}

void CDataFileListDlg::EnableButtons()
{
	if (m_FileList.GetSelectedCount()) {
		GetDlgItem(IDC_DELETEFILES)->EnableWindow(TRUE);
		GetDlgItem(IDC_PROPERTIES)->EnableWindow(TRUE);
		GetDlgItem(IDC_SETTOMATCH)->EnableWindow(TRUE);
	}
	else {
		GetDlgItem(IDC_DELETEFILES)->EnableWindow(FALSE);
		GetDlgItem(IDC_PROPERTIES)->EnableWindow(FALSE);
		GetDlgItem(IDC_SETTOMATCH)->EnableWindow(FALSE);
	}

	if (m_FileList.GetItemCount()) {
		GetDlgItem(IDC_DELETEALL)->EnableWindow(TRUE);
	}
	else {
		GetDlgItem(IDC_DELETEALL)->EnableWindow(FALSE);
	}
}

BOOL CDataFileListDlg::OnInitDialog() 
{
	BOOL ColorFlags[7] = {TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE};

	CDialog::OnInitDialog();
	
	// subclass list control
	m_FileList.SubclassDlgItem(IDC_FILELIST, this);

	// enable full row selection
	m_FileList.SetHighlightType(HIGHLIGHT_ROW);

	UpdateData();
	RECT rc;
	m_FileList.GetClientRect(&rc);
	m_FileList.InsertColumn(1, "Line Color", LVCFMT_LEFT, m_FileList.GetStringWidth("WLine ColorW"), 0);
	m_FileList.InsertColumn(2, "Fill Color", LVCFMT_LEFT, m_FileList.GetStringWidth("WFill ColorW"), 1);
	m_FileList.InsertColumn(3, "Symbol", LVCFMT_LEFT, m_FileList.GetStringWidth("WSymbolW"), 2);
	m_FileList.InsertColumn(4, "Symbol Size", LVCFMT_LEFT, m_FileList.GetStringWidth("WSymbol SizeW"), 3);
	m_FileList.InsertColumn(5, "Label", LVCFMT_LEFT, m_FileList.GetStringWidth("WLabelW"), 4);
	m_FileList.InsertColumn(6, "File", LVCFMT_LEFT, (rc.right - rc.left) - (m_FileList.GetStringWidth("WFill ColorW") + m_FileList.GetStringWidth("WLine ColorW") + m_FileList.GetStringWidth("WSymbolW") + m_FileList.GetStringWidth("WSymbol SizeW") + m_FileList.GetStringWidth("WLabelW") + m_FileList.GetStringWidth("WFormatW")), 5);
	m_FileList.InsertColumn(7, "Format", LVCFMT_LEFT, m_FileList.GetStringWidth("WFormatW"), 6);
	
	// set color flags
	m_FileList.SetColorColumnFlags(ColorFlags, 7);

	if (m_DataLayers) {
		for (int i = 0; i < m_DataLayers; i ++)
			AddListItem(m_DataLayerInfo[i].m_LineColor, m_DataLayerInfo[i].m_FillColor, m_DataLayerInfo[i].m_FileName, m_DataLayerInfo[i].m_Format, m_DataLayerInfo[i].m_Symbol, m_DataLayerInfo[i].m_SymbolSize, m_DataLayerInfo[i].m_Label);
	}
	else
		PostMessage(WM_COMMAND, IDC_ADDFILE);

	EnableButtons();

	SetWindowText(m_DlgTitle);

	// initialize control resize helper
	m_resizeHelper.Init(GetSafeHwnd());

	// set positioning rules
	m_resizeHelper.Fix(IDC_FILELIST, HLEFTRIGHT, VTOPBOTTOM);
	m_resizeHelper.Fix(IDC_ADDFILE, HLEFT, VHEIGHTBOTTOM);
	m_resizeHelper.Fix(IDC_DELETEFILES, HNOFIX, VHEIGHTBOTTOM);
	m_resizeHelper.Fix(IDC_DELETEALL, HNOFIX, VHEIGHTBOTTOM);
	m_resizeHelper.Fix(IDC_SETTOMATCH, HNOFIX, VHEIGHTBOTTOM);
	m_resizeHelper.Fix(IDC_PROPERTIES, HRIGHT, VHEIGHTBOTTOM);
	m_resizeHelper.Fix(IDOK, HLEFT, VHEIGHTBOTTOM);
	m_resizeHelper.Fix(IDCANCEL, HRIGHT, VHEIGHTBOTTOM);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDataFileListDlg::OnDblclkFilelist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// get item from list
	CPoint pt(CWnd::GetCurrentMessage()->pt);
	m_FileList.ScreenToClient(&pt);
	int nHitItem = m_FileList.HitTest(pt);

	if (nHitItem >= 0) {
		OnProperties();
	}
	
	*pResult = 0;
}

void CDataFileListDlg::OnClickFilelist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	EnableButtons();
	
	*pResult = 0;
}

void CDataFileListDlg::AddListItem(COLORREF LineColor, COLORREF FillColor, LPCTSTR FileName, int Format, int SymbolType, double SymbolSize, BOOL ShowLabels, int Index)
{
	char *symboltype[] = {"None", "Pixel", "Cross", "X", "Block", "Dot", "Circle", "Asterisk"};
	char *formats[] = {"MOSS polygon", "MOSS line", "MOSS point", "ARCGEN polygon", "ARCGEN line", "ARCGEN point", "ARC shapefile", "SVS tree list grid", "SVS tree list fireline", "SVS GRD", "LIDAR data", "Generic XYZ", "Hotspots", "CSV tree file", "Unknown"};
	char *labels[] = {"No", "Yes"};
	LVITEM lv;
	char szText[256];
	lv.mask = LVIF_TEXT;
	if (Index >= 0)
		lv.iItem = Index;
	else
		lv.iItem = m_FileList.GetItemCount();

	// set line color
	lv.iSubItem = 0;
	sprintf(szText, "%i", LineColor);
	lv.pszText = szText;
	if (Index >= 0)
		m_FileList.SetItem(&lv);
	else
		m_FileList.InsertItem(&lv);

	// set fill color
	lv.iSubItem = 1;
	sprintf(szText, "%i", FillColor);
	lv.pszText = szText;
	m_FileList.SetItem(&lv);

	// set symbol type
	lv.iSubItem = 2;
	strcpy(szText, symboltype[SymbolType]);
	lv.pszText = szText;
	m_FileList.SetItem(&lv);

	// set symbol size
	lv.iSubItem = 3;
	sprintf(szText, "%.2lf", SymbolSize);
	lv.pszText = szText;
	m_FileList.SetItem(&lv);

	// set label
	lv.iSubItem = 4;
	strcpy(szText, labels[ShowLabels ? 1 : 0]);
	lv.pszText = szText;
	m_FileList.SetItem(&lv);

	// set filename
	lv.iSubItem = 5;
	strcpy(szText, FileName);
	lv.pszText = szText;
	m_FileList.SetItem(&lv);

	// set format
	lv.iSubItem = 6;
	strcpy(szText, formats[Format]);
	lv.pszText = szText;
	m_FileList.SetItem(&lv);

	m_FileList.SetColumnWidth(0, LVSCW_AUTOSIZE_USEHEADER);
	m_FileList.SetColumnWidth(1, LVSCW_AUTOSIZE_USEHEADER);
	m_FileList.SetColumnWidth(2, LVSCW_AUTOSIZE_USEHEADER);
	m_FileList.SetColumnWidth(3, LVSCW_AUTOSIZE_USEHEADER);
	m_FileList.SetColumnWidth(4, LVSCW_AUTOSIZE_USEHEADER);
	m_FileList.SetColumnWidth(5, LVSCW_AUTOSIZE_USEHEADER);
	m_FileList.SetColumnWidth(6, LVSCW_AUTOSIZE_USEHEADER);
}

void CDataFileListDlg::GetListItem(int Index, COLORREF& LineColor, COLORREF& FillColor, CString& FileName, int& SymbolType, double& SymbolSize, BOOL& ShowLabels)
{
	char *symboltype[] = {"None", "Pixel", "Cross", "X", "Block", "Dot", "Circle", "Asterisk"};
	CString LabelString;
	LVITEM lv;
	char szText[256];
	lv.mask = LVIF_TEXT;
	lv.iItem = Index;
	lv.cchTextMax = 255;

	// get line color
	lv.iSubItem = 0;
	lv.pszText = szText;
	m_FileList.GetItem(&lv);
	LineColor = atol(szText);

	// get fill color
	lv.iSubItem = 1;
	lv.pszText = szText;
	m_FileList.GetItem(&lv);
	FillColor = atol(szText);

	// get symbol type
	lv.iSubItem = 2;
	lv.pszText = szText;
	m_FileList.GetItem(&lv);
	for (int i = 0; i < 5; i ++) {
		if (strcmp(symboltype[i], szText) == 0) {
			SymbolType = i;
			break;
		}
	}

	// get symbol size
	lv.iSubItem = 3;
	lv.pszText = szText;
	m_FileList.GetItem(&lv);
	SymbolSize = atof(szText);

	// get label flag
	lv.iSubItem = 4;
	lv.pszText = szText;
	m_FileList.GetItem(&lv);
	LabelString = _T(szText);
	if (LabelString.CompareNoCase("Yes") == 0)
		ShowLabels = TRUE;
	else
		ShowLabels = FALSE;

	// get filename
	lv.iSubItem = 5;
	lv.pszText = szText;
	m_FileList.GetItem(&lv);
	FileName = _T(szText);

}


void CDataFileListDlg::OnSettomatch() 
{
	int i;

	if (!m_FileList.GetSelectedCount())
		return;

	POSITION pos = m_FileList.GetFirstSelectedItemPosition();
	int Count = m_FileList.GetSelectedCount();
	CString TempFileName;

	if (Count == 1 && pos) {
		int Item = m_FileList.GetNextSelectedItem(pos);

		for (i = 0; i < m_DataLayers; i ++) {
			if (i != Item) {
				TempFileName = m_DataLayerInfo[i].m_FileName;
				m_DataLayerInfo[i] = m_DataLayerInfo[Item];
				m_DataLayerInfo[i].m_FileName = TempFileName;
			}
		}

		// clear list
		m_FileList.DeleteAllItems();

		// add new items
		for (i = 0; i < m_DataLayers; i ++)
			AddListItem(m_DataLayerInfo[i].m_LineColor, m_DataLayerInfo[i].m_FillColor, m_DataLayerInfo[i].m_FileName, m_DataLayerInfo[i].m_Format, m_DataLayerInfo[i].m_Symbol, m_DataLayerInfo[i].m_SymbolSize, m_DataLayerInfo[i].m_Label);
	}
}

void CDataFileListDlg::SetTitle(LPCTSTR szTitle)
{
	m_DlgTitle = _T(szTitle);
}

void CDataFileListDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	// resize controls
	m_resizeHelper.OnSize();
}

int CDataFileListDlg::DetermineFileFormat(CString FileName)
{
	int Format = -1;
	CString csTemp = FileName;
	csTemp.MakeLower();

	// look at extension to see if a format is indicated
	if (csTemp.Find(".shp") >= 0)
		Format = ARCSHAPEFILE_FORMAT;
	else if (csTemp.Find(".lda") >= 0)
		Format = LIDARRAW_FORMAT;
	else if (csTemp.Find(".las") >= 0)
		Format = LIDARRAW_FORMAT;
	else if (csTemp.Find(".laz") >= 0)
		Format = LIDARRAW_FORMAT;
	else if (csTemp.Find(".hst") >= 0)
		Format = HOTSPOT_FILE;
	else if (csTemp.Find(".csv") >= 0)
		Format = TREELIST_FILE;

	return(Format);
}
// #define		MOSSPOLY_FORMAT			0
// #define		MOSSLINE_FORMAT			1
// #define		MOSSPOINT_FORMAT		2
// #define		ARCGENPOLY_FORMAT		3
// #define		ARCGENLINE_FORMAT		4
// #define		ARCGENPOINT_FORMAT		5
// #define		ARCSHAPEFILE_FORMAT		6		.shp
// #define		SVSTREELISTGRID			7
// #define		SVSTREELISTFIRE			8
// #define		SVSGROUNDDEFINITION		9
// #define		LIDARRAW_FORMAT			10		.las, .lda, .laz
// #define		GENERICXYZ				11
// #define		HOTSPOT_FILE			12		.hst
// #define		TREELIST_FILE			13		.csv
