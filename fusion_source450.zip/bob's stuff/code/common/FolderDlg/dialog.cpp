// FolderDlgDlg.cpp : implementation file
//

#include "stdafx.h"
#include "main.h"
#include "dialog.h"

#ifdef _DEBUG
	#define new DEBUG_NEW
	#undef THIS_FILE
	static char THIS_FILE[] = __FILE__;
#endif

#ifndef __FOLDERDLG_H__
	#include "src/folderdlg.h"
#endif

#ifndef __FILTERED_FOLDERDLG_H__
	#include "src/filteredfolderdlg.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CDemoDlg dialog

CDemoDlg::CDemoDlg( IN CWnd* pParent /*=NULL*/ )
		: CDialog( CDemoDlg::IDD, pParent )
{
	//{{AFX_DATA_INIT(CDemoDlg)

	m_strRoot	= _T( "" );
	m_strPath	= _T( "" );
	m_strName	= _T( "" );
	m_strRoot	= _T( "" );
	m_strFilter	= _T( "*.exe;*.txt;*.inf;" );

	m_bFilter	= FALSE;

	//}}AFX_DATA_INIT

	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon    = AfxGetApp()->LoadIcon( IDR_MAINFRAME );
	m_pToolTip = NULL;
}

CDemoDlg::~CDemoDlg( VOID )
{
	SAFE_DELETE( m_pToolTip );
}

VOID CDemoDlg::DoDataExchange( IN CDataExchange* pDX )
{
	CDialog::DoDataExchange( pDX );

	//{{AFX_DATA_MAP(CDemoDlg)
	DDX_Control( pDX, IDC_TXT_FILTER,		m_wndFilter );
	DDX_Control( pDX, IDC_TXT_ROOT,			m_wndRoot	);
	DDX_Control( pDX, IDC_TXT_PATH,			m_wndPath	);
	DDX_Control( pDX, IDC_TXT_DISPNAME,		m_wndName	);

	DDX_Control( pDX, IDC_ITEMICON,			m_wndIcon	);
	DDX_Control( pDX, IDC_LNK,				m_wndLink	);
	DDX_Control( pDX, IDC_CHK_FILTER,		m_wndChkFilter	 );

	DDX_Control( pDX, IDC_CMD_BRWS_ROOT,	m_wndBtnBrwsRoot );
	DDX_Control( pDX, IDC_CMD_DEL_ROOT,		m_wndBtnDelRoot	 );
	DDX_Control( pDX, IDC_CMD_BRWS_PATH,	m_wndBtnBrwsPath );
	DDX_Control( pDX, IDC_CMD_DEL_PATH,		m_wndBtnDelPath  );	

	DDX_Text( pDX, IDC_TXT_PATH,		m_strPath	);
	DDV_MaxChars( pDX, m_strPath, _MAX_PATH );
	
	DDX_Text( pDX, IDC_TXT_ROOT,		m_strRoot	);
	DDV_MaxChars( pDX, m_strRoot, _MAX_PATH );

	DDX_Text( pDX, IDC_TXT_DISPNAME,	m_strName	);
	DDX_Text( pDX, IDC_TXT_FILTER,		m_strFilter );

	DDX_Check( pDX, IDC_CHK_FILTER,		m_bFilter	);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP( CDemoDlg, CDialog )
	//{{AFX_MSG_MAP(CDemoDlg)	
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()

	ON_BN_CLICKED( IDC_CMD_BRWS_ROOT,	OnCmdBrwsRoot )
	ON_BN_CLICKED( IDC_CMD_BRWS_PATH,	OnCmdBrwsPath )
	ON_BN_CLICKED( IDC_CMD_DEL_ROOT,	OnCmdDelRoot  )
	ON_BN_CLICKED( IDC_CMD_DEL_PATH,	OnCmdDelPath  )
	ON_BN_CLICKED( IDC_CHK_FILTER,		OnChkFilter	  )

	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDemoDlg message handlers

BOOL CDemoDlg::OnInitDialog( VOID )
{
	CDialog::OnInitDialog();

	// Shadow for XP

	ULONG ulStyle = ::GetClassLong( GetSafeHwnd(), GCL_STYLE );
	if( !( ulStyle & CS_DROPSHADOW ) )
		::SetClassLong( GetSafeHwnd(), GCL_STYLE, CS_DROPSHADOW );

// won't work with VC++ V6	
//	ULONG_PTR ulStyle = ::GetClassLongPtr( GetSafeHwnd(), GCL_STYLE );
//	if( !( ulStyle & CS_DROPSHADOW ) )
//		::SetClassLongPtr( GetSafeHwnd(), GCL_STYLE, CS_DROPSHADOW );

	// Set the icon for this dialog.  The framework does this automatically
	// when the application's main window is not a dialog

	SetIcon( m_hIcon, TRUE  ); // Set big icon
	SetIcon( m_hIcon, FALSE ); // Set small icon
	
	// TODO: Add extra initialization here
	
	m_wndLink.SetURL( 
		_T( "http://www.codeproject.com/dialog/cfolderdialog.asp" )
	);
	
	// Custom filtration:

#ifdef USE_XP_FILTRATION

	OSVERSIONINFO osvi = { sizeof( OSVERSIONINFO ) };
	
	if( ::GetVersionEx( &osvi ) )
	{
		if( osvi.dwPlatformId   == VER_PLATFORM_WIN32_NT &&
			osvi.dwMajorVersion >= 5 &&
			osvi.dwMinorVersion >= 1 )
		{
			m_wndChkFilter.EnableWindow( TRUE );	
		}
	}
	
#endif

	// Add tooltips for the dialog
	VERIFY( CreateToolTips() );

	return ( TRUE );
}

BOOL CDemoDlg::CreateToolTips( VOID )
{
	ASSERT_VALID( this );
	ASSERT( m_pToolTip == NULL );

	m_pToolTip = new CToolTipCtrl;
	ASSERT( m_pToolTip != NULL );

	if( m_pToolTip )
	{
		BOOL bCreated = m_pToolTip->Create( this );
		ASSERT( bCreated != FALSE );

		if( bCreated )
		{
			CRect rcMargins( 3, 3, 3, 3 );
			m_pToolTip->SetMargin( &rcMargins );

			VERIFY( m_pToolTip->AddTool( &m_wndBtnBrwsRoot, m_wndBtnBrwsRoot.GetDlgCtrlID() ) );
			VERIFY( m_pToolTip->AddTool( &m_wndBtnDelRoot,	m_wndBtnDelRoot.GetDlgCtrlID()  ) );
			VERIFY( m_pToolTip->AddTool( &m_wndBtnBrwsPath, m_wndBtnBrwsPath.GetDlgCtrlID() ) );
			VERIFY( m_pToolTip->AddTool( &m_wndBtnDelPath,	m_wndBtnDelPath.GetDlgCtrlID()	) );
			VERIFY( m_pToolTip->AddTool( &m_wndFilter,		m_wndFilter.GetDlgCtrlID()		) );
			VERIFY( m_pToolTip->AddTool( &m_wndChkFilter,	m_wndChkFilter.GetDlgCtrlID()	) );

			VERIFY( m_pToolTip->AddTool( &m_wndRoot,		m_wndRoot.GetDlgCtrlID()		) );
			VERIFY( m_pToolTip->AddTool( &m_wndPath,		m_wndRoot.GetDlgCtrlID()		) );
			VERIFY( m_pToolTip->AddTool( &m_wndName,		m_wndRoot.GetDlgCtrlID()		) );
			
			CWnd* pWndTmp = GetDlgItem( IDOK );
			ASSERT( pWndTmp != NULL );

			if( pWndTmp )
				VERIFY( m_pToolTip->AddTool( pWndTmp, pWndTmp->GetDlgCtrlID() ) );

			m_pToolTip->Activate( TRUE );
			return ( TRUE );
		}
	}

	return ( FALSE );
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

VOID CDemoDlg::OnPaint( VOID ) 
{
	if ( IsIconic() )
	{
		CPaintDC dc( this ); // device context for painting

		SendMessage( WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0 );

		// Center icon in client rectangle
		INT cxIcon = ::GetSystemMetrics( SM_CXICON );
		INT cyIcon = ::GetSystemMetrics( SM_CYICON );
		
		CRect rect;
		GetClientRect( &rect );

		INT x = ( rect.Width()  - cxIcon + 1 ) / 2;
		INT y = ( rect.Height() - cyIcon + 1 ) / 2;

		// Draw the icon
		dc.DrawIcon( x, y, m_hIcon );
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
// the minimized window.

HCURSOR CDemoDlg::OnQueryDragIcon( VOID )
{
	return (HCURSOR) m_hIcon;
}

VOID CDemoDlg::OnCmdBrwsRoot( VOID ) 
{
	UpdateData();
	
	LPCTSTR lpszTitle = _T( "Select the root folder for the browse dialog:" );
	UINT	uFlags	  = BIF_RETURNONLYFSDIRS | BIF_USENEWUI;
	
	CFolderDialog dlgRoot( lpszTitle, m_strRoot, this, uFlags );
		
	if( dlgRoot.DoModal() == IDOK )
	{
		m_strRoot = dlgRoot.GetFolderPath();		
		UpdateData( FALSE );
	}

	if( m_pToolTip )
		m_pToolTip->UpdateTipText( m_strRoot, &m_wndRoot );

	m_wndBtnDelRoot.EnableWindow( !m_strRoot.IsEmpty() );
}

VOID CDemoDlg::OnCmdBrwsPath( VOID ) 
{
	UpdateData();
	
	LPCTSTR lpszTitle = _T( "Select the folder you like best of all:" );
	UINT	uFlags	  = BIF_RETURNONLYFSDIRS | BIF_USENEWUI;

	CFolderDialog* pFolderDlg = NULL;

#ifdef USE_XP_FILTRATION
	
	if( m_bFilter == FALSE )	
	{

#endif USE_XP_FILTRATION
		
		pFolderDlg = new CFolderDialog( 
			lpszTitle, m_strPath, this, uFlags
		);

#ifdef USE_XP_FILTRATION

	}	
	else
	{
		pFolderDlg = (CFolderDialog*)new CFilteredFolderDialog( lpszTitle, m_strPath, 
			this, uFlags | BIF_BROWSEINCLUDEFILES );
		
		( (CFilteredFolderDialog*)pFolderDlg )->SetFilter( m_strFilter );
	}

#endif // USE_XP_FILTRATION
	
	ASSERT( pFolderDlg != NULL );

	if( pFolderDlg != NULL )
	{
		if( !m_strRoot.IsEmpty() )
			pFolderDlg->SetRootFolder( m_strRoot );
		else
			pFolderDlg->SetRootFolder( NULL );

		if( pFolderDlg->DoModal() == IDOK )
		{
			m_strPath = pFolderDlg->GetFolderPath();
			m_strName = pFolderDlg->GetFolderName();			
			
			UpdateData( FALSE );

			if( m_pToolTip )
			{
				m_pToolTip->UpdateTipText( m_strPath, &m_wndPath );
				m_pToolTip->UpdateTipText( m_strName, &m_wndName );
			}

			SetItemIcon( m_strPath );	
		}

		SAFE_DELETE( pFolderDlg );		
	}

	m_wndBtnDelPath.EnableWindow( !m_strPath.IsEmpty() );
}

VOID CDemoDlg::SetItemIcon( IN LPCTSTR pszPath )
{
	SHFILEINFO shfi = { 0 };

	if( pszPath != NULL )
	{
		ASSERT( AfxIsValidString( pszPath, MAX_PATH ) );

		HIMAGELIST hIml = (HIMAGELIST)::SHGetFileInfo( 
			pszPath, FILE_ATTRIBUTE_NORMAL, 
			&shfi, sizeof( SHFILEINFO ), SHGFI_SYSICONINDEX
		);

		if( hIml != NULL )
		{
			shfi.hIcon = ::ImageList_ExtractIcon( NULL, hIml, shfi.iIcon );
			hIml = NULL;
		}
	}

	::DestroyIcon( m_wndIcon.SetIcon( shfi.hIcon ) );
}

VOID CDemoDlg::OnCmdDelRoot( VOID ) 
{
	m_strRoot.Empty();
	UpdateData( FALSE );

	if( m_pToolTip )
		m_pToolTip->UpdateTipText( m_strRoot, &m_wndRoot );

	m_wndBtnDelRoot.EnableWindow( !m_strRoot.IsEmpty() );
}

VOID CDemoDlg::OnCmdDelPath( VOID ) 
{
	m_strPath.Empty();
	m_strName.Empty();	
	UpdateData( FALSE );

	SetItemIcon( NULL );

	if( m_pToolTip )
	{
		m_pToolTip->UpdateTipText( m_strPath, &m_wndPath );
		m_pToolTip->UpdateTipText( m_strName, &m_wndName );
	}

	m_wndBtnDelPath.EnableWindow( !m_strPath.IsEmpty() );
}

VOID CDemoDlg::OnChkFilter( VOID ) 
{
	m_wndFilter.EnableWindow( m_wndChkFilter.GetCheck() == BST_CHECKED );	
}

BOOL CDemoDlg::PreTranslateMessage( IN MSG* pMsg ) 
{
	if( m_pToolTip )
		m_pToolTip->RelayEvent( pMsg );

	return CDialog::PreTranslateMessage( pMsg );
}
