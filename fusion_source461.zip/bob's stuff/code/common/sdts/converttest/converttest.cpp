#ifndef INCLUDED_CONVERTTEST_H
#include "converttest.h"
#endif

#ifdef WIN32
#include <winsock2.h>
#else
#include <netinet/in.h>
#endif

#include <time.h>

#ifndef INCLUDED_SIO_CONVERTER_H
#include "io/sio_Converter.h"
#endif

#ifndef INCLUDED_SIO_8211UTILS_H
#include "io/sio_8211Utils.h"
#endif

#ifndef INCLUDED_SC_SUBFIELD_H
#include "container/sc_Subfield.h"
#endif

#ifndef INCLUDED_SIO_8211CONVERTER_H
#include "io/sio_8211Converter.h"
#endif

#ifndef INCLUDED_SIO_BUFFER_H
#include "io/sio_Buffer.h"
#endif

int main(void)
{
   sc_Subfield* test1 = new sc_Subfield;
   sio_8211Converter_BI8* ConverterBI8 = new sio_8211Converter_BI8;
   sio_8211Converter_BI16* ConverterBI16 = new sio_8211Converter_BI16;
   sio_8211Converter_BI24* ConverterBI24 = new sio_8211Converter_BI24;
   sio_8211Converter_BI32* ConverterBI32 = new sio_8211Converter_BI32;
   sio_8211Converter_BUI8* ConverterBUI8 = new sio_8211Converter_BUI8;
   sio_8211Converter_BUI16* ConverterBUI16 = new sio_8211Converter_BUI16;
   sio_8211Converter_BUI24* ConverterBUI24 = new sio_8211Converter_BUI24;
   sio_8211Converter_BUI32* ConverterBUI32 = new sio_8211Converter_BUI32;
   sio_8211Converter_BFP32* ConverterBFP32 = new sio_8211Converter_BFP32;
   sio_8211Converter_I* ConverterI = new sio_8211Converter_I;
   sio_8211Converter_R* ConverterR = new sio_8211Converter_R;
   sio_8211Converter_S* ConverterS = new sio_8211Converter_S;
   sio_Buffer* Buffer = new sio_Buffer;
   char foo[11] = "1234567";
   char* const bar = foo;
   const char* baz;
   long retval, passval;
   unsigned long upassval, i, j = 0;

// Tests for I, R and S are not exhaustive; such a test would not be
// feasible. They are here only as a trivial sort of test.
   cout << "Starting I Converter test. \n";
   retval = ConverterI->makeFixedSubfield(test1, foo, 7);
   retval = ConverterI->addSubfield(*test1, *Buffer);
   baz = Buffer->data();
   cout << "Started with " << foo << ".\n";
   cout << "Ended with ";
   cout.write(baz, 7);
   cout << ".\n";

   cout << "Starting R Converter test. \n";
   Buffer->reset();
   retval = ConverterR->makeFixedSubfield(test1, "123.456", 7);
   retval = ConverterR->addSubfield(*test1, *Buffer);
   baz = Buffer->data();
   cout << "Started with 123.456.\n";
   cout << "Ended with ";
   cout.write(baz, 7);
   cout << ".\n";

   cout << "Starting S Converter test. \n";
   Buffer->reset();
   retval = ConverterS->makeFixedSubfield(test1, "123.456", 7);
   retval = ConverterS->addSubfield(*test1, *Buffer);
   baz = Buffer->data();
   cout << "Started with 123.456.\n";
   cout << "Ended with ";
   cout.write(baz, 15);
   cout << ".\n";

   cout << "Starting BI8 Converter test.\n";
   for(i = 0; i < 255; i++)
   {
     foo[0] = (char) i;
     retval = ConverterBI8->makeFixedSubfield(test1, foo, 8);
     if( test1->getBI8(passval))
     { if((char)passval != (char)i)
       {
	 cout << "Bad comparison: " << i << " != " << passval << "\n";
       }
     }
     else
     {
	 cout << "Bad Conversion!\n";
     }
   }

   cout << "Starting BI16 Converter test.\n";
//   for(i = 0; i < 65535; i++)
   for(i = 0; i < ((1 << 16) - 1); i++)
   {
     foo[0] = (char) ((i >> 8) & 0xFF);
     foo[1] = (char) i;
     foo[2] = 0;
     Buffer->reset();
     retval = ConverterBI16->makeFixedSubfield(test1, foo, 16);
     retval = ConverterBI16->addSubfield(*test1, *Buffer);
     baz = Buffer->data();
     j = ((unsigned char)baz[0] << 8) + (unsigned char)baz[1];
     if(j != i)
     {
	 cout << "Bad comparison: " << i << " != " << j << "\n";
     }
   }

   cout << "Starting BI24 Converter test.\n";
//   for(i = 0; i < 16777215; i++)
   for(i = 0; i < ((1 << 24) - 1); i++)
   {
     foo[0] = (unsigned char) ((i >> 16) & 0xFF);
     foo[1] = (unsigned char) ((i >> 8) & 0xFF);
     foo[2] = (unsigned char) i;
     foo[3] = 0;
     Buffer->reset();
     retval = ConverterBI24->makeFixedSubfield(test1, foo, 24);
     retval = ConverterBI24->addSubfield(*test1, *Buffer);
     baz = Buffer->data();
     j = ((unsigned char)baz[0] << 16) + ((unsigned char)baz[1] << 8) +
	 (unsigned char)baz[2];
     if(j != i)
     {
	 cout << "Bad comparison: " << i << " != " << j << "\n";
     }
   }

   cout << "Starting BI32 Converter test.\n";
   time_t end, start = time(0);
   cout << "Start time: " << start << "\n"; // Included for benchmarking purposes.
//   for(i = 0; i < 4294967295; i++)
   for(i = 0; i < 0xFFFFFFFF; i++)
   {
     foo[0] = (unsigned char) (i >> 24);
     foo[1] = (unsigned char) (i >> 16);
     foo[2] = (unsigned char) (i >> 8);
     foo[3] = (unsigned char) (i);
     foo[4] = 0;
     Buffer->reset();
     retval = ConverterBI32->makeFixedSubfield(test1, foo, 32);
     retval = ConverterBI32->addSubfield(*test1, *Buffer);
     baz = Buffer->data();
     j = ((unsigned char)baz[0] << 24) + ((unsigned char)baz[1] << 16) +
	 ((unsigned char)baz[2] << 8) + (unsigned char)baz[3];
     if(j != i)
     {
	 cout << "Bad comparison: " << i << " != " << j << "\n";
     }
     // This prints a '*' every time the code runs 2^24 tests. It's a progress
     // meter of sorts, because the entire test takes a fairish time to run.
     if((i & 0xFFFFFF) == 0)
     {
//	  cout << time(0) << "\n";
	 cout << "*" << flush;
     }
   }
   end = time(0);
   cout << "End time: " << end << "\n";
   cout << "Run time: " << end - start << "\n";
   double smee = end - start;
   smee = smee / 0xFF;
   cout << "Time per tick: " << smee << "\n";


   cout << "Starting BUI8 Converter test.\n";
   for(i = 0; i < 255; i++)
   {
     foo[0] = (char) i;
     retval = ConverterBUI8->makeFixedSubfield(test1, foo, 8);
     if( test1->getBUI8(upassval))
     { if((unsigned char)upassval != (unsigned char)i)
       {
	 cout << "Bad comparison: " << i << " != " << upassval << "\n";
       }
     }
     else
     {
	 cout << "Bad Conversion!\n";
     }
   }

   cout << "Starting BUI16 Converter test.\n";
   for(i = 0; i < 65535; i++)
   {
     foo[0] = (char) ((i >> 8) & 0xFF);
     foo[1] = (char) i;
     foo[2] = 0;
     Buffer->reset();
     retval = ConverterBUI16->makeFixedSubfield(test1, foo, 16);
     retval = ConverterBUI16->addSubfield(*test1, *Buffer);
     baz = Buffer->data();
     j = ((unsigned char)baz[0] << 8) + (unsigned char)baz[1];
     if(j != i)
     {
	 cout << "Bad comparison: " << i << " != " << j << "\n";
     }
   }

   cout << "Starting BUI24 Converter test.\n";
   for(i = 0; i < 16777215; i++)
   {
     foo[0] = (unsigned char) ((i >> 16) & 0xFF);
     foo[1] = (unsigned char) ((i >> 8) & 0xFF);
     foo[2] = (unsigned char) i;
     foo[3] = 0;
     Buffer->reset();
     retval = ConverterBUI24->makeFixedSubfield(test1, foo, 24);
     retval = ConverterBUI24->addSubfield(*test1, *Buffer);
     baz = Buffer->data();
     j = ((unsigned char)baz[0] << 16) + ((unsigned char)baz[1] << 8) +
	 (unsigned char)baz[2];
     if(j != i)
     {
	 cout << "Bad comparison: " << i << " != " << j << "\n";
     }
   }

   cout << "Starting BUI32 Converter test.\n";
   for(i = 0; i < 4294967295; i++)
   {
     foo[0] = (unsigned char) (i >> 24);
     foo[1] = (unsigned char) (i >> 16);
     foo[2] = (unsigned char) (i >> 8);
     foo[3] = (unsigned char) (i);
     foo[4] = 0;
     Buffer->reset();
     retval = ConverterBUI32->makeFixedSubfield(test1, foo, 32);
     retval = ConverterBUI32->addSubfield(*test1, *Buffer);
     baz = Buffer->data();
     j = ((unsigned char)baz[0] << 24) + ((unsigned char)baz[1] << 16) +
	 ((unsigned char)baz[2] << 8) + (unsigned char)baz[3];
     if(j != i)
     {
	 cout << "Bad comparison: " << i << " != " << j << "\n";
     }
     if((i & 0xFFFFFF) == 0)
     {
//	  cout << time(0) << "\n";
	 cout << "*" << flush;
     }
   }

   cout << "\nStarting BFP32 test...\n";
   union
   {
      float fpnum;
      char  charval[4];
      long  debugval;
   } val1,val2;
   j = 0;
   for(i = 0; i < 4294967295; i++)
//   for(i = 0; i < 50000000; i++)
   {
      val1.debugval = i;
      Buffer->reset();
      retval = ConverterBFP32->makeFixedSubfield(test1, val1.charval, 32);
      retval = ConverterBFP32->addSubfield(*test1, *Buffer);
      baz = Buffer->data();
      val2.charval[0] = baz[0];
      val2.charval[1] = baz[1];
      val2.charval[2] = baz[2];
      val2.charval[3] = baz[3];
      if(val2.fpnum != val1.fpnum)
      {
	j++;
	cout << "Number out: " << val2.debugval << " Number in: " << val1.debugval;
	cout << "\n";
      }
      if((i & 0xFFFFFF) == 0)
      {
	 cout << "*" << flush;
      }
   }
   cout << j << " errors in a run of " << i << ".\n";

   delete test1;
   delete ConverterBI8;
   delete ConverterBI16;
   delete ConverterBI24;
   delete ConverterBI32;
   delete ConverterBUI8;
   delete ConverterBUI16;
   delete ConverterBUI24;
   delete ConverterBUI32;
   delete ConverterBFP32;
   return 0;
}
