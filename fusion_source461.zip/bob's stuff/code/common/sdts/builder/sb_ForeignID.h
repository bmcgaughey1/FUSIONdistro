//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//

#ifndef INCLUDED_SB_FOREIGNID_H
#define INCLUDED_SB_FOREIGNID_H

// $Id: sb_ForeignID.h,v 1.8 1998/08/24 20:47:47 mcoletti Exp $

#include <string>

#include <list>


#ifdef WIN32
using namespace std;
#endif


// Note that this is for a PACKED foreign id.  The Right Way (tm) to
// do this would be to have a base foreign id class that explicitly
// uses fields and subfields to hold the module name, record id, and
// usage modifier parameters; a packed foreign id class would merely
// be a subclass of that.  However, 99% of the time, we'll be using
// packed foreign id's, so I've only implemented that as the one
// foreign id class.

class sb_ForeignID
{
public:

  sb_ForeignID() {}

  sb_ForeignID( string const& mn,
                long id,
                string const& um ) 
    : _moduleName( mn ), _recordID( id ), _usageModifier( um ) {}

  sb_ForeignID( sb_ForeignID const& fid )
    : _moduleName( fid._moduleName ),
      _recordID( fid._recordID ),
      _usageModifier( fid._usageModifier ) {}


  string const& getModuleName() const { return _moduleName; }
  long getRecordID() const { return _recordID; }
  string const& getUsageModifier() const { return _usageModifier; }

  // assignes a foreign identifier string to the given string; returns false
  // if the module name, record id, and /or usage modifier are bogus
  bool get( string& );

  void setModuleName( string const& mn ) { _moduleName = mn; }
  void setRecordID( long id ) { _recordID = id; }
  void setUsageModifier( string const& um ) { _usageModifier = um; }

  sb_ForeignID& operator=( sb_ForeignID const& fid );

private:

  string _moduleName;
  long   _recordID;
  string _usageModifier;

}; // sb_ForeignID


typedef list<sb_ForeignID> foreign_ids; // typedef for foreign id container


#endif  // INCLUDED_SB_FOREIGNID_H
