// GeoreferencedImage.h: interface for the CGeoreferencedImage class.
//
// 3/28/2019 Fixed a problem with determining if the CGeoreferencedImage was valid by adding
// BOOL m_GeoInfoIsValid and BOOL m_ImageIsValid. Technically m_GeoInfoIsValid was present in 
// the code but it was never set (causing different behavior in Release and Debug builds due 
// to different initialization strategies).
//
// IsValid is inherited from the base CImage class but only checks the image...not the world file
// information 
//
// programs should check IsValid() and m_GeoInfoIsValid after creating a CGeoreferencedImage 
// object instead of just checking the m_GeoInfoIsValid flag
//
// Hopefully, this will solve the long-standing memory overwrite problem with the class.
//
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GEOREFERENCEDIMAGE_H__D1A4F21B_679E_451B_95C5_AEEE44E57285__INCLUDED_)
#define AFX_GEOREFERENCEDIMAGE_H__D1A4F21B_679E_451B_95C5_AEEE44E57285__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "image.h"
#include "WorldFile.h"	// Added by ClassView

#define		DUMMY_SIZE	128

class CGeoreferencedImage : public CImage
{
public:
	BOOL m_GeoInfoIsValid;
	BOOL m_ImageIsValid;

	double m_GEO_ULX;
	double m_GEO_ULY;
	double m_GEO_LRX;
	double m_GEO_LRY;
	CSize m_ImageSize;

	BOOL CropImage(double llx, double lly, double urx, double ury, LPCTSTR FileName);
	void MapImageToGeo(int imgx, int imgy, double& geox, double& geoy);
	void MapImageToGeo(long imgx, long imgy, double& geox, double& geoy);
	void MapImageToGeo(double imgx, double imgy, double &geox, double &geoy);
	void MapGeoToImage(double geox, double geoy, int& imgx, int& imgy, BOOL RoundDown = FALSE);
	void MapGeoToImage(double geox, double geoy, long& imgx, long& imgy, BOOL RoundDown = FALSE);
	BOOL ReadImage(LPCTSTR szFileName, BOOL CreatePalette = FALSE, BOOL ShowProgress = FALSE, int ColorOption = 1);
	BOOL IsValid();
	CWorldFile m_GeoreferenceInfo;		// original order...works with 64-bit release build
	CGeoreferencedImage();
	virtual ~CGeoreferencedImage();

//	CWorldFile m_GeoreferenceInfo;		// original order...works with 64-bit release build
//	int dummy1[DUMMY_SIZE];
//	int dummy2[DUMMY_SIZE];
};

#endif // !defined(AFX_GEOREFERENCEDIMAGE_H__D1A4F21B_679E_451B_95C5_AEEE44E57285__INCLUDED_)
