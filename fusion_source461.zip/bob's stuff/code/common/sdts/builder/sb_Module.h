//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//

#ifndef SB_MODULE_H
#define SB_MODULE_H

// $Id: sb_Module.h,v 1.8 1998/09/01 14:33:54 mcoletti Exp $

#ifdef WIN32
#pragma warning( disable : 4786 )
#endif

#include <string>


#ifndef INCLUDED_SIO8211FIELDFORMAT_H
#include "io/sio_8211FieldFormat.h"
#endif


class sc_Record;


// Consolidates common module attributes for the rest of the builder classes

class sb_Module
{
public:

  sb_Module() : _mnemonic(""), _id(1) {}

  virtual ~sb_Module() {}

  void getMnemonic( string & mnemonic ) const
    {
      mnemonic = _mnemonic;
    }

  int getID( ) const
    {
      return _id;
    }

  // maintained for backward compatibility
  string const & getModuleName(  ) const
    {
      return _mnemonic;
    }

  // maintained for backward compatibility
  int getRecordID( ) const
    {
      return _id;
    }


  void setMnemonic( string const & mnemonic ) 
    {
      _mnemonic = mnemonic;
    }

  void setID( int id )
    {
      _id = id;
    }

  // returns the schema associated with the module
  virtual bool getSchema( sio_8211Schema& schema ) const = 0;

  // fills the given record with proper fields and subfields for them module;
  // returns false if a mandatory field or subfield hasn't been given a
  // proper value
  virtual bool getRecord( sc_Record& ) const = 0;

  // sets the module with the fields and subfields found in the given sc_Record;
  // returns false if improper record for the module
  virtual bool setRecord( sc_Record const& ) = 0;

private:

  string _mnemonic;		// module mnemonic
  int    _id;			// module record number

  friend ostream& operator<<( ostream&, sb_Module const& );

}; // sb_Module

#endif
