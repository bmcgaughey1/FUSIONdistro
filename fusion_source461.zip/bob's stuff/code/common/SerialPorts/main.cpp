#include "stdafx.h"
#include "enumser.h"


void main()
{
  //Initialize COM (Required by CEnumerateSerial::UsingWMI)
  CoInitialize(NULL);

  //Initialize COM security (Required by CEnumerateSerial::UsingWMI)
  HRESULT hr = CoInitializeSecurity(NULL, -1, NULL, NULL, RPC_C_AUTHN_LEVEL_DEFAULT, RPC_C_IMP_LEVEL_IMPERSONATE, NULL, EOAC_NONE, NULL);
  if (FAILED(hr))
  {
    _tprintf(_T("Failed to initialize COM security, Error:%x\n"), hr);
    CoUninitialize();
    return;  
  }

#ifdef _AFX
  CUIntArray ports;
  INT_PTR i;
#else
  CSimpleArray<UINT> ports;
  int i;
#endif
  _tprintf(_T("CreateFile method reports\n"));
  if (CEnumerateSerial::UsingCreateFile(ports))
  {
    for (i=0; i<ports.GetSize(); i++)
      _tprintf(_T("COM%d\n"), ports[i]);
  }
  else
    _tprintf(_T("CEnumerateSerial::UsingCreateFile failed, Error:%d\n"), GetLastError());


  _tprintf(_T("QueryDosDevice method reports\n"));
  if (CEnumerateSerial::UsingQueryDosDevice(ports))
  {
    for (i=0; i<ports.GetSize(); i++)
      _tprintf(_T("COM%d\n"), ports[i]);
  }
  else
    _tprintf(_T("CEnumerateSerial::UsingQueryDosDevice failed, Error:%d\n"), GetLastError());


  _tprintf(_T("GetDefaultCommConfig method reports\n"));
  if (CEnumerateSerial::UsingGetDefaultCommConfig(ports))
  {
    for (i=0; i<ports.GetSize(); i++)
      _tprintf(_T("COM%d\n"), ports[i]);
  }
  else
    _tprintf(_T("CEnumerateSerial::UsingGetDefaultCommConfig failed, Error:%d\n"), GetLastError());

  _tprintf(_T("Device Manager (SetupAPI - GUID_DEVINTERFACE_COMPORT) reports\n"));
#ifdef _AFX  
  CStringArray sFriendlyNames;
#else
  CSimpleArray<CString> sFriendlyNames;
#endif
  if (CEnumerateSerial::UsingSetupAPI1(ports, sFriendlyNames))
  {
    for (i=0; i<ports.GetSize(); i++)
      _tprintf(_T("COM%d <%s>\n"), ports[i], sFriendlyNames[i].operator LPCTSTR());
  }
  else
    _tprintf(_T("CEnumerateSerial::UsingSetupAPI2 failed, Error:%d\n"), GetLastError());

  _tprintf(_T("Device Manager (SetupAPI - Ports Device information set) reports\n"));
  if (CEnumerateSerial::UsingSetupAPI2(ports, sFriendlyNames))
  {
    for (i=0; i<ports.GetSize(); i++)
      _tprintf(_T("COM%d <%s>\n"), ports[i], sFriendlyNames[i]);
  }
  else
    _tprintf(_T("CEnumerateSerial::UsingSetupAPI2 failed, Error:%d\n"), GetLastError());

  _tprintf(_T("EnumPorts method reports\n"));
  if (CEnumerateSerial::UsingEnumPorts(ports))
  {
    for (i=0; i<ports.GetSize(); i++)
      _tprintf(_T("COM%d\n"), ports[i]);
  }
  else
    _tprintf(_T("CEnumerateSerial::UsingEnumPorts failed, Error:%d\n"), GetLastError());

  _tprintf(_T("WMI method reports\n"));
  if (CEnumerateSerial::UsingWMI(ports, sFriendlyNames))
  {
    for (i=0; i<ports.GetSize(); i++)
      _tprintf(_T("COM%d <%s>\n"), ports[i], sFriendlyNames[i].operator LPCTSTR());
  }
  else
    _tprintf(_T("CEnumerateSerial::UsingWMI failed, Error:%d\n"), GetLastError());

  //Close down COM
  CoUninitialize();
}