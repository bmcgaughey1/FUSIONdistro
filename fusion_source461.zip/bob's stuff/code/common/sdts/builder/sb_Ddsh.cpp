//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//
// $Id: sb_Ddsh.cpp,v 1.11 1998/10/13 13:57:56 mcoletti Exp $
//

#ifdef WIN32
#pragma warning(disable: 4786)	// stupid warning that debug string exceeds 255
#endif

#include "builder/sb_Ddsh.h"



#include <iostream>
#include <strstream>

#include <limits.h>
#include <float.h>

#ifndef INCLUDED_SB_UTILS_H
#include "builder/sb_Utils.h"
#endif

#ifndef INCLUDED_SB_FOREIGNID_H
#include "builder/sb_ForeignID.h"
#endif

#ifndef INCLUDED_SC_RECORD_H
#include "container/sc_Record.h"
#endif

#ifndef INCLUDED_SC_FIELD_H
#include "container/sc_Field.h"
#endif

#ifndef INCLUDED_SC_SUBFIELD_H
#include "container/sc_Subfield.h"
#endif

#ifndef INCLUDED_SIO_8211CONVERTER_H
#include "io/sio_8211Converter.h"
#endif



static const char* _ident = "$Id: sb_Ddsh.cpp,v 1.11 1998/10/13 13:57:56 mcoletti Exp $";

// Strings and integers are initialized with these values; they are used
// to indicate whether a given module value has been assigned a value or not.

// (XXX I arbitrarily chose 0x4 as the sentinal value.  I hate ad hoc crap.)

static const string  UNVALUED_STRING(1, static_cast<string::value_type>(0x4) );

static const long    UNVALUED_LONG   = INT_MIN;

static const double  UNVALUED_DOUBLE = DBL_MAX;

static set<string> TYPE_domain;
static set<string> KEY_domain;



struct sb_Ddsh_Imp
{
  string   _Name;
  string   _Type;
  string   _EntityLabel;
  string   _EntityAuthority;
  string   _AttributeLabel;
  string   _AttributeAuthority;
  string   _Format;
  string   _Unit;
  double   _Precision;
  long     _MaximumSubfieldLength;
  string   _Key;


  sb_Ddsh_Imp()
    : 
    _Name( UNVALUED_STRING ),
    _Type( UNVALUED_STRING ),
    _EntityLabel( UNVALUED_STRING ),
    _EntityAuthority( UNVALUED_STRING ),
    _AttributeLabel( UNVALUED_STRING ),
    _AttributeAuthority( UNVALUED_STRING ),
    _Format( UNVALUED_STRING ),
    _Unit( UNVALUED_STRING ),
    _Precision( UNVALUED_DOUBLE ),
    _MaximumSubfieldLength( UNVALUED_LONG ),
    _Key( UNVALUED_STRING )
    {}

};


sb_Ddsh::sb_Ddsh()
  : _imp( new sb_Ddsh_Imp() )
{
  setMnemonic("DDSH");
  setID( 1 );


  // initialize static domain types

  if ( TYPE_domain.empty() )
    {
      TYPE_domain.insert( "ATPR" );
      TYPE_domain.insert( "ATSC" );
      TYPE_domain.insert( "CELL" );
    }

  if ( KEY_domain.empty() )
    {
      KEY_domain.insert( "NOKEY" );
      KEY_domain.insert( "PKEY" );
      KEY_domain.insert( "FKEY" );
      KEY_domain.insert( "PFKEY" );
    }

} // Ddsh ctor


sb_Ddsh::~sb_Ddsh()
{
  free( _imp );
} // Ddsh dtor




static sio_8211Converter_I converter_I; // XXX should define these in
static sio_8211Converter_A converter_A; // XXX sio_8211Converter.h
static sio_8211Converter_R converter_R;

static sio_8211Schema _schema; // module specific schema

static
void
_build_schema( sio_8211Schema& schema )
{
  schema.clear();               // make sure we are starting with clean schema

  schema.push_back( sio_8211FieldFormat() );

  sio_8211FieldFormat& field_format = schema.back();

  field_format.setDataStructCode( sio_8211FieldFormat::vector );
  field_format.setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  field_format.setName( "Data Dictionary/Schema" );
  field_format.setTag( "DDSH" );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "MODN" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "RCID" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "NAME" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "TYPE" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "ETLB" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "EUTH" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "ATLB" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "AUTH" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "FMT" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "UNIT" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "PREC" );
  field_format.back().setType( sio_8211SubfieldFormat::R );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_R );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "MXLN" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "KEY" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


} // _build_schema


static
bool
_ingest_record( sb_Ddsh& ddsh, sb_Ddsh_Imp &ddsh_imp, sc_Record const& record )
{

  // Make sure we have a record from an
  // External Spatial Reference module.

  sc_FieldCntr::const_iterator curfield;

  if ( ! sb_Utils::getFieldByMnem( record,"DDSH",curfield) )
    {
#ifdef SDTSXX_DEBUG
      cerr << "sb_Ddsh::sb_Ddsh(sc_Record const&): "
           << "Not an data dictionary/schema record.";
      cerr << endl;
#endif
      return false;
    }


  // We have a primary field from a  module. Start// picking it apart.

  sc_SubfieldCntr::const_iterator cursubfield;

  string tmp_str;
  long   tmp_int;


  // MODN
  if (sb_Utils::getSubfieldByMnem(*curfield,"MODN",cursubfield))
    {
      cursubfield->getA( tmp_str );
      ddsh.setMnemonic( tmp_str );
    }


  // RCID
  if (sb_Utils::getSubfieldByMnem(*curfield,"RCID",cursubfield))
    {
      cursubfield->getI( tmp_int );
      ddsh.setID( tmp_int );
    }


  // NAME
  if (sb_Utils::getSubfieldByMnem(*curfield,"NAME",cursubfield))
    {
      cursubfield->getA( ddsh_imp._Name);
    }
  else
    {
      return false;
    }


  // TYPE
  if (sb_Utils::getSubfieldByMnem(*curfield,"TYPE",cursubfield))
    {
      cursubfield->getA( ddsh_imp._Type);
    }
  else
    {
      return false;
    }


  // ETLB
  if (sb_Utils::getSubfieldByMnem(*curfield,"ETLB",cursubfield))
    {
      cursubfield->getA( ddsh_imp._EntityLabel);
    }


  // EUTH
  if (sb_Utils::getSubfieldByMnem(*curfield,"EUTH",cursubfield))
    {
      cursubfield->getA( ddsh_imp._EntityAuthority);
    }


  // ATLB
  if (sb_Utils::getSubfieldByMnem(*curfield,"ATLB",cursubfield))
    {
      cursubfield->getA( ddsh_imp._AttributeLabel);
    }


  // AUTH
  if (sb_Utils::getSubfieldByMnem(*curfield,"AUTH",cursubfield))
    {
      cursubfield->getA( ddsh_imp._AttributeAuthority);
    }


  // FMT
  if (sb_Utils::getSubfieldByMnem(*curfield,"FMT",cursubfield))
    {
      cursubfield->getA( ddsh_imp._Format);
    }


  // UNIT
  if (sb_Utils::getSubfieldByMnem(*curfield,"UNIT",cursubfield))
    {
      cursubfield->getA( ddsh_imp._Unit);
    }


  // PREC
  if (sb_Utils::getSubfieldByMnem(*curfield,"PREC",cursubfield))
    {
      cursubfield->getR( ddsh_imp._Precision);
    }


  // MXLN
  if (sb_Utils::getSubfieldByMnem(*curfield,"MXLN",cursubfield))
    {
      cursubfield->getI( ddsh_imp._MaximumSubfieldLength);
    }


  // KEY
  if (sb_Utils::getSubfieldByMnem(*curfield,"KEY",cursubfield))
    {
      cursubfield->getA( ddsh_imp._Key);
    }


  return true;


} // _ingest_record




bool
sb_Ddsh::getName( string& val ) const
{
  if ( _imp->_Name == UNVALUED_STRING )
    return false;

  val = _imp->_Name;

  return true;
} // sb_Ddsh::getName


bool
sb_Ddsh::getType( string& val ) const
{
  if ( _imp->_Type == UNVALUED_STRING )
    return false;

  val = _imp->_Type;

  return true;
} // sb_Ddsh::getType


bool
sb_Ddsh::getEntityLabel( string& val ) const
{
  if ( _imp->_EntityLabel == UNVALUED_STRING )
    return false;

  val = _imp->_EntityLabel;

  return true;
} // sb_Ddsh::getEntityLabel


bool
sb_Ddsh::getEntityAuthority( string& val ) const
{
  if ( _imp->_EntityAuthority == UNVALUED_STRING )
    return false;

  val = _imp->_EntityAuthority;

  return true;
} // sb_Ddsh::getEntityAuthority


bool
sb_Ddsh::getAttributeLabel( string& val ) const
{
  if ( _imp->_AttributeLabel == UNVALUED_STRING )
    return false;

  val = _imp->_AttributeLabel;

  return true;
} // sb_Ddsh::getAttributeLabel


bool
sb_Ddsh::getAttributeAuthority( string& val ) const
{
  if ( _imp->_AttributeAuthority == UNVALUED_STRING )
    return false;

  val = _imp->_AttributeAuthority;

  return true;
} // sb_Ddsh::getAttributeAuthority


bool
sb_Ddsh::getFormat( string& val ) const
{
  if ( _imp->_Format == UNVALUED_STRING )
    return false;

  val = _imp->_Format;

  return true;
} // sb_Ddsh::getFormat


bool
sb_Ddsh::getUnit( string& val ) const
{
  if ( _imp->_Unit == UNVALUED_STRING )
    return false;

  val = _imp->_Unit;

  return true;
} // sb_Ddsh::getUnit


bool
sb_Ddsh::getPrecision( double& val ) const
{
  if ( _imp->_Precision == UNVALUED_DOUBLE )
    return false;

  val = _imp->_Precision;

  return true;
} // sb_Ddsh::getPrecision


bool
sb_Ddsh::getMaximumSubfieldLength( long& val ) const
{
  if ( _imp->_MaximumSubfieldLength == UNVALUED_LONG )
    return false;

  val = _imp->_MaximumSubfieldLength;

  return true;
} // sb_Ddsh::getMaximumSubfieldLength


bool
sb_Ddsh::getKey( string& val ) const
{
  if ( _imp->_Key == UNVALUED_STRING )
    return false;

  val = _imp->_Key;

  return true;
} // sb_Ddsh::getKey


bool
sb_Ddsh::getSchema( sio_8211Schema& schema ) const
{
  // If the schema hasn't been
  // initialized, please do so.

  if ( _schema.empty() )
    {
      _build_schema( _schema );
    }

  if ( _schema.empty() )   // oops ... something screwed up
    {
      return false;
    }

  schema = _schema;

  return true;

} // sb_Ddsh::getSchema




bool
sb_Ddsh::getRecord( sc_Record & record ) const
{
  record.clear();               // start with a clean slate

  // first field, which contains module name and record number

  record.push_back( sc_Field() );

  record.back().setMnemonic( "DDSH" );
  record.back().setName( "Data Dictionary/Schema" );

  string tmp_str;
  double tmp_double;
  long   tmp_long;

  getMnemonic( tmp_str );
  sb_Utils::add_subfield( record.back(), "MODN", tmp_str );
  sb_Utils::add_subfield( record.back(), "RCID", getID() );

  if ( getName( tmp_str) )
    {
      sb_Utils::add_subfield( record.back(),"NAME", tmp_str );
    }
  else
    {
      return false;
    }


  if ( getType( tmp_str) )
    {

      if ( sb_Utils::valid_domain( tmp_str, TYPE_domain ) )
        {
          sb_Utils::add_subfield( record.back(),"TYPE", tmp_str );
        }
      else
        {
          return false;
        }
    }
  else
    {
      sb_Utils::add_empty_subfield( record.back(),"TYPE", sc_Subfield::is_A );
    }

  if ( getEntityLabel( tmp_str) )
    {
      sb_Utils::add_subfield( record.back(),"ETLB", tmp_str );
    }
  else
    {
      sb_Utils::add_empty_subfield( record.back(),"ETLB", sc_Subfield::is_A );
    }

  if ( getEntityAuthority( tmp_str) )
    {
      sb_Utils::add_subfield( record.back(),"EUTH", tmp_str );
    }
  else
  {
      sb_Utils::add_empty_subfield( record.back(),"EUTH", sc_Subfield::is_A );
  }

  if ( getAttributeLabel( tmp_str) )
    {
      sb_Utils::add_subfield( record.back(),"ATLB", tmp_str );
    }
  else
  {
      sb_Utils::add_empty_subfield( record.back(),"ATLB", sc_Subfield::is_A );
  }

  if ( getAttributeAuthority( tmp_str) )
    {
      sb_Utils::add_subfield( record.back(),"AUTH", tmp_str );
    }
  else
  {
      sb_Utils::add_empty_subfield( record.back(),"AUTH", sc_Subfield::is_A );
  }

  if ( getFormat( tmp_str) )
    {
      sb_Utils::add_subfield( record.back(),"FMT", tmp_str );
    }
  else
  {
      sb_Utils::add_empty_subfield( record.back(),"FMT", sc_Subfield::is_A );
  }

  if ( getUnit( tmp_str) )
    {
      sb_Utils::add_subfield( record.back(),"UNIT", tmp_str );
    }
  else
  {
      sb_Utils::add_empty_subfield( record.back(),"UNIT" , sc_Subfield::is_A);
  }

  if ( getPrecision( tmp_double) )
    {
      sb_Utils::add_subfield( record.back(),"PREC", tmp_double );
    }
  else
  {
      sb_Utils::add_empty_subfield( record.back(),"PREC", sc_Subfield::is_R );
  }

  if ( getMaximumSubfieldLength( tmp_long) )
    {
      sb_Utils::add_subfield( record.back(),"MXLN", tmp_long );
    }
  else
  {
      sb_Utils::add_empty_subfield( record.back(),"MXLN", sc_Subfield::is_I );
  }

  if ( getKey( tmp_str) )
    {
      if ( sb_Utils::valid_domain( tmp_str, KEY_domain ) )
        {
          sb_Utils::add_subfield( record.back(),"KEY", tmp_str );
        }
      else
        {
          return false;
        }
    }
  else
  {
    sb_Utils::add_empty_subfield( record.back(),"MXLN", sc_Subfield::is_A );
  }

  return true;


} // Ddsh::getRecord




bool
sb_Ddsh::setName( string const& val )
{
  _imp->_Name = val;

  return true;
} // sb_Ddsh::setName


bool
sb_Ddsh::setType( string const& val )
{
  if ( sb_Utils::valid_domain( val, TYPE_domain ) )
    _imp->_Type = val;
  else
    return false;

  return true;
} // sb_Ddsh::setType


bool
sb_Ddsh::setEntityLabel( string const& val )
{
  _imp->_EntityLabel = val;

  return true;
} // sb_Ddsh::setEntityLabel


bool
sb_Ddsh::setEntityAuthority( string const& val )
{
  _imp->_EntityAuthority = val;

  return true;
} // sb_Ddsh::setEntityAuthority


bool
sb_Ddsh::setAttributeLabel( string const& val )
{
  _imp->_AttributeLabel = val;

  return true;
} // sb_Ddsh::setAttributeLabel


bool
sb_Ddsh::setAttributeAuthority( string const& val )
{
  _imp->_AttributeAuthority = val;

  return true;
} // sb_Ddsh::setAttributeAuthority


bool
sb_Ddsh::setFormat( string const& val )
{
  _imp->_Format = val;

  return true;
} // sb_Ddsh::setFormat


bool
sb_Ddsh::setUnit( string const& val )
{
  _imp->_Unit = val;

  return true;
} // sb_Ddsh::setUnit


bool
sb_Ddsh::setPrecision( double val )
{
  _imp->_Precision = val;

  return true;
} // sb_Ddsh::setPrecision


bool
sb_Ddsh::setMaximumSubfieldLength( long val )
{
  _imp->_MaximumSubfieldLength = val;

  return true;
} // sb_Ddsh::setMaximumSubfieldLength


bool
sb_Ddsh::setKey( string const& val )
{
  if ( sb_Utils::valid_domain( val, KEY_domain ) )
    _imp->_Key = val;
  else
    return false;

  return true;
} // sb_Ddsh::setKey


bool
sb_Ddsh::setRecord( sc_Record const& record )
{
  return _ingest_record( *this, *_imp, record );
} // sb_Ddsh::setRecord



void
sb_Ddsh::unDefineName( )
{
_imp->_Name = UNVALUED_STRING;
} // sb_Ddsh::unDefineName


void
sb_Ddsh::unDefineType( )
{
_imp->_Type = UNVALUED_STRING;
} // sb_Ddsh::unDefineType


void
sb_Ddsh::unDefineEntityLabel( )
{
_imp->_EntityLabel = UNVALUED_STRING;
} // sb_Ddsh::unDefineEntityLabel


void
sb_Ddsh::unDefineEntityAuthority( )
{
_imp->_EntityAuthority = UNVALUED_STRING;
} // sb_Ddsh::unDefineEntityAuthority


void
sb_Ddsh::unDefineAttributeLabel( )
{
_imp->_AttributeLabel = UNVALUED_STRING;
} // sb_Ddsh::unDefineAttributeLabel


void
sb_Ddsh::unDefineAttributeAuthority( )
{
_imp->_AttributeAuthority = UNVALUED_STRING;
} // sb_Ddsh::unDefineAttributeAuthority


void
sb_Ddsh::unDefineFormat( )
{
_imp->_Format = UNVALUED_STRING;
} // sb_Ddsh::unDefineFormat


void
sb_Ddsh::unDefineUnit( )
{
_imp->_Unit = UNVALUED_STRING;
} // sb_Ddsh::unDefineUnit


void
sb_Ddsh::unDefinePrecision( )
{
_imp->_Precision = UNVALUED_DOUBLE;
} // sb_Ddsh::unDefinePrecision


void
sb_Ddsh::unDefineMaximumSubfieldLength( )
{
_imp->_MaximumSubfieldLength = UNVALUED_LONG;
} // sb_Ddsh::unDefineMaximumSubfieldLength


void
sb_Ddsh::unDefineKey( )
{
_imp->_Key = UNVALUED_STRING;
} // sb_Ddsh::unDefineKey


