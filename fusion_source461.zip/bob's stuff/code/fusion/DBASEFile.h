// DBASEFile.h: interface for the CDBASEFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DBASEFILE_H__A1A95660_7261_11D3_8544_006094974311__INCLUDED_)
#define AFX_DBASEFILE_H__A1A95660_7261_11D3_8544_006094974311__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDBASEFile  
{
public:
	typedef enum {
	  FTString,
	  FTInteger,
	  FTDouble,
	  FTInvalid
	} DBFFieldType;

public:
	BOOL WriteNULLAttribute(int iRecord, int iField);
	BOOL WriteStringAttribute(int iRecord, int iField, const char* pszValue);
	BOOL WriteIntegerAttribute(int iRecord, int iField, int nValue);
	BOOL WriteDoubleAttribute(int iRecord, int iField, double dValue);
	int AddField(const char * pszFieldName, int eType, int nWidth, int nDecimals);
	BOOL Create(LPCTSTR szFileName);
	void FlushRecord();
	void WriteHeader();
	void GoToFirstRecord();
	BOOL FillListCtrlWithFieldNames(CComboBox* list, int SelectedField = 0);
	BOOL ReadAsStringAttribute(int iRecord, int iField, CString& Value);
	BOOL ReadStringAttribute(int iRecord, int iField, CString& Value);
	BOOL ReadDoubleAttribute(int iRecord, int iField, double& Value);
	BOOL ReadIntegerAttribute(int iRecord, int iField, int& Value);
	int GetFieldInfo(int iField, char* pszFieldName = NULL, int* pnWidth = NULL, int* pnDecimals = NULL);
	int GetRecordCount();
	int GetFieldCount();
	void Close();
	BOOL Open(LPCTSTR szFileName, BOOL WriteCapability = FALSE);
	BOOL IsValid();
	CDBASEFile();
	CDBASEFile(LPCTSTR szFileName);
	virtual ~CDBASEFile();

private:
	void* ReallocateSpace(void* pMem, int nNewSize);
	char* pszFieldBuffer;
	void* ReadAttribute(int iRecord, int iField);
	int WriteAttribute(int hEntity, int iField, void * pValue);
	BOOL bUpdated;
	BOOL bNoHeader;
	char* pszCurrentRecord;
	BOOL bCurrentRecordModified;
	int nCurrentRecord;
	char* pszHeader;
	char* pachFieldType;
	int* panFieldDecimals;
	int* panFieldSize;
	int* panFieldOffset;
	int nFields;
	int nHeaderLength;
	int nRecordLength;
	int nRecords;
	FILE* fp;
	BOOL m_Valid;
};

#endif // !defined(AFX_DBASEFILE_H__A1A95660_7261_11D3_8544_006094974311__INCLUDED_)
