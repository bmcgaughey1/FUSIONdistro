// ASCIIGridFile.h: interface for the CASCIIGridFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ASCIIGRIDFILE_H__03678937_E87C_4A34_B920_2C7CEC6DE6E4__INCLUDED_)
#define AFX_ASCIIGRIDFILE_H__03678937_E87C_4A34_B920_2C7CEC6DE6E4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataFile.h"

class CASCIIGridFile : public CDataFile  
{
public:
	BOOL LoadNextRow(void);
	double ReadInternalValue(int row, int col);
	void DiscardValues();
	BOOL LoadValues();
	BOOL IsGoodFile();
	BOOL ConvertToPLANS(LPCSTR PlansDTMFileName, int XYUnits = 0, int ZUnits = 0, double XYFactor = 1.0, double ZFactor = 1.0, int Projection = -1, int Zone = 0, BOOL UseDoublePrecision = FALSE, int HorizontalDatum = -1, int VerticalDatum = -1, double Zoffset = 0.0, BOOL UseNANLogic = FALSE);
	BOOL ReadHeader();
	CASCIIGridFile(LPCTSTR FileName);
	virtual ~CASCIIGridFile();

	BOOL m_HaveValuesLoaded;// data values are loaded into memory
	BOOL m_HaveRowLoaded;	// data values for a single row are loaded into memory
	BOOL m_LLIsCenter;		// TRUE if m_LLX and m_LLY are for center of LL cell
	int m_Columns;			// number of columns
	int m_Rows;				// number of rows
	double m_LLX;			// may be center or corner of LL cell
	double m_LLY;			// may be center or corner of LL cell
	double m_OriginX;		// always LL corner
	double m_OriginY;		// always LL corner
	double m_MaxVal;		// maximum value
	double m_MinVal;		// minimum value
	double m_CellSize;		// size of cell...always square
	double m_NODATA;		// value used to flag void areas
	double** m_Values;		// start memory for values when loaded
	double* m_RowValues;	// memory for single row of data

private:
	int m_HeaderLines;		// number of lines in the header
	BOOL m_HeaderValid;		// flag indicating header has been read and is valid
};
#endif // !defined(AFX_ASCIIGRIDFILE_H__03678937_E87C_4A34_B920_2C7CEC6DE6E4__INCLUDED_)
