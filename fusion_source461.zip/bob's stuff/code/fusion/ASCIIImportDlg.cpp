// ASCIIImportDlg.cpp : implementation file
//

#include "stdafx.h"
#include <io.h>
#include "fusion.h"
#include "ASCIIImportDlg.h"
#include "LidarData_laslib.h"
#include "inifile.h"
#include "datafile.h"
#include "Dataindex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CASCIIImportDlg dialog


CASCIIImportDlg::CASCIIImportDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CASCIIImportDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CASCIIImportDlg)
	m_StartingRow = 1;
	m_UseTab = TRUE;
	m_UseSpace = TRUE;
	m_UseComma = TRUE;
	m_UseOther = FALSE;
	m_OtherDelimiter = _T("");
	m_OutputFileName = _T("");
	m_InputFileName = _T("");
	m_Field_X = 1;
	m_Field_Y = 2;
	m_Field_Elevation = 3;
	m_Field_PulseNumber = 0;
	m_Field_ReturnNumber = 0;
	m_Field_Intensity = 4;
	m_Field_ReturnsPerPulse = 0;
	m_Field_ScanAngle = 0;
	m_MergeDelimiters = TRUE;
	m_CreateIndex = TRUE;
	m_IgnoreNegativeReturns = TRUE;
	m_ImportSelectedReturns = FALSE;
	m_ReturnsToImport = _T("");
	//}}AFX_DATA_INIT
}


void CASCIIImportDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CASCIIImportDlg)
	DDX_Text(pDX, IDC_STARTINGROW, m_StartingRow);
	DDV_MinMaxInt(pDX, m_StartingRow, 1, 100);
	DDX_Check(pDX, IDC_USETAB, m_UseTab);
	DDX_Check(pDX, IDC_USESPACE, m_UseSpace);
	DDX_Check(pDX, IDC_USECOMMA, m_UseComma);
	DDX_Check(pDX, IDC_USEOTHER, m_UseOther);
	DDX_Text(pDX, IDC_OTHERDELIMITER, m_OtherDelimiter);
	DDX_Text(pDX, IDC_OUTPUTFILENAME, m_OutputFileName);
	DDX_Text(pDX, IDC_INPUTFILENAME, m_InputFileName);
	DDX_CBIndex(pDX, IDC_FIELDLIST_X, m_Field_X);
	DDX_CBIndex(pDX, IDC_FIELDLIST_Y, m_Field_Y);
	DDX_CBIndex(pDX, IDC_FIELDLIST_ELEVATION, m_Field_Elevation);
	DDX_CBIndex(pDX, IDC_FIELDLIST_PULSE, m_Field_PulseNumber);
	DDX_CBIndex(pDX, IDC_FIELDLIST_RETURN, m_Field_ReturnNumber);
	DDX_CBIndex(pDX, IDC_FIELDLIST_INTENSITY, m_Field_Intensity);
	DDX_CBIndex(pDX, IDC_FIELDLIST_RETURNS_PER_PULSE, m_Field_ReturnsPerPulse);
	DDX_CBIndex(pDX, IDC_FIELDLIST_SCAN_ANGLE, m_Field_ScanAngle);
	DDX_Check(pDX, IDC_MERGEDELIMITERS, m_MergeDelimiters);
	DDX_Check(pDX, IDC_INDEX, m_CreateIndex);
	DDX_Check(pDX, IDC_IGNORE_NEGATIVE_RETURNS, m_IgnoreNegativeReturns);
	DDX_Check(pDX, IDC_IMPORT_SPECIFIC_RETURNS, m_ImportSelectedReturns);
	DDX_Text(pDX, IDC_RETURNS_TO_IMPORT, m_ReturnsToImport);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CASCIIImportDlg, CDialog)
	//{{AFX_MSG_MAP(CASCIIImportDlg)
	ON_BN_CLICKED(IDC_INPUT_BROWSE, OnInputBrowse)
	ON_BN_CLICKED(IDC_OUTPUT_BROWSE, OnOutputBrowse)
	ON_BN_CLICKED(IDC_LOAD_CONFIGURATION, OnLoadConfiguration)
	ON_BN_CLICKED(IDC_SAVE_CONFIGURATION, OnSaveConfiguration)
	ON_BN_CLICKED(IDC_IMPORT, OnImport)
	ON_BN_CLICKED(IDC_USETAB, OnUpdateParsedResults)
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_WM_SYSCOMMAND()
	ON_BN_CLICKED(IDC_IMPORT_SPECIFIC_RETURNS, OnNeedControlUpdate)
	ON_NOTIFY(NM_DBLCLK, IDC_FILECONTENTS, OnDblclkFilecontents)
	ON_BN_CLICKED(IDC_USESPACE, OnUpdateParsedResults)
	ON_BN_CLICKED(IDC_USECOMMA, OnUpdateParsedResults)
	ON_BN_CLICKED(IDC_USEOTHER, OnUpdateParsedResults)
	ON_EN_CHANGE(IDC_STARTINGROW, OnUpdateParsedResults)
//	ON_NOTIFY(UDN_DELTAPOS, IDC_STARTINGROW_SPIN, OnUpdateParsedResults)
	ON_BN_CLICKED(IDC_MERGEDELIMITERS, OnUpdateParsedResults)
	ON_CBN_SELCHANGE(IDC_FIELDLIST_X, OnUpdateParsedResults)
	ON_CBN_SELCHANGE(IDC_FIELDLIST_Y, OnUpdateParsedResults)
	ON_CBN_SELCHANGE(IDC_FIELDLIST_ELEVATION, OnUpdateParsedResults)
	ON_CBN_SELCHANGE(IDC_FIELDLIST_INTENSITY, OnUpdateParsedResults)
	ON_CBN_SELCHANGE(IDC_FIELDLIST_PULSE, OnUpdateParsedResults)
	ON_CBN_SELCHANGE(IDC_FIELDLIST_RETURN, OnUpdateParsedResults)
	ON_CBN_SELCHANGE(IDC_FIELDLIST_RETURNS_PER_PULSE, OnUpdateParsedResults)
	ON_CBN_SELCHANGE(IDC_FIELDLIST_SCAN_ANGLE, OnUpdateParsedResults)
	ON_NOTIFY(NM_CLICK, IDC_FILECONTENTS, OnClickFilecontents)
	//}}AFX_MSG_MAP
	ON_NOTIFY(UDN_DELTAPOS, IDC_STARTINGROW_SPIN, &CASCIIImportDlg::OnDeltaposStartingrowSpin)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CASCIIImportDlg message handlers

BOOL CASCIIImportDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// set up font for data display
	m_DataFont.CreatePointFont(90, "Courier New");

	// set up spinner for starting line
	CSpinButtonCtrl *spin = (CSpinButtonCtrl*) GetDlgItem(IDC_STARTINGROW_SPIN);
	spin->SetBuddy(GetDlgItem(IDC_STARTINGROW));
	spin->SetRange(1, 100);
	spin->SetPos(1);

	// set up progress bar
	CProgressCtrl* progress = (CProgressCtrl*) GetDlgItem(IDC_PROGRESS);
	progress->SetRange(0, 100);
	progress->SetPos(0);

	// subclass list controls
	m_RawFileLines.SubclassDlgItem(IDC_FILECONTENTS, this);
	m_ParsedResult.SubclassDlgItem(IDC_PARSEDCOLUMNS, this);

	// enable full row selection
	m_RawFileLines.SetHighlightType(HIGHLIGHT_ROW);
	m_ParsedResult.SetHighlightType(HIGHLIGHT_ROW);

	// enable odd row coloring
	m_RawFileLines.EnableOddRowColor();
	m_ParsedResult.EnableOddRowColor();

	// enable grid lines for parsed data display
	m_ParsedResult.EnableGridlines();

	m_ParsedResult.EnableOddRowColor();

	// set font for data displays
	m_RawFileLines.SetFont(&m_DataFont);
	m_ParsedResult.SetFont(&m_DataFont);

	m_RawFileLines.InsertColumn(1, "Line", LVCFMT_LEFT, m_ParsedResult.GetStringWidth("W000W"), 0);
	m_RawFileLines.InsertColumn(2, "Raw data from input file", LVCFMT_LEFT, 1000, 1);

	// initialize control resize helper
	m_resizeHelper.Init(m_hWnd);
	
	// set resizing hints
	m_resizeHelper.Fix(IDC_INPUTFILENAME, HLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_OUTPUTFILENAME, HLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_INPUT_BROWSE, HRIGHT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_OUTPUT_BROWSE, HRIGHT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_STARTINGROW, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_STARTINGROW_LABEL, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_STARTINGROW_SPIN, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_DELIMITER_FRAME, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_USETAB, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_USESPACE, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_USECOMMA, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_USEOTHER, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_OTHERDELIMITER, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_MERGEDELIMITERS, HWIDTHLEFT, VHEIGHTTOP);

	m_resizeHelper.Fix(IDC_OPTIONS_FRAME, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_INDEX, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_IGNORE_NEGATIVE_RETURNS, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_IMPORT_SPECIFIC_RETURNS, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_RETURNS_TO_IMPORT, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_OPTIONS_FRAME, HWIDTHLEFT, VHEIGHTTOP);

	m_resizeHelper.Fix(IDC_COLUMN_FRAME, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_X, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_Y, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_ELEVATION, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_INTENSITY, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_PULSE, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_RETURN, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_RETURNS_PER_PULSE, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_SCAN_ANGLE, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_X_LABEL, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_Y_LABEL, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_ELEVATION_LABEL, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_INTENSITY_LABEL, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_PULSE_LABEL, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_RETURN_LABEL, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_RETURNS_PER_PULSE_LABEL, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FIELDLIST_SCAN_ANGLE_LABEL, HWIDTHLEFT, VHEIGHTTOP);
	
	m_resizeHelper.Fix(IDC_FILECONTENTS_LABEL, HWIDTHLEFT, VHEIGHTTOP);
	m_resizeHelper.Fix(IDC_FILECONTENTS, HLEFTRIGHT, VTOP);

	m_resizeHelper.Fix(IDC_PARSEDCOLUMNS_LABEL, HWIDTHLEFT, VHEIGHT);
	m_resizeHelper.Fix(IDC_PARSEDCOLUMNS, HLEFTRIGHT, VBOTTOM);

	m_resizeHelper.Fix(IDC_PROGRESS, HLEFTRIGHT, VHEIGHTBOTTOM);
	m_resizeHelper.Fix(IDC_IMPORT, HWIDTHLEFT, VHEIGHTBOTTOM);
	m_resizeHelper.Fix(IDC_LOAD_CONFIGURATION, HWIDTHLEFT, VHEIGHTBOTTOM);
	m_resizeHelper.Fix(IDC_SAVE_CONFIGURATION, HWIDTHLEFT, VHEIGHTBOTTOM);
	m_resizeHelper.Fix(IDOK, HWIDTHRIGHT, VHEIGHTBOTTOM);

	// do parsed data display column names
	m_ParsedResult.InsertColumn(1, "X", LVCFMT_LEFT, m_ParsedResult.GetStringWidth("W0000000.0000W"), 0);
	m_ParsedResult.InsertColumn(2, "Y", LVCFMT_LEFT, m_ParsedResult.GetStringWidth("W0000000.0000W"), 1);
	m_ParsedResult.InsertColumn(3, "Elevation", LVCFMT_LEFT, m_ParsedResult.GetStringWidth("W00000.00W"), 2);
	m_ParsedResult.InsertColumn(4, "Intensity", LVCFMT_LEFT, m_ParsedResult.GetStringWidth("W000.00W"), 3);
	m_ParsedResult.InsertColumn(5, "Pulse", LVCFMT_LEFT, m_ParsedResult.GetStringWidth("WPulseW"), 4);
	m_ParsedResult.InsertColumn(6, "Return", LVCFMT_LEFT, m_ParsedResult.GetStringWidth("WReturnW"), 5);
	m_ParsedResult.InsertColumn(7, "ReturnsPerPulse", LVCFMT_LEFT, m_ParsedResult.GetStringWidth("WReturnW"), 6);
	m_ParsedResult.InsertColumn(8, "ScanAngle", LVCFMT_LEFT, m_ParsedResult.GetStringWidth("W00.00W"), 7);

	UpdateControls();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CASCIIImportDlg::OnInputBrowse() 
{
	UpdateData();
	
	CString csFilter;
	CString csExt;

	// load strings that specify the file types for the file...open dialog
	csFilter.LoadString(IDS_TEXTFILEFILTER);
	csExt.LoadString(IDS_TEXTFILEEXT);

	// create an instance of the file...open dialog
	CFileDialog fd(TRUE, csExt, NULL, OFN_HIDEREADONLY | OFN_FILEMUSTEXIST, csFilter, (CWnd*) this);
	char szInitialDir[_MAX_PATH];
	if (GetCurrentDirectory(_MAX_PATH, szInitialDir))
		fd.m_ofn.lpstrInitialDir = szInitialDir;

	// use the file...open dialog to get an image file name
	if (fd.DoModal() == IDOK) {
		// retrieve the name for the file...open dialog
		m_InputFileName = fd.GetPathName();
		UpdateData(FALSE);

		DisplayRawDataFromFile(m_InputFileName);

		OnUpdateParsedResults();
	}
}

void CASCIIImportDlg::OnOutputBrowse() 
{
	UpdateData();

	CString csFilter;
	CString csExt = _T("lda");

	csFilter.LoadString(IDS_DATAFILEFILTER);
	csExt.LoadString(IDS_DATAFILEEXT);

	CFileDialog fd(FALSE, csExt, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, csFilter, (CWnd*) this);
	char szInitialDir[_MAX_PATH];
	if (GetCurrentDirectory(_MAX_PATH, szInitialDir))
		fd.m_ofn.lpstrInitialDir = szInitialDir;

	if (fd.DoModal() == IDOK) {
		m_OutputFileName = fd.GetPathName();

		UpdateData(FALSE);
	}

	UpdateControls();
}

void CASCIIImportDlg::OnLoadConfiguration() 
{
	UpdateData();
	
	CString csFilter;
	CString csExt;
	CString CfgFileName;

	// load strings that specify the file types for the file...open dialog
	csFilter.LoadString(IDS_IMPORTPARAMETERFILEFILTER);
	csExt.LoadString(IDS_IMPORTPARAMETERFILEEXT);

	// create an instance of the file...open dialog
	CFileDialog fd(TRUE, csExt, NULL, OFN_HIDEREADONLY | OFN_FILEMUSTEXIST, csFilter, (CWnd*) this);
	char szInitialDir[_MAX_PATH];
	if (GetCurrentDirectory(_MAX_PATH, szInitialDir))
		fd.m_ofn.lpstrInitialDir = szInitialDir;

	// use the file...open dialog to get an image file name
	if (fd.DoModal() == IDOK) {
		// retrieve the name for the file...open dialog
		CfgFileName = fd.GetPathName();

		// read the configuration parameters
		if (ReadConfiguration(CfgFileName)) {
			UpdateData(FALSE);

			OnUpdateParsedResults();
		}
	}
}

void CASCIIImportDlg::OnSaveConfiguration() 
{
	UpdateData();

	CString csFilter;
	CString csExt;
	CString CfgFileName;

	csFilter.LoadString(IDS_IMPORTPARAMETERFILEFILTER);
	csExt.LoadString(IDS_IMPORTPARAMETERFILEEXT);

	CFileDialog fd(FALSE, csExt, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, csFilter, (CWnd*) this);
	char szInitialDir[_MAX_PATH];
	if (GetCurrentDirectory(_MAX_PATH, szInitialDir))
		fd.m_ofn.lpstrInitialDir = szInitialDir;

	if (fd.DoModal() == IDOK) {
		CfgFileName = fd.GetPathName();

		if (!WriteConfiguration(CfgFileName)) {
			AfxMessageBox("Unable to save configuration parmeters", MB_OK | MB_ICONEXCLAMATION);
		}
	}
}

void CASCIIImportDlg::OnOK() 
{
	// close the dialog
	
	CDialog::OnOK();
}

void CASCIIImportDlg::OnCancel() 
{
	CDialog::OnOK();
}

void CASCIIImportDlg::OnImport() 
{
	UpdateData();

	// validate parameters
	if (!m_InputFileName.IsEmpty() && !m_OutputFileName.IsEmpty()) {
		BeginWaitCursor();

		// create output file
		char *signature = {"LIDARBIN"};
		int major = 1;
		int minor = 1;
		FILE* f = fopen(m_OutputFileName, "wb");
		if (f) {
			fwrite(signature, sizeof(char), 8, f);
			fwrite(&major, sizeof(int), 1, f);
			fwrite(&minor, sizeof(int), 1, f);

			CDataFile dat(m_InputFileName);
			long ASCIIFileSize = dat.GetFileSize();

			char buf[2048];

			char delimiter[17];
			delimiter[0] = '\0';
			if (m_UseTab)
				strcat(delimiter, "\t");
			if (m_UseSpace)
				strcat(delimiter, " ");
			if (m_UseComma)
				strcat(delimiter, ",");
			if (m_UseOther)
				strcat(delimiter, m_OtherDelimiter);
			
			CProgressCtrl* progress = (CProgressCtrl*) GetDlgItem(IDC_PROGRESS);
			double values[512];
			LIDARRETURN pt;
			int flds = 0;
			int cnt = 0;
			int Points = 0;
			double minx = 999999999.0;
			double miny = 999999999.0;
			double minz = 999999999.0;
			double maxx = -999999999.0;
			double maxy = -999999999.0;
			double maxz = -999999999.0;

			int percent;

			CString ReturnString;

			pt.Intensity = 1.0;
			pt.NadirAngle = 0.0;
			pt.PulseNumber = 1;
			pt.ReturnNumber = 1;

			// read lines and parse values
			while (dat.ReadDataLine(buf, SKIPCOMMENTSCOMMANDS, FALSE)) {
				cnt ++;

				if (cnt < m_StartingRow)
					continue;

				// parse fields from line
				flds = ParseValuesFromDataLine(buf, delimiter, values);

				// assign values to fields
				if (m_Field_X > 0 && m_Field_X <= flds)
					pt.X = values[m_Field_X - 1];
				if (m_Field_Y > 0 && m_Field_Y <= flds)
					pt.Y = values[m_Field_Y - 1];
				if (m_Field_Elevation > 0 && m_Field_Elevation <= flds)
					pt.Elevation = (float) values[m_Field_Elevation - 1];
				if (m_Field_Intensity > 0 && m_Field_Intensity <= flds)
					pt.Intensity = (float) values[m_Field_Intensity - 1];
				if (m_Field_PulseNumber > 0 && m_Field_PulseNumber <= flds)
					pt.PulseNumber = (int) values[m_Field_PulseNumber - 1];
				if (m_Field_ReturnNumber > 0 && m_Field_ReturnNumber <= flds)
					pt.ReturnNumber = (int) values[m_Field_ReturnNumber - 1];
				if (m_Field_ScanAngle > 0 && m_Field_ScanAngle <= flds)
					pt.NadirAngle = (float) values[m_Field_ScanAngle - 1];

				// test to see if we need to skip the point
				if (m_IgnoreNegativeReturns && pt.Elevation < 0.0)
					continue;
				
				if (m_ImportSelectedReturns) {
					ReturnString.Format("%1i", pt.ReturnNumber);
					if (m_ReturnsToImport.Find(ReturnString, 0) < 0)
						continue;
				}

				// write the point
				fwrite(&pt, sizeof(LIDARRETURN), 1, f);

				if (m_CreateIndex) {
					minx = __min(minx, pt.X);
					miny = __min(miny, pt.Y);
					minz = __min(minz, pt.Elevation);
					maxx = __max(maxx, pt.X);
					maxy = __max(maxy, pt.Y);
					maxz = __max(maxz, pt.Elevation);
				}

				Points ++;

				// update progress
				if (Points % 100 == 0) {
					percent = (int) (((double) dat.GetPosition() / (double) ASCIIFileSize) * 100.0);
					if (m_CreateIndex)
						percent = percent / 2;
					progress->SetPos(percent);
				}
			}
			fclose(f);
			
			// create index files
			if (m_CreateIndex) {
				CDataIndex index;
				if (index.CreateIndex(m_OutputFileName, 10, 256, 256, Points, minx, maxx, miny, maxy, minz, maxz, TRUE)) {
					progress->SetPos(0);
					EndWaitCursor();
					AfxMessageBox("ASCII file converted and indexed");
				}
				else {
					progress->SetPos(0);
					EndWaitCursor();
					AfxMessageBox("Could not create index file...XYZ file converted");
				}
			}
			else {
				progress->SetPos(0);
				EndWaitCursor();
				if (Points)
					AfxMessageBox("ASCII file converted");
				else
					AfxMessageBox("No point data in ASCII file");
			}
		}
	}
}

void CASCIIImportDlg::UpdateControls()
{
	UpdateData();

	// conversion is possible if we have an input and output file name and at least field assignments for XYZ
	if (!m_InputFileName.IsEmpty() && !m_OutputFileName.IsEmpty() && m_Field_X > 0 && m_Field_Y > 0 && m_Field_Elevation > 0) {
		GetDlgItem(IDC_IMPORT)->EnableWindow(TRUE);
	}
	else {
		GetDlgItem(IDC_IMPORT)->EnableWindow(FALSE);
	}

	GetDlgItem(IDC_OTHERDELIMITER)->EnableWindow(m_UseOther);
	GetDlgItem(IDC_RETURNS_TO_IMPORT)->EnableWindow(m_ImportSelectedReturns);

	GetDlgItem(IDC_MERGEDELIMITERS)->EnableWindow(FALSE);
}

BOOL CASCIIImportDlg::ReadConfiguration(LPCTSTR FileName)
{
	CINIFile ini(FileName);

	if (_access(FileName, 0) == 0) {
		CString csTemp;

		m_StartingRow = ini.ReadSetting("General", "StartingRow", 1);
		m_CreateIndex = ini.ReadSetting("General", "CreateIndex", TRUE);
		m_IgnoreNegativeReturns = ini.ReadSetting("General", "IgnoreNegativeReturns", TRUE);
		m_ImportSelectedReturns = ini.ReadSetting("General", "ImportSelectedReturns", TRUE);
		ini.ReadSetting("General", "ReturnsToImport", csTemp, "");
		csTemp.Replace("\"", "");
		m_ReturnsToImport = csTemp;
		m_MergeDelimiters = ini.ReadSetting("Delimiter", "MergeDelimiters", TRUE);
		m_UseTab = ini.ReadSetting("Delimiter", "UseTab", TRUE);
		m_UseSpace = ini.ReadSetting("Delimiter", "UseSpace", TRUE);
		m_UseComma = ini.ReadSetting("Delimiter", "UseComma", TRUE);
		m_UseOther = ini.ReadSetting("Delimiter", "UseOther", FALSE);
		ini.ReadSetting("Delimiter", "OtherDelimiter", csTemp, "");
		csTemp.Replace("\"", "");
		m_OtherDelimiter = csTemp;
		m_Field_X = ini.ReadSetting("Fields", "X", 1);
		m_Field_Y = ini.ReadSetting("Fields", "Y", 2);
		m_Field_Elevation = ini.ReadSetting("Fields", "Elevation", 3);
		m_Field_Intensity = ini.ReadSetting("Fields", "Intensity", 4);
		m_Field_PulseNumber = ini.ReadSetting("Fields", "PulseNumber", -1);
		m_Field_ReturnNumber = ini.ReadSetting("Fields", "ReturnNumber", -1);
		m_Field_ReturnsPerPulse = ini.ReadSetting("Fields", "ReturnsPerPulse", -1);
		m_Field_ScanAngle = ini.ReadSetting("Fields", "ScanAngle", -1);

		return(TRUE);
	}
	return(FALSE);
}

BOOL CASCIIImportDlg::WriteConfiguration(LPCTSTR FileName)
{
	// delete existing file
	DeleteFile(FileName);

	CINIFile ini(FileName);

	CString csTemp;
	ini.WriteSetting("General", "StartingRow", m_StartingRow);
	ini.WriteSetting("General", "CreateIndex", m_CreateIndex );
	ini.WriteSetting("General", "IgnoreNegativeReturns", m_IgnoreNegativeReturns);
	ini.WriteSetting("General", "ImportSelectedReturns", m_ImportSelectedReturns);
	csTemp.Format("\"%s\"", m_ReturnsToImport);
	ini.WriteSetting("General", "ReturnsToImport", csTemp);
	ini.WriteSetting("Delimiter", "MergeDelimiters", m_MergeDelimiters);
	ini.WriteSetting("Delimiter", "UseTab", m_UseTab);
	ini.WriteSetting("Delimiter", "UseSpace", m_UseSpace);
	ini.WriteSetting("Delimiter", "UseComma", m_UseComma);
	ini.WriteSetting("Delimiter", "UseOther", m_UseOther);
	csTemp.Format("\"%s\"", m_OtherDelimiter);
	ini.WriteSetting("Delimiter", "OtherDelimiter", csTemp);
	ini.WriteSetting("Fields", "X", m_Field_X);
	ini.WriteSetting("Fields", "Y", m_Field_Y);
	ini.WriteSetting("Fields", "Elevation", m_Field_Elevation);
	ini.WriteSetting("Fields", "Intensity", m_Field_Intensity);
	ini.WriteSetting("Fields", "PulseNumber", m_Field_PulseNumber);
	ini.WriteSetting("Fields", "ReturnNumber", m_Field_ReturnNumber);
	ini.WriteSetting("Fields", "ReturnsPerPulse", m_Field_ReturnsPerPulse);
	ini.WriteSetting("Fields", "ScanAngle", m_Field_ScanAngle);

	return(TRUE);
}

void CASCIIImportDlg::OnUpdateParsedResults() 
{
	// parse lines from the raw data display and display columns
	if (!m_InputFileName.IsEmpty()) {
		UpdateData();

		// highlight starting line in raw data
		HighlightStartingRow();

		// update the lists of columns for variables
		UpdateColumnLists(m_InputFileName);

		DisplayParsedColumns();

		UpdateData(FALSE);
	}

	UpdateControls();
}

void CASCIIImportDlg::DisplayRawDataFromFile(LPCTSTR FileName)
{
	m_RawFileLines.DeleteAllItems();

	if (!m_InputFileName.IsEmpty()) {
		CDataFile dat(m_InputFileName);
		int cnt = 0;
		char lineno[16];
		char buf[2048];
		LVITEM lv;
		lv.mask = LVIF_TEXT;
		while (dat.ReadDataLine(buf, SKIPCOMMENTSCOMMANDS, FALSE) && cnt < 100) {
			cnt ++;

			if (cnt < m_StartingRow)
				continue;

			// add line to display
			lv.iItem = m_RawFileLines.GetItemCount();

			sprintf(lineno, "%i", cnt);
			lv.iSubItem = 0;
			lv.pszText = lineno;
			m_RawFileLines.InsertItem(&lv);

			lv.iSubItem = 1;
			lv.pszText = buf;
			m_RawFileLines.SetItem(&lv);
		}
		m_RawFileLines.SetColumnWidth(0, LVSCW_AUTOSIZE_USEHEADER);
	}
}

void CASCIIImportDlg::DisplayParsedColumns()
{
	UpdateData();

	int flds = 0;
	m_ParsedResult.DeleteAllItems();

	if (!m_InputFileName.IsEmpty()) {
		CDataFile dat(m_InputFileName);
		int cnt = 0;
		char buf[2048];

		char delimiter[17];
		delimiter[0] = '\0';
		if (m_UseTab)
			strcat(delimiter, "\t");
		if (m_UseSpace)
			strcat(delimiter, " ");
		if (m_UseComma)
			strcat(delimiter, ",");
		if (m_UseOther)
			strcat(delimiter, m_OtherDelimiter);
		
		while (dat.ReadDataLine(buf, SKIPCOMMENTSCOMMANDS, FALSE)) {
			cnt ++;

			if (cnt < m_StartingRow)
				continue;

			// count fields that can be parsed from the line
			char* tok = strtok(buf, delimiter);
			while (tok) {
				flds ++;

				tok = strtok(NULL, delimiter);
			}
			break;
		}
		dat.Rewind();

		double values[512];
		int LinesAdded = 0;
		LVITEM lv;
		char szText[256];
		lv.mask = LVIF_TEXT;

		// read the first 100 lines and parse values
		cnt = 0;
		while (dat.ReadDataLine(buf, SKIPCOMMENTSCOMMANDS, FALSE) && cnt < 100) {
			cnt ++;

			if (cnt < m_StartingRow)
				continue;

			// parse fields from line
			flds = ParseValuesFromDataLine(buf, delimiter, values);

			// add values to parsed display
			lv.iItem = m_ParsedResult.GetItemCount();

			// set pointer to text
			lv.pszText = szText;

			lv.iSubItem = 0;
			if (m_Field_X > 0 && m_Field_X <= flds) {
				sprintf(szText, "%lf", values[m_Field_X - 1]);
			}
			else
				strcpy(szText, "---");
			m_ParsedResult.InsertItem(&lv);

			lv.iSubItem = 1;
			if (m_Field_Y > 0 && m_Field_Y <= flds) {
				sprintf(szText, "%lf", values[m_Field_Y - 1]);
			}
			else
				strcpy(szText, "---");
			m_ParsedResult.SetItem(&lv);

			lv.iSubItem = 2;
			if (m_Field_Elevation > 0 && m_Field_Elevation <= flds) {
				sprintf(szText, "%lf", values[m_Field_Elevation - 1]);
			}
			else
				strcpy(szText, "---");
			m_ParsedResult.SetItem(&lv);

			lv.iSubItem = 3;
			if (m_Field_Intensity > 0 && m_Field_Intensity <= flds) {
				sprintf(szText, "%lf", values[m_Field_Intensity - 1]);
			}
			else
				strcpy(szText, "---");
			m_ParsedResult.SetItem(&lv);

			lv.iSubItem = 4;
			if (m_Field_PulseNumber > 0 && m_Field_PulseNumber <= flds) {
				sprintf(szText, "%.0lf", values[m_Field_PulseNumber - 1]);
			}
			else
				strcpy(szText, "---");
			m_ParsedResult.SetItem(&lv);

			lv.iSubItem = 5;
			if (m_Field_ReturnNumber > 0 && m_Field_ReturnNumber <= flds) {
				sprintf(szText, "%.0lf", values[m_Field_ReturnNumber - 1]);
			}
			else
				strcpy(szText, "---");
			m_ParsedResult.SetItem(&lv);

			lv.iSubItem = 6;
			if (m_Field_ReturnsPerPulse > 0 && m_Field_ReturnsPerPulse <= flds) {
				sprintf(szText, "%.0lf", values[m_Field_ReturnsPerPulse - 1]);
			}
			else
				strcpy(szText, "---");
			m_ParsedResult.SetItem(&lv);

			lv.iSubItem = 7;
			if (m_Field_ScanAngle > 0 && m_Field_ScanAngle <= flds) {
				sprintf(szText, "%lf", values[m_Field_ScanAngle - 1]);
			}
			else
				strcpy(szText, "---");
			m_ParsedResult.SetItem(&lv);

			LinesAdded ++;
		}
		// update column widths
		m_ParsedResult.SetColumnWidth(0, m_ParsedResult.GetStringWidth("WW9999999.999999WW"));
		m_ParsedResult.SetColumnWidth(1, m_ParsedResult.GetStringWidth("WW9999999.999999WW"));
		m_ParsedResult.SetColumnWidth(2, m_ParsedResult.GetStringWidth("WW9999.999999WW"));
		m_ParsedResult.SetColumnWidth(3, m_ParsedResult.GetStringWidth("WW999.999999WW"));
		m_ParsedResult.SetColumnWidth(7, m_ParsedResult.GetStringWidth("WW99.999999WW"));
	}

	UpdateData(FALSE);
}

int CASCIIImportDlg::UpdateColumnLists(LPCTSTR FileName)
{
	UpdateData();

	int flds = 0;

	if (!m_InputFileName.IsEmpty()) {
		CDataFile dat(m_InputFileName);
		int cnt = 0;
		char buf[2048];

		char delimiter[17];
		delimiter[0] = '\0';
		if (m_UseTab)
			strcat(delimiter, "\t");
		if (m_UseSpace)
			strcat(delimiter, " ");
		if (m_UseComma)
			strcat(delimiter, ",");
		if (m_UseOther)
			strcat(delimiter, m_OtherDelimiter);
		
		while (dat.ReadDataLine(buf, SKIPCOMMENTSCOMMANDS, FALSE)) {
			cnt ++;

			if (cnt < m_StartingRow)
				continue;

			// count fields that can be parsed from the line
			char* tok = strtok(buf, delimiter);
			while (tok) {
				flds ++;

				tok = strtok(NULL, delimiter);
			}

			int list_ids[] = {IDC_FIELDLIST_X, IDC_FIELDLIST_Y, IDC_FIELDLIST_ELEVATION, IDC_FIELDLIST_PULSE, IDC_FIELDLIST_RETURN, IDC_FIELDLIST_INTENSITY, IDC_FIELDLIST_RETURNS_PER_PULSE, IDC_FIELDLIST_SCAN_ANGLE};
			int i, j;
			CString csTemp;
			CComboBox* combo;
			if (flds) {
				// build lists for controls
				for (i = 0; i < 8; i ++) {
					combo = (CComboBox*) GetDlgItem(list_ids[i]);
					if (combo) {
						combo->ResetContent();
						combo->AddString("none");
						for (j = 1; j <= flds; j ++) {
							csTemp.Format("Field %i", j);
							combo->AddString(csTemp);
						}
					}
				}
			}

			break;
		}

		// check the current field selections and set to "none" if greater than the number of fields in the data
		if (m_Field_X > flds)
			m_Field_X = 0;
		if (m_Field_Y > flds)
			m_Field_Y = 0;
		if (m_Field_Elevation > flds)
			m_Field_Elevation = 0;
		if (m_Field_PulseNumber > flds)
			m_Field_PulseNumber = 0;
		if (m_Field_ReturnNumber > flds)
			m_Field_ReturnNumber = 0;
		if (m_Field_Intensity > flds)
			m_Field_Intensity = 0;
		if (m_Field_ReturnsPerPulse > flds)
			m_Field_ReturnsPerPulse = 0;
		if (m_Field_ScanAngle > flds)
			m_Field_ScanAngle = 0;
	}

	UpdateData(FALSE);

	return(flds);
}

int CASCIIImportDlg::ParseValuesFromDataLine(LPTSTR buf, LPCTSTR delimiter, double *values)
{
	// parse fields from line
	int flds = 0;
	char* tok = strtok(buf, delimiter);
	while (tok) {
		values[flds] = atof(tok);

		flds ++;
		tok = strtok(NULL, delimiter);
	}

	return(flds);
}

void CASCIIImportDlg::HighlightStartingRow()
{
	if (m_StartingRow > 0 && m_StartingRow <= m_RawFileLines.GetItemCount()) {
		for (int i = 0; i < m_RawFileLines.GetItemCount(); i ++)
			m_RawFileLines.SetItem(i, 0, LVIF_STATE, NULL, 0, 0, LVIS_SELECTED, 0);

		m_RawFileLines.SetItem(m_StartingRow - 1, 0, LVIF_STATE, NULL, 0, LVIS_SELECTED, LVIS_SELECTED, 0);
		m_RawFileLines.EnsureVisible(m_StartingRow - 1, FALSE);
	}
}

void CASCIIImportDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	// resize controls
	m_resizeHelper.OnSize();
}

void CASCIIImportDlg::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	m_resizeHelper.SetMinSize(lpMMI->ptMinTrackSize);

	CDialog::OnGetMinMaxInfo(lpMMI);
}

void CASCIIImportDlg::OnSysCommand(UINT nID, LPARAM lParam) 
{
	// make dialog close when user closes using "X" or window menu...close goes through OnOK()
	if ((nID & 0xFFF0) == SC_CLOSE) {
		OnOK();
	}
	else {
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CASCIIImportDlg::OnNeedControlUpdate() 
{
	UpdateControls();
}

void CASCIIImportDlg::OnDblclkFilecontents(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// get item from list
	CPoint pt(CWnd::GetCurrentMessage()->pt);
	m_RawFileLines.ScreenToClient(&pt);
	int nHitItem = m_RawFileLines.HitTest(pt);

	if (nHitItem >= 0) {
		UpdateData();
		m_StartingRow = nHitItem + 1;
		UpdateData(FALSE);
		OnUpdateParsedResults();
	}
	
	*pResult = 0;
}

void CASCIIImportDlg::OnClickFilecontents(NMHDR* pNMHDR, LRESULT* pResult) 
{
	OnDblclkFilecontents(pNMHDR, pResult);
}


void CASCIIImportDlg::OnDeltaposStartingrowSpin(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: Add your control notification handler code here
	OnUpdateParsedResults();

	*pResult = 0;
}
