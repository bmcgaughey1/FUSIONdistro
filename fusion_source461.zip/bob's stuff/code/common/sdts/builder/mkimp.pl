#!/usr/local/bin/perl -w
#
# usage: 
#     file of "module name" followed by lines of
#     "long name", mnemonic, type vectors
#
# $Id: mkimp.pl,v 1.7 1998/07/17 20:41:54 mcoletti Exp $
#


# get module name first

$_ = <> || die("no file man");
chop;

m/(^[A-Za-z]+)/;

$module_name = $1;

$_ = $';
m/([A-Za-z]+[A-Za-z \/]+[A-Za-z\/]+)/;       # chop leading and trailing spaces
$description = $1;              # for description string


print <<EOT;
//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//
// \$Id\$
//

EOT

print "#include \"builder/sb_", $module_name, ".h\"\n\n";

print <<EOF;


#ifdef HAVE_ISO_HEADERS
#include <iostream>
#include <strstream>
#else
#include <iostream.h>
#include <strstream.h>
#endif

#include <limits.h>
#include <float.h>

#ifndef INCLUDED_SB_UTILS_H
#include "builder/sb_Utils.h"
#endif

#ifndef INCLUDED_SB_FOREIGNID_H
#include "builder/sb_ForeignID.h"
#endif

#ifndef INCLUDED_SC_RECORD_H
#include "container/sc_Record.h"
#endif

#ifndef INCLUDED_SC_FIELD_H
#include "container/sc_Field.h"
#endif

#ifndef INCLUDED_SC_SUBFIELD_H
#include "container/sc_Subfield.h"
#endif

#ifndef INCLUDED_SIO_8211CONVERTER_H
#include "io/sio_8211Converter.h"
#endif



static const char* _ident = "\$Id\$";

// Strings and integers are initialized with these values; they are used
// to indicate whether a given module value has been assigned a value or not.

// (XXX I arbitrarily chose 0x4 as the sentinal value.  I hate ad hoc crap.)

static const string  UNVALUED_STRING(1, static_cast<string::value_type>(0x4) );

static const long    UNVALUED_LONG   = INT_MIN;

static const double  UNVALUED_DOUBLE = DBL_MAX;

EOF



# read all the function types, which will be defined with the following
# format:
#
# long name<ws>mnemonic<ws>type

$long_name = "";
$mnemonic  = "";
$type      = "";

@facet     = ();


while ( <> ) {
    ( $long_name, $mnemonic, $type ) = split;

    #print $long_name, " ", $mnemonic, " ", $type, "\n";

    push @facet, [ $long_name, $mnemonic, $type ];
}


# first do the implementation structure

print "struct sb_", $module_name, "_Imp\n{\n";

                                # data members

foreach $i ( @facet ) {


    if ( $i->[2] eq "A" ) {
        print "string   _\l", $i->[0], ";\n";
    }
    elsif ( $i->[2] eq "I" ) {
        print "long     _\l", $i->[0], ";\n";
    }
    elsif ( $i->[2] eq "R" ) {
        print "double   _\l", $i->[0], ";\n";
    }
    elsif ( $i->[2] eq "C" ) {
        print "string   _\l", $i->[0], ";\n";
    }
    else {
        print "bogus value ", $i->[2], "\n";
        exit( -1 );
    }

}

                                # ctor

print "\n\nsb_", $module_name, "_Imp()\n: ";

for ( $j = 0; $j < $#facet; $j++ ) {

    if ( ${$facet[$j]}[2] eq "A" ) {
       print "\n_\l", ${$facet[$j]}[0], "( UNVALUED_STRING )";
    }
    elsif ( ${$facet[$j]}[2] eq "I" ) {
        print "\n_\l", ${$facet[$j]}[0], "( UNVALUED_LONG )";
    }
    elsif ( ${$facet[$j]}[2] eq "R" ) {
        print "\n_\l", ${$facet[$j]}[0], "( UNVALUED_DOUBLE )";
    }
    elsif ( ${$facet[$j]}[2] eq "C" ) {
        print "\n_\l", ${$facet[$j]}[0], "( UNVALUED_STRING )";
    }
    else {
        print "bogus value ", ${$facet[$j]}[2], "\n";
        exit( -1 );
    }
    print ",";
}

#$j++;

if ( ${$facet[$j]}[2] eq "A" ) {
    print "\n_\l", ${$facet[$j]}[0], "( UNVALUED_STRING )";
}
elsif ( ${$facet[$j]}[2] eq "I" ) {
    print "\n_\l", ${$facet[$j]}[0], "( UNVALUED_LONG )";
}
elsif ( ${$facet[$j]}[2] eq "R" ) {
    print "\n_\l", ${$facet[$j]}[0], "( UNVALUED_DOUBLE )";
}
elsif ( ${$facet[$j]}[2] eq "C" ) {
    print "\n_\l", ${$facet[$j]}[0], "( UNVALUED_STRING )";
}
else {
    print "bogus value ", ${$facet[$j]}[2], "\n";
    exit( -1 );
}

print "\n{}\n\n};\n\n\n";

                                # end of implementation struct


# ctor

print "sb_", $module_name, "::sb_", $module_name, "()\n";
print " : _imp( new sb_", $module_name, "_Imp() )\n";
print "{\n";
print "setMnemonic(\"", uc($module_name), "\");\n";
print "setID( 1 );\n";
print "\n\n// insert static initializers\n\n";
print "} // ", $module_name, " ctor\n\n\n";


# dtor

print "sb_", $module_name, '::~sb_', $module_name, "()\n";
print "{\n";
print "delete _imp;\n";
print "} // ", $module_name, " dtor\n\n\n";


# create factory function to build a sdts++ io schema

print <<EOS;


static sio_8211Converter_I converter_I; // XXX should define these in
static sio_8211Converter_A converter_A; // XXX sio_8211Converter.h
static sio_8211Converter_R converter_R;
static sio_8211Converter_C converter_C;

static sio_8211Schema _schema; // module specific schema

static
void
_build_schema( sio_8211Schema& schema )
{
  schema.clear();               // make sure we are starting with clean schema

  schema.push_back( sio_8211FieldFormat() );

  sio_8211FieldFormat& field_format = schema.back();

  field_format.setDataStructCode( sio_8211FieldFormat::vector );
  field_format.setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
EOS

print "field_format.setName( \"", $description, "\"", " );\n";
print "field_format.setTag( \"", uc($module_name), "\" );\n\n\n";


                                # blat out subfield specific stuff

print <<EOSTUFF;
  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "MODN" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "RCID" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );

EOSTUFF




foreach $i ( @facet ) {

    print "field_format.push_back( sio_8211SubfieldFormat() );\n\n";

    print "field_format.back().setLabel( \"", $i->[1], "\" );\n";

    print "field_format.back().setType( sio_8211SubfieldFormat::";
    print $i->[2], " );\n";

    print "field_format.back().setFormat( sio_8211SubfieldFormat::variable );\n";

    print "field_format.back().setConverter( &converter_";
    print $i->[2], " );\n\n\n";

}


print "} // _build_schema\n\n\n";



# now emit the function that sets the current builder object based on what's
# found in the given sc_Record

  print "static\nbool\n_ingest_record( ";
  print "sb_", $module_name, "& ", lc($module_name),", ";
  print "sb_", $module_name, "_Imp &", lc($module_name), "_imp, ";
  print "sc_Record const& record )\n{\n\n";

  print "// Make sure we have a record from an\n";
  print "// External Spatial Reference module.\n\n";

  print "sc_FieldCntr::const_iterator curfield;\n\n";

  print "if ( ! sb_Utils::getFieldByMnem( record,\"", uc($module_name), "\",curfield) )\n";

  print "{\n";
  print "#ifdef SDTSXX_DEBUG\n";
  print "cerr << \"sb_", $module_name,"::sb_", $module_name;
  print "(sc_Record const&): \"\n";
  print "<< \"Not an ", lc($description), " record.\";\n";
  print "cerr << endl;\n";
  print "#endif\n";
  print "return false;\n";
  print "}\n\n\n";

  print "// We have a primary field from a  module. Start";
  print "// picking it apart.\n\n";

  print "sc_SubfieldCntr::const_iterator cursubfield;\n\n";

  print "string tmp_str;\n";
  print "long   tmp_int;\n\n\n";

  print "// MODN\n";
  print "if (sb_Utils::getSubfieldByMnem(*curfield,\"MODN\",cursubfield))\n";
  print "{\ncursubfield->getA( tmp_str );\n";
  print lc($module_name), ".setMnemonic( tmp_str );\n}\n\n\n";

  print "// RCID\n";
  print "if (sb_Utils::getSubfieldByMnem(*curfield,\"RCID\",cursubfield))\n";
  print "{\n";
  print "cursubfield->getI( tmp_int );\n";
  print lc($module_name), ".setID( tmp_int );\n";
  print "}\n\n\n";

  foreach $i ( @facet ) {

      print "// ", $i->[1], "\n";
      print "if (sb_Utils::getSubfieldByMnem(*curfield,\"",$i->[1],"\",cursubfield))\n";
      print "{\ncursubfield->get", $i->[2],"( ", lc($module_name),"_imp._\l", $i->[0],");\n}\nelse\n{\nreturn false;\n}\n\n\n";

  }

  print "return true;\n\n\n} // _ingest_record\n\n\n\n\n";



# now blat out all the accessor functions

  foreach $i ( @facet ) {

      print "bool\n";
      print "sb_", $module_name, "::get", $i->[0], "( ";


      if ( $i->[2] eq "A" ) 
      {
          print "string& val";
      }
      elsif ( $i->[2] eq "I" ) 
      {
          print "long& val";
      }
      elsif ( $i->[2] eq "R" ) 
      {
          print "double& val";
      }
      elsif ( $i->[2] eq "C" ) 
      {
          print "string& val";
      }
      else 
      {
          print "bogus value ", $i->[2], "\n";
          exit( -1 );
      }
      
      print " ) const\n{\n";

      print "if ( _imp->_\l", $i->[0], " == ";



      if ( $i->[2] eq "A" ) 
      {
          print "UNVALUED_STRING";
      }
      elsif ( $i->[2] eq "I" ) 
      {
          print "UNVALUED_LONG";
      }
      elsif ( $i->[2] eq "R" ) 
      {
          print "UNVALUED_DOUBLE";
      }
      elsif ( $i->[2] eq "C" ) 
      {
          print "UNVALUED_STRING";
      }
      else 
      {
          print "bogus value ", $i->[2], "\n";
          exit( -1 );
      }
      

      print " )\nreturn false;\n\n";

      print "val = _imp->_\l", $i->[0],";\n\n";

      print "return true;\n";

      print "} // sb_", $module_name, "::get", $i->[0], "\n\n\n";

  }






  print "bool\n";
  print "sb_", $module_name, "::getSchema( sio_8211Schema& schema ) const\n";
  print "{\n";
  print "// If the schema hasn't been\n// initialized, please do so.\n\n";

  print <<EOSCHEMA;
  if ( _schema.empty() )
    {
      _build_schema( _schema );
    }

  if ( _schema.empty() )   // oops ... something screwed up
    {
      return false;
    }

  schema = _schema;

  return true;

EOSCHEMA

    print "} // sb_", $module_name, "::getSchema\n\n\n\n\n";




# get record

  print "bool\n";
  print "sb_", $module_name, "::getRecord( sc_Record & record ) const\n";
  print "{\n";
  print "record.clear();               // start with a clean slate\n\n";

  print "// first field, which contains module name and record number\n\n";

  print "record.push_back( sc_Field() );\n\n";

  print "record.back().setMnemonic( \"", uc($module_name),"\" );\n\n";
  print "record.back().setName( \"", $description,"\" );\n\n";

  print "string tmp_str;\n";
  print "double tmp_double;\n";
  print "long   tmp_long;\n\n";

  print "getMnemonic( tmp_str );\n";
  print "sb_Utils::add_subfield( record.back(), \"MODN\", tmp_str );\n";
  print "sb_Utils::add_subfield( record.back(), \"RCID\", getID() );\n\n";


  foreach $i ( @facet ) {

      print "if ( get", $i->[0], "( ";

      if ( $i->[2] eq "A" ) 
      {
          print "tmp_str";
      }
      elsif ( $i->[2] eq "I" ) 
      {
          print "tmp_long";
      }
      elsif ( $i->[2] eq "R" ) 
      {
          print "tmp_double";
      }
      elsif ( $i->[2] eq "C" ) 
      {
          print "tmp_str";
      }
      else 
      {
          print "bogus value ", $i->[2], "\n";
          exit( -1 );
      }

      print " ) )\n";
      print "{\n";
      print "sb_Utils::add_subfield( record.back(),\"", $i->[1],"\", ";

      if ( $i->[2] eq "A" ) 
      {
          print "tmp_str";
      }
      elsif ( $i->[2] eq "I" ) 
      {
          print "tmp_long";
      }
      elsif ( $i->[2] eq "R" ) 
      {
          print "tmp_double";
      }
      elsif ( $i->[2] eq "C" ) 
      {
          print "tmp_str";
      }
      else 
      {
          print "bogus value ", $i->[2], "\n";
          exit( -1 );
      }

      print " );\n";
      print "}\n";
      print "else\n";
      print "{\n";
      print "sb_Utils::add_empty_subfield( record.back(), \"", $i->[1],"\", ";

      if ( $i->[2] eq "A" ) 
      {
          print "sc_Subfield::is_A";
      }
      elsif ( $i->[2] eq "I" ) 
      {
          print "sc_Subfield::is_I";
      }
      elsif ( $i->[2] eq "R" ) 
      {
          print "sc_Subfield::is_R";
      }
      elsif ( $i->[2] eq "C" ) 
      {
          print "sc_Subfield::is_C";
      }
      else 
      {
          print "bogus value ", $i->[2], "\n";
          exit( -1 );
      }

      print " );\n";
      print "}\n\n\n";

  }

  print "return true;\n\n\n} // ", $module_name, "::getRecord\n\n\n\n\n";



# now blat out all the mutator functions

  foreach $i ( @facet ) {

      print "bool\n";
      print "sb_", $module_name, "::set", $i->[0], "( ";


      if ( $i->[2] eq "A" ) 
      {
          print "string const& val";
      }
      elsif ( $i->[2] eq "I" ) 
      {
          print "long val";
      }
      elsif ( $i->[2] eq "R" ) 
      {
          print "double val";
      }
      elsif ( $i->[2] eq "C" ) 
      {
          print "string const& val";
      }
      else 
      {
          print "bogus value ", $i->[2], "\n";
          exit( -1 );
      }
      
      print " )\n{\n";

      print "_imp->_\l", $i->[0]," = val;\n\n";

      print "return true;\n";

      print "} // sb_", $module_name, "::set", $i->[0], "\n\n\n";

  }



  print "bool\n";
  print "sb_", $module_name, "::setRecord( sc_Record const& record )\n";
  print "{\nreturn _ingest_record( *this, *_imp, record );";
  print "\n} // sb_", $module_name, "::setRecord\n\n\n\n\n";



# finally, roll out those unDefine*() implementations


  foreach $i ( @facet ) {

      print "void\n";
      print "sb_", $module_name, "::unDefine", $i->[0], "( )\n{\n";

      print "_imp->_\l", $i->[0]," = ";

      if ( $i->[2] eq "A" ) 
      {
          print "UNVALUED_STRING";
      }
      elsif ( $i->[2] eq "I" ) 
      {
          print "UNVALUED_LONG";
      }
      elsif ( $i->[2] eq "R" ) 
      {
          print "UNVALUED_DOUBLE";
      }
      elsif ( $i->[2] eq "C" ) 
      {
          print "UNVALUED_STRING";
      }
      else 
      {
          print "bogus value ", $i->[2], "\n";
          exit( -1 );
      }

      print ";\n} // sb_", $module_name, "::unDefine", $i->[0], "\n\n\n";

  }


