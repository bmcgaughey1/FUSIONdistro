// header for GCTPC DLL
// RJM 8/21/98

// Projection codes
//   0 = Geographic
//   1 = Universal Transverse Mercator (UTM)
//   2 = State Plane Coordinates
//   3 = Albers Conical Equal Area
//   4 = Lambert Conformal Conic
//   5 = Mercator
//   6 = Polar Stereographic
//   7 = Polyconic
//   8 = Equidistant Conic
//   9 = Transverse Mercator
//  10 = Stereographic
//  11 = Lambert Azimuthal Equal Area
//  12 = Azimuthal Equidistant
//  13 = Gnomonic
//  14 = Orthographic
//  15 = General Vertical Near-Side Perspective
//  16 = Sinusiodal
//  17 = Equirectangular
//  18 = Miller Cylindrical
//  19 = Van der Grinten
//  20 = (Hotine) Oblique Mercator 
//  21 = Robinson
//  22 = Space Oblique Mercator (SOM)
//  23 = Alaska Conformal
//  24 = Interrupted Goode Homolosine 
//  25 = Mollweide
//  26 = Interrupted Mollweide
//  27 = Hammer
//  28 = Wagner IV
//  29 = Wagner VII
//  30 = Oblated Equal Area
//  99 = User defined

// Define projection codes
#ifndef	GCTPDEF
#define GEO 0
#define UTM 1
#define SPCS 2
#define ALBERS 3
#define LAMCC 4
#define MERCAT 5
#define PS 6
#define POLYC 7
#define EQUIDC 8
#define TM 9
#define STEREO 10
#define LAMAZ 11
#define AZMEQD 12
#define GNOMON 13
#define ORTHO 14
#define GVNSP 15
#define SNSOID 16
#define EQRECT 17
#define MILLER 18
#define VGRINT 19
#define HOM 20
#define ROBIN 21
#define SOM 22
#define ALASKA 23
#define GOOD 24
#define MOLL 25
#define IMOLL 26
#define HAMMER 27
#define WAGIV 28
#define WAGVII 29
#define OBEQA 30
#define USDEF 99 

// Define unit code numbers to their names

#define RADIAN 0		// Radians
#define FEET 1			// Feet 
#define METER 2			// Meters
#define SECOND 3		// Seconds
#define DEGREE 4		// Decimal degrees
#define INT_FEET 5		// International Feet

/* The STPLN_TABLE unit value is specifically used for State Plane -- if units
   equals STPLN_TABLE and Datum is NAD83--actual units are retrieved from
   a table according to the zone.  If Datum is NAD27--actual units will be feet.
   An error will occur with this unit if the projection is not State Plane.  */

#define STPLN_TABLE 6

/* General code numbers */

#define IN_BREAK -2		/*  Return status if the interupted projection
				    point lies in the break area */
#define COEFCT 15		/*  projection coefficient count */
#define PROJCT 30		/*  projection count */
#define SPHDCT 31		/*  spheroid count */

#define MAXPROJ 31		/*  Maximum projection number */
#define MAXUNIT 5		/*  Maximum unit code number */
#define GEO_TERM 0		/*  Array index for print-to-term flag */
#define GEO_FILE 1		/*  Array index for print-to-file flag */
#define GEO_TRUE 1		/*  True value for geometric true/false flags */
#define GEO_FALSE -1		/*  False val for geometric true/false flags */

#define	GCTPDEF
#endif  // #ifndef GCTPDEF

#ifdef __cplusplus
extern "C"
{
#endif
__declspec(dllexport) BOOL CALLBACK GCTP_Project(double *incoor, long insys, long inzone, double *inparm,
						long inunit, long inspheroid, long ipr, char *efile,
						long jpr, char *pfile, double *outcoor, long outsys,
						long outzone, double *outparm, long outunit, long outspheroid, long *iflg);

__declspec(dllexport) BOOL CALLBACK GCTP_GEOtoUTM(double *incoor, long pts, long inunit, long inspheroid, 
						char *efile,
						double *outcoor, long outzone, double *outparm, 
						long outunit, long outspheroid, long *iflg);

__declspec(dllexport) BOOL CALLBACK GCTP_GEOtoSTPLN(double *incoor, long pts, long inunit, long inspheroid, 
						char *efile,
						double *outcoor, long outzone, double *outparm, 
						long outunit, long outspheroid, long *iflg);

__declspec(dllexport) BOOL CALLBACK GCTP_UTMtoGEO(double *incoor, long pts, long inzone, double *inparm,
						long inunit, long inspheroid, char *efile,
						double *outcoor, long outunit, long outspheroid,
						long *iflg);

__declspec(dllexport) BOOL CALLBACK GCTP_STPLNtoGEO(double *incoor, long pts, long inzone, double *inparm,
						long inunit, long inspheroid, char *efile,
						double *outcoor, long outunit, long outspheroid,
						long *iflg);

__declspec(dllexport) BOOL CALLBACK GCTP_UTMtoSTPLN(double *incoor, long pts, long inzone, double *inparm,
						long inunit, long inspheroid, char *efile,
						double *outcoor,
						long outzone, double *outparm, long outunit, long outspheroid,
						long *iflg);

__declspec(dllexport) BOOL CALLBACK GCTP_STPLNtoUTM(double *incoor, long pts, long inzone, double *inparm,
						long inunit, long inspheroid, char *efile,
						double *outcoor,
						long outzone, double *outparm, long outunit, long outspheroid,
						long *iflg);

__declspec(dllexport) BOOL CALLBACK GCTP_UTMtoUTM(double *incoor, long pts, long inzone, double *inparm,
						long inunit, long inspheroid, char *efile,
						double *outcoor, long outzone, double *outparm, long outunit, long outspheroid,
						long *iflg);

__declspec(dllexport) BOOL CALLBACK GCTP_STPLNtoSTPLN(double *incoor, long pts, long inzone, double *inparm,
						long inunit, long inspheroid, char *efile,
						double *outcoor, long outzone, double *outparm, long outunit, long outspheroid,
						long *iflg);

__declspec(dllexport) BOOL CALLBACK GCTP_forward_init(long outsys, long outzone, double *outparm, long outspheroid, long *iflg);

__declspec(dllexport) BOOL CALLBACK GCTP_inverse_init(long insys, long inzone, double *inparm, long inspheroid, long *iflg);

__declspec(dllexport) BOOL CALLBACK GCTP_forward_transform(long outsys, double lon, double lat, double *x, double *y);

__declspec(dllexport) BOOL CALLBACK GCTP_inverse_transform(long insys, double x, double y, double *lon, double *lat);

#ifdef __cplusplus
}
#endif
