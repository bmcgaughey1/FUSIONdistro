//   PHY - attempt to add support for other fields
//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
//
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//
// $Id: sb_Rsdf.cpp,v 1.8 1998/08/31 22:17:30 mcoletti Exp $
//

#include "builder/sb_Rsdf.h"



#include <iostream>
#include <strstream>

#include <limits.h>
#include <float.h>

#ifndef INCLUDED_SB_UTILS_H
#include "builder/sb_Utils.h"
#endif

#ifndef INCLUDED_SB_FOREIGNID_H
#include "builder/sb_ForeignID.h"
#endif

#ifndef INCLUDED_SC_RECORD_H
#include "container/sc_Record.h"
#endif

#ifndef INCLUDED_SC_FIELD_H
#include "container/sc_Field.h"
#endif

#ifndef INCLUDED_SC_SUBFIELD_H
#include "container/sc_Subfield.h"
#endif

#ifndef INCLUDED_SIO_8211CONVERTER_H
#include "io/sio_8211Converter.h"
#endif



static const char* _ident = "$Id: sb_Rsdf.cpp,v 1.8 1998/08/31 22:17:30 mcoletti Exp $";

// Strings and integers are initialized with these values; they are used
// to indicate whether a given module value has been assigned a value or not.

// (XXX I arbitrarily chose 0x4 as the sentinal value.  I hate ad hoc crap.)

static const string  UNVALUED_STRING(1, static_cast<string::value_type>(0x4) );

static const long    UNVALUED_LONG   = INT_MIN;

static const double  UNVALUED_DOUBLE = DBL_MAX;

struct sb_Rsdf_Imp
{
  string   _ObjectRepresentation;
  string   _CellSequencingCode;
  string   _AcquisitionDeviceMethod;
  string   _AcquisitionDate;
  string   _Comments;
  string   _DefaultImplementation;
  string   _Compression;
  string   _CodingMethod;
  long     _RowExtent;
  long     _ColumnExtent;
  // long     _PlaneExtent;  // Phy - cut out unneeded stuff
  string   _ScanOrigin;
  string   _ScanPattern;
  string   _TesseralIndexing; 
  // string   _TesseralIndexFormat;   -- Phy - cut out unneeded stuff
  // string   _TesseralIndexingDescription; -- Phy - cut out unneeded stuff
  long     _NumberLinesAlternation;
  string   _FirstScanDirection;
  double   _AspectRatio;
  long     _NumberLayers;
  double   _SADR_X;
  double   _SADR_Y;
 
  sb_ForeignID _isid;           // internal spatial foreign ID
  foreign_ids  _lyids;          // layer ID foreign ID container
  foreign_ids  _ratps;          // raster attribute foreign ID container

  sb_Rsdf_Imp()
    :
    _ObjectRepresentation( UNVALUED_STRING ),
    _CellSequencingCode( UNVALUED_STRING ),
    _AcquisitionDeviceMethod( UNVALUED_STRING ),
    _AcquisitionDate( UNVALUED_STRING ),
    _Comments( UNVALUED_STRING ),
    _DefaultImplementation( UNVALUED_STRING ),
    _Compression( UNVALUED_STRING ),
    _CodingMethod( UNVALUED_STRING ),
    _RowExtent( UNVALUED_LONG ),
    _ColumnExtent( UNVALUED_LONG ),
  //  _PlaneExtent( UNVALUED_LONG ),  Phy - cut out unneeded stuff
    _ScanOrigin( UNVALUED_STRING ),
    _ScanPattern( UNVALUED_STRING ),
    _TesseralIndexing( UNVALUED_STRING ), 
  //  _TesseralIndexFormat( UNVALUED_STRING ),  Phy - cut out unneeded stuff
  //  _TesseralIndexingDescription( UNVALUED_STRING ), Phy - cut out unneeded stuff
    _NumberLinesAlternation( UNVALUED_LONG ),
    _FirstScanDirection( UNVALUED_STRING ),
    _AspectRatio( UNVALUED_DOUBLE ),
    _NumberLayers( UNVALUED_LONG ),
    _SADR_X( UNVALUED_DOUBLE ),
    _SADR_Y( UNVALUED_DOUBLE )
  {}

}; // sb_Rsdf_Imp


sb_Rsdf::sb_Rsdf()
  : _imp( new sb_Rsdf_Imp() )
{
  setMnemonic("RSDF");
  setID( 1 );


  // insert static initializers

} // Rsdf ctor


sb_Rsdf::~sb_Rsdf()
{
  delete _imp ;
} // Rsdf dtor




static sio_8211Converter_I converter_I; // XXX should define these in
static sio_8211Converter_A converter_A; // XXX sio_8211Converter.h
static sio_8211Converter_R converter_R;

static sio_8211Schema _schema; // module specific schema

static
void
_build_schema( sio_8211Schema& schema )
{
  schema.clear();               // make sure we are starting with clean schema

  schema.push_back( sio_8211FieldFormat() );

  // Phy - throughout here I added in missing required subfields, and excluded
  //        unneeded subfields and entire fields.

  sio_8211FieldFormat& field_format = schema.back();

  field_format.setDataStructCode( sio_8211FieldFormat::vector );
  field_format.setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  field_format.setName( "Raster Definition" );
  field_format.setTag( "RSDF" );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "MODN" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "RCID" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "OBRP" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "CSCD" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "AQMD" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "AQDT" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "COMT" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "DEFI" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "CMPR" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "METH" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "RWXT" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "CLXT" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );

// Phy - cut out all unneeded stuff
//  field_format.push_back( sio_8211SubfieldFormat() );
//
//  field_format.back().setLabel( "PLXT" );
//  field_format.back().setType( sio_8211SubfieldFormat::I );
//  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
//  field_format.back().setConverter( &converter_I );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "SCOR" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "SCPT" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "TIDX" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

// Phy - cut out unneeded stuff
//  field_format.push_back( sio_8211SubfieldFormat() );
//
//  field_format.back().setLabel( "TIFT" );
//  field_format.back().setType( sio_8211SubfieldFormat::A );
//  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
//  field_format.back().setConverter( &converter_A );
//
//
//  field_format.push_back( sio_8211SubfieldFormat() );
//
//  field_format.back().setLabel( "TIDS" );
//  field_format.back().setType( sio_8211SubfieldFormat::A );
//  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
//  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "ALTN" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "FSCN" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "ASPR" );
  field_format.back().setType( sio_8211SubfieldFormat::R );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_R );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "NLAY" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );


				// ISID

  schema.push_back( sio_8211FieldFormat() );

  schema.back().setDataStructCode( sio_8211FieldFormat::vector );
  schema.back().setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  schema.back().setName( "Internal Spatial Id" );
  schema.back().setTag( "ISID" );


  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "MODN" );
  schema.back().back().setType( sio_8211SubfieldFormat::A );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_A );


  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "RCID" );
  schema.back().back().setType( sio_8211SubfieldFormat::I );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_I );


// Phy - cut out all unneeded stuff for now
//
//
				// RDXT
//
//  schema.push_back( sio_8211FieldFormat() );
//
//  schema.back().setDataStructCode( sio_8211FieldFormat::array );
//  schema.back().setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
//  schema.back().setName( "Raster Dimension Extent" );
//  schema.back().setTag( "RDXT" );
//
//
//  schema.back().push_back( sio_8211SubfieldFormat() );
//
//  schema.back().back().setLabel( "DEXT" );
//  schema.back().back().setType( sio_8211SubfieldFormat::I );
//  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
//  schema.back().back().setConverter( &converter_I );
//
//
//  schema.back().push_back( sio_8211SubfieldFormat() );
//
//  schema.back().back().setLabel( "DSCO" );
//  schema.back().back().setType( sio_8211SubfieldFormat::A );
//  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
//  schema.back().back().setConverter( &converter_A );


				// SADR

  schema.push_back( sio_8211FieldFormat() );

  schema.back().setDataStructCode( sio_8211FieldFormat::vector );
  schema.back().setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  schema.back().setName( "Spatial Address" );
  schema.back().setTag( "SADR" );


				// XXX Need finer grain control of
				// XXX coordinate format; arbitrarily
				// XXX using 'R'

  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "X" );
  schema.back().back().setType( sio_8211SubfieldFormat::R );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_R );


  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "Y" );
  schema.back().back().setType( sio_8211SubfieldFormat::R );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_R );



#ifdef NOT_IMPLEMENTED

				// XXLB

  schema.push_back( sio_8211FieldFormat() );

  schema.back().setDataStructCode( sio_8211FieldFormat::array );
  schema.back().setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  schema.back().setName( "X-Axis Label" );
  schema.back().setTag( "XXLB" );


				// YXLB

  schema.push_back( sio_8211FieldFormat() );

  schema.back().setDataStructCode( sio_8211FieldFormat::array );
  schema.back().setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  schema.back().setName( "Y-Axis Label" );
  schema.back().setTag( "YXLB" );

#endif

				// LYID

  schema.push_back( sio_8211FieldFormat() );

  schema.back().setDataStructCode( sio_8211FieldFormat::array );
  schema.back().setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  schema.back().setName( "Layer ID" );
  schema.back().setTag( "LYID" );


  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "MODN" );
  schema.back().back().setType( sio_8211SubfieldFormat::A );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_A );


  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "RCID" );
  schema.back().back().setType( sio_8211SubfieldFormat::I );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_I );



			// RATP

  schema.push_back( sio_8211FieldFormat() );

  schema.back().setDataStructCode( sio_8211FieldFormat::array );
  schema.back().setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  schema.back().setName( "Raster Attribute ID" );
  schema.back().setTag( "RATP" );


  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "MODN" );
  schema.back().back().setType( sio_8211SubfieldFormat::A );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_A );


  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "RCID" );
  schema.back().back().setType( sio_8211SubfieldFormat::I );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_I );


// Phy - cut out all unneeded stuff for now
//
				// CPID
//
//  schema.push_back( sio_8211FieldFormat() );
//
//  schema.back().setDataStructCode( sio_8211FieldFormat::array );
//  schema.back().setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
//  schema.back().setName( "Composite ID" );
//  schema.back().setTag( "CPID" );
//
//
//  schema.back().push_back( sio_8211SubfieldFormat() );
//
//  schema.back().back().setLabel( "MODN" );
//  schema.back().back().setType( sio_8211SubfieldFormat::A );
//  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
//  schema.back().back().setConverter( &converter_A );
//
//
//  schema.back().push_back( sio_8211SubfieldFormat() );
//
//  schema.back().back().setLabel( "RCID" );
//  schema.back().back().setType( sio_8211SubfieldFormat::I );
//  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
//  schema.back().back().setConverter( &converter_I );

} // _build_schema





//
// NOTE THAT THIS ONLY GETS THE FIRST FIELD!!
// Phy -- attempt to add support for other fields
//
static
bool
_ingest_record( sb_Rsdf& rsdf, sb_Rsdf_Imp &rsdf_imp, sc_Record const& record )
{

  // Make sure we have a record from an
  // External Spatial Reference module.

  sc_FieldCntr::const_iterator curfield;

  if ( ! sb_Utils::getFieldByMnem( record,"RSDF",curfield) )
  {
#ifdef SDTSXX_DEBUG
    cerr << "sb_Rsdf::sb_Rsdf(sc_Record const&): "
	 << "Not an raster definition record.";
    cerr << endl;
#endif
    return false;
  }


  // We have a primary field from a  module. Start// picking it apart.

  sc_SubfieldCntr::const_iterator cursubfield;

  string tmp_str;
  long   tmp_int;


  // MODN
  if (sb_Utils::getSubfieldByMnem(*curfield,"MODN",cursubfield))
  {
    cursubfield->getA( tmp_str );
    rsdf.setMnemonic( tmp_str );
  }


  // RCID
  if (sb_Utils::getSubfieldByMnem(*curfield,"RCID",cursubfield))
  {
    cursubfield->getI( tmp_int );
    rsdf.setID( tmp_int );
  }


  // OBRP
  if (sb_Utils::getSubfieldByMnem(*curfield,"OBRP",cursubfield))
  {
    cursubfield->getA( rsdf_imp._ObjectRepresentation);
  }
  else
  {
    return false;
  }


  // CSCD
  if (sb_Utils::getSubfieldByMnem(*curfield,"CSCD",cursubfield))
  {
    cursubfield->getA( rsdf_imp._CellSequencingCode);
  }
  else
  {
    return false;
  }


  // Phy -- subfields CMPR and METH moved to after DEFI

  // AQMD
  if (sb_Utils::getSubfieldByMnem(*curfield,"AQMD",cursubfield))
  {
    cursubfield->getA( rsdf_imp._AcquisitionDeviceMethod);
  }
  else
  {
    return false;
  }


  // AQDT
  if (sb_Utils::getSubfieldByMnem(*curfield,"AQDT",cursubfield))
  {
    cursubfield->getA( rsdf_imp._AcquisitionDate);
  }
  else
  {
    return false;
  }


  // COMT
  if (sb_Utils::getSubfieldByMnem(*curfield,"COMT",cursubfield))
  {
    cursubfield->getA( rsdf_imp._Comments);
  }
  else
  {
    return false;
  }


  // DEFI
  if (sb_Utils::getSubfieldByMnem(*curfield,"DEFI",cursubfield))
  {
    cursubfield->getA( rsdf_imp._DefaultImplementation);
  }
  else
  {
    return false;
  }


  // CMPR -- Phy - moved this after DEFI
  if (sb_Utils::getSubfieldByMnem(*curfield,"CMPR",cursubfield))
  {
    cursubfield->getA( rsdf_imp._Compression);
  }
  else
  {
    return false;
  }


  // METH -- Phy move this after CMPR
  if (sb_Utils::getSubfieldByMnem(*curfield,"METH",cursubfield))
  {
    cursubfield->getA( rsdf_imp._CodingMethod);  // Phy - fix name
  }
  else
  {
    return false;
  }


  // RWXT
  if (sb_Utils::getSubfieldByMnem(*curfield,"RWXT",cursubfield))
  {
    cursubfield->getI( rsdf_imp._RowExtent); //Phy - fix spelling
  }
  else
  {
    return false;
  }


  // CLXT
  if (sb_Utils::getSubfieldByMnem(*curfield,"CLXT",cursubfield))
  {
    cursubfield->getI( rsdf_imp._ColumnExtent);
  }
  else
  {
    return false;
  }


  // PLXT -- Phy - cutout unneeded stuff
  //if (sb_Utils::getSubfieldByMnem(*curfield,"PLXT",cursubfield))
  // {
  //  cursubfield->getI( rsdf_imp._PlaneExtent);
  //}
  //else
  //{
  //  return false;
  //}


  // SCOR
  if (sb_Utils::getSubfieldByMnem(*curfield,"SCOR",cursubfield))
  {
    cursubfield->getA( rsdf_imp._ScanOrigin);
  }
  else
  {
    return false;
  }


   // SCPT - Phy - moved to after SCOR
  if (sb_Utils::getSubfieldByMnem(*curfield,"SCPT",cursubfield))
  {
    cursubfield->getA( rsdf_imp._ScanPattern);
  }
  else
  {
    return false;
  }


  // TIDX
  if (sb_Utils::getSubfieldByMnem(*curfield,"TIDX",cursubfield))
  {
    cursubfield->getA( rsdf_imp._TesseralIndexing);
  }
  else
  {
    return false;
  }


  // TIFT -- Phy - cut out unneeded stuff
  //if (sb_Utils::getSubfieldByMnem(*curfield,"TIFT",cursubfield))
  //{
  //  cursubfield->getA( rsdf_imp._TesseralIndexFormat);
  //}
  //else
  //{
  //  return false;
  // }


  // TIDS -- Phy - cut out unneeded stuff
  //if (sb_Utils::getSubfieldByMnem(*curfield,"TIDS",cursubfield))
  //{
  //  cursubfield->getA( rsdf_imp._TesseralIndexingDescription);
  //}
  //else
  //{
  //  return false;
  //}


  // ALTN
  if (sb_Utils::getSubfieldByMnem(*curfield,"ALTN",cursubfield))
  {
    cursubfield->getI( rsdf_imp._NumberLinesAlternation);
  }
  else
  {
    return false;
  }


  // FSCN
  if (sb_Utils::getSubfieldByMnem(*curfield,"FSCN",cursubfield))
  {
    cursubfield->getA( rsdf_imp._FirstScanDirection);
  }
  else
  {
    return false;
  }


  // ASPR
  if (sb_Utils::getSubfieldByMnem(*curfield,"ASPR",cursubfield))
  {
    cursubfield->getR( rsdf_imp._AspectRatio); //Phy - fix spelling
  }
  else
  {
    return false;
  }


  // NLAY
  if (sb_Utils::getSubfieldByMnem(*curfield,"NLAY",cursubfield))
  {
    cursubfield->getI( rsdf_imp._NumberLayers);
  }
  else
  {
    return false;
  }


  // Phy ??? -- Add support for secondary field ISID

  if ( ! sb_Utils::getFieldByMnem( record,"ISID",curfield) )
  {
#ifdef SDTSXX_DEBUG
    cerr << "sb_Rsdf::sb_Rsdf(sc_Record const&): "
	 << "No Secondary ISID field.";
    cerr << endl;
#endif
    return false;
  }


  // We have a secondary ISID field. Start picking it apart.

  // Phy ??? - will Mnem MODN work here or does it need to be different to avoid confusion ???
  // ISID_MODN

  string tmp_string;

  if (sb_Utils::getSubfieldByMnem(*curfield,"MODN",cursubfield))
  {
    cursubfield->getA( tmp_string );
    rsdf_imp._isid.setModuleName( tmp_string );
  }
  else
  {
    return false;
  }


  // ISID_RCID

  long tmp_long;

  if (sb_Utils::getSubfieldByMnem(*curfield,"RCID",cursubfield))
  {
    cursubfield->getI( tmp_long );
    rsdf_imp._isid.setRecordID( tmp_long );
  }
  else
  {
    return false;
  }


  // Phy ??? -- Add support for secondary field SADR

  if ( ! sb_Utils::getFieldByMnem( record,"SADR",curfield) )
  {
#ifdef SDTSXX_DEBUG
    cerr << "sb_Rsdf::sb_Rsdf(sc_Record const&): "
	 << "No Secondary SADR field.";
    cerr << endl;
#endif
    return false;
  }


  // We have a secondary SADR field. Start picking it apart.

  // _SADR_X
  if (sb_Utils::getSubfieldByMnem(*curfield,"X",cursubfield))
  {
	  // Phy - ??? - didn't check on this call name ..
    cursubfield->getR( rsdf_imp._SADR_X);
  }
  else
  {
    return false;
  }

  // _SADR_Y
  if (sb_Utils::getSubfieldByMnem(*curfield,"Y",cursubfield))
  {
    cursubfield->getR( rsdf_imp._SADR_Y);
  }
  else
  {
    return false;
  }


  // Phy ??? -- Add support for secondary field LYID     ??? REPEATING FIELD ???

  // XXX This still needs to be done.  The getFieldByMnem mechanism
  // XXX breaks down in the case of repeating fields.  Either something
  // XXX will have to be added to sb_Utils to handle this case, or we'll
  // XXX have to unravel the record by hand here.  Since we're not needing to
  // XXX read Raster records yet , I'll put off implementing this for now.
 
  if ( ! sb_Utils::getFieldByMnem( record,"ISID",curfield) )
  {
#ifdef SDTSXX_DEBUG
    cerr << "sb_Rsdf::sb_Rsdf(sc_Record const&): "
	 << "No Secondary ISID field.";
    cerr << endl;
#endif
    return false;
  }


#ifdef NOT_IMPLEMENTED

  // Phy ??? - will Mnem MODN work here or does it need to be different to avoid confusion ???
  // LYID_MODN
  if (sb_Utils::getSubfieldByMnem(*curfield,"MODN",cursubfield))
  {
    cursubfield->getA( rsdf_imp._LYID_MODN);
  }
  else
  {
    return false;
  }

  // LYID_RCID
  if (sb_Utils::getSubfieldByMnem(*curfield,"RCID",cursubfield))
  {
    cursubfield->getI( rsdf_imp._LYID_RCID);
  }
  else
  {
    return false;
  }


  // Phy ??? -- Add support for secondary field RATP  ??? REPEATING FIELD ???

  if ( ! sb_Utils::getFieldByMnem( record,"RATP",curfield) )
  {
#ifdef SDTSXX_DEBUG
    cerr << "sb_Rsdf::sb_Rsdf(sc_Record const&): "
	 << "No Secondary RATP field.";
    cerr << endl;
#endif
    return false;
  }


  // Phy ??? - will Mnem MODN work here or does it need to be
  // different to avoid confusion ???

  // XXX The same thing applies to this field as what's down for the
  // XXX previous one.

  // RATP_MODN
  if (sb_Utils::getSubfieldByMnem(*curfield,"MODN",cursubfield))
  {
    cursubfield->getA( rsdf_imp._RATP_MODN);
  }
  else
  {
    return false;
  }

  // RATP_RCID
  if (sb_Utils::getSubfieldByMnem(*curfield,"RCID",cursubfield))
  {
    cursubfield->getI( rsdf_imp._RATP_RCID);
  }
  else
  {
    return false;
  }

#endif // NOT_IMPLEMENTED


  return true;


} // _ingest_record




bool
sb_Rsdf::getObjectRepresentation( string& val ) const
{
  if ( _imp->_ObjectRepresentation == UNVALUED_STRING )
    return false;

  val = _imp->_ObjectRepresentation;

  return true;
} // sb_Rsdf::getObjectRepresentation


bool
sb_Rsdf::getCellSequencingCode( string& val ) const
{
  if ( _imp->_CellSequencingCode == UNVALUED_STRING )
    return false;

  val = _imp->_CellSequencingCode;

  return true;
} // sb_Rsdf::getCellSequencingCode


bool
sb_Rsdf::getEncodingMethod( string& val ) const
{
  if ( _imp->_CodingMethod == UNVALUED_STRING )
    return false;

  val = _imp->_CodingMethod;

  return true;
} // sb_Rsdf::getEncodingMethod


bool
sb_Rsdf::getCompression( string& val ) const
{
  if ( _imp->_Compression == UNVALUED_STRING )
    return false;

  val = _imp->_Compression;

  return true;
} // sb_Rsdf::getCompression


bool
sb_Rsdf::getAcquisitionDeviceMethod( string& val ) const
{
  if ( _imp->_AcquisitionDeviceMethod == UNVALUED_STRING )
    return false;

  val = _imp->_AcquisitionDeviceMethod;

  return true;
} // sb_Rsdf::getAcquisitionDeviceMethod


bool
sb_Rsdf::getAcquisitionDate( string& val ) const
{
  if ( _imp->_AcquisitionDate == UNVALUED_STRING )
    return false;

  val = _imp->_AcquisitionDate;

  return true;
} // sb_Rsdf::getAcquisitionDate


bool
sb_Rsdf::getComments( string& val ) const
{
  if ( _imp->_Comments == UNVALUED_STRING )
    return false;

  val = _imp->_Comments;

  return true;
} // sb_Rsdf::getComments


bool
sb_Rsdf::getDefaultImplementation( string& val ) const
{
  if ( _imp->_DefaultImplementation == UNVALUED_STRING )
    return false;

  val = _imp->_DefaultImplementation;

  return true;
} // sb_Rsdf::getDefaultImplementation


bool
sb_Rsdf::getRowExtant( long& val ) const
{
  if ( _imp->_RowExtent == UNVALUED_LONG )
    return false;

  val = _imp->_RowExtent;

  return true;
} // sb_Rsdf::getRowExtant


bool
sb_Rsdf::getColumnExtent( long& val ) const
{
  if ( _imp->_ColumnExtent == UNVALUED_LONG )
    return false;

  val = _imp->_ColumnExtent;

  return true;
} // sb_Rsdf::getColumnExtent


// Phy -- cut out unneeded stuff
//bool
//sb_Rsdf::getPlaneExtent( long& val ) const
//{
//  if ( _imp->_PlaneExtent == UNVALUED_LONG )
//    return false;
//
//  val = _imp->_PlaneExtent;
//
//  return true;
//} // sb_Rsdf::getPlaneExtent


bool
sb_Rsdf::getScanOrigin( string& val ) const
{
  if ( _imp->_ScanOrigin == UNVALUED_STRING )
    return false;

  val = _imp->_ScanOrigin;

  return true;
} // sb_Rsdf::getScanOrigin


bool
sb_Rsdf::getTesseralIndexing( string& val ) const
{
  if ( _imp->_TesseralIndexing == UNVALUED_STRING )
    return false;

  val = _imp->_TesseralIndexing;

  return true;
} // sb_Rsdf::getTesseralIndexing


bool
sb_Rsdf::getScanPattern( string& val ) const
{
  if ( _imp->_ScanPattern == UNVALUED_STRING )
    return false;

  val = _imp->_ScanPattern;

  return true;
} // sb_Rsdf::getScanPattern


// Phy - cut out unneeded stuff
//bool
//sb_Rsdf::getTesseralIndexFormat( string& val ) const
//{
//  if ( _imp->_TesseralIndexFormat == UNVALUED_STRING )
//    return false;
//
//  val = _imp->_TesseralIndexFormat;
//
//  return true;
//} // sb_Rsdf::getTesseralIndexFormat
//
//
//bool
//sb_Rsdf::getTesseralIndexingDescription( string& val ) const
//{
// if ( _imp->_TesseralIndexingDescription == UNVALUED_STRING )
//    return false;
//
//  val = _imp->_TesseralIndexingDescription;
//
//  return true;
//} // sb_Rsdf::getTesseralIndexingDescription


bool
sb_Rsdf::getNumberLinesAlternation( long& val ) const
{
  if ( _imp->_NumberLinesAlternation == UNVALUED_LONG )
    return false;

  val = _imp->_NumberLinesAlternation;

  return true;
} // sb_Rsdf::getNumberLinesAlternation


bool
sb_Rsdf::getFirstScanDirection( string& val ) const
{
  if ( _imp->_FirstScanDirection == UNVALUED_STRING )
    return false;

  val = _imp->_FirstScanDirection;

  return true;
} // sb_Rsdf::getFirstScanDirection


bool
sb_Rsdf::getAspectRation( double& val ) const
{
  if ( _imp->_AspectRatio == UNVALUED_DOUBLE )
    return false;

  val = _imp->_AspectRatio;

  return true;
} // sb_Rsdf::getAspectRation


bool
sb_Rsdf::getNumberLayers( long& val ) const
{
  if ( _imp->_NumberLayers == UNVALUED_LONG )
    return false;

  val = _imp->_NumberLayers;

  return true;
} // sb_Rsdf::getNumberLayers



bool
sb_Rsdf::getSpatialAddress( double& x, double& y ) const
{
  if ( _imp->_SADR_X == UNVALUED_DOUBLE || _imp->_SADR_Y == UNVALUED_DOUBLE )
    return false;

  x = _imp->_SADR_X;
  y = _imp->_SADR_Y;

  return true;
} // sb_Rsdf::getSpatialAddress


bool
sb_Rsdf::getInternalSpatialId( sb_ForeignID & fid ) const
{
  if ( _imp->_isid.getModuleName() == "" || _imp->_isid.getRecordID() == 0 )
    {
      return false;
    }

  fid = _imp->_isid;

  return true;
} 


bool
sb_Rsdf::getLayerIds( foreign_ids& fids ) const
{
  if ( _imp->_lyids.empty() )
    {
      return false;
    }

  fids = _imp->_lyids;

  return true;
} 



bool
sb_Rsdf::getRasterAttributeIds( foreign_ids& fids ) const
{
  if ( _imp->_ratps.empty() )
    {
      return false;
  }

  fids = _imp->_ratps;

  return true;
} 


bool
sb_Rsdf::getSchema( sio_8211Schema& schema ) const
{
  // If the schema hasn't been
  // initialized, please do so.

  if ( _schema.empty() )
  {
    _build_schema( _schema );
  }

  if ( _schema.empty() )   // oops ... something screwed up
  {
    return false;
  }

  schema = _schema;

  return true;

} // sb_Rsdf::getSchema




bool
sb_Rsdf::getRecord( sc_Record & record ) const
{
  record.clear();               // start with a clean slate

  // first field, which contains module name and record number

  record.push_back( sc_Field() );

  record.back().setMnemonic( "RSDF" );

  record.back().setName( "Raster Definition" );

  string tmp_str;
  double tmp_double;
  long   tmp_long;

  getMnemonic( tmp_str );
  sb_Utils::add_subfield( record.back(), "MODN", tmp_str );
  sb_Utils::add_subfield( record.back(), "RCID", getID() );

  if ( getObjectRepresentation( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"OBRP", tmp_str );
  }
  else
  {
    return false;
  }


  if ( getCellSequencingCode( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"CSCD", tmp_str );
  }
  else
  {
    return false;
  }


  if ( getAcquisitionDeviceMethod( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"AQMD", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "AQMD", sc_Subfield::is_A );
  }


  if ( getAcquisitionDate( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"AQDT", tmp_str );
  }
  else
  {
    // Phy - change to not make date mandatory 
    sb_Utils::add_empty_subfield( record.back(), "AQDT", sc_Subfield::is_A );
  }


  if ( getComments( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"COMT", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "COMT", sc_Subfield::is_A );
  }


  if ( getDefaultImplementation( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"DEFI", tmp_str );
  }
  else
  {
    return false;
  }


  if ( getCompression( tmp_str ) ) // XXX Mandatory?
  {
    sb_Utils::add_subfield( record.back(),"CMPR", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "CMPR", sc_Subfield::is_A );
  }


  if ( getEncodingMethod( tmp_str ) ) // XXX Mandatory?
  {
    sb_Utils::add_subfield( record.back(),"METH", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "METH", sc_Subfield::is_A );
  }



  if ( getRowExtant( tmp_long ) )
  {
    sb_Utils::add_subfield( record.back(),"RWXT", tmp_long );
  }
  else
  {
    return false;
  }


  if ( getColumnExtent( tmp_long ) )
  {
    sb_Utils::add_subfield( record.back(),"CLXT", tmp_long );
  }
  else
  {
    return false;
  }

  
  // Phy - cut out unneeded stuff
  //if ( getPlaneExtent( tmp_long ) )
  //{
  // sb_Utils::add_subfield( record.back(),"PLXT", tmp_long );
  //}
  //else
  //{
  //  sb_Utils::add_empty_subfield( record.back(), "PLXT", sc_Subfield::is_I );
  //}


  if ( getScanOrigin( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"SCOR", tmp_str );
  }
  else
  {
    return false;
  }


  if ( getScanPattern( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"SCPT", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "SCPT", sc_Subfield::is_A );
  }


  if ( getTesseralIndexing( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"TIDX", tmp_str );
  }
  else
  {
    return false;
  }



// Phy - cut out unneeded stuff
//  if ( getTesseralIndexFormat( tmp_str ) )
//  {
//    sb_Utils::add_subfield( record.back(),"TIFT", tmp_str );
//  }
//  else
//  {
//    sb_Utils::add_empty_subfield( record.back(), "TIFT", sc_Subfield::is_A );
//  }
//
//
//  if ( getTesseralIndexingDescription( tmp_str ) )
//  {
//    sb_Utils::add_subfield( record.back(),"TIDS", tmp_str );
//  }
//  else
//  {
//    sb_Utils::add_empty_subfield( record.back(), "TIDS", sc_Subfield::is_A );
//  }


  if ( getNumberLinesAlternation( tmp_long ) )
  {
    sb_Utils::add_subfield( record.back(),"ALTN", tmp_long );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "ALTN", sc_Subfield::is_I );
  }


  if ( getFirstScanDirection( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"FSCN", tmp_str );
  }
  else
  {
    return false;
  }


  if ( getAspectRation( tmp_double ) )
  {
    sb_Utils::add_subfield( record.back(),"ASPR", tmp_double );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "ASPR", sc_Subfield::is_R );
  }


  if ( getNumberLayers( tmp_long ) )
  {
    sb_Utils::add_subfield( record.back(),"NLAY", tmp_long );
  }
  else
  {
    return false;
  }



  // PHY -- Field ISID

  record.push_back( sc_Field() );

  record.back().setMnemonic( "ISID" );

  record.back().setName( "Internal Spatial Id" );


  sb_ForeignID isid;

  if ( getISID( isid ) )
  {
    sb_Utils::add_subfield( record.back(),"MODN", isid.getModuleName() );
    sb_Utils::add_subfield( record.back(),"RCID", isid.getRecordID() );
  }
  else
  {
    return false;
  }



  // Field SADR 

  record.push_back( sc_Field() );

  record.back().setMnemonic( "SADR" );

  record.back().setName( "Spatial Address" );


  double x, y;

  if ( getSADR( x, y ) )
  {
    sb_Utils::add_subfield( record.back(),"X", x );
    sb_Utils::add_subfield( record.back(),"Y", y );
  }
  else
  {
    return false;
  }


  // For each LYID field, add a LYID field to the record.

  for ( foreign_ids::const_iterator lyid_itr = _imp->_lyids.begin();
        lyid_itr != _imp->_lyids.end();
        lyid_itr++ )
    {

      record.push_back( sc_Field() );

      record.back().setMnemonic( "LYID" );

      record.back().setName( "Layer Id" );

      sb_Utils::add_subfield( record.back(),"MODN", (*lyid_itr).getModuleName() );
      sb_Utils::add_subfield( record.back(),"RCID", (*lyid_itr).getRecordID() );
    }


  // For each RATP field, add a RAPT field to the record.

  for ( foreign_ids::const_iterator ratp_itr = _imp->_ratps.begin();
        ratp_itr != _imp->_ratps.end();
        ratp_itr++ )
    {
      record.push_back( sc_Field() );

      record.back().setMnemonic( "RATP" );

      record.back().setName( "Raster Attribute Id" );

      sb_Utils::add_subfield( record.back(),"MODN", (*ratp_itr).getModuleName() );
      sb_Utils::add_subfield( record.back(),"RCID", (*ratp_itr).getRecordID() );
    }

  return true;


} // Rsdf::getRecord




bool
sb_Rsdf::setObjectRepresentation( string const& val )
{
  _imp->_ObjectRepresentation = val;

  return true;
} // sb_Rsdf::setObjectRepresentation


bool
sb_Rsdf::setCellSequencingCode( string const& val )
{
  _imp->_CellSequencingCode = val;

  return true;
} // sb_Rsdf::setCellSequencingCode


bool
sb_Rsdf::setCompression( string const& val )
{
  _imp->_Compression = val;

  return true;
} // sb_Rsdf::setCompression


bool
sb_Rsdf::setEncodingMethod( string const& val )
{
  _imp->_CodingMethod = val;

  return true;
} // sb_Rsdf::setEncodingMethod


bool
sb_Rsdf::setAcquisitionDeviceMethod( string const& val )
{
  _imp->_AcquisitionDeviceMethod = val;

  return true;
} // sb_Rsdf::setAcquisitionDeviceMethod


bool
sb_Rsdf::setAcquisitionDate( string const& val )
{
  _imp->_AcquisitionDate = val;

  return true;
} // sb_Rsdf::setAcquisitionDate


bool
sb_Rsdf::setComments( string const& val )
{
  _imp->_Comments = val;

  return true;
} // sb_Rsdf::setComments


bool
sb_Rsdf::setDefaultImplementation( string const& val )
{
  _imp->_DefaultImplementation = val;

  return true;
} // sb_Rsdf::setDefaultImplementation


bool
sb_Rsdf::setRowExtant( long val )
{
  _imp->_RowExtent = val;

  return true;
} // sb_Rsdf::setRowExtant


bool
sb_Rsdf::setColumnExtent( long val )
{
  _imp->_ColumnExtent = val;

  return true;
} // sb_Rsdf::setColumnExtent


// Phy - cut out unneeded stuff
//bool
//sb_Rsdf::setPlaneExtent( long val )
//{
//  _imp->_PlaneExtent = val;
//
//  return true;
//} // sb_Rsdf::setPlaneExtent


bool
sb_Rsdf::setScanOrigin( string const& val )
{
  _imp->_ScanOrigin = val;

  return true;
} // sb_Rsdf::setScanOrigin


bool
sb_Rsdf::setTesseralIndexing( string const& val )
{
  _imp->_TesseralIndexing = val;

  return true;
} // sb_Rsdf::setTesseralIndexing


bool
sb_Rsdf::setScanPattern( string const& val )
{
  _imp->_ScanPattern = val;

  return true;
} // sb_Rsdf::setScanPattern

// Phy - cut out unneeded stuff
//bool
//sb_Rsdf::setTesseralIndexFormat( string const& val )
//{
//  _imp->_TesseralIndexFormat = val;
//
//  return true;
//} // sb_Rsdf::setTesseralIndexFormat
//
//
//bool
//sb_Rsdf::setTesseralIndexingDescription( string const& val )
//{
//  _imp->_TesseralIndexingDescription = val;
//
//  return true;
//} // sb_Rsdf::setTesseralIndexingDescription


bool
sb_Rsdf::setNumberLinesAlternation( long val )
{
  _imp->_NumberLinesAlternation = val;

  return true;
} // sb_Rsdf::setNumberLinesAlternation


bool
sb_Rsdf::setFirstScanDirection( string const& val )
{
  _imp->_FirstScanDirection = val;

  return true;
} // sb_Rsdf::setFirstScanDirection


bool
sb_Rsdf::setAspectRation( double val )
{
  _imp->_AspectRatio = val;

  return true;
} // sb_Rsdf::setAspectRation


bool
sb_Rsdf::setNumberLayers( long val )
{
  _imp->_NumberLayers = val;

  return true;
} // sb_Rsdf::setNumberLayers


bool
sb_Rsdf::setSpatialAddress( double x, double y )
{
  _imp->_SADR_X = x;
  _imp->_SADR_Y = y;

  return true;
} // sb_Rsdf::setSpatialAddress


// Phy - Add set for field ISID
bool
sb_Rsdf::setInternalSpatialId( sb_ForeignID const & fid )
{
  _imp->_isid = fid;
  return true;
}


bool
sb_Rsdf::setLayerId( foreign_ids const& fids )
{
  _imp->_lyids = fids;
  return true;
}

// Phy - ??? Add set for field RATP
bool
sb_Rsdf::setRasterAttributeId( foreign_ids const& fids )
{
  _imp->_ratps = fids;
  return true;
}


bool
sb_Rsdf::setRecord( sc_Record const& record )
{
  return _ingest_record( *this, *_imp, record );
} // sb_Rsdf::setRecord




void
sb_Rsdf::unDefineObjectRepresentation( )
{
  _imp->_ObjectRepresentation = UNVALUED_STRING;
} // sb_Rsdf::unDefineObjectRepresentation


void
sb_Rsdf::unDefineCellSequencingCode( )
{
  _imp->_CellSequencingCode = UNVALUED_STRING;
} // sb_Rsdf::unDefineCellSequencingCode


void
sb_Rsdf::unDefineCompression( )
{
_imp->_Compression = UNVALUED_STRING;
} // sb_Rsdf::unDefineCompression


void
sb_Rsdf::unDefineEncodingMethod( )
{
_imp->_CodingMethod = UNVALUED_STRING;
} // sb_Rsdf::unDefineEncodingMethod


void
sb_Rsdf::unDefineAcquisitionDeviceMethod( )
{
  _imp->_AcquisitionDeviceMethod = UNVALUED_STRING;
} // sb_Rsdf::unDefineAcquisitionDeviceMethod


void
sb_Rsdf::unDefineAcquisitionDate( )
{
  _imp->_AcquisitionDate = UNVALUED_STRING;
} // sb_Rsdf::unDefineAcquisitionDate


void
sb_Rsdf::unDefineComments( )
{
  _imp->_Comments = UNVALUED_STRING;
} // sb_Rsdf::unDefineComments


void
sb_Rsdf::unDefineDefaultImplementation( )
{
  _imp->_DefaultImplementation = UNVALUED_STRING;
} // sb_Rsdf::unDefineDefaultImplementation


void
sb_Rsdf::unDefineRowExtant( )
{
  _imp->_RowExtent = UNVALUED_LONG; // Phy - fixed spelling
} // sb_Rsdf::unDefineRowExtant


void
sb_Rsdf::unDefineColumnExtent( )
{
  _imp->_ColumnExtent = UNVALUED_LONG;
} // sb_Rsdf::unDefineColumnExtent

// Phy - unneeded
//void
//sb_Rsdf::unDefinePlaneExtent( )
//{
//  _imp->_PlaneExtent = UNVALUED_LONG;
//} // sb_Rsdf::unDefinePlaneExtent


void
sb_Rsdf::unDefineScanOrigin( )
{
  _imp->_ScanOrigin = UNVALUED_STRING;
} // sb_Rsdf::unDefineScanOrigin


void
sb_Rsdf::unDefineTesseralIndexing( )
{
  _imp->_TesseralIndexing = UNVALUED_STRING;
} // sb_Rsdf::unDefineTesseralIndexing


void
sb_Rsdf::unDefineScanPattern( )
{
  _imp->_ScanPattern = UNVALUED_STRING;
} // sb_Rsdf::unDefineScanPattern

// Phy - unneeded
//void
//sb_Rsdf::unDefineTesseralIndexFormat( )
//{
//  _imp->_TesseralIndexFormat = UNVALUED_STRING;
//} // sb_Rsdf::unDefineTesseralIndexFormat
//
//
//void
//sb_Rsdf::unDefineTesseralIndexingDescription( )
//{
//  _imp->_TesseralIndexingDescription = UNVALUED_STRING;
//} // sb_Rsdf::unDefineTesseralIndexingDescription


void
sb_Rsdf::unDefineNumberLinesAlternation( )
{
  _imp->_NumberLinesAlternation = UNVALUED_LONG;
} // sb_Rsdf::unDefineNumberLinesAlternation


void
sb_Rsdf::unDefineFirstScanDirection( )
{
  _imp->_FirstScanDirection = UNVALUED_STRING;
} // sb_Rsdf::unDefineFirstScanDirection


void
sb_Rsdf::unDefineAspectRation( )
{
  _imp->_AspectRatio = UNVALUED_DOUBLE;  // Phy - fixed spelling
} // sb_Rsdf::unDefineAspectRation


void
sb_Rsdf::unDefineNumberLayers( )
{
  _imp->_NumberLayers = UNVALUED_LONG;
} // sb_Rsdf::unDefineNumberLayers


void
sb_Rsdf::unDefineSpatialAddress()
{
  _imp->_SADR_X = UNVALUED_DOUBLE;
  _imp->_SADR_Y = UNVALUED_DOUBLE;
} // sb_RsDF::unDefineSpatialAddress


// Phy - Field ISID
void
sb_Rsdf::unDefineInternalSpatialId()
{
  _imp->_isid.setModuleName( "" ); // reset to null state
  _imp->_isid.setRecordID( 0 );
}

// Phy - ??? Field LYID
void
sb_Rsdf::unDefineLayerIds()
{
  _imp->_lyids.clear();
}

// Phy - ??? Field RATP
void
sb_Rsdf::unDefineRasterAttributeIds()
{
  _imp->_ratps.clear();
}
