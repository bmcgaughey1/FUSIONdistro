//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//

#include <builder/sb_Module.h>

#include <iostream>

#ifndef INCLUDED_SC_RECORD_H
#include "container/sc_Record.h"
#endif


static const char* _ident = "$Id: sb_Module.cpp,v 1.2 1998/08/31 22:17:29 mcoletti Exp $";

ostream&
operator<<( ostream& os, sb_Module const& module )
{
  sc_Record record;

  if ( module.getRecord( record ) )
    {
      os << record << "\n";
    }
  else
    {
      os << "unable to dump builder object\n";
    }

  return os;

}
