//
// $Id: sio_Reader_t.cpp,v 1.16 1998/08/31 23:18:44 mcoletti Exp $
//

#ifdef WIN32
#pragma warning( disable : 4786 )
#endif

#include <iostream>
#include <fstream>


#ifdef WIN32
#include "../getopt/getopt.h"
using namespace std;
#endif

// stooopid IRIX has non-standard getopt() behavior; it returns -1
// instead of EOF when the last command line argument is processed

#ifdef _SGIAPI
#include <getopt.h>
#else
const int GETOPTDONE = EOF;
#endif


#include "io/sio_Reader.h"
#include "io/sio_8211Converter.h"

#include "container/sc_Record.h"



sio_8211Converter_BI8   converter_bi8;
sio_8211Converter_BI16	converter_bi16;
sio_8211Converter_BI24  converter_bi24;
sio_8211Converter_BI32	converter_bi32;
sio_8211Converter_BUI8	converter_bui8;
sio_8211Converter_BUI16	converter_bui16;
sio_8211Converter_BUI24	converter_bui24;
sio_8211Converter_BUI32	converter_bui32;
sio_8211Converter_BFP32	converter_bfp32;
sio_8211Converter_BFP64 converter_bfp64;

bool verbose = false;		// true if user wants to dump record contents





void
assign_converter( converter_dictionary & cd,                  
                  string const & mnemonic,
                  string const & converter_type )
{
  if ( mnemonic.empty() )  
    {    
      cerr << "binary type without a subfield\n";  
    }  

  if( 'b' == converter_type[0] ) // is binary  
    {    
      if ( 'i' == converter_type[1] ) // signed    
        {      
          switch( converter_type[2] )
            {
            case '8' :
              cd[mnemonic] = &converter_bi8;        
              break;      
            case '1':
              cd[mnemonic] = &converter_bi16;
              break;
            case '2' :
              cd[mnemonic] = &converter_bi24;
              break;
            case '3' :
              cd[mnemonic] = &converter_bi32;
              break;      
            default :
              cerr << converter_type << " unknown binary type\n";        
              exit(-9);      
            }
          return;   
        }    
      else if ( 'u' == converter_type[1] && // unsigned
		'i' == converter_type[2] )    
        {      
          switch( converter_type[3] )      
            {
            case '8' :        
              cd[mnemonic] = &converter_bui8;
              break;
            case '1' :
              cd[mnemonic] = &converter_bui16;
              break;
            case '2' :
              cd[mnemonic] = &converter_bui24;
              break;
            case '3' :
              cd[mnemonic] = &converter_bui32;
              break;
            default :        
              cerr << converter_type << " unknown binary type\n";
              exit(-9);      
            }
          return;    
        }    
      else if ( 'f' == converter_type[1] && // floating point
                'p' == converter_type[2] )    
        {      
          switch( converter_type[3] )      
            {
            case '6' :        
              cd[mnemonic] = &converter_bfp64;
              break;      
            case '3' :
              cd[mnemonic] = &converter_bfp32;
              break;
            default :
              cerr << converter_type << " unknown binary type\n";
              exit(-9);      
            }
          return;    
        }  
    }  

  cerr << converter_type << " unknown binary type\n";
  exit(-9);
} // assign_converter



void
dump_converter_dictionary( converter_dictionary const & cd )
{
  if ( ! cd.empty() )
    {
      cout << "converter dictionary:\n";
    }


  for ( converter_dictionary::const_iterator i = cd.begin();
        i != cd.end();
        i++ )
    {
      cout << "\t" << (*i).first << " : ";

      if ( &converter_bi8 == (*i).second)
        {
          cout << "BI8\n";
        }
      else if ( &converter_bi16 == (*i).second)
        {
          cout << "BI16\n";
        }
      else if ( &converter_bi24 == (*i).second)
        {
          cout << "BI24\n";
        }
      else if ( &converter_bi32 == (*i).second)
        {
          cout << "BI32\n";
        }
      else if ( &converter_bui8 == (*i).second)
        {
          cout << "BUI8\n";
        }
      else if ( &converter_bui16 == (*i).second)
        {
          cout << "BUI16\n";
        }
      else if ( &converter_bui24 == (*i).second)
        {
          cout << "BUI24\n";
        }
      else if ( &converter_bui32 == (*i).second)
        {
          cout << "BUI32\n";
        }
      else if ( &converter_bfp32 == (*i).second)
        {
          cout << "BFP32\n";
        }
      else if ( &converter_bfp64 == (*i).second)
        {
          cout << "BFP64\n";
        }
      else
        cout << "unknown\n";

    }

} // dump_converter_dictionary




void
usage( const char * name )
{
  cerr << name << ": [flags] [-i in_8211_file]\n"       
       << "flags:\n"
       << "\t-i\tinput file\n"       
       << "\t-v\tverbose\n"       
       << "\t-s mnemonic -b (b(u)?i(8|16|24|32))|(bfp(32|64))\n"       
       << "\t\tassign binary converter to subfield mnemonic\n";
} // usage()



int
main( int argc, char** argv )
{
  string last_mnemonic;
  string subfield_mnemonic;

  converter_dictionary converters; // hints for reader for binary data

  extern char *optarg;
  extern int   optind;

  int ch;

  char * ifs_name = "-";
  
  converters["X"] = &converter_bi32; // set up default converter hints
  converters["Y"] = &converter_bi32; // for these mnemonics
  converters["ELEVATION"] = &converter_bi16;

  while((ch = getopt(argc, argv, "vi:s:b:h")) != GETOPTDONE)
    switch(ch)
      {
      case 'v':
        verbose = true;
	break;

      case 'i':
        ifs_name = optarg;
	break;

      case 's':
	converters[optarg] = '\0'; // Set to null
	last_mnemonic = optarg;
	break;	

      case 'b':
	assign_converter( converters, last_mnemonic, optarg ); 
	break;

      case 'h':
	usage( argv[0] );
        break;

      case '?':
      default:
        break;
      }


  ifstream ifs;                 // module to be read from

  if ( 0 == ifs_name )
    {
      cerr << "must specify an input file name\n";
      exit( -1 );
    }

#ifdef WIN32
  ifs.open( ifs_name, ios::binary );
#else
  ifs.open( ifs_name );
#endif
  if ( ! ifs )
    {
      cerr << "unable to open " << ifs_name << "\n";
      exit(-1);
    }


  sio_8211Reader          reader( ifs, &converters );
  sio_8211ForwardIterator i( reader );


  sc_Record record;


  int records = 0;


  if ( verbose )
    {
      dump_converter_dictionary( converters );
    }

  while ( i )
    {
      i.get( record );

      if ( verbose )
        {
          cout << record << "\n";
        }

      ++i;
      ++records;
    }

  ifs.close();

  cout << "read " << records << " record(s)\n";

  return 0;
}
