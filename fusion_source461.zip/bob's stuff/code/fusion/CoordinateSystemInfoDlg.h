#if !defined(AFX_COORDINATESYSTEMINFODLG_H__3B27E067_24B5_4710_94F9_DE67120F1BDF__INCLUDED_)
#define AFX_COORDINATESYSTEMINFODLG_H__3B27E067_24B5_4710_94F9_DE67120F1BDF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CoordinateSystemInfoDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCoordinateSystemInfoDlg dialog

class CCoordinateSystemInfoDlg : public CDialog
{
// Construction
public:
	CCoordinateSystemInfoDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCoordinateSystemInfoDlg)
	enum { IDD = IDD_PROJECTIONINFO };
	int		m_GPSProjection;
	int		m_GPSZone;
	int		m_GPSSpheroid;
	int		m_GPSCoordUnits;
	int		m_GPSElevationUnits;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCoordinateSystemInfoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCoordinateSystemInfoDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COORDINATESYSTEMINFODLG_H__3B27E067_24B5_4710_94F9_DE67120F1BDF__INCLUDED_)
