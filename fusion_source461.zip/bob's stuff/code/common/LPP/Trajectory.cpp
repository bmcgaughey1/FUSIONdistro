// Trajectory.cpp: implementation of the CTrajectory class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Trajectory.h"
#include "datafile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define	PI	3.14159265358979
#define	D2R (PI / 180.0)

int CompareTrajectoryPoint(const void *arg1, const void *arg2)
{
	if (((TRAJ_POSITION*) arg1)->GPSWeek < ((TRAJ_POSITION*) arg2)->GPSWeek)
		return(-1);
	else if (((TRAJ_POSITION*) arg1)->GPSWeek > ((TRAJ_POSITION*) arg2)->GPSWeek)
		return(1);
	else {
		// compare intensity values
		if (((TRAJ_POSITION*) arg1)->GPSTime < ((TRAJ_POSITION*) arg2)->GPSTime)
			return(-1);
		else if (((TRAJ_POSITION*) arg1)->GPSTime > ((TRAJ_POSITION*) arg2)->GPSTime)
			return(1);
		else
			return(0);
	}
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTrajectory::CTrajectory()
{
	m_Positions = NULL;
	m_Valid = FALSE;
	m_CurrentPosition = 0;
	m_NumberOfPositions = 0;
}

CTrajectory::CTrajectory(LPCTSTR FileName, int Format)
{
	m_Positions = NULL;
	m_Valid = FALSE;
	m_CurrentPosition = 0;
	m_NumberOfPositions = 0;

	LoadTrajectory(FileName, Format);
}

CTrajectory::~CTrajectory()
{
	Close();
}

BOOL CTrajectory::IsValid()
{
	return(m_Valid);
}

BOOL CTrajectory::LoadTrajectory(LPCTSTR FileName, int Format, BOOL Append, BOOL DoSort)
{
	long i;

	if (m_Valid && !Append)
		Close();
	
	if (!Append) {
		m_MinPosition.GPSWeek = 999999;
		m_MinPosition.GPSTime = 999999999.0;
		m_MinPosition.Latitude = 999999999.0;
		m_MinPosition.Longitude = 999999999.0;
		m_MinPosition.EllipsoidHeight = 999999999.0;
		m_MinPosition.Roll = 999999999.0;
		m_MinPosition.Pitch = 999999999.0;
		m_MinPosition.Heading = 999999999.0;

		m_MaxPosition.GPSWeek = -999999;
		m_MaxPosition.GPSTime = -999999999.0;
		m_MaxPosition.Latitude = -999999999.0;
		m_MaxPosition.Longitude = -999999999.0;
		m_MaxPosition.EllipsoidHeight = -999999999.0;
		m_MaxPosition.Roll = -999999999.0;
		m_MaxPosition.Pitch = -999999999.0;
		m_MaxPosition.Heading = -999999999.0;
	}

	if (Format == LPP) {
		CLPPTrajectoryFile LPPFile(FileName);
		LPPRecord Position;
		if (LPPFile.IsValid()) {
			// allocate memory for positions
			TRAJ_POSITION* m_TempPositions;
			if (Append)
				m_TempPositions = new TRAJ_POSITION[LPPFile.GetRecordCount() + m_NumberOfPositions];
			else {
				m_TempPositions = new TRAJ_POSITION[LPPFile.GetRecordCount()];
				m_NumberOfPositions = 0;		// just to make sure...
			}

			if (m_TempPositions) {
				// copy existing positions into new memory and delete old memory
				if (Append) {
					for (i = 0; i < m_NumberOfPositions; i ++) 
						m_TempPositions[i] = m_Positions[i];

					delete [] m_Positions;
					m_Positions = NULL;
				}

				// read positions and populate memory
				for (i = 0; i < LPPFile.GetRecordCount(); i ++) {
					LPPFile.ReadPosition(Position);

					// transfer values
					m_TempPositions[m_NumberOfPositions + i].GPSWeek = Position.GPSWeek;
					m_TempPositions[m_NumberOfPositions + i].GPSTime = Position.GPSTime;
					m_TempPositions[m_NumberOfPositions + i].Latitude = Position.Latitude;
					m_TempPositions[m_NumberOfPositions + i].Longitude = Position.Longitude;
					m_TempPositions[m_NumberOfPositions + i].EllipsoidHeight = Position.EllipsoidHeight;
					m_TempPositions[m_NumberOfPositions + i].Roll = Position.Roll;
					m_TempPositions[m_NumberOfPositions + i].Pitch = Position.Pitch;
					m_TempPositions[m_NumberOfPositions + i].Heading = Position.Heading;

					// update min/max values
					m_MinPosition.GPSWeek = min(m_MinPosition.GPSWeek, Position.GPSWeek);
					m_MinPosition.GPSTime = min(m_MinPosition.GPSTime, Position.GPSTime);
					m_MinPosition.Latitude = min(m_MinPosition.Latitude, Position.Latitude);
					m_MinPosition.Longitude = min(m_MinPosition.Longitude, Position.Longitude);
					m_MinPosition.EllipsoidHeight = min(m_MinPosition.EllipsoidHeight, Position.EllipsoidHeight);
					m_MinPosition.Roll = min(m_MinPosition.Roll, Position.Roll);
					m_MinPosition.Pitch = min(m_MinPosition.Pitch, Position.Pitch);
					m_MinPosition.Heading = min(m_MinPosition.Heading, Position.Heading);

					m_MaxPosition.GPSWeek = max(m_MinPosition.GPSWeek, Position.GPSWeek);
					m_MaxPosition.GPSTime = max(m_MinPosition.GPSTime, Position.GPSTime);
					m_MaxPosition.Latitude = max(m_MinPosition.Latitude, Position.Latitude);
					m_MaxPosition.Longitude = max(m_MinPosition.Longitude, Position.Longitude);
					m_MaxPosition.EllipsoidHeight = max(m_MinPosition.EllipsoidHeight, Position.EllipsoidHeight);
					m_MaxPosition.Roll = max(m_MinPosition.Roll, Position.Roll);
					m_MaxPosition.Pitch = max(m_MinPosition.Pitch, Position.Pitch);
					m_MaxPosition.Heading = max(m_MinPosition.Heading, Position.Heading);
				}

				m_NumberOfPositions = m_NumberOfPositions + LPPFile.GetRecordCount();
				m_Valid = TRUE;

				m_Positions = m_TempPositions;
			}
		}
	}
	else if (Format == SBET1) {		// DNR colville
	}
	else if (Format == SBET2) {		// USFS colville (state plane)
		// format has GPS time, easting, northing, elev, heading, roll, pitch
		CDataFile SBETDat(FileName);
		if (SBETDat.IsValid()) {
			// count lines
			int LineCount = 0;
			char buf[2048];
			while (SBETDat.ReadDataLine(buf, SKIPCOMMENTSCOMMANDS)) {
				LineCount ++;
			}
			SBETDat.Rewind();

			TRAJ_POSITION* m_TempPositions;
			if (Append)
				m_TempPositions = new TRAJ_POSITION[LineCount + m_NumberOfPositions];
			else {
				m_TempPositions = new TRAJ_POSITION[LineCount];
				m_NumberOfPositions = 0;		// just to make sure...
			}

			// read lines and parse data
			if (m_TempPositions) {
				// copy existing positions into new memory and delete old memory
				if (Append) {
					for (i = 0; i < m_NumberOfPositions; i ++) 
						m_TempPositions[i] = m_Positions[i];

					delete [] m_Positions;
					m_Positions = NULL;
				}

				for (i = 0; i < LineCount; i ++) {
					SBETDat.ReadDataLine(buf, SKIPCOMMENTSCOMMANDS);

					// parse and transfer values
					m_TempPositions[m_NumberOfPositions + i].GPSWeek = 0;
					m_TempPositions[m_NumberOfPositions + i].GPSTime = atof(strtok(buf, " ,\t"));
					m_TempPositions[m_NumberOfPositions + i].Longitude = atof(strtok(NULL, " ,\t"));
					m_TempPositions[m_NumberOfPositions + i].Latitude = atof(strtok(NULL, " ,\t"));
					m_TempPositions[m_NumberOfPositions + i].EllipsoidHeight = atof(strtok(NULL, " ,\t"));
					m_TempPositions[m_NumberOfPositions + i].Heading = atof(strtok(NULL, " ,\t"));
					m_TempPositions[m_NumberOfPositions + i].Roll = atof(strtok(NULL, " ,\t"));
					m_TempPositions[m_NumberOfPositions + i].Pitch = atof(strtok(NULL, " ,\t"));

					// update min/max values
					m_MinPosition.GPSWeek = min(m_MinPosition.GPSWeek, m_TempPositions[m_NumberOfPositions + i].GPSWeek);
					m_MinPosition.GPSTime = min(m_MinPosition.GPSTime, m_TempPositions[m_NumberOfPositions + i].GPSTime);
					m_MinPosition.Latitude = min(m_MinPosition.Latitude, m_TempPositions[m_NumberOfPositions + i].Latitude);
					m_MinPosition.Longitude = min(m_MinPosition.Longitude, m_TempPositions[m_NumberOfPositions + i].Longitude);
					m_MinPosition.EllipsoidHeight = min(m_MinPosition.EllipsoidHeight, m_TempPositions[m_NumberOfPositions + i].EllipsoidHeight);
					m_MinPosition.Roll = min(m_MinPosition.Roll, m_TempPositions[m_NumberOfPositions + i].Roll);
					m_MinPosition.Pitch = min(m_MinPosition.Pitch, m_TempPositions[m_NumberOfPositions + i].Pitch);
					m_MinPosition.Heading = min(m_MinPosition.Heading, m_TempPositions[m_NumberOfPositions + i].Heading);

					m_MaxPosition.GPSWeek = max(m_MinPosition.GPSWeek, m_TempPositions[m_NumberOfPositions + i].GPSWeek);
					m_MaxPosition.GPSTime = max(m_MinPosition.GPSTime, m_TempPositions[m_NumberOfPositions + i].GPSTime);
					m_MaxPosition.Latitude = max(m_MinPosition.Latitude, m_TempPositions[m_NumberOfPositions + i].Latitude);
					m_MaxPosition.Longitude = max(m_MinPosition.Longitude, m_TempPositions[m_NumberOfPositions + i].Longitude);
					m_MaxPosition.EllipsoidHeight = max(m_MinPosition.EllipsoidHeight, m_TempPositions[m_NumberOfPositions + i].EllipsoidHeight);
					m_MaxPosition.Roll = max(m_MinPosition.Roll, m_TempPositions[m_NumberOfPositions + i].Roll);
					m_MaxPosition.Pitch = max(m_MinPosition.Pitch, m_TempPositions[m_NumberOfPositions + i].Pitch);
					m_MaxPosition.Heading = max(m_MinPosition.Heading, m_TempPositions[m_NumberOfPositions + i].Heading);
				}

				m_NumberOfPositions = m_NumberOfPositions + LineCount;
				m_Valid = TRUE;

				m_Positions = m_TempPositions;
			}

			SBETDat.Close();
		}
	}
	else if (Format == BINARYSRS) {
		double GPSTime;
		double Latitude;
		double Longitude;
		double EllHt;
		double XVelocity;
		double YVelocity;
		double ZVelocity;
		double Roll;
		double Pitch;
		double Heading;
		double WanderAngle;
		double XAcceleration;
		double YAcceleration;
		double ZAcceleration;
		double XAngularRate;
		double YAngularRate;
		double ZAngularRate;
		int ValueReadCount;

		// binary format...open file
		FILE* bin_indat = fopen(FileName, "rb");
		if (bin_indat) {
			// count lines
			int LineCount = 0;
			while (TRUE) {
				// read values and count lines
				ValueReadCount = 0;
				ValueReadCount += fread(&GPSTime, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&Latitude, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&Longitude, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&EllHt, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&XVelocity, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&YVelocity, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&ZVelocity, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&Roll, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&Pitch, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&Heading, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&WanderAngle, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&XAcceleration, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&YAcceleration, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&ZAcceleration, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&XAngularRate, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&YAngularRate, sizeof(double), 1, bin_indat);
				ValueReadCount += fread(&ZAngularRate, sizeof(double), 1, bin_indat);

				if (ValueReadCount != 17)		// failed...assume end of file
					break;

				LineCount ++;
			}
			rewind(bin_indat);

			TRAJ_POSITION* m_TempPositions;
			if (Append)
				m_TempPositions = new TRAJ_POSITION[LineCount + m_NumberOfPositions];
			else {
				m_TempPositions = new TRAJ_POSITION[LineCount];
				m_NumberOfPositions = 0;		// just to make sure...
			}

			// read lines and parse data
			if (m_TempPositions) {
				// copy existing positions into new memory and delete old memory
				if (Append) {
					for (i = 0; i < m_NumberOfPositions; i ++) 
						m_TempPositions[i] = m_Positions[i];

					delete [] m_Positions;
					m_Positions = NULL;
				}

				for (i = 0; i < LineCount; i ++) {
					// read values and count lines
					ValueReadCount = 0;
					ValueReadCount += fread(&GPSTime, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&Latitude, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&Longitude, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&EllHt, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&XVelocity, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&YVelocity, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&ZVelocity, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&Roll, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&Pitch, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&Heading, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&WanderAngle, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&XAcceleration, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&YAcceleration, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&ZAcceleration, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&XAngularRate, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&YAngularRate, sizeof(double), 1, bin_indat);
					ValueReadCount += fread(&ZAngularRate, sizeof(double), 1, bin_indat);

					if (ValueReadCount != 17)		// failed...assume end of file
						break;

					// parse and transfer values
					m_TempPositions[m_NumberOfPositions + i].GPSWeek = 0;
					m_TempPositions[m_NumberOfPositions + i].GPSTime = GPSTime;
					m_TempPositions[m_NumberOfPositions + i].Longitude = Longitude / D2R;
					m_TempPositions[m_NumberOfPositions + i].Latitude = Latitude / D2R;
					m_TempPositions[m_NumberOfPositions + i].EllipsoidHeight = EllHt;
					m_TempPositions[m_NumberOfPositions + i].Heading = Heading / D2R;
					m_TempPositions[m_NumberOfPositions + i].Roll = Roll / D2R;
					m_TempPositions[m_NumberOfPositions + i].Pitch = Pitch / D2R;

					// update min/max values
					m_MinPosition.GPSWeek = min(m_MinPosition.GPSWeek, m_TempPositions[m_NumberOfPositions + i].GPSWeek);
					m_MinPosition.GPSTime = min(m_MinPosition.GPSTime, m_TempPositions[m_NumberOfPositions + i].GPSTime);
					m_MinPosition.Latitude = min(m_MinPosition.Latitude, m_TempPositions[m_NumberOfPositions + i].Latitude);
					m_MinPosition.Longitude = min(m_MinPosition.Longitude, m_TempPositions[m_NumberOfPositions + i].Longitude);
					m_MinPosition.EllipsoidHeight = min(m_MinPosition.EllipsoidHeight, m_TempPositions[m_NumberOfPositions + i].EllipsoidHeight);
					m_MinPosition.Roll = min(m_MinPosition.Roll, m_TempPositions[m_NumberOfPositions + i].Roll);
					m_MinPosition.Pitch = min(m_MinPosition.Pitch, m_TempPositions[m_NumberOfPositions + i].Pitch);
					m_MinPosition.Heading = min(m_MinPosition.Heading, m_TempPositions[m_NumberOfPositions + i].Heading);

					m_MaxPosition.GPSWeek = max(m_MinPosition.GPSWeek, m_TempPositions[m_NumberOfPositions + i].GPSWeek);
					m_MaxPosition.GPSTime = max(m_MinPosition.GPSTime, m_TempPositions[m_NumberOfPositions + i].GPSTime);
					m_MaxPosition.Latitude = max(m_MinPosition.Latitude, m_TempPositions[m_NumberOfPositions + i].Latitude);
					m_MaxPosition.Longitude = max(m_MinPosition.Longitude, m_TempPositions[m_NumberOfPositions + i].Longitude);
					m_MaxPosition.EllipsoidHeight = max(m_MinPosition.EllipsoidHeight, m_TempPositions[m_NumberOfPositions + i].EllipsoidHeight);
					m_MaxPosition.Roll = max(m_MinPosition.Roll, m_TempPositions[m_NumberOfPositions + i].Roll);
					m_MaxPosition.Pitch = max(m_MinPosition.Pitch, m_TempPositions[m_NumberOfPositions + i].Pitch);
					m_MaxPosition.Heading = max(m_MinPosition.Heading, m_TempPositions[m_NumberOfPositions + i].Heading);
				}

				m_NumberOfPositions = m_NumberOfPositions + LineCount;
				m_Valid = TRUE;

				m_Positions = m_TempPositions;
			}

			fclose(bin_indat);
		}
	}

	if (m_Valid && Append && DoSort)
		SortTrajectory();

	return(m_Valid);
}

void CTrajectory::Close()
{
	if (m_Positions)
		delete [] m_Positions;
	
	m_Positions = NULL;
	m_Valid = FALSE;
	m_NumberOfPositions = 0;
}

long CTrajectory::GetPositionCount()
{
	if (m_Valid)
		return(m_NumberOfPositions);

	return(0);
}

BOOL CTrajectory::InterpolatePosition(TRAJ_POSITION &Position, int GPSWeek, double GPSTime, int StartFromBeginning)
{
	double frac;
	BOOL retcode = FALSE;

	if (!m_Valid)
		return(FALSE);

	if (StartFromBeginning)
		m_CurrentPosition = 0;

	for (int i = m_CurrentPosition; i < m_NumberOfPositions; i ++) {
		if (m_Positions[i].GPSWeek == GPSWeek) {
			if (m_Positions[i].GPSTime == GPSTime) {
				// use position at (i)
				Position.GPSWeek = m_Positions[i].GPSWeek;
				Position.GPSTime = m_Positions[i].GPSTime;
				Position.Latitude = m_Positions[i].Latitude;
				Position.Longitude = m_Positions[i].Longitude;
				Position.EllipsoidHeight = m_Positions[i].EllipsoidHeight;
				Position.Roll = m_Positions[i].Roll;
				Position.Pitch = m_Positions[i].Pitch;
				Position.Heading = m_Positions[i].Heading;

				m_CurrentPosition = i;
				retcode = TRUE;
				break;
			}
			else if (m_Positions[i].GPSTime > GPSTime && i > 0) {
				if (m_Positions[i - 1].GPSTime < GPSTime) {
					// interpolate using positions at (i - 1) and (i)
					frac = (GPSTime - m_Positions[i - 1].GPSTime) / (m_Positions[i].GPSTime - m_Positions[i - 1].GPSTime);

					Position.GPSWeek = m_Positions[i].GPSWeek;
					Position.GPSTime = GPSTime;
					Position.Latitude = m_Positions[i - 1].Latitude + frac * (m_Positions[i].Latitude - m_Positions[i - 1].Latitude);
					Position.Longitude = m_Positions[i - 1].Longitude + frac * (m_Positions[i].Longitude - m_Positions[i - 1].Longitude);
					Position.EllipsoidHeight = m_Positions[i - 1].EllipsoidHeight + frac * (m_Positions[i].EllipsoidHeight - m_Positions[i - 1].EllipsoidHeight);
					Position.Roll = m_Positions[i - 1].Roll + frac * (m_Positions[i].Roll - m_Positions[i - 1].Roll);
					Position.Pitch = m_Positions[i - 1].Pitch + frac * (m_Positions[i].Pitch - m_Positions[i - 1].Pitch);
					Position.Heading = m_Positions[i - 1].Heading + frac * (m_Positions[i].Heading - m_Positions[i - 1].Heading);

					m_CurrentPosition = i;
					retcode = TRUE;
					break;
				}
			}
		}
	}
	return(retcode);
}

BOOL CTrajectory::ScanForPositionRange()
{
	if (!m_Valid)
		return(FALSE);
	
	m_MinPosition.GPSWeek = 999999;
	m_MinPosition.GPSTime = 999999999.0;
	m_MinPosition.Latitude = 999999999.0;
	m_MinPosition.Longitude = 999999999.0;
	m_MinPosition.EllipsoidHeight = 999999999.0;
	m_MinPosition.Roll = 999999999.0;
	m_MinPosition.Pitch = 999999999.0;
	m_MinPosition.Heading = 999999999.0;

	m_MaxPosition.GPSWeek = -999999;
	m_MaxPosition.GPSTime = -999999999.0;
	m_MaxPosition.Latitude = -999999999.0;
	m_MaxPosition.Longitude = -999999999.0;
	m_MaxPosition.EllipsoidHeight = -999999999.0;
	m_MaxPosition.Roll = -999999999.0;
	m_MaxPosition.Pitch = -999999999.0;
	m_MaxPosition.Heading = -999999999.0;

	for (long i = 0; i < m_NumberOfPositions; i ++) {
		// update min/max values
		m_MinPosition.GPSWeek = min(m_MinPosition.GPSWeek, m_Positions[i].GPSWeek);
		m_MinPosition.GPSTime = min(m_MinPosition.GPSTime, m_Positions[i].GPSTime);
		m_MinPosition.Latitude = min(m_MinPosition.Latitude, m_Positions[i].Latitude);
		m_MinPosition.Longitude = min(m_MinPosition.Longitude, m_Positions[i].Longitude);
		m_MinPosition.EllipsoidHeight = min(m_MinPosition.EllipsoidHeight, m_Positions[i].EllipsoidHeight);
		m_MinPosition.Roll = min(m_MinPosition.Roll, m_Positions[i].Roll);
		m_MinPosition.Pitch = min(m_MinPosition.Pitch, m_Positions[i].Pitch);
		m_MinPosition.Heading = min(m_MinPosition.Heading, m_Positions[i].Heading);

		m_MaxPosition.GPSWeek = max(m_MinPosition.GPSWeek, m_Positions[i].GPSWeek);
		m_MaxPosition.GPSTime = max(m_MinPosition.GPSTime, m_Positions[i].GPSTime);
		m_MaxPosition.Latitude = max(m_MinPosition.Latitude, m_Positions[i].Latitude);
		m_MaxPosition.Longitude = max(m_MinPosition.Longitude, m_Positions[i].Longitude);
		m_MaxPosition.EllipsoidHeight = max(m_MinPosition.EllipsoidHeight, m_Positions[i].EllipsoidHeight);
		m_MaxPosition.Roll = max(m_MinPosition.Roll, m_Positions[i].Roll);
		m_MaxPosition.Pitch = max(m_MinPosition.Pitch, m_Positions[i].Pitch);
		m_MaxPosition.Heading = max(m_MinPosition.Heading, m_Positions[i].Heading);
	}

	return(TRUE);
}

void CTrajectory::SortTrajectory()
{
	if (m_Valid) {
		qsort(m_Positions, m_NumberOfPositions, sizeof(TRAJ_POSITION), CompareTrajectoryPoint);
	}
}
