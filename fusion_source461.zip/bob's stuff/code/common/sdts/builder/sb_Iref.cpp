//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//

#ifdef WIN32
#pragma warning(disable: 4786)	// stupid warning that debug string exceeds 255
#endif

#include <builder/sb_Iref.h>

#include <float.h>
#include <limits.h>

#include <iostream>

#include <string>

#ifndef INCLUDED_SB_UTILS_H
#include "builder/sb_Utils.h"
#endif

#ifdef NOT_IMPLEMENTED
#ifndef INCLUDED_SB_FOREIGNID_H
#include "builder/sb_ForeignID.h"
#endif
#endif

#ifndef INCLUDED_SC_RECORD_H
#include "container/sc_Record.h"
#endif

#ifndef INCLUDED_SC_FIELD_H
#include "container/sc_Field.h"
#endif

#ifndef INCLUDED_SC_SUBFIELD_H
#include "container/sc_Subfield.h"
#endif


#ifndef INCLUDED_SIO_8211CONVERTER_H
#include "io/sio_8211Converter.h"
#endif



static const char* _ident = "$Id: sb_Iref.cpp,v 1.14 1998/09/16 15:42:16 mcoletti Exp $";

// Strings and integers are initialized with these values; they're used
// to indicate whether a given module value has been assigned a value or not.

// (XXX I arbitrarily chose 0x4 as the sentinal value.  I hate ad hoc crap.)

static const string  UNVALUED_STRING(1, static_cast<string::value_type>(0x4) );

static const long    UNVALUED_LONG   = INT_MIN;

static const double  UNVALUED_DOUBLE = DBL_MAX;

static sio_8211Schema _iref_schema; // iref module schema, which will be
                                // defined by build_iref_schema

static sio_8211Converter_I converter_I; // XXX should define these in
static sio_8211Converter_A converter_A; // XXX sio_8211Converter.h
static sio_8211Converter_R converter_R;


struct 
sb_Iref_Imp
{
  string _comment;
      
  string _spatialAddType;
  string _spatialAddXCompLbl;
  string _spatialAddYCompLbl;
  string _horizontalCompFmt;
  string _verticalCompFmt;
     
  double _scaleFactX;
  double _scaleFactY;
  double _scaleFactZ;
  double _xOrigin;
  double _yOrigin; 
  double _zOrigin;
      
  double _xCompHorizRes;
  double _yCompHorizRes;
  double _verticalResComp;

#ifdef NOT_IMPLEMENTED
  vector<sb_ForeignID> _dimensionID;
#endif

  sb_Iref_Imp()
    : _comment( UNVALUED_STRING ),
      _spatialAddType( UNVALUED_STRING ),
      _spatialAddXCompLbl( UNVALUED_STRING ),
      _spatialAddYCompLbl( UNVALUED_STRING ),
      _horizontalCompFmt( UNVALUED_STRING ),
      _verticalCompFmt( UNVALUED_STRING ),
      _scaleFactX( UNVALUED_DOUBLE ),
      _scaleFactY( UNVALUED_DOUBLE ),
      _scaleFactZ( UNVALUED_DOUBLE ),
      _xOrigin( UNVALUED_DOUBLE ),
      _yOrigin( UNVALUED_DOUBLE ),
      _zOrigin( UNVALUED_DOUBLE ),
      _xCompHorizRes( UNVALUED_DOUBLE ),
      _yCompHorizRes( UNVALUED_DOUBLE ),
      _verticalResComp( UNVALUED_DOUBLE )
    {}

}; // sb_Iref_Imp






sb_Iref::sb_Iref()
  : _imp( new sb_Iref_Imp )
{
  setMnemonic( "IREF" );        // set reasonable module mnemonic and
  setID( 1 );                   // record id defaults
}


sb_Iref::~sb_Iref()
{
  delete _imp;
}





//
// builds a schema suitable for writing an SDTS IREF module
//
void
_build_iref_schema( sio_8211Schema& schema )
{
  schema.clear();               // make sure we're starting with clean schema

  schema.push_back( sio_8211FieldFormat() );

  sio_8211FieldFormat& field_format = schema.back();

  field_format.setDataStructCode( sio_8211FieldFormat::vector );
  field_format.setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  field_format.setName( "INTERNAL SPATIAL REFERENCE" );
  field_format.setTag( "IREF" );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "MODN" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "RCID" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "COMT" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "SATP" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "XLBL" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "YLBL" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "HFMT" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


#ifdef NOT_RASTER_PROFILE
  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "VFMT" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );
#endif

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "SFAX" );
  field_format.back().setType( sio_8211SubfieldFormat::R );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_R );



  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "SFAY" );
  field_format.back().setType( sio_8211SubfieldFormat::R );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_R );


#ifdef NOT_RASTER_PROFILE
  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "SFAZ" );
  field_format.back().setType( sio_8211SubfieldFormat::R );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_R );
#endif


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "XORG" );
  field_format.back().setType( sio_8211SubfieldFormat::R );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_R );



  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "YORG" );
  field_format.back().setType( sio_8211SubfieldFormat::R );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_R );



#ifdef NOT_RASTER_PROFILE
  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "ZORG" );
  field_format.back().setType( sio_8211SubfieldFormat::R );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_R );
#endif


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "XHRS" );
  field_format.back().setType( sio_8211SubfieldFormat::R );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_R );



  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "YHRS" );
  field_format.back().setType( sio_8211SubfieldFormat::R );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_R );



#ifdef NOT_RASTER_PROFILE
  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "VRES" );
  field_format.back().setType( sio_8211SubfieldFormat::R );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_R );
#endif

  // DMID

  schema.push_back( sio_8211FieldFormat() );

  schema.back().setDataStructCode( sio_8211FieldFormat::array );
  schema.back().setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  schema.back().setName( "DIMENSION ID" );
  schema.back().setTag( "DMID" );

  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "MODN" );
  schema.back().back().setType( sio_8211SubfieldFormat::A );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_A );

  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "RCID" );
  schema.back().back().setType( sio_8211SubfieldFormat::I );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_I );



} // _build_iref_schema






//
// Build an sb_Iref from an sc_Record
//

static
bool
_ingest_record( sb_Iref & iref, 
                sb_Iref_Imp & iref_imp, 
                sc_Record const & record )
{

  // Make sure we have a record from a Internal Spatial Reference module.

  sc_FieldCntr::const_iterator curfield;
  if ( ! sb_Utils::getFieldByMnem( record, "IREF", curfield ) )
    {
#ifdef SDTSXX_DEBUG
      cerr << "sb_Iref::sb_Iref(sc_Record const&): "
           << "Not an Internal Spatial Reference record.";
      cerr << endl;
#endif;
      return false;
    }

  // We have a primary field from a  module. Start
  // picking it apart.

  sc_SubfieldCntr::const_iterator cursubfield;

  // MODN
  if ( sb_Utils::getSubfieldByMnem( *curfield, "MODN", cursubfield ) )
    {
      string tmp;
      
      cursubfield->getA(  tmp  );
      iref.setMnemonic(  tmp  );
    }
      

  // RCID
  if ( sb_Utils::getSubfieldByMnem( *curfield, "RCID", cursubfield ) )
    {
      long tmp;
      cursubfield->getI(  tmp  );
      iref.setID(  tmp  );
    }


   // COMT
  if ( sb_Utils::getSubfieldByMnem( *curfield, "COMT", cursubfield ) )
    cursubfield->getA( iref_imp._comment );

   // SATP 
  if ( sb_Utils::getSubfieldByMnem( *curfield, "SATP", cursubfield ) )
    cursubfield->getA( iref_imp._spatialAddType );

   // XLBL
  if ( sb_Utils::getSubfieldByMnem( *curfield, "XLBL", cursubfield ) )
    cursubfield->getA( iref_imp._spatialAddXCompLbl );

   // YLBL
  if ( sb_Utils::getSubfieldByMnem( *curfield, "YLBL", cursubfield ) )
    cursubfield->getA( iref_imp._spatialAddYCompLbl );

   // HFMT
  if ( sb_Utils::getSubfieldByMnem( *curfield, "HFMT", cursubfield ) )
    cursubfield->getA( iref_imp._horizontalCompFmt );

#ifdef NOT_RASTER_PROFILE
   // VFMT
  if ( sb_Utils::getSubfieldByMnem( *curfield, "VFMT", cursubfield ) )
    cursubfield->getA( iref_imp._verticalCompFmt );
#endif

   // SFAX
  if ( sb_Utils::getSubfieldByMnem( *curfield, "SFAX", cursubfield ) )
    if ( ! sb_Utils::getDoubleFromSubfield( cursubfield, iref_imp._scaleFactX ) )
      return false;

   // SFAY
  if ( sb_Utils::getSubfieldByMnem( *curfield, "SFAY", cursubfield ) )
    if ( ! sb_Utils::getDoubleFromSubfield( cursubfield, iref_imp._scaleFactY ) )
      return false;

#ifdef NOT_RASTER_PROFILE
   // SFAZ
  if ( sb_Utils::getSubfieldByMnem( *curfield, "SFAZ", cursubfield ) )
    if ( ! sb_Utils::getDoubleFromSubfield( cursubfield, iref_imp._scaleFactZ ) )
      return false;
#endif

   // XORG
  if ( sb_Utils::getSubfieldByMnem( *curfield, "XORG", cursubfield ) )
    if ( ! sb_Utils::getDoubleFromSubfield( cursubfield, iref_imp._xOrigin ) )
      return false;

   // YORG
  if ( sb_Utils::getSubfieldByMnem( *curfield, "YORG", cursubfield ) )
    if ( ! sb_Utils::getDoubleFromSubfield( cursubfield, iref_imp._yOrigin ) )
      return false;

#ifdef NOT_RASTER_PROFILE
   // ZORG
  if ( sb_Utils::getSubfieldByMnem( *curfield, "ZORG", cursubfield ) )
    {
      if ( ! sb_Utils::getDoubleFromSubfield( cursubfield, iref_imp._zOrigin ) )
        return false;
    }
#endif

  // XHRS
  if ( sb_Utils::getSubfieldByMnem( *curfield, "XHRS", cursubfield ) )
    if ( ! sb_Utils::getDoubleFromSubfield(  cursubfield,  iref_imp._xCompHorizRes ) )
      return false;
     
   // YHRS
  if ( sb_Utils::getSubfieldByMnem( *curfield, "YHRS", cursubfield ) )
    if ( ! sb_Utils::getDoubleFromSubfield(  cursubfield, iref_imp._yCompHorizRes ) )
      return false;
         
#ifdef NOT_RASTER_PROFILE
   // VRES
  if ( sb_Utils::getSubfieldByMnem( *curfield, "VRES", cursubfield ) )
    if ( ! sb_Utils::getDoubleFromSubfield(  cursubfield,  iref_imp._verticalResComp ) )
      return false;
#endif


  // Secondary Fields

#ifdef NOT_IMPLEMENTED
  sc_FieldCntr const& fields = record; 
  for ( curfield  = fields.begin( );
        curfield != fields.end( );
        curfield++ )
    {
      if ( curfield->getMnemonic(  ) == "DMID" )
        iref_imp._dimensionID.push_back( sb_ForeignID( *curfield )  );
    }
#endif

   return true;

} // _ingest_record




bool
sb_Iref::getComment(  string& val  ) const
{
  if ( _imp->_comment == UNVALUED_STRING )
    {
      return false;
    }
  val = _imp->_comment;
  return true;
}


bool
sb_Iref::getSpatialAddressType(  string& val  ) const
{
  if ( _imp->_spatialAddType == UNVALUED_STRING )
    {
      return false;
    }
  val = _imp->_spatialAddType;
  return true;
}


bool
sb_Iref::getSpatialAddressXLabel(  string& val  ) const
{
  if ( _imp->_spatialAddXCompLbl == UNVALUED_STRING )
    {
      return false;
    }
  val = _imp->_spatialAddXCompLbl;
  return true;
}


bool
sb_Iref::getSpatialAddressYLabel(  string& val  ) const
{
  if ( _imp->_spatialAddYCompLbl == UNVALUED_STRING )
    {
      return false;
    }
  val = _imp->_spatialAddYCompLbl;
  return true;
}


bool
sb_Iref::getHorizontalComponentFormat(  string& val  ) const
{
  if ( _imp->_horizontalCompFmt == UNVALUED_STRING )
    {
      return false;
    }
  val = _imp->_horizontalCompFmt;
  return true;
}

 
#ifdef NOT_RASTER_PROFILE
bool
sb_Iref::getVerticalComponentFormat(  string& val  ) const
{
  if ( _imp->_verticalCompFmt == UNVALUED_STRING )
    {
      return false;
    }
  val = _imp->_verticalCompFmt;
  return true;
}
#endif


bool
sb_Iref::getScaleFactorX(  double& val  ) const
{
  if ( _imp->_scaleFactX == UNVALUED_DOUBLE )
    {
      return false;
    }
  val = _imp->_scaleFactX;
  return true;
}


bool
sb_Iref::getScaleFactorY(  double& val  ) const
{
  if ( _imp->_scaleFactY == UNVALUED_DOUBLE )
    {
      return false;
    }
  val = _imp->_scaleFactY;
  return true;
}


#ifdef NOT_RASTER_PROFILE
bool
sb_Iref::getScaleFactorZ(  double& val  ) const
{
  if ( _imp->_scaleFactZ == UNVALUED_DOUBLE )
    {
      return false;
    }
  val = _imp->_scaleFactZ;
  return true;
}
#endif


bool
sb_Iref::getXOrigin(  double& val  ) const
{
  if ( _imp->_xOrigin == UNVALUED_DOUBLE )
    {
      return false;
    }
  val = _imp->_xOrigin;
  return true;
}


bool
sb_Iref::getYOrigin(  double& val  ) const
{
  if ( _imp->_yOrigin == UNVALUED_DOUBLE )
    {
      return false;
    }
  val = _imp->_yOrigin;
  return true;
}

 
#ifdef NOT_RASTER_PROFILE
bool
sb_Iref::getZOrigin(  double& val  ) const
{
  if ( _imp->_zOrigin == UNVALUED_DOUBLE )
    {
      return false;
    }
  val = _imp->_zOrigin;
  return true;
}
#endif


bool
sb_Iref::getXComponentHorizontalResolution(  double& val  ) const
{
  if ( _imp->_xCompHorizRes == UNVALUED_DOUBLE )
    {
      return false;
    }
  val = _imp->_xCompHorizRes;
  return true;
}


bool
sb_Iref::getYComponentHorizontalResolution(  double& val  ) const
{
  if ( _imp->_yCompHorizRes == UNVALUED_DOUBLE )
    {
      return false;
    }
  val = _imp->_yCompHorizRes;
  return true;
}


#ifdef NOT_RASTER_PROFILE
bool
sb_Iref::getVerticalResolutionComponent(  double& val  ) const
{
  if ( _imp->_verticalResComp == UNVALUED_DOUBLE )
    {
      return false;
    }
  val = _imp->_verticalResComp;
  return true;
}
#endif


#ifdef NOT_IMPLEMENTED
bool
sb_Iref::getDimensionID(  vector<sb_ForeignID>& fids  ) const
{
  if (  _imp->_dimensionID.empty(  )  ) return false;

  fids = _imp->_dimensionID;

  return true;
}
#endif


bool
sb_Iref::getRecord( sc_Record & record ) const
{

  record.clear();               // start with a clean slate

  // IREF field

  record.push_back( sc_Field() );

  record.back().setMnemonic( "IREF" );

  string tmp_str;
  double tmp_double;

  getMnemonic( tmp_str );
  sb_Utils::add_subfield( record.back(), "MODN", tmp_str );
  sb_Utils::add_subfield( record.back(), "RCID", getID() );


  // Add each field and subfield to the record.  Bail if a mandatory
  // subfield hasn't been set.

  if ( getCOMT( tmp_str ) )
    {
      sb_Utils::add_subfield( record.back(), "COMT", tmp_str );
    }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "COMT", sc_Subfield::is_A );
    }

  set<string> SATP_domain;      // XXX this needs to be static const somewhere
  SATP_domain.insert( TWO_TUPLE );
  SATP_domain.insert( THREE_TUPLE );

  string SATP;

  if ( ! ( getSATP( SATP ) &&
           sb_Utils::valid_domain( SATP, SATP_domain ) ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "SATP", SATP );


  string XLBL;

  if ( ! getXLBL( XLBL ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "XLBL", XLBL );



  if ( ! getYLBL( tmp_str ) )   // some basic sanity checking
    {
      return false;
    }
  else if ( XLBL == LONGITUDE )
    {
      if ( tmp_str != LATITUDE ) return false;
    }
  else if ( XLBL == LATITUDE )
    {
      if ( tmp_str != LONGITUDE ) return false;
    }
  else if ( XLBL == EASTING )
    {
      if ( tmp_str != NORTHING ) return false;
    }
  else if ( XLBL == NORTHING )
    {
      if ( tmp_str != EASTING ) return false;
    }

  sb_Utils::add_subfield( record.back(), "YLBL", tmp_str );


  set<string> FMT_domain;
  FMT_domain.insert( "I" );
  FMT_domain.insert( "R" );
  FMT_domain.insert( "S" );
  FMT_domain.insert( "BI8" );
  FMT_domain.insert( "BI16" );
  FMT_domain.insert( "BI24" );
  FMT_domain.insert( "BI32" );
  FMT_domain.insert( "BUI" );
  FMT_domain.insert( "BUI8" );
  FMT_domain.insert( "BUI16" );
  FMT_domain.insert( "BUI24" );
  FMT_domain.insert( "BUI32" );
  FMT_domain.insert( "BFP32" );
  FMT_domain.insert( "BFP64" );


  if ( ! ( getHFMT( tmp_str )  && 
           sb_Utils::valid_domain( tmp_str, FMT_domain) ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "HFMT", tmp_str );



#ifdef NOT_RASTER_PROFILE
  if ( SATP == THREE_TUPLE )
  {
    if ( ! ( getVFMT( tmp_str )   && 
             sb_Utils::valid_domain( tmp_str, FMT_domain) ) )
    {
      return false;
    }
    sb_Utils::add_subfield( record.back(), "VFMT", tmp_str );
  }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "VFMT", sc_Subfield::is_A );
    }
#endif


  if ( ! getSFAX( tmp_double ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "SFAX", tmp_double );



  if ( ! getSFAY( tmp_double ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "SFAY", tmp_double );



#ifdef NOT_RASTER_PROFILE
  if ( SATP == THREE_TUPLE )
  {
    if ( ! getSFAZ( tmp_double ) )
    {
      return false;
    }
    sb_Utils::add_subfield( record.back(), "SFAZ", tmp_double );
  }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "SFAZ", sc_Subfield::is_A );
    }
#endif


  if ( ! getXORG( tmp_double ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "XORG", tmp_double );



  if ( ! getYORG( tmp_double ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "YORG", tmp_double );


#ifdef NOT_RASTER_PROFILE
  if ( SATP == THREE_TUPLE )
  {
    if ( ! getZORG( tmp_double ) )
    {
      return false;
    }
    sb_Utils::add_subfield( record.back(), "ZORG", tmp_double );
  }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "ZORG", sc_Subfield::is_A );
    }
#endif


  if ( ! getXHRS( tmp_double ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "XHRS", tmp_double );



  if ( ! getYHRS( tmp_double ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "YHRS", tmp_double );



#ifdef NOT_RASTER_PROFILE
  if ( SATP == THREE_TUPLE )
  {
    if ( ! getVRES( tmp_double ) )
    {
      return false;
    }
    sb_Utils::add_subfield( record.back(), "VRES", tmp_double );

  }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "VRES", sc_Subfield::is_A );
    }
#endif

  // XXX Dimension ID


  return true;

} // sb_Iref::getRecord




void
sb_Iref::setComment( string const & val ) 
{
  _imp->_comment = val;
} // sb_Iref::setComment


void
sb_Iref::setSpatialAddressType( string const & val ) 
{
  _imp->_spatialAddType = val;
} // sb_Iref::setSpatialAddressType


void
sb_Iref::setSpatialAddressXLabel( string const & val ) 
{
  _imp->_spatialAddXCompLbl = val;
} // sb_Iref::setSpatialAddressXLabel


void
sb_Iref::setSpatialAddressYLabel( string const & val ) 
{   _imp->_spatialAddYCompLbl = val;
} // sb_Iref::setSpatialAddressYLabel



void
sb_Iref::setHorizontalComponentFormat( string const & val ) 
{   _imp->_horizontalCompFmt = val;
} // sb_Iref::setHorizontalComponentFormat



#ifdef NOT_RASTER_PROFILE
void
sb_Iref::setVerticalComponentFormat( string const & val ) 
{   _imp->_verticalCompFmt = val;
} // sb_Iref::setVerticalComponentFormat
#endif

       
void
sb_Iref::setScaleFactorX( double const & val ) 
{   _imp->_scaleFactX = val;
} // sb_Iref::setScaleFactorX



void
sb_Iref::setScaleFactorY( double const & val ) 
{   _imp->_scaleFactY = val;
} // sb_Iref::setScaleFactorY



#ifdef NOT_RASTER_PROFILE
void
sb_Iref::setScaleFactorZ( double const & val ) 
{   _imp->_scaleFactZ = val;
} // sb_Iref::setScaleFactorZ
#endif


void
sb_Iref::setXOrigin( double const & val ) 
{   _imp->_xOrigin = val;
} // sb_Iref::setXOrigin



void
sb_Iref::setYOrigin( double const & val ) 
{   _imp->_yOrigin = val;
} // sb_Iref::setYOrigin



#ifdef NOT_RASTER_PROFILE
void
sb_Iref::setZOrigin( double const & val ) 
{   _imp->_zOrigin = val;
} // sb_Iref::setZOrigin
#endif


      
void
sb_Iref::setXComponentHorizontalResolution( double const & val ) 
{   _imp->_xCompHorizRes = val;
} // sb_Iref::setXComponentHorizontalResolution



void
sb_Iref::setYComponentHorizontalResolution( double const & val ) 
{   _imp->_yCompHorizRes = val;
} // sb_Iref::setYComponentHorizontalResolution



#ifdef NOT_RASTER_PROFILE
void
sb_Iref::setVerticalResolutionComponent( double const & val ) 
{   _imp->_verticalResComp = val;
} // sb_Iref::setVerticalResolutionComponent
#endif



#ifdef NOT_IMPLEMENTED
void
sb_Iref::setDimensionID( vector<sb_ForeignID> const & val ) 
{   _imp->_dimensionID = val;
} // sb_Iref::setDimensionID
#endif





bool
sb_Iref::setRecord( sc_Record const & record )
{
  return _ingest_record( *this, *(this->_imp), record );
} // sb_Iref::setRecord




bool
sb_Iref::getSchema( sio_8211Schema& schema ) const
{
                                // If the schema hasn't been
                                // initialized, please do so.

  if ( _iref_schema.empty() )
    {
      _build_iref_schema( _iref_schema );
    }

  if ( _iref_schema.empty() )   // oops ... something screwed up
    {
      return false;
    }

  schema = _iref_schema;

  return true;

} // sb_Iref::getSchema
