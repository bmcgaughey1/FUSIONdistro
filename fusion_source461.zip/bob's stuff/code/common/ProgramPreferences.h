// ProgramPreferences.h: interface for the CProgramPreferences class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROGRAMPREFERENCES_H__079E1D30_27BD_458C_B499_2F75AF9B7846__INCLUDED_)
#define AFX_PROGRAMPREFERENCES_H__079E1D30_27BD_458C_B499_2F75AF9B7846__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CProgramPreferences  
{
public:
	void SetPreference(LPCTSTR szKey, int Value);
	void SetPreference(LPCTSTR szKey, double Value, int Digits = 15);
	void SetPreference(LPCTSTR szKey, LPCTSTR Value);
	void SetPreference(int Key, int Value);
	void SetPreference(int Key, double Value, int Digits = 15);
	void SetPreference(int Key, LPCTSTR Value);
	int GetPreference(LPCTSTR szKey, int DefaultValue);
	double GetPreference(LPCTSTR szKey, double DefaultValue);
	CString GetPreference(LPCTSTR szKey, LPCTSTR DefaultValue);
	int GetPreference(int Key, int DefaultValue);
	double GetPreference(int Key, double DefaultValue);
	CString GetPreference(int Key, LPCTSTR DefaultValue);
	void SetSectionName(LPCTSTR szSection);
	CString GetSectionName();
	CProgramPreferences();
	virtual ~CProgramPreferences();

private:
	CString m_Section;
};

#endif // !defined(AFX_PROGRAMPREFERENCES_H__079E1D30_27BD_458C_B499_2F75AF9B7846__INCLUDED_)
