// WorldFile.cpp: implementation of the CWorldFile class.
//
//
// The image-to-world transformation is a six-parameter affine transformation in the form of:
//
// x1 = Ax + By + C
// y1 = Dx + Ey + F
//
// where
//
//	x1 = calculated x-coordinate of the pixel on the map
//	y1 =  calculated y-coordinate of the pixel on the map
//	x = column number of a pixel in the image
//	y = row number of a pixel in the image
//	A = x-scale; dimension of a pixel in map units in x direction
//	B, D = rotation terms
//	C, F = translation terms; x,y map coordinates of the center of the upper-left pixel
//	E = negative of y-scale; dimension of a pixel in map units in y direction
//
// Note  The y-scale (E) is negative because the origins of an image and a geographic coordinate system are different. 
// The origin of an image is located in the upper-left corner, whereas the origin of the map coordinate system is located 
// in the lower-left corner. Row values in the image increase from the origin downward, while y-coordinate values in 
// the map increase from the origin upward.
//
// The transformation parameters are stored in the world file in this order:
//
//                  20.17541308822119 - A
//                   0.00000000000000 - D
//                   0.00000000000000 - B
//                 -20.17541308822119 - E
//              424178.11472601280548 - C
//             4313415.90726399607956 - F
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WorldFile.h"
#include "DataFile.h"
#include "FileSpec.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CWorldFile::CWorldFile()
{
	m_Aterm = 1.0;
	m_Bterm = 0.0;
	m_Cterm = 0.0;
	m_Dterm = 0.0;
	m_Eterm = -1.0;
	m_Fterm = 0.0;

	m_FileName.Empty();
}

CWorldFile::~CWorldFile()
{

}

BOOL CWorldFile::FindAndRead(LPCTSTR BaseFileName)
{
	CFileSpec FileSpec(BaseFileName);

	m_FileName = CString(BaseFileName);

	// first try the simple rule...append a "w" to the file extension
	FileSpec.SetExt(FileSpec.Extension() + _T("w"));
	if (FileSpec.Exists()) {
		m_FileName = FileSpec.GetFullSpec();
		ReadValues();
		return(TRUE);
	}

	// if no extension...add "w" to file name
	FileSpec.SetFullSpec(BaseFileName);
	if (FileSpec.Extension().IsEmpty()) {
		FileSpec.SetFileNameEx(FileSpec.FileName() + _T("w"));
		if (FileSpec.Exists()) {
			m_FileName = FileSpec.GetFullSpec();
			ReadValues();
			return(TRUE);
		}
	}
	
	// try 8.3 rules...use first and third characters of extension and append "w"
	FileSpec.SetFullSpec(BaseFileName);
	if (FileSpec.Extension().GetLength() == 4) {
		CString newext = FileSpec.Extension().GetAt(0);
		newext += FileSpec.Extension().GetAt(1);
		newext += FileSpec.Extension().GetAt(3);
		newext += 'w';
		FileSpec.SetExt(newext);
		if (FileSpec.Exists()) {
			m_FileName = FileSpec.GetFullSpec();
			ReadValues();
			return(TRUE);
		}
	}

	// give up
	FileSpec.SetFullSpec(BaseFileName);
	m_FileName = FileSpec.GetFullSpec();

	// set term values...origin at 0,0...pixel size 1 by 1
	m_Aterm = 1.0;
	m_Bterm = 0.0;
	m_Cterm = 0.0;
	m_Dterm = 0.0;
	m_Eterm = -1.0;
	m_Fterm = 0.0;

	return(FALSE);
}

BOOL CWorldFile::ReadValues()
{
	CDataFile dat(m_FileName);
	if (dat.IsValid()) {
		// read values
		char buf[512];
		dat.ReadASCIILine(buf);
		m_Aterm = atof(buf);
		dat.ReadASCIILine(buf);
		m_Dterm = atof(buf);
		dat.ReadASCIILine(buf);
		m_Bterm = atof(buf);
		dat.ReadASCIILine(buf);
		m_Eterm = atof(buf);
		dat.ReadASCIILine(buf);
		m_Cterm = atof(buf);
		dat.ReadASCIILine(buf);
		m_Fterm = atof(buf);

		dat.Close();

		return(TRUE);
	}
	return(FALSE);
}

BOOL CWorldFile::WriteValues(LPCTSTR FileName)
{
	FILE* f = fopen(FileName, "wt");
	if (f) {
		fprintf(f, "%lf\n", m_Aterm);
		fprintf(f, "%lf\n", m_Dterm);
		fprintf(f, "%lf\n", m_Bterm);
		fprintf(f, "%lf\n", m_Eterm);
		fprintf(f, "%lf\n", m_Cterm);
		fprintf(f, "%lf\n", m_Fterm);
		fclose(f);
		return(TRUE);
	}
	return(FALSE);
}
