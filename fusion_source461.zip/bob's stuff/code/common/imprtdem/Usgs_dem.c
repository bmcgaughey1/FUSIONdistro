/*****************************************************************************
*
*  usgs_dem.c		Copyright 1992, Carto Instruments
*
*     routines to reformat a USGS DEM file
*
*  Revision History:
*
*			usgs_dem.c
*			Revision: 1.3
*			Date: 1994/12/13 20:06:41
*			Author: RJM
*
*  1/29/2007 changed logic that reads type b record elevation values to read 6 characters
*            to account for files that have no spaces between elevation values
*
*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <math.h>
#include <float.h>
//#include <fswindow.h>
//#include <colors.h>
#include "imprtdem.h"

#define		VOID_MARKER		-1.0

extern char source_dtm[_MAX_PATH], dest_dtm[_MAX_PATH];
extern double z_factor;
extern int		simple_status;			/* flag to control use of simple status messages */


int read_type_a(FILE *, TYPE_A *);
int read_type_b_header(FILE *, TYPE_B *);
int read_type_b_elev(FILE *, TYPE_B *);

void free_type_b_elev(TYPE_B *);
int seek_type_b_end(FILE *);
void calc_dtm_envelope(TYPE_A *record, struct _wxycoord *min, struct _wxycoord *max);

void set_usgs_desc_name(char *buf);

void print_type_a(TYPE_A *);
void print_type_b_header(TYPE_B *);

int read_dem_real(FILE *file, double *number);
int read_dem_float(FILE *file, float *number);

extern TYPE_A type_a_record;
extern TYPE_B type_b_record;

int check_usgs_fmt(void)
{
	FILE *file;
	TYPE_A *a_rec = &type_a_record;

	if ((file = fopen(source_dtm, "rb")) == NULL)
		return(-2);

	/* attempt to read the type A record...header */
   if (read_type_a(file, a_rec))
		return(-3);

	fclose(file);

	return(0);
}

int read_usgs_head(ASCII_HEADER *dtm)
{
	FILE *file;
	TYPE_A *a_rec = &type_a_record;
	struct _wxycoord minimum;
	struct _wxycoord maximum;
	long max_pt_per_col;

	/* read the type a record...header */
	if ((file = fopen(source_dtm, "rb")) == NULL)
		return(-2);

	/* attempt to read the type A record...header */
   if (read_type_a(file, a_rec))
		return(-3);

	fclose(file);

	/* scan file to determine the dtm envelope */
	scan_for_dtm_envelope(a_rec, &minimum, &maximum, &max_pt_per_col);

	/* fill out ASCII_HEADER */
	dtm->origin_x = minimum.wx;
	dtm->origin_y = minimum.wy;
	dtm->rotation = a_rec->rotation;
	dtm->column_spacing = (double) a_rec->resolve[0];
	dtm->point_spacing = (double) a_rec->resolve[1];
	dtm->columns = max((long) a_rec->prof_cols, (long) ((maximum.wx - minimum.wx) / dtm->column_spacing + 1.0));
	dtm->points = max(max_pt_per_col, (long) ((maximum.wy - minimum.wy) / dtm->point_spacing + 1.0));
	dtm->xy_units = a_rec->plan_units - 1;
	dtm->z_units = a_rec->elev_units - 1;

	return(0);
}

int reformat_usgs(ASCII_HEADER *dtm, BIN_HEADER *bin)
{
	FILE *dtm_file;
	FILE *bin_file;
	TYPE_A *a_rec = &type_a_record;
	TYPE_B *b_rec = &type_b_record;

	long i;
	long j;
	long bin_start;
	short elev_i = 0;
	long elev_l = 0l;
	float elev_f = 0.0f;
	double elev_d = 0.0;
	double min_z = DBL_MAX;
	double max_z = DBL_MIN;
	int row = 3;

	char ts[256];

	/* open the DEM file */
	if ((dtm_file = fopen(source_dtm, "rb")) == NULL)
		return(-2);

	/* open the binary file */
	if ((bin_file = fopen(dest_dtm, "rb+")) == NULL) {
		fclose(dtm_file);
		return(-5);
	}

	/* 1/10/92 */

	/* seek to first profile in DEM file...second 1024 byte record */
	if (seek_type_b_end(dtm_file)) {
		fclose(dtm_file);
		fclose(bin_file);
		return(-3);
	}

	/* seek to start of data area in binary dtm file */
	if (fseek(bin_file, 200L, SEEK_SET)) {
		fclose(dtm_file);
		fclose(bin_file);
		return(-6);
	}

	if (!simple_status) {
		sprintf(ts, "Reformatting DEM file...profile       of %5li", dtm->columns);
		print_status_message(ts);
		print_status_message("\b\b\b\b\b\b\b\b\b");
	}

	/* step through profiles and do the format conversion */
	for (i = 0; i < dtm->columns; i ++) {
		if ((i + 1) % 10 == 0 && !simple_status) {
			sprintf(ts, "\b\b\b\b\b%5li", i + 1l);
			print_status_message(ts);
		}
//		else {
//			sprintf(ts, "Profile %5li\n", i + 1);
//			print_status_message(ts);
//		}

		/* read next profile header...type B record */
	   if (read_type_b_header(dtm_file, b_rec)) {
			fclose(dtm_file);
			fclose(bin_file);
			return(-3);
		}

		/* calculate starting position in binary dtm profile...in DEM, not all profiles are complete */
		bin_start = (long) ((b_rec->prof_y - dtm->origin_y) / (double) a_rec->resolve[1]);

		/* write off void area markers at beginning of profile...if needed */
		for (j = 0l; j < bin_start; j ++) {
			switch (bin->z_bytes) {
				case 0:
					elev_i = (short) VOID_MARKER;
					if (fwrite(&elev_i, sizeof(short), 1, bin_file) < 1) {
						fclose(dtm_file);
						fclose(bin_file);
						return(-6);
					}
					break;
				case 1:
					elev_l = (long) VOID_MARKER;
					if (fwrite(&elev_l, sizeof(long), 1, bin_file) < 1) {
						fclose(dtm_file);
						fclose(bin_file);
						return(-6);
					}
					break;
				case 2:
					elev_f = (float) VOID_MARKER;
					if (fwrite(&elev_f, sizeof(float), 1, bin_file) < 1) {
						fclose(dtm_file);
						fclose(bin_file);
						return(-6);
					}
					break;
				case 3:
					elev_d = VOID_MARKER;
					if (fwrite(&elev_d, sizeof(double), 1, bin_file) < 1) {
						fclose(dtm_file);
						fclose(bin_file);
						return(-6);
					}
					break;
			}
		}

		/* read the elevation data from DEM file */
	   if (read_type_b_elev(dtm_file, b_rec)) {
			fclose(dtm_file);
			fclose(bin_file);
			return(-3);
		}

		/* write off elevations */
		for (j = bin_start; j < bin_start + b_rec->no_points; j ++) {
			elev_d = b_rec->elev_array[j - bin_start] * (double) a_rec->resolve[2] + b_rec->local_elev;

			if (elev_d < 0.0)
				elev_d = (double) VOID_MARKER;

			switch (bin->z_bytes) {
				case 0:
					elev_i = (short) (elev_d * z_factor);
					if (fwrite(&elev_i, sizeof(short), 1, bin_file) < 1) {
						fclose(dtm_file);
						fclose(bin_file);
						return(-6);
					}
					if (elev_i > 0) {
						min_z = (((double) elev_i) < min_z) ? (double) elev_i : min_z;
						max_z = (((double) elev_i) > max_z) ? (double) elev_i : max_z;
					}
					break;
				case 1:
					elev_l = (long) (elev_d * z_factor);
					if (fwrite(&elev_l, sizeof(long), 1, bin_file) < 1) {
						fclose(dtm_file);
						fclose(bin_file);
						return(-6);
					}
					if (elev_l > 0L) {
						min_z = (((double) elev_l) < min_z) ? (double) elev_l : min_z;
						max_z = (((double) elev_l) > max_z) ? (double) elev_l : max_z;
					}
					break;
				case 2:
					elev_f = (float) (elev_d * z_factor);
					if (fwrite(&elev_f, sizeof(float), 1, bin_file) < 1) {
						fclose(dtm_file);
						fclose(bin_file);
						return(-6);
					}
					if (elev_f > 0.0f) {
						min_z = (((double) elev_f) < min_z) ? (double) elev_f : min_z;
						max_z = (((double) elev_f) > max_z) ? (double) elev_f : max_z;
					}
					break;
				case 3:
					elev_d = elev_d * z_factor;
					if (fwrite(&elev_d, sizeof(double), 1, bin_file) < 1) {
						fclose(dtm_file);
						fclose(bin_file);
						return(-6);
					}
					if (elev_d > 0.0) {
						min_z = (elev_d < min_z) ?  elev_d : min_z;
						max_z = (elev_d > max_z) ?  elev_d : max_z;
					}
					break;
			}
		}

		/* write off void area markers at end of profile...if needed */
		for (j = bin_start + b_rec->no_points; j < dtm->points; j ++) {
			switch (bin->z_bytes) {
				case 0:
					elev_i = (short) VOID_MARKER;
					if (fwrite(&elev_i, sizeof(short), 1, bin_file) < 1) {
						fclose(dtm_file);
						fclose(bin_file);
						return(-6);
					}
					break;
				case 1:
					elev_l = (long) VOID_MARKER;
					if (fwrite(&elev_l, sizeof(long), 1, bin_file) < 1) {
						fclose(dtm_file);
						fclose(bin_file);
						return(-6);
					}
					break;
				case 2:
					elev_f = (float) VOID_MARKER;
					if (fwrite(&elev_f, sizeof(float), 1, bin_file) < 1) {
						fclose(dtm_file);
						fclose(bin_file);
						return(-6);
					}
					break;
				case 3:
					elev_d = VOID_MARKER;
					if (fwrite(&elev_d, sizeof(double), 1, bin_file) < 1) {
						fclose(dtm_file);
						fclose(bin_file);
						return(-6);
					}
					break;
			}
		}

		/* free the memory associated with elevation data */
		free_type_b_elev(b_rec);

		/* seek to end of current type B record */
		seek_type_b_end(dtm_file);
	}

	fclose(dtm_file);
	fclose(bin_file);

	if (!simple_status)
		print_status_message("\r                                                                      \r");

	bin->min_z = min_z;
	bin->max_z = max_z;

	return(0);
}

/*==========================================================================*/

int read_type_a(FILE *file,			/* pointer to file handle */
					 TYPE_A *record)		/* pointer to TYPE_A record structure */
{
	/**************************************************************************
	*
	*  function name:	read_type_a()
	*
	*  description:
	*
	*		reads the type A header record from the DEM file
	*
	*		all of the fseek calls should not be necessary, but the DEM files
	*		don't seem to be consistent...or at least C's reading of them.
	*
	*  return value:
	*
	*		returns 0 if successful, 0 otherwise
	*
	**************************************************************************/

	int i;

	/* read quad name and add terminator...seems that quad name field has extra
		stuff in it after column 30, so only read first 30 characters */
	if (fread(record->quad_name, sizeof(char), 30, file) != 30)
		return(1);

	record->quad_name[30] = '\0';


/* removing code to read "other field" in element 1...seems to be
	inconsistent between old DEM format and new format */

	/* seek to process code */
/*	fseek(file, 137l, SEEK_SET); */

	/* read process code */
/*	if (fread(&record->process_code, sizeof(char), 1, file) != 1)
		return(1); */

	/* seek to sectional indicator */
/*	fseek(file, 1l, SEEK_CUR); */

	/* read sectional indicator and add terminator */
/*	if (fread(record->sec_ind, sizeof(char), 3, file) != 3)
		return(1); */

/*	record->sec_ind[3] = '\0'; */

	/* read mapping center and add terminator */
/*	fseek(file, 140l, SEEK_SET);
	if (fread(record->mc_origin, sizeof(char), 4, file) != 4)
		return(1); */

/*	record->mc_origin[4] = '\0'; */

	/* read the DEM level code */
	fseek(file, 144l, SEEK_SET);
	if (fscanf(file, "%6i", &record->level_code) != 1)
		return(1);

	/* read the elevation pattern */
	fseek(file, 150l, SEEK_SET);
	if (fscanf(file, "%6i", &record->elev_pattern) != 1)
		return(1);

	/* read the planimetric reference system */
	fseek(file, 156l, SEEK_SET);
	if (fscanf(file, "%6i", &record->coord_sys) != 1)
		return(1);

	/* read the coordinate system zone */
	fseek(file, 162l, SEEK_SET);
	if (fscanf(file, "%6i", &record->coord_zone) != 1)
		return(1);

	/* read the map projection parameters */
	fseek(file, 168l, SEEK_SET);
	for (i = 0; i < 15; i ++) {
		if (read_dem_real(file, &record->map_proj[i]) != 1)
			return(1);
	}

	/* read the units for XY data */
	fseek(file, 528l, SEEK_SET);
   if (fscanf(file, "%6i", &record->plan_units) != 1)
		return(1);

	/* read the units for Z data */
	fseek(file, 534l, SEEK_SET);
	if (fscanf(file, "%6i", &record->elev_units) != 1)
		return(1);

	/* read the number of polygon sides */
	fseek(file, 540l, SEEK_SET);
	if (fscanf(file, "%6i", &record->poly_sides) != 1)
		return(1);

	/* read the bounding box corner coordinates */
	fseek(file, 546l, SEEK_SET);
	for (i = 0; i < 8; i ++) {
		if (read_dem_real(file, &record->corners[i]) != 1)
			return(1);
	}

	/* read the minimum elevation */
	fseek(file, 738l, SEEK_SET);
	if (read_dem_real(file, &record->min_elev) != 1)
		return(1);

	/* read the maximum elevation */
	if (read_dem_real(file, &record->max_elev) != 1)
		return(1);

	/* read the rotation within the coordinate system */
	fseek(file, 786l, SEEK_SET);
	if (read_dem_real(file, &record->rotation) != 1)
		return(1);

	/* read the elevation accuracy code */
	fseek(file, 810l, SEEK_SET);
	if (fscanf(file, "%6i", &record->elev_accuracy) != 1)
		return(1);

	/* read the resolution units for the dem data */
	fseek(file, 816l, SEEK_SET);
	for (i = 0; i < 3; i ++) {
		if (read_dem_float(file, &record->resolve[i]) != 1)
			return(1);
	}

	/* read the row/column array */
	fseek(file, 852l, SEEK_SET);
	if (fscanf(file, "%6i", &record->prof_rows) != 1)
		return(1);

	if (fscanf(file, "%6i", &record->prof_cols) != 1)
		return(1);

/* does not read any of the parameters defined in the "new format" */

	return(0);
}

/*==========================================================================*/

void print_type_a(TYPE_A *a_rec)
{
	/**************************************************************************
	*
	*  function name:	print_type_a()
	*
	*  description:
	*
	*		prints selected parameters from type A record
	*
	*  return value:
	*
	*		no value is returned
	*
	**************************************************************************/

	printf("DEM name %s\n", a_rec->quad_name);
	printf("Elevation pattern: %6i\n", a_rec->elev_pattern);
	printf("Planimetric reference system: %6i   Zone: %6i\n", a_rec->coord_sys, a_rec->coord_zone);
	printf("Measurement units...XY:%6i  Z:%6i\n", a_rec->plan_units, a_rec->elev_units);
	printf("DEM corners:  (%lf,%lf)\n", a_rec->corners[0], a_rec->corners[1]);
	printf("              (%lf,%lf)\n", a_rec->corners[2], a_rec->corners[3]);
	printf("              (%lf,%lf)\n", a_rec->corners[4], a_rec->corners[5]);
	printf("              (%lf,%lf)\n", a_rec->corners[6], a_rec->corners[7]);
	printf("Minimum elevation: %lf   Max: %lf\n", a_rec->min_elev, a_rec->max_elev);
	printf("Rotation: %lf\n", a_rec->rotation);
	printf("Resolution...X:%f   Y:%f   Z:%f\n", a_rec->resolve[0], a_rec->resolve[1], a_rec->resolve[2]);
	printf("Number of profiles: %6i\n\n\n\n", a_rec->prof_cols);
}

/*==========================================================================*/

void print_dem_header(char *hdr_file)
{
	FILE *f;
	TYPE_A *a_rec = &type_a_record;

	f = fopen(hdr_file, "wt");

	if (f != (FILE *) NULL) {
		fprintf(f, "DEM name: %s\n", a_rec->quad_name);
		fprintf(f, "DEM level code: %i\n", a_rec->level_code);
		fprintf(f, "Elevation pattern: %i\n", a_rec->elev_pattern);
		fprintf(f, "Planimetric reference system: %6i   Zone: %6i\n", a_rec->coord_sys, a_rec->coord_zone);
		fprintf(f, "Measurement units...XY:%6i  Z:%6i\n", a_rec->plan_units, a_rec->elev_units);
		fprintf(f, "DEM corners:  (%lf,%lf)\n", a_rec->corners[0], a_rec->corners[1]);
		fprintf(f, "              (%lf,%lf)\n", a_rec->corners[2], a_rec->corners[3]);
		fprintf(f, "              (%lf,%lf)\n", a_rec->corners[4], a_rec->corners[5]);
		fprintf(f, "              (%lf,%lf)\n", a_rec->corners[6], a_rec->corners[7]);
		fprintf(f, "Minimum elevation: %lf   Max: %lf\n", a_rec->min_elev, a_rec->max_elev);
		fprintf(f, "Rotation: %lf\n", a_rec->rotation);
		fprintf(f, "Resolution...X:%f   Y:%f   Z:%f\n", a_rec->resolve[0], a_rec->resolve[1], a_rec->resolve[2]);
		fprintf(f, "Number of profiles: %6i\n\n\n\n", a_rec->prof_cols);

		fclose(f);
	}
}

/*==========================================================================*/

int read_type_b_header(FILE *file,			/* pointer to file handle */
					 		  TYPE_B *record)		/* pointer to TYPE_B record structure */
{
	/**************************************************************************
	*
	*  function name:	read_type_b_header()
	*
	*  description:
	*
	*		reads a type B record header...assumes file pointer is positioned
	*		at the beginning of the record
	*
	*  return value:
	*
	*		returns 0 if successful, 1 otherwise
	*
	**************************************************************************/

	/* read the row/column identifiers */
	if (fscanf(file, "%6i", &record->row_id) != 1)
		return(1);
	if (fscanf(file, "%6i", &record->col_id) != 1)
		return(1);

	/* read the number of points/columns in "patch" */
	if (fscanf(file, "%6i", &record->no_points) != 1)
		return(1);
	if (fscanf(file, "%6i", &record->no_cols) != 1)
		return(1);

	/* read the first data point's XY coordinate */
	if (read_dem_real(file, &record->prof_x) != 1)
		return(1);
	if (read_dem_real(file, &record->prof_y) != 1)
		return(1);

	/* read the profile local elevation datum */
	if (read_dem_real(file, &record->local_elev) != 1)
		return(1);

	/* read the min/max elevations */
	if (read_dem_real(file, &record->min_elev) != 1)
		return(1);
	if (read_dem_real(file, &record->max_elev) != 1)
		return(1);

	return(0);
}

/*==========================================================================*/

void print_type_b_header(TYPE_B *b_rec)	/* pointer to TYPE_B record structure */
{
	/**************************************************************************
	*
	*  function name:	print_type_b_header()
	*
	*  description:
	*
	*		prints the information in the type B record to screen
	*
	*  return value:
	*
	*		no value is returned
	*
	**************************************************************************/

	printf("Row/column ID: %6i %6i\n", b_rec->row_id, b_rec->col_id);
	printf("Number of elevations: %6i %6i\n", b_rec->no_points, b_rec->no_cols);
	printf("First point: (%lf,%lf)\n", b_rec->prof_x, b_rec->prof_y);
	printf("Local elevation datum: %lf\n", b_rec->local_elev);
	printf("Min/max elevation...Min:%lf    Max:%lf\n", b_rec->min_elev, b_rec->max_elev);
}

/*==========================================================================*/

int read_type_b_elev(FILE *file,				/* pointer to file handle */
					 		TYPE_B *record)		/* pointer to TYPE_B record structure */
{
	/**************************************************************************
	*
	*  function name:	read_type_b_elev()
	*
	*  description:
	*
	*		reads the elevation data associated with the current type B record.
	*
	*		assumes file pointer is located at the end of the type B record
	*		header
	*
	*		allocates memory for the elevation data then reads the data
	*
	*		use free_type_b_elev() to free up the elevation data memory
	*
	*  return value:
	*
	*		returns 0 if successful, 1 otherwise
	*
	**************************************************************************/

	int i;

	/* allocate memory for elevation data */
	if ((record->elev_array = (int *) malloc(record->no_points * sizeof(int))) == (int *) NULL)
		return(1);

	/* read the elevations */
	for (i = 0; i < record->no_points; i ++) {
		if (fscanf(file, "%6i", &record->elev_array[i]) != 1)
			return(1);
	}

	return(0);
}

/*==========================================================================*/

void free_type_b_elev(TYPE_B *record)		/* pointer to type B record */
{
	/**************************************************************************
	*
	*  function name:	free_type_b_elev()
	*
	*  description:
	*
	*		frees the memory associated with a type B record's elevation array
	*
	*  return value:
	*
	*		no value is returned
	*
	**************************************************************************/

	free(record->elev_array);
}

/*==========================================================================*/

int seek_type_b_end(FILE *file)		/* pointer to file handle */
{
	/**************************************************************************
	*
	*  function name:
	*
	*  description:
	*
	*  return value:
	*
	**************************************************************************/

	long current_offset;
	long new_offset;
	long i;
	int c;

	/* get the current position */
	current_offset = ftell(file);

	/* calculate offset to next 1024 byte logical record */
	new_offset = 1024l - (current_offset - (current_offset / 1024l) * 1024l);

	/* 1/10/92 */
	/* set up to seek to new record location...may end seek early if a control */
	/* character is encountered */
	i = 0l;
	while (i < new_offset) {
		c = fgetc(file);
		i ++;
		if (c == EOF)
			return(1);

		if (c < 32)
			break;
	}

	/* if a control character was encountered...read until a good character is */
	/* found, then back up 1 character */
	if (i != new_offset) {
		while (TRUE) {
			c = fgetc(file);
			if (c < 32 && c > 0)
				continue;
			else if (c == EOF)
				return(1);
			else
				break;
		}
		fseek(file, -1l, SEEK_CUR);
	}

/*	else
		fseek(file, new_offset, SEEK_CUR);
*/
	return(0);
}

/*==========================================================================*/

void calc_dtm_envelope(TYPE_A *record,			/* pointer to type a record */
							 struct _wxycoord *min,	/* minimum X and Y */
							 struct _wxycoord *max)	/* maximum X and Y */
{
	/**************************************************************************
	*
	*  function name:	calc_dtm_envelope()
	*
	*  description:
	*
	*		calculates the extents of the dtm file needed to contain the quad
	*		described in the type a record
	*
	*  return value:
	*
	*		no value is returned
	*
	**************************************************************************/

	double min_x = DBL_MAX;
	double max_x = DBL_MIN;
	double min_y = DBL_MAX;
	double max_y = DBL_MIN;
	int i;

	/* look through quad corners and find min/max X an Y values */
	for (i = 0; i < 7; i += 2) {
		if (record->corners[i] < min_x)
			min_x = record->corners[i];

		if (record->corners[i] > max_x)
			max_x = record->corners[i];

		if (record->corners[i + 1] < min_y)
			min_y = record->corners[i + 1];

		if (record->corners[i + 1] > max_y)
			max_y = record->corners[i + 1];
	}

	/* find minimum X and Y...round min quad X and Y up to nearest multiple */
	min->wx = ceil(min_x / record->resolve[0]) * record->resolve[0];
	min->wy = ceil(min_y / record->resolve[1]) * record->resolve[1];

	/* find maximum X and Y...round min quad X and Y down to nearest multiple */
	max->wx = floor(max_x / record->resolve[0]) * record->resolve[0];
	max->wy = floor(max_y / record->resolve[1]) * record->resolve[1];
}

/*==========================================================================*/

void scan_for_dtm_envelope(TYPE_A *record,			/* pointer to type a record */
							 struct _wxycoord *min,	/* minimum X and Y */
							 struct _wxycoord *max,	/* maximum X and Y */
							 long *max_pt_per_col)	/* maximum number of points in a profile */
{
	/**************************************************************************
	*
	*  function name:	scan_for_dtm_envelope()
	*
	*  description:
	*
	*		scans the DEM file to determine the extent of the dtm file needed to
	*		contain the quad
	*
	*  return value:
	*
	*		no value is returned
	*
	**************************************************************************/

	double min_x = DBL_MAX;
	double max_x = DBL_MIN;
	double min_y = DBL_MAX;
	double max_y = DBL_MIN;
	double end_x, end_y;
	FILE *dtm_file;
	TYPE_A *a_rec = &type_a_record;
	TYPE_B *b_rec = &type_b_record;

	long i;
	char ts[256];

	*max_pt_per_col = 0l;

	/* open the DEM file */
	if ((dtm_file = fopen(source_dtm, "rb")) == NULL)
		return;

   if (read_type_a(dtm_file, a_rec))
		return;

	/* seek to first profile in DEM file...second 1024 byte record */
	if (seek_type_b_end(dtm_file)) {
		fclose(dtm_file);
		return;
	}

	if (!simple_status) {
		sprintf(ts, "Scanning DEM file to determine data limits...profile       of %5i", a_rec->prof_cols);
		print_status_message(ts);
		print_status_message("\b\b\b\b\b\b\b\b\b");
	}

	/* step through profiles and read min\max X and Y */
	for (i = 0; i < (long) a_rec->prof_cols; i ++) {
		if ((i + 1) % 10 == 0 && !simple_status) {
			sprintf(ts, "\b\b\b\b\b%5li", i + 1l);
			print_status_message(ts);
		}
//		else {
//			sprintf(ts, "Profile %5li\n", i + 1);
//			print_status_message(ts);
//		}

		/* read next profile header...type B record */
	   if (read_type_b_header(dtm_file, b_rec)) {
			fclose(dtm_file);
			return;
		}

		/* check profile ends against min/max */
		if (b_rec->prof_x < min_x)
			min_x = b_rec->prof_x;
		if (b_rec->prof_y < min_y)
			min_y = b_rec->prof_y;
		if (b_rec->prof_x > max_x)
			max_x = b_rec->prof_x;
		if (b_rec->prof_y > max_y)
			max_y = b_rec->prof_y;

		if ((long) b_rec->no_points > *max_pt_per_col)
			*max_pt_per_col = b_rec->no_points;

		end_x = b_rec->prof_x + ((double) (b_rec->no_cols - 1) * (double) a_rec->resolve[0]);
		end_y = b_rec->prof_y + ((double) (b_rec->no_points - 1) * (double) a_rec->resolve[1]);
		if (end_x < min_x)
			min_x = end_x;
		if (end_y < min_y)
			min_y = end_y;
		if (end_x > max_x)
			max_x = end_x;
		if (end_y > max_y)
			max_y = end_y;

		/* read the elevation data from DEM file */
	   if (read_type_b_elev(dtm_file, b_rec)) {
			fclose(dtm_file);
			return;
		}

		/* free the memory associated with elevation data */
		free_type_b_elev(b_rec);

		/* seek to end of current type B record */
		seek_type_b_end(dtm_file);
	}

	fclose(dtm_file);

	if (!simple_status)
		print_status_message("\r                                                                      \r");

	min->wx = min_x;
	min->wy = min_y;

	max->wx = max_x;
	max->wy = max_y;
}

/*==========================================================================*/

void set_usgs_desc_name(char *buf)		/* pointer to location for DEM name */
{
	/**************************************************************************
	*
	*  function name:	set_usgs_desc_name()
	*
	*  description:
	*
	*		set the descriptive name to the quad name plus "USGS DEM"
	*
	*  return value:
	*
	*		no value is returned
	*
	**************************************************************************/

	char *cnt = type_a_record.quad_name;
	int i = 0;
	char label[] = {"USGS DEM"};

	/* copy the quad name */
	while (*cnt != '\0') {
		buf[i] = *cnt;

		i ++;
		cnt ++;
	}

	/* copy the string "USGS DEM" */
	cnt = label;

	while (*cnt != '\0') {
		buf[i] = *cnt;

		i ++;
		cnt ++;
	}

	/* add terminator */
	buf[i] = '\0';
}

/*==========================================================================*/

int read_dem_real(FILE *file,			/* pointer to file handle */
						double *number)	/* pointer to double variable */
{
	/**************************************************************************
	*
	*  function name:	read_dem_real()
	*
	*  description:
	*
	*		reads a double precision floating point number from the DEM file
	*		special handling is required for the .000000000D+03 format ('D'
	*		causes problems for C language)
	*
	*		reads D24.15 format (FORTRAN notation)
	*
	*  return value:
	*
	*		returns 1 if successful, 0 otherwise
	*
	**************************************************************************/

	char buf[40];
	char *cnt;

	if (fread(buf, sizeof(char), 24, file) != 24)
		return(0);

	buf[24] = '\0';

	cnt = buf;

	while (*cnt != '\0') {
		if (*cnt == 'D')
			*cnt = 'E';

		cnt ++;
	}

	if (sscanf(buf, "%lf", number) != 1)
		return(0);

	return(1);
}

/*==========================================================================*/

int read_dem_float(FILE *file,			/* pointer to file handle */
						 float *number)		/* pointer to float variable */
{
	/**************************************************************************
	*
	*  function name:	read_dem_float()
	*
	*  description:
	*
	*		reads a single precision floating point number from the DEM file
	*
	*		reads E12.6 format (FORTRAN notation)
	*
	*  return value:
	*
	*		returns 1 if successful, 0 otherwise
	*
	**************************************************************************/

	char buf[40];
	char *cnt;

	if (fread(buf, sizeof(char), 12, file) != 12)
		return(0);

	buf[12] = '\0';

	cnt = buf;

	while (*cnt != '\0') {
		if (*cnt == 'D')
			*cnt = 'E';

		cnt ++;
	}

	if (sscanf(buf, "%f", number) != 1)
		return(0);

	return(1);
}

