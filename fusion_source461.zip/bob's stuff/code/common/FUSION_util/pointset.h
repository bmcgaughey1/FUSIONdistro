// pointset.h: interface for the CPointSet class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_POINTSET_H__7016B36C_32FC_4196_94F7_0D45CC7C22DC__INCLUDED_)
#define AFX_POINTSET_H__7016B36C_32FC_4196_94F7_0D45CC7C22DC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "spatialextent.h"

#define		PROXIMITY		1

typedef struct {
	bool Active;
	CString FileName;
	CSpatialExtentZ Extent;
	unsigned __int64 PointCount;
} DATAFILEINFO;

typedef struct {
	bool Active;
	CSpatialExtent Extent;
} AOI_FILTER;

typedef struct {
	bool Active;
	int ReturnsToKeep[15];
} RN_FILTER;

typedef struct {
	bool Active;
	int ClassesToKeep[255];
} CLASS_FILTER;

typedef struct {
	double X;
	double Y;
	float Elevation;
	unsigned int Row;
	unsigned int Col;
	unsigned char Class;
	unsigned char Return;
	unsigned char Status;
} PS_POINT_INFO;

class CPointSet  
{
public:
	__int64 RetrieveProximitySubset(PS_POINT_INFO* pts, __int64 maxpts, __int64 focalpt, double radius);
	bool Optimize(int IntendedUse);
	__int64 GetPointsInMemory();
	void UnloadPoints();
	bool HaveValidSet();
	__int64 PrecountPointsInSet(bool UseIndex = false);
	__int64 LoadPointsInSet(bool UseIndex = false);
	void IgnoreWithheldPoints();
	void IncludeWithheldPoints();
	void ResetFilters();
	void EnableClassFilter(int* classes, int numberofclasses);
	void EnableReturnNumberFilter(int r1 = 0, int r2 = 0, int r3 = 0, int r4 = 0, int r5 = 0, int r6 = 0, int r7 = 0, int r8 = 0, int r9 = 0, int r10 = 0, int r11 = 0, int r12 = 0, int r13 = 0, int r14 = 0, int r15 = 0);
	void EnableAOIFilter(double minx, double miny, double maxx, double maxy);
	bool	GetFileInfo(int index, DATAFILEINFO& info);
	__int64	GetOverallPointCount();
	bool	GetOverallExtent(CSpatialExtentZ& extent);
	int		GetFileCount();

	bool	CreateOverview();
	int		CountFilesMatchingSpec(LPCSTR FileSpec);
	int		ExpandFileSpecToList(LPCTSTR FileSpec);

	bool	IsValid();

	CPointSet();
	CPointSet(LPCTSTR FileSpec);
	virtual ~CPointSet();
	void Empty();

private:
	bool				m_Valid;
	bool				m_IgnoreWithheldPoints;
	int					m_FileCount;
	__int64				m_OverallPointCount;			// all points in all files...no filtering
	__int64				m_PointCount;				// number of points after filters are applied
	__int64				m_PointsInMemory;				// number of points in memory
	CSpatialExtentZ		m_OverallDataExtent;
	CSpatialExtentZ		m_Extent;
	CStringArray		m_FileList;
	CString				m_FileSpec;
	DATAFILEINFO*		m_FileInfoList;
	AOI_FILTER			m_AOI;
	RN_FILTER			m_RN;
	CLASS_FILTER		m_CLASS;
	PS_POINT_INFO*		m_Points;
};

#endif // !defined(AFX_POINTSET_H__7016B36C_32FC_4196_94F7_0D45CC7C22DC__INCLUDED_)
