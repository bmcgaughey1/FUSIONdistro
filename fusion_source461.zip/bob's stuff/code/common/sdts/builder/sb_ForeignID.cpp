//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//


// $Id: sb_ForeignID.cpp,v 1.5 1998/09/01 14:33:50 mcoletti Exp $

#include "builder/sb_ForeignID.h"

#include <strstream>

static const char* _ident = "$Id: sb_ForeignID.cpp,v 1.5 1998/09/01 14:33:50 mcoletti Exp $";


bool
sb_ForeignID::get( string& fid )
{
  if ( _moduleName.empty() || _recordID < 0 )
    {
      return false;
    }

  strstream tmp_ss;

                                // XXX Should add sanity check to see
                                // XXX that usage modifier is in the
                                // XXX proper domain if it actually has a
                                // XXX value.

  tmp_ss << _moduleName << "#" << _recordID << _usageModifier;

  getline( tmp_ss, fid );

  return true;
} // sb_ForeignID::



sb_ForeignID&
sb_ForeignID::operator=( sb_ForeignID const& rhs )
{
  if ( this == &rhs ) return *this;

  _moduleName    = rhs._moduleName;
  _recordID      = rhs._recordID;
  _usageModifier = rhs._usageModifier;

   return *this;
} // sb_ForeignID::operator=
