// CoordinateSystemInfoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "fusion.h"
#include "CoordinateSystemInfoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCoordinateSystemInfoDlg dialog


CCoordinateSystemInfoDlg::CCoordinateSystemInfoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCoordinateSystemInfoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCoordinateSystemInfoDlg)
	m_GPSProjection = -1;
	m_GPSZone = 0;
	m_GPSSpheroid = -1;
	m_GPSCoordUnits = -1;
	m_GPSElevationUnits = -1;
	//}}AFX_DATA_INIT
}


void CCoordinateSystemInfoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCoordinateSystemInfoDlg)
	DDX_CBIndex(pDX, IDC_INPUT_SYSTEM, m_GPSProjection);
	DDX_Text(pDX, IDC_INPUT_ZONE, m_GPSZone);
	DDX_CBIndex(pDX, IDC_INPUT_SPHEROID, m_GPSSpheroid);
	DDX_CBIndex(pDX, IDC_INPUT_UNIT, m_GPSCoordUnits);
	DDX_CBIndex(pDX, IDC_ELEVATION_UNITS, m_GPSElevationUnits);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCoordinateSystemInfoDlg, CDialog)
	//{{AFX_MSG_MAP(CCoordinateSystemInfoDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCoordinateSystemInfoDlg message handlers
