
#ifdef _MSC_VER
#include <iostream>
#include <fstream>
   using namespace std;
#else
#include <iostream.h>
#include <fstream.h>
#endif

// CCC change below
#define SB_ARC_TEST
#define SB_OBJECT_TEST

#include "build_test/t_sb_output.h"


// binary 32 bit integer converter function
sio_8211Converter_BI32  bi32_converter;


int
main( int argc, char** argv )
{
	// CCC change below
	sb_Arc *aSBobject;


	if ( ! argv[1] ) 
	{
		cerr << "usage: "
			<< argv[0] << " 8211file " << endl;
		return 1;
	}

#ifdef WIN32
ifstream ddf( argv[1], ios::binary );
#else
ifstream ddf( argv[1] );
#endif

	if ( ! ddf ) 
	{
		cerr << "couldn't open "
			<< argv[1] << endl;
		return 2;
	}

	map<string, sio_8211Converter*> converters;

	converters["X"] = &bi32_converter;
	converters["Y"] = &bi32_converter;

	
	sio_8211Reader  reader( ddf, &converters );

	sc_Record record;

	for( sio_8211ForwardIterator i( reader );
        	! i.done();
	        ++i )
	{
		i.get( record );
		// CCC change below
		aSBobject = new sb_Arc( record );

		cout << record << endl;
		cout << "\n***\n";
		dumpSbObject( *aSBobject );

	        delete aSBobject;
	}

	return 0;
}
