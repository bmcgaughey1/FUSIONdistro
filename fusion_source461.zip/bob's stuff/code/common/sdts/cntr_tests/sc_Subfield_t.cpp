//
// sc_Subfield_t.cpp
//
// $Id: sc_Subfield_t.cpp,v 1.2 1998/08/31 23:33:11 mcoletti Exp $
//
// TODO:
//
//   We should add checks for _all_ get*() and set*() members, not just a
//   sampling.
//

#include <cassert>

#ifdef HAVE_ISO_HEADERS
#include <iostream>
#else
#include <iostream>
#endif


#ifdef WIN32
using namespace std;
#endif


#include "container/sc_Subfield.h"


int
main( int argc, char** argv )
{

  cout << argv[0] << " ... " << flush;

  sc_Subfield sf;

  long          long_val;
  unsigned long ulong_val;
  string        string_val;

  // test initial state as being null

  assert( ! sf.getI( long_val ) );


  // test set and get

  sf.setI( 42 );

  assert( sf.getI( long_val ) );

  assert( 42 == long_val );


  // test pedantic get (i.e., trying to get a value of the wrong type

  assert( ! sf.getBUI8( ulong_val ) );


  // test setting to different type and getting a value of that type

  sf.setBUI8( 24 );

  assert( sf.getBUI8( ulong_val ) );

  assert( 24 == ulong_val );


  // string testing

  sf.setA( "FOO" );

  assert( sf.getA( string_val ) );

  assert( "FOO" == string_val );

  assert( ! sf.getBUI8( ulong_val ) );	// can't get long from string


  // copy ctor test

  {
    sc_Subfield local_sf( sf );
    string my_val;

    assert( local_sf.getA( my_val ) );

    assert( "FOO" == my_val );

    assert( ! local_sf.getBUI8( ulong_val ) );
  }


  // assignment operator test

  {
    sc_Subfield local_sf;
    string my_val;

    local_sf = sf;

    assert( local_sf.getA( my_val ) );

    assert( "FOO" == my_val );

    assert( ! local_sf.getBUI8( ulong_val ) );
  }


  // null reset test

  sf.setUnvalued();

  assert( ! sf.getA( string_val ) );


  // done!

  cout << "ok\n";

  exit( 0 );
}
