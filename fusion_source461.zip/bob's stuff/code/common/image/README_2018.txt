9/5/2018 Visual Studio 2017 migration

Image libraries for jpeg (IJG-V9c) and tiff () were built in folders under "Code from other people" and then
header files and libraries were moved to the code\common\image folder to provide a consistant point for 
linking to programs
