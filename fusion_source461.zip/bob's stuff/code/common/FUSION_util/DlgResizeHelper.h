////////////////////////////////////////////////////////////////////////
// CDlgResizeHelper
//	
// Author: Stephan Keil (Stephan.Keil@gmx.de)
// Date:   2000-06-26
//
// Helps you with keeping dialog layout on resizing.
// It automatically collects all child windows by calling Init() (you
// can also explicitly add other windows by calling Add()) and resizes
// them in OnResize(). Default resizing is proportional to the parent
// window but you can change that behaviour for some or all child windows
// by calling the various Fix() members.
// 
//
// 3/14/13 RJM
// added HCENTER to center control left to right

#ifndef CDlgResizeHelper_H_
#define CDlgResizeHelper_H_

#pragma warning (disable: 4786)
#include <list>

#define HNOFIX			CDlgResizeHelper::kNoHFix		// let size and position scale relative to the parent window
#define	HWIDTH			CDlgResizeHelper::kWidth		// fix the width, change the position
#define HLEFT			CDlgResizeHelper::kLeft			// fix the left edge, change the size
#define	HRIGHT			CDlgResizeHelper::kRight		// fix the right edge, change the size
#define HWIDTHLEFT		CDlgResizeHelper::kWidthLeft	// fix the left edge and keep the width
#define HWIDTHRIGHT		CDlgResizeHelper::kWidthRight	// fix the right edge and keep the width
#define HLEFTRIGHT		CDlgResizeHelper::kLeftRight	// fix the left and right edges, width doesn't change
#define HCENTER			CDlgResizeHelper::kCenter		// center the control left to right

#define VNOFIX			CDlgResizeHelper::kNoVFix
#define VHEIGHT			CDlgResizeHelper::kHeight
#define VTOP			CDlgResizeHelper::kTop
#define VBOTTOM			CDlgResizeHelper::kBottom
#define VHEIGHTTOP		CDlgResizeHelper::kHeightTop
#define VHEIGHTBOTTOM	CDlgResizeHelper::kHeightBottom
#define VTOPBOTTOM		CDlgResizeHelper::kTopBottom

class CDlgResizeHelper
{
public:
	void SetMinSize(POINT& MinSize);

  // fix horizontal dimension/position
  enum EHFix {
    kNoHFix     = 0,
    kWidth      = 1,
    kLeft       = 2,
    kRight      = 4,
    kWidthLeft  = 3,
    kWidthRight = 5,
    kLeftRight  = 6,
	kCenter		= 8
  };

  // fix vertical dimension/position
  enum EVFix {
    kNoVFix       = 0,
    kHeight       = 1,
    kTop          = 2,
    kBottom       = 4,
    kHeightTop    = 3,
    kHeightBottom = 5,
    kTopBottom    = 6
  };

  // initialize with parent window, all child windows must already have
  // their original position/size
  void Init(HWND a_hParent);

  // explicitly add a window to the list of child windows (e.g. a sibling window)
  // Note: you've got to call Init() before you can add a window
  void Add(HWND a_hWnd);

  // fix position/dimension for a child window, determine child by...
  // ...HWND...
  BOOL Fix(HWND a_hCtrl, EHFix a_hFix, EVFix a_vFix);
  // ...item ID (if it's a dialog item)...
  BOOL Fix(int a_itemId, EHFix a_hFix, EVFix a_vFix);
  // ...all child windows with a common class name (e.g. "Edit")
  UINT Fix(LPCTSTR a_pszClassName, EHFix a_hFix, EVFix a_vFix);
  // ...or all registered windows
  BOOL Fix(EHFix a_hFix, EVFix a_vFix);

  // resize child windows according to changes of parent window and fix attributes
  void OnSize();
private:
  struct CtrlSize {
    CRect m_origSize;
    HWND  m_hCtrl = NULL;
    EHFix  m_hFix;
    EVFix  m_vFix;
    CtrlSize() : m_hFix(kNoHFix), m_vFix(kNoVFix) {
    }
  };
  typedef std::list<CtrlSize> CtrlCont_t;
  CtrlCont_t m_ctrls;
  HWND       m_hParent;
  CRect      m_origParentSize;
};

#endif // CDlgResizeHelper_H_
