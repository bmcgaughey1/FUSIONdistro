typedef union {
  int  i_val;
  char c_val;
} YYSTYPE;
#define	NUMBER	258
#define	TYPE	259
#define	CHAR	260


extern YYSTYPE sio_8211_yylval;
