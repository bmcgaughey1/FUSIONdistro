// ColorRamp.cpp: implementation of the CColorRamp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ColorRamp.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CColorRamp::CColorRamp()
{
}

CColorRamp::~CColorRamp()
{

}

CColorRamp::CColorRamp(int ColorModel, int R1, int G1, int B1, int R2, int G2, int B2)
{
	CreateRamp(ColorModel, R1, G1, B1, R2, G2, B2);
}


void CColorRamp::SetEndpoints(double MinValue, double MaxValue)
{
	m_MinValue = MinValue;
	m_MaxValue = MaxValue;

	m_Range = MaxValue - MinValue;
}

COLORREF CColorRamp::GetColorForValue(double Value)
{
	double C1step, C2step, C3step;
	int R, G, B, H, S, V;
	unsigned int seed;
	ColorValue tColor;

	if (m_ColorModel == RGBColor) {
		C1step = (double) (m_StopColor.R - m_StartColor.R) / m_Range;
		C2step = (double) (m_StopColor.G - m_StartColor.G) / m_Range;
		C3step = (double) (m_StopColor.B - m_StartColor.B) / m_Range;

		R = (int) ((double) m_StartColor.R + (Value - m_MinValue) * C1step);
		G = (int) ((double) m_StartColor.G + (Value - m_MinValue) * C2step);
		B = (int) ((double) m_StartColor.B + (Value - m_MinValue) * C3step);
	}
	else if (m_ColorModel == HSVColor) {
		C1step = (double) (m_StopColor.H - m_StartColor.H) / m_Range;
		C2step = (double) (m_StopColor.S - m_StartColor.S) / m_Range;
		C3step = (double) (m_StopColor.V - m_StartColor.V) / m_Range;

		H = (int) ((double) m_StartColor.H + (Value - m_MinValue) * C1step) % 360;
		S = (int) ((double) m_StartColor.S + (Value - m_MinValue) * C2step);
		V = (int) ((double) m_StartColor.V + (Value - m_MinValue) * C3step);

		tColor.SetUsingHSV(H, S, V);
		R = tColor.R;
		G = tColor.G;
		B = tColor.B;
	}
	else {			// random color
		seed =  (unsigned int) ((Value - m_MinValue) / m_Range * 32767.0);
		srand(seed);

//		R = (int) (((double) rand() / (double) RAND_MAX) * (double) (m_StopColor.R - m_StartColor.R)) + m_StartColor.R;
//		G = (int) (((double) rand() / (double) RAND_MAX) * (double) (m_StopColor.G - m_StartColor.G)) + m_StartColor.G;
//		B = (int) (((double) rand() / (double) RAND_MAX) * (double) (m_StopColor.B - m_StartColor.B)) + m_StartColor.B;
//		B = (int) (((double) rand() / (double) RAND_MAX) * 128.0) + 63;

		H = (int) (((double) rand() / (double) RAND_MAX) * (double) (m_StopColor.H - m_StartColor.H)) + m_StartColor.H % 360;
		S = (int) (((double) rand() / (double) RAND_MAX) * (double) (m_StopColor.S - m_StartColor.S)) + m_StartColor.S;
		V = (int) (((double) rand() / (double) RAND_MAX) * (double) (m_StopColor.V - m_StartColor.V)) + m_StartColor.V;

		tColor.SetUsingHSV(H, S, V);
		R = tColor.R;
		G = tColor.G;
		B = tColor.B;
	}

	return(RGB(R, G, B));
}

void CColorRamp::CreateRamp(int ColorModel, int R1, int G1, int B1, int R2, int G2, int B2)
{
	// end color values are always specified using RGB color model
	SetColorModel(ColorModel);

	m_StartColor.SetUsingRGB(R1, G1, B1);
	m_StopColor.SetUsingRGB(R2, G2, B2);

	if (m_StopColor.H <= m_StartColor.H)
		m_StopColor.H += 360;
}
