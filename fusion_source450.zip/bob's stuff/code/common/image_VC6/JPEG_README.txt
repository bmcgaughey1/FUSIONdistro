To update the JPEG library there are 2 changes that need to be made in the IJG code:

in jconfig.h comment out the line that defines USE_WINDOWS_MESSAGEBOX...may not be defined. If defined, a windows
message box is used to display errors from the library. If not defined, error messages go to stdout.

in jmorecfg.h change the definitions of RGB_RED, RGB_GREEN, and RGB_BLUE as follows:
#define RGB_RED		2	/* Offset of Red in an RGB scanline element */
#define RGB_GREEN	1	/* Offset of Green */
#define RGB_BLUE	0	/* Offset of Blue */
