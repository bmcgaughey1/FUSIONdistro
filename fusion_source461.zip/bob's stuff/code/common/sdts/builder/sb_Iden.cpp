//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//

// $Id: sb_Iden.cpp,v 1.5 1998/08/27 15:49:04 mcoletti Exp $

#ifdef _WIN32
#pragma warning(disable: 4786)	// stupid warning that debug string exceeds 255
   #include <iostream>
#else
   #include <iostream.h>
#endif

#include <limits.h>

#include "builder/sb_Iden.h"


#ifndef INCLUDED_SB_UTILS_H
#include "builder/sb_Utils.h"
#endif


#ifdef NOT_IMPLEMENTED
#ifndef INCLUDED_SB_FOREIGNID_H
#include "builder/sb_ForeignID.h"
#endif
#endif

#ifndef INCLUDED_SC_RECORD_H
#include "container/sc_Record.h"
#endif


#ifndef INCLUDED_SIO_8211CONVERTER_H
#include "io/sio_8211Converter.h"
#endif


static const char* _iden = "$Id: sb_Iden.cpp,v 1.5 1998/08/27 15:49:04 mcoletti Exp $";


// Strings and integers are initialized with these values; they're used
// to indicate whether a given module value has been assigned a value or not.

// (XXX I arbitrarily chose 0x4 as the sentinal value.  I hate ad hoc crap.)

static const string  UNVALUED_STRING(1, static_cast<string::value_type>(0x4) );

static const long    UNVALUED_LONG   = INT_MIN;

static sio_8211Schema _iden_schema; // iden module schema, which will be
                                // defined by build_iden_schema

static sio_8211Converter_I converter_I; // XXX should define these in
static sio_8211Converter_A converter_A; // XXX sio_8211Converter.h


//
// builds a schema suitable for writing an SDTS IDEN module
//
void
_build_iden_schema( sio_8211Schema& schema )
{



  // IDENIFICATION field

  schema.push_back( sio_8211FieldFormat() );

  sio_8211FieldFormat& field_format = schema.back();

  field_format.setDataStructCode( sio_8211FieldFormat::vector );
  field_format.setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  field_format.setName( "IDENIFICATION" );
  field_format.setTag( "IDEN" );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "MODN" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "RCID" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "STID" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "STVS" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "DOCU" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "PRID" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "PRVS" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "PDOC" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "TITL" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "DAID" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "DAST" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "MPDT" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "DCDT" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "SCAL" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "COMT" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );
   


  // CONFORMANCE field

  schema.push_back( sio_8211FieldFormat() );

  schema.back().setDataStructCode( sio_8211FieldFormat::vector );
  schema.back().setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  schema.back().setName( "CONFORMANCE" );
  schema.back().setTag( "CONF" );

  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "FFYN" );
  schema.back().back().setType( sio_8211SubfieldFormat::A );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_A );

  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "VGYN" );
  schema.back().back().setType( sio_8211SubfieldFormat::A );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_A );

  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "GTYN" );
  schema.back().back().setType( sio_8211SubfieldFormat::A );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_A );

  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "RCYN" );
  schema.back().back().setType( sio_8211SubfieldFormat::A );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_A );

  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "EXSP" );
  schema.back().back().setType( sio_8211SubfieldFormat::I );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_I );

  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "FTLV" );
  schema.back().back().setType( sio_8211SubfieldFormat::I );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_I );

  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "CDLV" );
  schema.back().back().setType( sio_8211SubfieldFormat::I );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_I );

  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "NGDM" );
  schema.back().back().setType( sio_8211SubfieldFormat::A );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_A );


  // ATTRIBUTE ID field

  schema.push_back( sio_8211FieldFormat() );

  schema.back().setDataStructCode( sio_8211FieldFormat::array );
  schema.back().setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  schema.back().setName( "ATTRIBUTE ID" );
  schema.back().setTag( "ATID" );

  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "MODN" );
  schema.back().back().setType( sio_8211SubfieldFormat::A );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_A );

  schema.back().push_back( sio_8211SubfieldFormat() );

  schema.back().back().setLabel( "RCID" );
  schema.back().back().setType( sio_8211SubfieldFormat::I );
  schema.back().back().setFormat( sio_8211SubfieldFormat::variable );
  schema.back().back().setConverter( &converter_I );

} // build_iden_schema





struct sb_Iden_Imp
{
  string standardIden;
  string standardVer;
  string standardDocRef;
  string profileIden;
  string profileVer;
  string profileDocRef;
  string title;
  string dataID;
  string dataStruct;
  string mapDate;
  string dataSetCreationDate;
  long   scale;
  string comment;

  string composites;
  string vectorGeom;
  string vectorTopol;
  string raster;
  long   externSpatRef;
  long   featuresLevel;
  long   codingLevel;
  string nongeoDimension;


#ifdef NOT_IMPLEMENTED
  sb_ForeignID attrID;          // XXX need valued indicator here, too
#endif

  bool   bad;                   // true if in bad state

  sb_Iden_Imp() : 
    bad( false ),
    standardIden( UNVALUED_STRING ),
    standardVer( UNVALUED_STRING ),
    standardDocRef( UNVALUED_STRING ),
    profileIden( UNVALUED_STRING ),
    profileVer( UNVALUED_STRING ),
    profileDocRef( UNVALUED_STRING ),
    title( UNVALUED_STRING ),
    dataID( UNVALUED_STRING ),
    dataStruct( UNVALUED_STRING ),
    mapDate( UNVALUED_STRING ),
    dataSetCreationDate( UNVALUED_STRING ),
    scale( UNVALUED_LONG ),
    comment( UNVALUED_STRING ),
    composites( UNVALUED_STRING ),
    vectorGeom( UNVALUED_STRING ),
    vectorTopol( UNVALUED_STRING ),
    raster( UNVALUED_STRING ),
    externSpatRef( UNVALUED_LONG ),
    featuresLevel( UNVALUED_LONG ),
    codingLevel( UNVALUED_LONG ),
    nongeoDimension( UNVALUED_STRING )
    {}

}; // struct sb_Iden_Imp



sb_Iden::sb_Iden() : _imp( new sb_Iden_Imp )
{
  setMnemonic( "IDEN" );        // set reasonable module mnemonic and
  setID( 0 );                   // record id defaults
}



sb_Iden::~sb_Iden()
{
  delete _imp;
}


// populate an iden object from the given sc_Record that (hopefully)
// contains an IDEN module record
static
bool
_ingest_record( sb_Iden & iden, sb_Iden_Imp & iden_imp, sc_Record & record )
{

   // Make sure we have a record from a Idenification module.

   sc_FieldCntr::const_iterator curfield;

   if ( ! sb_Utils::getFieldByMnem( record, "IDEN", curfield) )
      {
#ifdef SDTSXX_DEBUG
         cerr << "sb_Iden::sb_Iden(sc_Record const&): Not a IDEN record.";
         cerr << endl;
#endif
         return false;
      }

   // We have a primary field from a Idenification module. Start picking 
   // it apart.

   sc_SubfieldCntr::const_iterator cursubfield;

   // MODN
   if (sb_Utils::getSubfieldByMnem(*curfield,"MODN",cursubfield))
     {
       string tmp;
      
       cursubfield->getA( tmp );
       iden.setMnemonic( tmp );
     }
      

   // RCID
   if (sb_Utils::getSubfieldByMnem(*curfield,"RCID",cursubfield))
     {
       long tmp;
       cursubfield->getI( tmp );
       iden.setID( tmp );
     }

   // STID
   if (sb_Utils::getSubfieldByMnem(*curfield,"STID",cursubfield))
      cursubfield->getA(iden_imp.standardIden);

   // STVS
   if (sb_Utils::getSubfieldByMnem(*curfield,"STVS",cursubfield))
      cursubfield->getA(iden_imp.standardVer);

   // DOCU
   if (sb_Utils::getSubfieldByMnem(*curfield,"DOCU",cursubfield))
      cursubfield->getA(iden_imp.standardDocRef);

   // PRID
   if (sb_Utils::getSubfieldByMnem(*curfield,"PRID",cursubfield))
      cursubfield->getA(iden_imp.profileIden);
 
   // PRVS
   if (sb_Utils::getSubfieldByMnem(*curfield,"PRVS",cursubfield))
      cursubfield->getA(iden_imp.profileVer);

   // PDOC
   if (sb_Utils::getSubfieldByMnem(*curfield,"PDOC",cursubfield))
      cursubfield->getA(iden_imp.profileDocRef);

   // TITL
   if (sb_Utils::getSubfieldByMnem(*curfield,"TITL",cursubfield))
      cursubfield->getA(iden_imp.title);

   // DAID
   if (sb_Utils::getSubfieldByMnem(*curfield,"DAID",cursubfield))
      cursubfield->getA(iden_imp.dataID);

   // DAST
   if (sb_Utils::getSubfieldByMnem(*curfield,"DAST",cursubfield))
      cursubfield->getA(iden_imp.dataStruct);

   // MPDT
   if (sb_Utils::getSubfieldByMnem(*curfield,"MPDT",cursubfield))
      cursubfield->getA(iden_imp.mapDate);

   // DCDT
   if (sb_Utils::getSubfieldByMnem(*curfield,"DCDT",cursubfield))
      cursubfield->getA(iden_imp.dataSetCreationDate);

   // SCAL
   if (sb_Utils::getSubfieldByMnem(*curfield,"SCAL",cursubfield))
      cursubfield->getI(iden_imp.scale);

   // COMT
   if (sb_Utils::getSubfieldByMnem(*curfield,"COMT",cursubfield))
      cursubfield->getA(iden_imp.comment);

   // Secondary Fields

   // Conformance (CONF) Field
   if (!sb_Utils::getFieldByMnem(record,"CONF",curfield))
      {
#ifdef SDTSXX_DEBUG
         cerr << "sb_Iden::sb_Iden(sc_Record const&): Not a Conformance "
              << "field to be found.";
         cerr << endl;
#endif
         return false;
      }

   // We have a secondary field from a Idenification module. Start picking 
   // it apart.

   // FFYN 
   if (sb_Utils::getSubfieldByMnem(*curfield,"FFYN",cursubfield))
      cursubfield->getA(iden_imp.composites);

   // VGYN
   if (sb_Utils::getSubfieldByMnem(*curfield,"VGYN",cursubfield))
      cursubfield->getA(iden_imp.vectorGeom);

   // GTYN
   if (sb_Utils::getSubfieldByMnem(*curfield,"GTYN",cursubfield))
      cursubfield->getA(iden_imp.vectorTopol);

   // RCYN
   if (sb_Utils::getSubfieldByMnem(*curfield,"RCYN",cursubfield))
      cursubfield->getA(iden_imp.raster);

   // EXSP
   if (sb_Utils::getSubfieldByMnem(*curfield,"EXSP",cursubfield))
      cursubfield->getI(iden_imp.externSpatRef);

   // FTLV
   if (sb_Utils::getSubfieldByMnem(*curfield,"FTLV",cursubfield))
      cursubfield->getI(iden_imp.featuresLevel);

   // CDLV - Coding level (I)
   if (sb_Utils::getSubfieldByMnem(*curfield,"CDLV",cursubfield))
      cursubfield->getI(iden_imp.codingLevel);

   // NGDM = nongeospatila deminsions (A)
   if (sb_Utils::getSubfieldByMnem(*curfield,"NGDM",cursubfield))
      cursubfield->getA(iden_imp.nongeoDimension);

#ifdef NOT_IMPLEMENTED
   // Attribute ID (ATID) Field
   if (sb_Utils::getFieldByMnem(record,"ATID",curfield))
      iden_imp.attrID = sb_ForeignID(*curfield);
#endif

   return true;

}; // _ingest_record



sb_Iden::sb_Iden( sc_Record& record )
  : _imp( new sb_Iden_Imp )
{
   // Build an sb_Iden from an sc_Record.
  if ( ! _ingest_record( *this, *_imp, record ) )
    {
      _imp->bad = true;
    }
} // sb_Iden ctor






bool
sb_Iden::getStandardIdentification( string& str ) const
{
  if (  _imp->standardIden == UNVALUED_STRING )
    return false;

  str =  _imp->standardIden;

  return true;
}


bool
sb_Iden::getStandardVersion( string& str ) const
{
  if (  _imp->standardVer == UNVALUED_STRING )
    return false;

  str =  _imp->standardVer;

  return true;
}


bool
sb_Iden::getStandardDocumentationReference( string& str ) const
{
  if (  _imp->standardDocRef == UNVALUED_STRING )
    return false;

  str =  _imp->standardDocRef;

  return true;
}


bool
sb_Iden::getProfileIdentification( string& str  ) const
{  
  if (  _imp->profileIden == UNVALUED_STRING )
    return false;

  str =  _imp->profileIden;

  return true;
}


bool
sb_Iden::getProfileVersion( string& str ) const
{
  if (  _imp->profileVer == UNVALUED_STRING )
    return false;

  str =  _imp->profileVer;

  return true;
}

 
bool
sb_Iden::getProfileDocumentationReference( string& str ) const
{
  if (  _imp->profileDocRef == UNVALUED_STRING )
    return false;

  str =  _imp->profileDocRef;

  return true;
}


bool
sb_Iden::getTitle( string& str ) const
{
  if (  _imp->title == UNVALUED_STRING )
    return false;

  str =  _imp->title;

  return true;
}


bool
sb_Iden::getDataID( string& str ) const
{
  if (  _imp->dataID == UNVALUED_STRING )
    return false;

  str =  _imp->dataID;

  return true;
}


bool
sb_Iden::getDataStructure( string& str ) const
{
  if (  _imp->dataStruct == UNVALUED_STRING )
    return false;

  str =  _imp->dataStruct;

  return true;
}


bool
sb_Iden::getMapDate( string& str ) const
{
  if (  _imp->mapDate == UNVALUED_STRING )
    return false;

  str =  _imp->mapDate;

  return true;
}


bool
sb_Iden::getDataSetCreationDate( string& str ) const
{
  if (  _imp->dataSetCreationDate == UNVALUED_STRING )
    return false;

  str =  _imp->dataSetCreationDate;

  return true;
}

 
bool
sb_Iden::getScale( long & num ) const
{
  if (  _imp->scale == UNVALUED_LONG )
    return false;

  num =  _imp->scale;

  return true;
}


bool
sb_Iden::getComment( string& str ) const
{
  if (  _imp->comment == UNVALUED_STRING )
    return false;

  str =  _imp->comment;

  return true;
}


bool
sb_Iden::getComposites( string& str ) const
{
  if (  _imp->composites == UNVALUED_STRING )
    return false;

  str =  _imp->composites;

  return true;
}


bool
sb_Iden::getVectorGeometry( string& str ) const
{
  if (  _imp->vectorGeom == UNVALUED_STRING )
    return false;

  str =  _imp->vectorGeom;

  return true;
}


bool
sb_Iden::getVectorTopology( string& str ) const
{
  if (  _imp->vectorTopol == UNVALUED_STRING )
    return false;

  str =  _imp->vectorTopol;

  return true;
}

 
bool
sb_Iden::getRaster( string& str ) const
{
  if (  _imp->raster == UNVALUED_STRING )
    return false;

  str =  _imp->raster;

  return true;
}


bool
sb_Iden::getExternalSpatialReference( long& num ) const
{
  if (  _imp->externSpatRef == UNVALUED_LONG )
    return false;

  num =  _imp->externSpatRef;

  return true;
}


bool
sb_Iden::getFeaturesLevel( long & num ) const
{
  if (  _imp->featuresLevel == UNVALUED_LONG )
    return false;

  num =  _imp->featuresLevel;

  return true;
}


bool
sb_Iden::getCodingLevel( long & num ) const
{
  if (  _imp->codingLevel == UNVALUED_LONG )
    return false;

  num =  _imp->codingLevel;

  return true;
}
      


bool
sb_Iden::getNonGeoSpatialDimensions( string& str ) const
{
  if (  _imp->nongeoDimension == UNVALUED_STRING )
    return false;

  str =  _imp->nongeoDimension;

  return true;
}
      

#ifdef NOT_IMPLEMENTED
bool
sb_Iden::getAttributeID( sb_ForeignID& fid ) const
{
  fid = _imp->attrID;           // XXX need to check for unset state
  return true;
}
#endif


bool
sb_Iden::getSchema( sio_8211Schema& schema ) const
{
                                // If the schema hasn't been
                                // initialized, please do so.

  if ( _iden_schema.empty() )
    {
      _build_iden_schema( _iden_schema );
    }

  if ( _iden_schema.empty() )   // oops ... something screwed up
    {
      return false;
    }

  schema = _iden_schema;

  return true;

} // sb_Iden::getSchema




bool
sb_Iden::getRecord( sc_Record& record ) const
{

  record.clear();               // start with a clean slate

  // IDEN field

  record.push_back( sc_Field() );

  record.back().setMnemonic( "IDEN" );

  string tmp_str;
  long   tmp_long;

  getMnemonic( tmp_str );
  sb_Utils::add_subfield( record.back(), "MODN", tmp_str );
  sb_Utils::add_subfield( record.back(), "RCID", getID() );

  // Add each field and subfield to the record.  Bail if a mandatory
  // subfield hasn't been set.

  if ( ! getStandardIdentification( tmp_str ) )
    {
      return false;
    }

  sb_Utils::add_subfield( record.back(), "STID", tmp_str );

  if ( ! getStandardVersion( tmp_str ) )
    {
      return false;
    }

  sb_Utils::add_subfield( record.back(), "STVS", tmp_str );


  if ( getDOCU( tmp_str ) )     // DOCU optional, so only add if set
    {
      sb_Utils::add_subfield( record.back(), "DOCU", tmp_str );
    }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "DOCU", sc_Subfield::is_A );
    }


  if ( ! getPRID( tmp_str ) )
    {
      return false;
    }

  sb_Utils::add_subfield( record.back(), "PRID", tmp_str );

  if ( ! getPRVS( tmp_str ) )
    {
      return false;
    }

  sb_Utils::add_subfield( record.back(), "PRVS", tmp_str );


  if ( getPDOC( tmp_str ) ) // optional subfield; add if have value
    {
      sb_Utils::add_subfield( record.back(), "PDOC", tmp_str );
    }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "PDOC", sc_Subfield::is_A );
    }


  if ( ! getTitle( tmp_str ) )
    {
      return false;
    }

  sb_Utils::add_subfield( record.back(), "TITL", tmp_str );

  if ( getDataID( tmp_str ) )
    {
      sb_Utils::add_subfield( record.back(), "DAID", tmp_str );
    }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "DAID", sc_Subfield::is_A );
    }



                                // The next five subfields are
                                // optional, so they'll only be set if
                                // they've got values.

  if ( getDataStructure( tmp_str ) )
    {
      sb_Utils::add_subfield( record.back(), "DAST", tmp_str );
    }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "DAST", sc_Subfield::is_A );
    }


  if ( getMapDate( tmp_str ) )
    {
      sb_Utils::add_subfield( record.back(), "MPDT", tmp_str );
    }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "MPDT", sc_Subfield::is_A );
    }


  if ( getDataSetCreationDate( tmp_str ) )
    {
      sb_Utils::add_subfield( record.back(), "DCDT", tmp_str );
    }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "DCDT", sc_Subfield::is_A );
    }


  if ( getScale( tmp_long ) )
    {
      sb_Utils::add_subfield( record.back(), "SCAL", tmp_long );
    }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "SCAL", sc_Subfield::is_I );
    }

  if ( getComment( tmp_str ) )
    {
      sb_Utils::add_subfield( record.back(), "COMT", tmp_str );
    }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "COMT", sc_Subfield::is_A );
    }


  // Conformance field



  record.push_back( sc_Field() );

  record.back().setMnemonic( "CONF" );
   

  if ( ! ( getComposites( tmp_str ) &&
           sb_Utils::valid_domain( tmp_str, "YN" ) ) )
    {
      return false;
    }

  sb_Utils::add_subfield( record.back(), "FFYN", tmp_str );

  if ( ! ( getVGYN( tmp_str ) &&
           sb_Utils::valid_domain( tmp_str, "YN" ) ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "VGYN", tmp_str );

  if ( ! ( getGTYN( tmp_str ) && 
           sb_Utils::valid_domain( tmp_str, "YN" ) ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "GTYN", tmp_str );

  if ( ! ( getRaster( tmp_str ) && sb_Utils::valid_domain( tmp_str, "YN" ) ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "RCYN", tmp_str );


  set<long> EXSP_domain;
  EXSP_domain.insert( 1 );
  EXSP_domain.insert( 2 );
  EXSP_domain.insert( 3 );

  // set.insert( NULL );  XXX What is the NULL value?

  if ( ! ( getEXSP( tmp_long ) &&
           sb_Utils::valid_domain( tmp_long, EXSP_domain ) ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "EXSP", tmp_long );

  set<long> FTLV_domain;
  FTLV_domain.insert( 1 );
  FTLV_domain.insert( 2 );
  FTLV_domain.insert( 3 );
  FTLV_domain.insert( 4 );

  // set.insert( NULL );  XXX What is the NULL value?


  if ( ! ( getFeaturesLevel( tmp_long ) &&
           sb_Utils::valid_domain( tmp_long, FTLV_domain ) ) )
    {
      return false;
    }
  sb_Utils::add_subfield( record.back(), "FTLV", tmp_long );


  if ( getCodingLevel( tmp_long ) ) // this subfield is optional
    {
      set<long> CDLV_domain;
      CDLV_domain.insert( 0 );
      CDLV_domain.insert( 1 );
      CDLV_domain.insert( 2 );
      
      if ( ! sb_Utils::valid_domain( tmp_long, CDLV_domain ) )
        {
          return false;
        }

      sb_Utils::add_subfield( record.back(), "CDLV", tmp_long );
    }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "CDLV", sc_Subfield::is_I );
    }

  if ( getNGDM( tmp_str ) )     // this subfield is optional
    {
      if ( ! sb_Utils::valid_domain( tmp_str, "YN" ) )
        {
          return false;
        }

      sb_Utils::add_subfield( record.back(), "NGDM", tmp_str );
    }
  else
    {
      sb_Utils::add_empty_subfield( record.back(), "NGDM", sc_Subfield::is_A );
    }

  return true;

} // sb_Iden::getRecord




void
sb_Iden::setStandardIdentification( string const & str )
{
  _imp->standardIden = str;
}


void
sb_Iden::setStandardVersion( string const & str )
{
  _imp->standardVer = str;
}


void
sb_Iden::setStandardDocumentationReference( string const & str )
{
  _imp->standardDocRef = str;
}



void
sb_Iden::setProfileIdentification( string const & str )
{
  _imp->profileIden = str;
}


void
sb_Iden::setProfileVersion( string const & str )
{
  _imp->profileVer = str;
}


void
sb_Iden::setProfileDocumentationReference( string const & str )
{
  _imp->profileDocRef = str;
}


void
sb_Iden::setTitle( string const & str )
{
  _imp->title = str;
}


void
sb_Iden::setDataID( string const & str )
{
  _imp->dataID = str;
}


void
sb_Iden::setDataStructure( string const & str )
{
  _imp->dataStruct = str;
}


void
sb_Iden::setMapDate( string const & str )
{
  _imp->mapDate = str;
}


void
sb_Iden::setDataSetCreationDate( string const & str )
{
  _imp->dataSetCreationDate = str;
}


void
sb_Iden::setScale( long val )
{
  _imp->scale = val;
}


void
sb_Iden::setComment( string const & str )
{
  _imp->comment = str;
}



void
sb_Iden::setComposites( string const & str )
{
  _imp->composites = str;
}


void
sb_Iden::setVectorGeometry( string const & str )
{
  _imp->vectorGeom = str;
}


void
sb_Iden::setVectorTopology( string const & str )
{
  _imp->vectorTopol = str;
}


void
sb_Iden::setRaster( string const & str )
{
  _imp->raster = str;
}


void
sb_Iden::setExternalSpatialReference( long val )
{
  _imp->externSpatRef = val;
}


void
sb_Iden::setFeaturesLevel( long val )
{
  _imp->featuresLevel = val;
}


void
sb_Iden::setCodingLevel( long val )
{
  _imp->codingLevel = val;
}


void
sb_Iden::setNonGeoSpatialDimensions( string const & str )
{
  _imp->nongeoDimension = str;
}


      
#ifdef NOT_IMPLEMENTED
void
sb_Iden::setAttributeID( sb_ForeignID const & fid )
{
  _imp->attrID = fid;
}
#endif



