// Trajectory.h: interface for the CTrajectory class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRAJECTORY_H__984FCF56_374B_4065_9459_2109CFC106E8__INCLUDED_)
#define AFX_TRAJECTORY_H__984FCF56_374B_4065_9459_2109CFC106E8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "LPPTrajectoryFile.h"

#define		LPP			1
#define		SBET1		2		// Colville DNR (lat/long 19 fields)
#define		SBET2		3		// Colville USFS (state plane 7 fields)
#define		BINARYSRS	4		// binary 17 fields...lat/long

typedef struct {
	int GPSWeek;
	double GPSTime;
	double Latitude;
	double Longitude;
	double EllipsoidHeight;
	double Roll;
	double Pitch;
	double Heading;
} TRAJ_POSITION;

class CTrajectory  
{
public:
	void SortTrajectory();
	BOOL ScanForPositionRange();
	BOOL InterpolatePosition(TRAJ_POSITION& Position, int GPSWeek, double GPSTime, int StartFromBeginning = 0);
	long GetPositionCount();
	void Close();
	BOOL LoadTrajectory(LPCTSTR FileName, int Format = 1, BOOL Append = 0, BOOL DoSort = 1);
	BOOL IsValid();
	CTrajectory();
	CTrajectory(LPCTSTR FileName, int Format = LPP);
	virtual ~CTrajectory();
	TRAJ_POSITION* m_Positions;
	TRAJ_POSITION m_MaxPosition;
	TRAJ_POSITION m_MinPosition;

private:
	long m_NumberOfPositions;
	long m_CurrentPosition;
	int m_Format;
	BOOL m_Valid;
};

#endif // !defined(AFX_TRAJECTORY_H__984FCF56_374B_4065_9459_2109CFC106E8__INCLUDED_)
