//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FolderDlg.rc
//
#define IDD_FOLDERDLG_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_TXT_ROOT                    1000
#define IDC_CMD_BRWS_ROOT               1001
#define IDC_CMD_DEL_ROOT                1002
#define IDC_LNK                         1003
#define IDC_TXT_PATH                    1004
#define IDC_CMD_BRWS_PATH               1005
#define IDC_CMD_DEL_PATH                1006
#define IDC_TXT_DISPNAME                1007
#define IDC_ITEMICON                    1008
#define IDC_CHK_FILTER                  1009
#define IDC_TXT_FILTER                  1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
