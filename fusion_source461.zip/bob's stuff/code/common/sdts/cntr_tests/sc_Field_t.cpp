//
// sc_Field_t.cpp
//
// $Id: sc_Field_t.cpp,v 1.3 1998/09/01 22:38:47 mcoletti Exp $
//
// TODO:
//
//   We should add checks for _all_ get*() and set*() members, not just a
//   sampling.
//

#include <cassert>

#ifdef HAVE_ISO_HEADERS
#include <iostream>
#else
#include <iostream>
#endif


#ifdef WIN32
using namespace std;
#endif


#include "container/sc_Field.h"


int
main( int argc, char** argv )
{

  cout << argv[0] << " ... " << flush;

  sc_Field f;

  unsigned long ulong_val;
  string        string_val;


				// name and mnemonic should start out null

  assert( "" == f.getName() );
  assert( "" == f.getMnemonic() );

  f.setName( "Blah blah" );
  f.setMnemonic( "FOO" );

  assert( "Blah blah" == f.getName() );
  assert( "FOO" == f.getMnemonic() );

  assert( f.empty() );		// also should start out with no subfields


				// insert a subfield and insure it behaves ok

  f.push_back( sc_Subfield() );

  assert( ! f.empty() );


  f.back().setA( "BAZ" );

  assert( f.back().getA( string_val ) );

  assert( "BAZ" == string_val );



  // copy ctor test

  {
    sc_Field local_f( f );
    string my_val;

    assert( local_f.back().getA( my_val ) );

    assert( "BAZ" == my_val );

    assert( ! local_f.back().getBUI8( ulong_val ) );
  }


  // assignment operator test

  {
    sc_Field local_f;
    string my_val;

    local_f = f;

    assert( local_f.back().getA( my_val ) );

    assert( "BAZ" == my_val );

    assert( ! local_f.back().getBUI8( ulong_val ) );
  }


  // null reset test

  f.back().setUnvalued();

  assert( ! f.back().getA( string_val ) );


  f.clear();

  assert( f.empty() );


  // done!

  cout << "ok\n";

  exit( 0 );
}
