// DBASEFile.cpp: implementation of the CDBASEFile class.
//
//	10/23/2018 fixed problem in FillListCtrlWithFieldNames() where fieldname was 1 character too short. char fieldname[11] did not leave room for terminating null character
//	so I changed it to char fieldname[12];
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "envision.h"
#include "DBASEFile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define XBASE_FLDHDR_SZ       32

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDBASEFile::CDBASEFile()
{
	m_Valid = FALSE;
	bUpdated = FALSE;
	bNoHeader = FALSE;

	panFieldOffset = NULL;
	panFieldSize = NULL;
	panFieldDecimals = NULL;
	pachFieldType = NULL;
	pszCurrentRecord = NULL;
	pszHeader = NULL;
	pszFieldBuffer = NULL;
}

CDBASEFile::CDBASEFile(LPCTSTR szFileName)
{
	m_Valid = FALSE;
	bUpdated = FALSE;
	bNoHeader = FALSE;

	panFieldOffset = NULL;
	panFieldSize = NULL;
	panFieldDecimals = NULL;
	pachFieldType = NULL;
	pszCurrentRecord = NULL;
	pszHeader = NULL;
	pszFieldBuffer = NULL;

	Open(szFileName);
}

CDBASEFile::~CDBASEFile()
{
	Close();
}

BOOL CDBASEFile::IsValid()
{
	return(m_Valid);
}

BOOL CDBASEFile::Open(LPCTSTR szFileName, BOOL WriteCapability)
{
	if (m_Valid)
		Close();

	// open file
	if (WriteCapability)
		fp = fopen(szFileName, "rb+");
	else
		fp = fopen(szFileName, "rb");

	if (fp) {
		bNoHeader = FALSE;
		bUpdated = FALSE;
		nCurrentRecord = -1;
		bCurrentRecordModified = FALSE;

		// read header info
		unsigned char* pabyBuf;
		pabyBuf = new unsigned char[500];
		fread(pabyBuf, 32, 1, fp);

		nRecords = pabyBuf[4] + pabyBuf[5] * 256 + pabyBuf[6] * 256 * 256 + pabyBuf[7] * 256 * 256 * 256;

		nHeaderLength = pabyBuf[8] + pabyBuf[9] * 256;
		nRecordLength = pabyBuf[10] + pabyBuf[11] * 256;
    
		nFields = (nHeaderLength - 32) / 32;

		// set up space for full record
		pszCurrentRecord = (char*) malloc(nRecordLength);
		delete[] pabyBuf;

		// read the field definitions
		pszHeader = (char*) malloc(nHeaderLength);

		fseek(fp, 32, SEEK_SET);
		fread(pszHeader, nHeaderLength, 1, fp);

		panFieldOffset = (int *) malloc(sizeof(int) * nFields);
		panFieldSize = (int *) malloc(sizeof(int) * nFields);
		panFieldDecimals = (int *) malloc(sizeof(int) * nFields);
		pachFieldType = (char *) malloc(nFields);

		unsigned char* pabyFInfo;
		int MaxFieldSize = 0;
		for (int iField = 0; iField < nFields; iField++) {
			pabyFInfo = (unsigned char*) pszHeader + iField * 32;

			if (pabyFInfo[11] == 'N' || pabyFInfo[11] == 'F') {
				panFieldSize[iField] = pabyFInfo[16];
				panFieldDecimals[iField] = pabyFInfo[17];
			}
			else {
				panFieldSize[iField] = pabyFInfo[16] + pabyFInfo[17]*256;
				panFieldDecimals[iField] = 0;
			}

			MaxFieldSize = max(MaxFieldSize, panFieldSize[iField]);

			pachFieldType[iField] = (char) pabyFInfo[11];
			if (iField == 0)
				panFieldOffset[iField] = 1;
			else
				panFieldOffset[iField] = panFieldOffset[iField - 1] + panFieldSize[iField - 1];
		}

		// create a field buffer big enough for the largest field
		pszFieldBuffer = (char *) malloc(MaxFieldSize * 2 + 10);

		m_Valid = TRUE;
	}

	return(m_Valid);
}

void CDBASEFile::Close()
{
	if (m_Valid) {
		// Write out header if not already written
		if (bNoHeader)
			WriteHeader();

		FlushRecord();

		// Update last access date, and number of records if we have
		// write access
		if (bUpdated) {
			unsigned char		abyFileHeader[XBASE_FLDHDR_SZ];

			fseek(fp, 0, 0);
			fread(abyFileHeader, 32, 1, fp);

			abyFileHeader[1] = 2;			/* YY */
			abyFileHeader[2] = 10;			/* MM */
			abyFileHeader[3] = 31;			/* DD */

			abyFileHeader[4] = nRecords % 256;
			abyFileHeader[5] = (nRecords / 256) % 256;
			abyFileHeader[6] = (nRecords / (256 * 256)) % 256;
			abyFileHeader[7] = (nRecords / (256 * 256 * 256)) % 256;

			fseek(fp, 0, 0);
			fwrite(abyFileHeader, 32, 1, fp);
		}

		fclose(fp);

		if(panFieldOffset != NULL) {
			free(panFieldOffset);
			free(panFieldSize);
			free(panFieldDecimals);
			free(pachFieldType);
		}
		free(pszHeader);
		free(pszCurrentRecord);
		free(pszFieldBuffer);

		panFieldOffset = NULL;
		panFieldSize = NULL;
		panFieldDecimals = NULL;
		pachFieldType = NULL;
		pszCurrentRecord = NULL;
		pszHeader = NULL;
		pszFieldBuffer = NULL;

		m_Valid = FALSE;
	}
}

int CDBASEFile::GetFieldCount()
{
	if (m_Valid)
		return(nFields);
	else
		return(0);
}

int CDBASEFile::GetRecordCount()
{
	if (m_Valid)
		return(nRecords);
	else
		return(0);
}

int CDBASEFile::GetFieldInfo(int iField, char *pszFieldName, int *pnWidth, int *pnDecimals)
{
	if (m_Valid) {
		if (iField < 0 || iField >= nFields)
			return(-1);

		if (pnWidth != NULL)
			*pnWidth = panFieldSize[iField];

		if (pnDecimals != NULL)
			*pnDecimals = panFieldDecimals[iField];

		if (pszFieldName != NULL) {
			strncpy(pszFieldName, pszHeader + iField * 32, 11);
			pszFieldName[11] = '\0';
			for (int i = 10; i > 0 && pszFieldName[i] == ' '; i --)
				pszFieldName[i] = '\0';
		}

		if (pachFieldType[iField] == 'N' || pachFieldType[iField] == 'D' || pachFieldType[iField] == 'F') {
			if (panFieldDecimals[iField] > 0)
				return(FTDouble);
			else
				return(FTInteger);
		}
		else {
			return(FTString);
		}
	}
	
	return(-1);
}

BOOL CDBASEFile::ReadIntegerAttribute(int iRecord, int iField, int& Value)
{
    double	*pdValue;

    pdValue = (double *) ReadAttribute(iRecord, iField);

	if (pdValue) {
		Value = (int) *pdValue;
		return(TRUE);
	}
	return(FALSE);
}

BOOL CDBASEFile::ReadDoubleAttribute(int iRecord, int iField, double& Value)
{
    double	*pdValue;

    pdValue = (double *) ReadAttribute(iRecord, iField);

	if (pdValue) {
		Value = *pdValue;
		return(TRUE);
	}
	return(FALSE);
}

BOOL CDBASEFile::ReadAsStringAttribute(int iRecord, int iField, CString &Value)
{
	BOOL retcode = FALSE;

	// read field value into string...regardless of field type
    if (pachFieldType[iField] == 'N' || pachFieldType[iField] == 'D' || pachFieldType[iField] == 'F') {
	    double* pdValue = (double *) ReadAttribute(iRecord, iField);
		char buffer[50];
		_gcvt(*pdValue, panFieldSize[iField] + 2, buffer);
   		Value = _T(buffer);
		Value.TrimLeft();
		Value.TrimRight();

		// check for trailing decimal point
		if (Value.Right(1) == ".")
			Value.TrimRight(".");

		retcode = TRUE;
	}
	else {
		char* pszValue = (char*)  ReadAttribute(iRecord, iField);
	
		if (pszValue) {
			Value = _T(pszValue);
			Value.TrimLeft();
			Value.TrimRight();
	
			retcode = TRUE;
		}
	}

	return(retcode);
}

BOOL CDBASEFile::ReadStringAttribute(int iRecord, int iField, CString &Value)
{
	char* pszValue;

	pszValue = (char*)  ReadAttribute(iRecord, iField);
	
	if (pszValue) {
		Value = _T(pszValue);
		Value.TrimLeft();
		Value.TrimRight();
		return(TRUE);
	}
	return(FALSE);
}

void* CDBASEFile::ReadAttribute(int iRecord, int iField)
{
    int	     nRecordOffset;
    unsigned char	*pabyRec;
    void	*pReturnField = NULL;

    static double dDoubleField;

	// see if we have read the record
    if (iRecord < 0 || iRecord >= nRecords)
        return(NULL);

	// see if requested record is current record
    if (nCurrentRecord != iRecord) {
		nRecordOffset = nRecordLength * iRecord + nHeaderLength;

		fseek(fp, nRecordOffset, 0 );
		fread(pszCurrentRecord, nRecordLength, 1, fp);

		nCurrentRecord = iRecord;
    }

    pabyRec = (unsigned char *) pszCurrentRecord;

	// Extract the requested field
    strncpy(pszFieldBuffer, (const char*) (pabyRec + panFieldOffset[iField]), panFieldSize[iField]);
    pszFieldBuffer[panFieldSize[iField]] = '\0';

    pReturnField = pszFieldBuffer;

	// Decode the field
    if (pachFieldType[iField] == 'N' || pachFieldType[iField] == 'D' || pachFieldType[iField] == 'F') {
////		if (panFieldDecimals[iField] == 0) {
////			dDoubleField = atoi(pszFieldBuffer);
////		}
////		else {
//			sscanf(pszFieldBuffer, "%le", &dDoubleField);
////		}
		dDoubleField = atof(pszFieldBuffer);

		pReturnField = &dDoubleField;
    }
    
    return(pReturnField);
}

BOOL CDBASEFile::FillListCtrlWithFieldNames(CComboBox *list, int SelectedField)
{
	list->ResetContent();
	if (m_Valid) {
		char fieldname[12];
		for (int i = 0; i < GetFieldCount(); i ++) {
			GetFieldInfo(i, fieldname);
			list->AddString(fieldname);
		}
		list->SetCurSel(SelectedField);

		return(TRUE);
	}
	return(FALSE);
}

void CDBASEFile::GoToFirstRecord()
{
	nCurrentRecord = -1;
}

void CDBASEFile::WriteHeader()
{
    unsigned char	abyHeader[XBASE_FLDHDR_SZ];

    if(!bNoHeader)
        return;

    bNoHeader = FALSE;

	// Initialize the file header information.
    for(int i = 0; i < XBASE_FLDHDR_SZ; i++)
        abyHeader[i] = 0;

    abyHeader[0] = 0x03;		// memo field? - just copying

    // date updated on close, record count preset at zero

    abyHeader[8] = nHeaderLength % 256;
    abyHeader[9] = nHeaderLength / 256;
    
    abyHeader[10] = nRecordLength % 256;
    abyHeader[11] = nRecordLength / 256;

	// Write the initial 32 byte file header, and all the field
	// descriptions.
    fseek(fp, 0, 0);
    fwrite(abyHeader, XBASE_FLDHDR_SZ, 1, fp);
    fwrite(pszHeader, XBASE_FLDHDR_SZ, nFields, fp);

	// Write out the newline character if there is room for it
    if (nHeaderLength > 32 * nFields + 32) {
        char	cNewline;

        cNewline = 0x0d;
        fwrite(&cNewline, 1, 1, fp);
    }
}

void CDBASEFile::FlushRecord()
{
    int		nRecordOffset;

    if (bCurrentRecordModified && nCurrentRecord > -1) {
		bCurrentRecordModified = FALSE;

		nRecordOffset = nRecordLength * nCurrentRecord + nHeaderLength;

		fseek(fp, nRecordOffset, 0);
		fwrite(pszCurrentRecord, nRecordLength, 1, fp);
    }
}

BOOL CDBASEFile::Create(LPCTSTR szFileName)
{
	// Create the file
    FILE* f = fopen( szFileName, "wb" );
    if (!f)
        return(FALSE);

    fputc(0, f);
    fclose(f);

    f = fopen( szFileName, "rb+" );
    if (!f)
        return(FALSE);

	// Create the info structure
    fp = f;
    nRecords = 0;
    nFields = 0;
    nRecordLength = 1;
    nHeaderLength = 33;
    
    panFieldOffset = NULL;
    panFieldSize = NULL;
    panFieldDecimals = NULL;
    pachFieldType = NULL;
    pszHeader = NULL;

    nCurrentRecord = -1;
    bCurrentRecordModified = FALSE;
    pszCurrentRecord = NULL;

    bNoHeader = TRUE;
	m_Valid = TRUE;

    return(TRUE);
}

int CDBASEFile::AddField(const char *pszFieldName, int eType, int nWidth, int nDecimals)
{
    char	*pszFInfo;
    int		i;

	// Do some checking to ensure we can add records to this file
    if (nRecords > 0)
		return(-1);

    if (!bNoHeader)
        return(-1);

    if (eType != FTDouble && nDecimals != 0)
        return(-1);

	// ReallocateSpace all the arrays larger to hold the additional field
	// information
    nFields++;

    panFieldOffset = (int *) ReallocateSpace(panFieldOffset, sizeof(int) * nFields);

    panFieldSize = (int *) ReallocateSpace(panFieldSize, sizeof(int) * nFields);

    panFieldDecimals = (int *) ReallocateSpace(panFieldDecimals, sizeof(int) * nFields);

    pachFieldType = (char *) ReallocateSpace(pachFieldType, sizeof(char) * nFields);

	// Assign the new field information fields
    panFieldOffset[nFields - 1] = nRecordLength;
    nRecordLength += nWidth;
    panFieldSize[nFields - 1] = nWidth;
    panFieldDecimals[nFields - 1] = nDecimals;

    if (eType == FTString)
        pachFieldType[nFields - 1] = 'C';
    else
        pachFieldType[nFields - 1] = 'N';

	// Extend the required header information
    nHeaderLength += 32;
    bUpdated = FALSE;

    pszHeader = (char *) ReallocateSpace(pszHeader, nFields * 32);

    pszFInfo = pszHeader + 32 * (nFields - 1);

    for (i = 0; i < 32; i++)
        pszFInfo[i] = '\0';

    if ((int) strlen(pszFieldName) < 10)
        strncpy(pszFInfo, pszFieldName, strlen(pszFieldName));
    else
        strncpy(pszFInfo, pszFieldName, 10);

    pszFInfo[11] = pachFieldType[nFields - 1];

    if (eType == FTString) {
        pszFInfo[16] = nWidth % 256;
        pszFInfo[17] = nWidth / 256;
    }
    else {
        pszFInfo[16] = nWidth;
        pszFInfo[17] = nDecimals;
    }
    
	// Make the current record buffer appropriately larger
    pszCurrentRecord = (char *) ReallocateSpace(pszCurrentRecord, nRecordLength);

    return(nFields - 1);
}

int CDBASEFile::WriteAttribute(int hEntity, int iField, void *pValue)
{
    int	       	nRecordOffset, i, j;
    unsigned char	*pabyRec;
    char	szSField[400], szFormat[20];

	// Is this a valid record>
    if (hEntity < 0 || hEntity > nRecords)
        return(FALSE);

    if (bNoHeader)
        WriteHeader();

	// Is this a brand new record?
    if (hEntity == nRecords) {
		FlushRecord();

		nRecords++;
		for (i = 0; i < nRecordLength; i++)
		    pszCurrentRecord[i] = ' ';

		nCurrentRecord = hEntity;
    }

	// Is this an existing record, but different than the last one
	// we accessed?
    if (nCurrentRecord != hEntity) {
		FlushRecord();

		nRecordOffset = nRecordLength * hEntity + nHeaderLength;

		fseek(fp, nRecordOffset, 0);
		fread(pszCurrentRecord, nRecordLength, 1, fp);

		nCurrentRecord = hEntity;
    }

    pabyRec = (unsigned char *) pszCurrentRecord;

    bCurrentRecordModified = TRUE;
    bUpdated = TRUE;

	// Translate NULL value to valid DBF file representation
    if (pValue == NULL) {
        switch (pachFieldType[iField]) {
        case 'N':
        case 'F':
			// NULL numeric fields have value "****************"
            memset((char *) (pabyRec + panFieldOffset[iField]), '*', panFieldSize[iField]);
            break;

        case 'D':
			// NULL date fields have value "00000000"
            memset((char *) (pabyRec + panFieldOffset[iField]), '0', panFieldSize[iField]);
            break;

        case 'L':
			// NULL boolean fields have value "?"
            memset((char *) (pabyRec + panFieldOffset[iField]), '?', panFieldSize[iField]);
            break;

        default:
            // empty string fields are considered NULL
            memset((char *) (pabyRec + panFieldOffset[iField]), '\0', panFieldSize[iField]);
            break;
        }
        return(TRUE);
    }

	// Assign all the record fields
    switch(pachFieldType[iField]) {
	case 'D':
	case 'N':
	case 'F':
		if (panFieldDecimals[iField] == 0) {
            int		nWidth = panFieldSize[iField];

            if (sizeof(szSField) - 2 < nWidth)
                nWidth = sizeof(szSField) - 2;

			sprintf(szFormat, "%%%dd", nWidth);
			sprintf(szSField, szFormat, (int) *((double *) pValue));
			if ((int)strlen(szSField) > panFieldSize[iField])
				szSField[panFieldSize[iField]] = '\0';

			strncpy((char *) (pabyRec + panFieldOffset[iField]), szSField, strlen(szSField));
		}
		else {
            int		nWidth = panFieldSize[iField];

            if (sizeof(szSField) - 2 < nWidth)
                nWidth = sizeof(szSField) - 2;

			sprintf( szFormat, "%%%d.%df", nWidth, panFieldDecimals[iField]);
			sprintf(szSField, szFormat, *((double *) pValue));
			if ((int) strlen(szSField) > panFieldSize[iField])
				szSField[panFieldSize[iField]] = '\0';
			strncpy((char *) (pabyRec + panFieldOffset[iField]), szSField, strlen(szSField));
		}
		break;

	default:
		if ((int) strlen((char *) pValue) > panFieldSize[iField])
			j = panFieldSize[iField];
		else {
            memset(pabyRec + panFieldOffset[iField], ' ', panFieldSize[iField]);
		    j = (int) strlen((char *) pValue);
        }

		strncpy((char *) (pabyRec + panFieldOffset[iField]), (char *) pValue, j );
		break;
    }

    return(TRUE);
}

BOOL CDBASEFile::WriteDoubleAttribute(int iRecord, int iField, double dValue)
{
	return(WriteAttribute(iRecord, iField, (void *) &dValue));
}

BOOL CDBASEFile::WriteIntegerAttribute(int iRecord, int iField, int nValue)
{
	double	dValue = nValue;

	return(WriteAttribute(iRecord, iField, (void *) &dValue));
}

BOOL CDBASEFile::WriteStringAttribute(int iRecord, int iField, const char *pszValue)
{
    return(WriteAttribute(iRecord, iField, (void *) pszValue));
}

BOOL CDBASEFile::WriteNULLAttribute(int iRecord, int iField)
{
	return(WriteAttribute(iRecord, iField, NULL));
}

void* CDBASEFile::ReallocateSpace(void *pMem, int nNewSize)
{
    if (!pMem)
        return((void *) malloc(nNewSize));
    else
        return((void *) realloc(pMem, nNewSize));
}
