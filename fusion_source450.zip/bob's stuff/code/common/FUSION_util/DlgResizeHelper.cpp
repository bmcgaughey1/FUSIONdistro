#include "stdafx.h"
#include "DlgResizeHelper.h"

void CDlgResizeHelper::Init(HWND a_hParent) {
  m_hParent = a_hParent;
  m_ctrls.clear();
  if (::IsWindow(m_hParent)) {

    // keep original parent size
    ::GetWindowRect(m_hParent, m_origParentSize);

    // get all child windows and store their original sizes and positions
    HWND hCtrl = ::GetWindow(m_hParent, GW_CHILD);
    while (hCtrl) {
      CtrlSize cs;
      cs.m_hCtrl = hCtrl;
      ::GetWindowRect(hCtrl, cs.m_origSize);
      ::ScreenToClient(m_hParent, &cs.m_origSize.TopLeft());
      ::ScreenToClient(m_hParent, &cs.m_origSize.BottomRight());
      m_ctrls.push_back(cs);

      hCtrl = ::GetNextWindow(hCtrl, GW_HWNDNEXT);
    }
  }
}

void CDlgResizeHelper::Add(HWND a_hWnd) {
  if (m_hParent && a_hWnd) {
    CtrlSize cs;
    cs.m_hCtrl = a_hWnd;
    ::GetWindowRect(a_hWnd, cs.m_origSize);
    ::ScreenToClient(m_hParent, &cs.m_origSize.TopLeft());
    ::ScreenToClient(m_hParent, &cs.m_origSize.BottomRight());
    m_ctrls.push_back(cs);
  }
}

void CDlgResizeHelper::OnSize() {
  if (::IsWindow(m_hParent)) {
    CRect currParentSize;
    ::GetWindowRect(m_hParent, currParentSize);

    double xRatio = (double) currParentSize.Width() / (double) m_origParentSize.Width();
    double yRatio = (double) currParentSize.Height() / (double) m_origParentSize.Height();

    // resize child windows according to their fix attributes
    CtrlCont_t::const_iterator it;
	CRect currCtrlSize;
    for (it=m_ctrls.begin(); it!=m_ctrls.end(); ++it) {
      EHFix hFix = it->m_hFix;
      EVFix vFix = it->m_vFix;

	  // changed size calculations so fixed right side uses the correct left side...
	  // if right side is fixed, calculate left side based on right side location
      if (hFix & kLeft) {
        currCtrlSize.left = it->m_origSize.left;
      } else {
		  if ((hFix & kWidth) && (hFix & kRight)) {
			currCtrlSize.left = it->m_origSize.left + currParentSize.Width() - m_origParentSize.Width();
		  }
		  else if (hFix & kRight) {
			  currCtrlSize.left = (LONG) ((it->m_origSize.right + currParentSize.Width() - m_origParentSize.Width()) - (it->m_origSize.Width() * xRatio));
		  }
		  else {
			currCtrlSize.left = (LONG) (it->m_origSize.left * xRatio);
		  }
      }

      if (hFix & kRight) {
        currCtrlSize.right = it->m_origSize.right + currParentSize.Width() - m_origParentSize.Width();
      } else {
		  if (hFix & kWidth) {
			  currCtrlSize.right = currCtrlSize.left + it->m_origSize.Width();
		  }
		  else {
			  currCtrlSize.right = currCtrlSize.left + (LONG) (it->m_origSize.Width() * xRatio);
		  }
      }

	  if (hFix & kCenter) {
		  currCtrlSize.left = currParentSize.Width() / 2 - it->m_origSize.Width() / 2;
		  currCtrlSize.right = currParentSize.Width() / 2 + it->m_origSize.Width() / 2;
	  }

      if (vFix & kTop) {
        currCtrlSize.top = it->m_origSize.top;
      } else {
        currCtrlSize.top = ((vFix & kHeight) && (vFix & kBottom)) ? (it->m_origSize.top + currParentSize.Height() - m_origParentSize.Height()) : ((LONG) (it->m_origSize.top * yRatio));
      }
      if (vFix & kBottom) {
        currCtrlSize.bottom = it->m_origSize.bottom + currParentSize.Height() - m_origParentSize.Height();
      } else {
        currCtrlSize.bottom = (vFix & kHeight) ? (currCtrlSize.top + it->m_origSize.Height()) : ((LONG) (it->m_origSize.bottom * yRatio));
      }

	  // might go easier ;-)
/*      if (hFix & kLeft) {
        currCtrlSize.left = it->m_origSize.left;
      } else {
        currCtrlSize.left = ((hFix & kWidth) && (hFix & kRight)) ? (it->m_origSize.left + currParentSize.Width() - m_origParentSize.Width()) : (it->m_origSize.left * xRatio);
      }
      if (hFix & kRight) {
        currCtrlSize.right = it->m_origSize.right + currParentSize.Width() - m_origParentSize.Width();
      } else {
        currCtrlSize.right = (hFix & kWidth) ? (currCtrlSize.left + it->m_origSize.Width()) : (it->m_origSize.right * xRatio);
      }

      if (vFix & kTop) {
        currCtrlSize.top = it->m_origSize.top;
      } else {
        currCtrlSize.top = ((vFix & kHeight) && (vFix & kBottom)) ? (it->m_origSize.top + currParentSize.Height() - m_origParentSize.Height()) : (it->m_origSize.top * yRatio);
      }
      if (vFix & kBottom) {
        currCtrlSize.bottom = it->m_origSize.bottom + currParentSize.Height() - m_origParentSize.Height();
      } else {
        currCtrlSize.bottom = (vFix & kHeight) ? (currCtrlSize.top + it->m_origSize.Height()) : (it->m_origSize.bottom * yRatio);
      }
*/
      // resize child window...special case when either horizontal or vertical size is fixed...windows seems to use a copy of the 
	  // old control instead of doing a full redraw...causes some additional flicker
	  if (!hFix || !vFix) {
		::MoveWindow(it->m_hCtrl, currCtrlSize.left, currCtrlSize.top, currCtrlSize.Width() - 1, currCtrlSize.Height() - 1, FALSE);
	  }

      ::MoveWindow(it->m_hCtrl, currCtrlSize.left, currCtrlSize.top, currCtrlSize.Width(), currCtrlSize.Height(), FALSE);
    }
	::InvalidateRect(m_hParent, NULL, TRUE);
  }
}

BOOL CDlgResizeHelper::Fix(HWND a_hCtrl, EHFix a_hFix, EVFix a_vFix) {
  CtrlCont_t::iterator it;
  for(it = m_ctrls.begin(); it!=m_ctrls.end(); ++it) {
    if (it->m_hCtrl == a_hCtrl) {
      it->m_hFix = a_hFix;
      it->m_vFix = a_vFix;
      return TRUE;
    }
  }
  return FALSE;
}

BOOL CDlgResizeHelper::Fix(int a_itemId, EHFix a_hFix, EVFix a_vFix) {
  return Fix(::GetDlgItem(m_hParent, a_itemId), a_hFix, a_vFix);
}

BOOL CDlgResizeHelper::Fix(EHFix a_hFix, EVFix a_vFix) {
  CtrlCont_t::iterator it;
  for(it = m_ctrls.begin(); it!=m_ctrls.end(); ++it) {
    it->m_hFix = a_hFix;
    it->m_vFix = a_vFix;
  }
  return TRUE;
}

UINT CDlgResizeHelper::Fix(LPCTSTR a_pszClassName, EHFix a_hFix, EVFix a_vFix) {
  char pszCN[200];  // ToDo: size?
  UINT cnt = 0;
  CtrlCont_t::iterator it;
  for(it = m_ctrls.begin(); it!=m_ctrls.end(); ++it) {
    ::GetClassName(it->m_hCtrl, pszCN, sizeof(pszCN));
    if (strcmp(pszCN, a_pszClassName) == 0) {
      cnt++;
      it->m_hFix = a_hFix;
      it->m_vFix = a_vFix;
    }
  }
  return cnt;
}

void CDlgResizeHelper::SetMinSize(POINT &MinSize)
{
	MinSize.x = m_origParentSize.right - m_origParentSize.left;
	MinSize.y = m_origParentSize.bottom - m_origParentSize.top;
}
