#if !defined(AFX_DATAFILELISTDLG_H__E47D79B3_DE6D_4038_A377_DAF6931E9F65__INCLUDED_)
#define AFX_DATAFILELISTDLG_H__E47D79B3_DE6D_4038_A377_DAF6931E9F65__INCLUDED_

#if _MSC_VER > 1000

#pragma once
#endif // _MSC_VER > 1000
#include "ListCtrlEx.h"	// Added by ClassView
#include "layerdisplayobject.h"	// Added by ClassView
#include "DlgResizeHelper.h"

// DataFileListDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataFileListDlg dialog

// dialog types
#define		DATALAYERS		0
#define		POILAYERS		1
#define		HOTSPOTLAYERS	2
#define		TREELAYERS		3

class CDataFileListDlg : public CDialog
{
// Construction
public:
	int DetermineFileFormat(CString FileName);
	int m_DlgType;
	CString m_DlgTitle;
	void SetTitle(LPCTSTR szTitle);
	int m_DataLayers;
	CLayerDisplayObject* m_DataLayerInfo;
//	CLayerDisplayObject m_DataLayerInfo[MAX_LAYERS];
	CListCtrlEx m_FileList;
	void EnableButtons();
	CDataFileListDlg(CWnd* pParent = NULL);   // standard constructor
	~CDataFileListDlg();

// Dialog Data
	//{{AFX_DATA(CDataFileListDlg)
	enum { IDD = IDD_DATAFILELIST };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataFileListDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

private:
	void AddListItem(COLORREF LineColor, COLORREF FillColor, LPCTSTR FileName, int Format, int SymbolType, double SymbolSize, BOOL ShowLabels, int Index = -1);
	void GetListItem(int Index, COLORREF& LineColor, COLORREF& FillColor, CString& FileName, int& SymbolType, double& SymbolSize, BOOL& ShowLabels);

// Implementation
protected:
	CDlgResizeHelper m_resizeHelper;

	// Generated message map functions
	//{{AFX_MSG(CDataFileListDlg)
	afx_msg void OnAddfile();
	afx_msg void OnDeletefiles();
	afx_msg void OnDeleteall();
	afx_msg void OnProperties();
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkFilelist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickFilelist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSettomatch();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATAFILELISTDLG_H__E47D79B3_DE6D_4038_A377_DAF6931E9F65__INCLUDED_)
