//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestZipDlg.rc
//
#define IDD_TESTZIPDLG_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDD_OPTIONS                     129
#define IDR_DLGMENU                     132
#define IDD_DIALOG1                     134
#define IDD_FILECOMMENT                 135
#define IDC_CONTENTS                    1000
#define IDC_RADIO1                      1009
#define IDC_RADIO2                      1010
#define IDC_RADIO3                      1011
#define IDC_EDIT1                       1012
#define IDC_CHECK1                      1013
#define IDC_CHECK2                      1014
#define IDC_EDIT2                       1018
#define IDC_SPIN1                       1019
#define IDC_COMM_TXT                    1020
#define ID_ACTION_ADD_FILES             32774
#define ID_ACTION_ADD_FOLODER           32775
#define ID_ACTION_DELETE                32776
#define ID_ACTION_EXTRACT               32777
#define ID_ARCHIVE_CLOSE                32778
#define ID_ARCHIVE_OPTIONS              32779
#define ID_ARCHIVE_EXIT                 32783
#define ID_HELP_ABOUT                   32784
#define ID_ARCHIVE_NEW                  32785
#define ID_ARCHIVE_OPEN                 32786
#define IDS_COL1                        57345
#define IDS_COL2                        57346
#define IDS_COL3                        57347
#define IDS_COL4                        57348
#define IDS_COL5                        57349
#define IDS_COL6                        57350
#define IDS_COL7                        57351
#define IDS_COL8                        57352

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
