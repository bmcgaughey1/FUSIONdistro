// ColorRamp.h: interface for the CColorRamp class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COLORRAMP_H__8D1AEFA1_AC81_4D27_B5DD_4CBC59BA3FB1__INCLUDED_)
#define AFX_COLORRAMP_H__8D1AEFA1_AC81_4D27_B5DD_4CBC59BA3FB1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define		RGBColor		1
#define		HSVColor		2
#define		RandomColor		3

class ColorValue
{
public:
	int R;
	int G;
	int B;
	int H;
	int S;
	int V;
	int Intensity;

	void SetUsingRGB(int Red, int Green, int Blue) {
		R = Red;
		G = Green;
		B = Blue;
		PopulateAllValues(RGBColor);
	}

	void SetUsingHSV(int Hue, int Saturation, int Luminance) {
		H = Hue;
		S = Saturation;
		V = Luminance;
		PopulateAllValues(HSVColor);
	}

private:
	void PopulateAllValues(int WeHave) {
		if (WeHave == RGBColor) {
			// equation is luminance for CRT phosphor from Poynton color FAQ
			Intensity = (int) ((double) R * 0.2126 + (double) G * 0.7152 + (double) B * 0.0722);
			
			double min, max, delta, temp;
			min = __min(R, __min(G, B));	
			max = __max(R, __max(G, B));
			delta = max - min;
			
			V = (int) max;
			if (!delta) {
				H = S = 0;
			}
			else {
				temp = delta / max;
				S = (int) (temp * 255.0);

				if (R == (int) max) {
					temp = (double)(G - B) / delta;
				}
				else {
					if (G == (int) max) {
 						temp = 2.0 + ((double)(B - R) / delta);
					}
					else {
						temp = 4.0 + ((double)(R - G) / delta);
					}
				}
				temp *= 60.0;
				if (temp < 0.0)
					temp += 360.0;
				if (temp == 360)
					temp = 0.0;
				
				H = (int) temp;
			}
		}
		else {			// HSV
			if (!H && !S) {
				R = G = B = V;
			}

			double min, max, delta, hue;
			
			max = V;
			delta = (max * S) / 255.0;
			min = max - delta;

			hue = H % 360;
			if (H > 300 || H <= 60) {
				R = (int) max;
				if (H > 300) {
					G = (int) min;
					hue = (hue - 360.0) / 60.0;
					B = (int) ((hue * delta - min) * -1);
				}
				else {
					B = (int) min;
					hue = hue / 60.0;
					G = (int) (hue * delta + min);
				}
			}
			else if (H > 60 && H < 180) {
				G = (int) max;
				if (H < 120) {
					B = (int) min;
					hue = (hue / 60.0 - 2.0 ) * delta;
					R = (int) (min - hue);
				}
				else {
					R = (int) min;
					hue = (hue / 60.0 - 2.0) * delta;
					B = (int) (min + hue);
				}
			}
			else {
				B = (int) max;
				if (H < 240) {
					R = (int) min;
					hue = (hue / 60.0 - 4.0 ) * delta;
					G = (int) (min - hue);
				}
				else {
					G = (int) min;
					hue = (hue / 60.0 - 4.0) * delta;
					R = (int) (min + hue);
				}
			}
			// equation is luminance for CRT phosphor from Poynton color FAQ
			Intensity = (int) ((double) R * 0.2126 + (double) G * 0.7152 + (double) B * 0.0722);
		}
	}
};

class CColorRamp  
{
public:
	void CreateRamp(int ColorModel,  int R1, int G1, int B1, int R2, int G2, int B2);
	COLORREF GetColorForValue(double Value);
	void SetEndpoints(double MinValue, double MaxValue);
	ColorValue m_StartColor;
	ColorValue m_StopColor;
	int m_ColorModel;

	double m_MinValue;
	double m_MaxValue;
	double m_Range;

	void SetColorModel(int Model) {
		m_ColorModel = Model;
	}

	CColorRamp();
	CColorRamp(int ColorModel,  int R1, int G1, int B1, int R2, int G2, int B2);
	virtual ~CColorRamp();

};

#endif // !defined(AFX_COLORRAMP_H__8D1AEFA1_AC81_4D27_B5DD_4CBC59BA3FB1__INCLUDED_)
