// TileMaster.h: interface for the CTileMaster class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TILEMASTER_H__22D80222_8A07_49A1_9CA0_DE3926DE4E19__INCLUDED_)
#define AFX_TILEMASTER_H__22D80222_8A07_49A1_9CA0_DE3926DE4E19__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "lidardata.h"
#include "plansdtm.h"

typedef struct {
	CString FileName;
	double MinX;
	double MinY;
	double MinZ;
	double MaxX;
	double MaxY;
	double MaxZ;
	int Points;
} DATAFILEINFO;

class CTileMaster  
{
public:
	int GetError();
	int IsError();
	void AddData(LPCTSTR FileSpec);
	void AddGround(LPCTSTR FileSpec);
	void AddDensity(LPCTSTR FileSpec);
	void AddMask(LPCTSTR FileSpec);
	BOOL FormTile(double MinX, double MinY, double MaxX, double MaxY, double BufferX, double BufferY);
	void DestroyOverview();
	BOOL IsValid();
	BOOL CreateOverview();
	void Initialize();
	void Destroy();
	CTileMaster();
	virtual ~CTileMaster();

private:
	BOOL RectanglesIntersect(double MinX1, double MinY1, double MaxX1, double MaxY1, double MinX2, double MinY2, double MaxX2, double MaxY2);
	int m_ErrorCode;
	int ExpandFileSpecToList(CString FileSpec, CStringArray& FileList);
	int CountFilesMatchingSpec(LPCSTR FileSpec);
	BOOL IsOverviewValid();
	BOOL m_OverviewValid;
	BOOL m_Valid;
	BOOL m_UseGround;
	BOOL m_UseMask;
	BOOL m_UseDensity;
	CString m_DataFileSpec;
	CString m_GroundFileSpec;
	CString m_MaskFileSpec;
	CString m_DensityFileSpec;
	int m_DataFileCount;
	int m_GroundFileCount;
	int m_MaskFileCount;
	int m_DensityFileCount;
	CStringArray m_DataFileList;
	CStringArray m_GroundFileList;
	CStringArray m_MaskFileList;
	CStringArray m_DensityFileList;

	double m_OverviewMinX;
	double m_OverviewMinY;
	double m_OverviewMinZ;
	double m_OverviewMaxX;
	double m_OverviewMaxY;
	double m_OverviewMaxZ;
	unsigned int m_OverviewPointCount;		// may be too small

	double m_TileMinX;
	double m_TileMinY;
	double m_TileMinZ;
	double m_TileMaxX;
	double m_TileMaxY;
	double m_TileMaxZ;
	double m_TileBufferX;
	double m_TileBufferY;

	DATAFILEINFO* m_DataFileInfoList; 
	PlansDTM* m_GroundModelHeaderList;
	PlansDTM* m_DensityHeaderList;
};

#endif // !defined(AFX_TILEMASTER_H__22D80222_8A07_49A1_9CA0_DE3926DE4E19__INCLUDED_)
