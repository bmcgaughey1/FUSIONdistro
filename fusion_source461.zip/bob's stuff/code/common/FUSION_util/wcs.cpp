// wcs.cpp : implementation file
//

#include <stdafx.h>
#include "wcs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// wcs
WCS::WCS()
{
	s_minx = 0;
	s_miny = 0;
	s_maxx = 0;
	s_maxy = 0;

	w_minx = 0.0;
	w_miny = 0.0;
	w_maxx = 0.0;
	w_maxy = 0.0;

	xratio = 0.0;
	yratio = 0.0;

	valid = FALSE;
}

WCS::~WCS()
{
}

void WCS::Scale(int left, int top, int right, int bottom, double minx, double miny, double maxx, double maxy)
{
	s_minx = left;
	s_miny = top;
	s_maxx = right;
	s_maxy = bottom;

	w_minx = minx;
	w_miny = miny;
	w_maxx = maxx;
	w_maxy = maxy;

//	xratio = (double)((double)s_maxx - (double)s_minx + 1.0) / (w_maxx - w_minx);
//	yratio = (double)((double)s_maxy - (double)s_miny + 1.0) / (w_maxy - w_miny);
	xratio = (double)((double)s_maxx - (double)s_minx) / (w_maxx - w_minx);
	yratio = (double)((double)s_maxy - (double)s_miny) / (w_maxy - w_miny);

	valid = TRUE;
}

void WCS::Scale(CDC *dc, double minx, double miny, double maxx, double maxy)
{
	RECT rc;

	if (dc->IsPrinting()) {
		rc.left = 0;
		rc.top = 0;
		rc.right = dc->GetDeviceCaps(HORZRES);
		rc.bottom = dc->GetDeviceCaps(VERTRES);
	}
	else {
		CWnd* win = dc->GetWindow();

		win->GetClientRect(&rc);
	}

	s_minx = rc.left;
	s_miny = rc.top;
	s_maxx = rc.right;
	s_maxy = rc.bottom;

	w_minx = minx;
	w_miny = miny;
	w_maxx = maxx;
	w_maxy = maxy;

//	xratio = (double)((double)s_maxx - (double)s_minx + 1.0) / (w_maxx - w_minx);
//	yratio = (double)((double)s_maxy - (double)s_miny + 1.0) / (w_maxy - w_miny);
	xratio = (double)((double)s_maxx - (double)s_minx) / (w_maxx - w_minx);
	yratio = (double)((double)s_maxy - (double)s_miny) / (w_maxy - w_miny);

	valid = TRUE;
}

void WCS::IsoAdjust(CDC *dc)
{
	IsoAdjust(dc->GetDeviceCaps(ASPECTX), dc->GetDeviceCaps(ASPECTY));
}

void WCS::IsoAdjust(int aspectx, int aspecty)
{
	double horiz, vert;
	double center_x, center_y;
	double aspect;

	// calculate the horizontal and vertical dimension of the world window
	horiz = w_maxx - w_minx;
	vert = w_maxy - w_miny;

	// calculate old center location
	center_x = w_minx + horiz / 2.0;
	center_y = w_miny + vert / 2.0;

	// compare the horizontal and vertical ratio to the window aspect and
	// adjust the X or Y scaling accordingly
//	aspect = ((double)aspectx * (double)((double)s_maxx - (double)s_minx + 1.0)) / ((double)aspecty * (double)((double)s_maxy - (double)s_miny + 1.0));
	aspect = ((double)aspectx * (double)((double)s_maxx - (double)s_minx)) / ((double)aspecty * (double)((double)s_maxy - (double)s_miny));

	if ((horiz / vert) > aspect) {
		w_maxy = w_miny + horiz / aspect;
	}
	else if ((horiz / vert) < aspect) {
		w_maxx = w_minx + vert * aspect;
	}
	else {
		return;
	}

	/* calculate the NEW horizontal and vertical dimension of the window */
	horiz = w_maxx - w_minx;
	vert = w_maxy - w_miny;

	/* calculate the new scaling parameters to center coordinate system */
	w_minx = center_x - horiz / 2.0;
	w_maxx = center_x + horiz / 2.0;
	w_miny = center_y - vert / 2.0;
	w_maxy = center_y + vert / 2.0;

//	xratio = (double)((double)s_maxx - (double)s_minx + 1.0) / (w_maxx - w_minx);
//	yratio = (double)((double)s_maxy - (double)s_miny + 1.0) / (w_maxy - w_miny);
	xratio = (double)((double)s_maxx - (double)s_minx) / (w_maxx - w_minx);
	yratio = (double)((double)s_maxy - (double)s_miny) / (w_maxy - w_miny);
}

int WCS::WX(double x)
{
	return((int) ((x - w_minx) * xratio) + s_minx);
}

int WCS::WY(double y)
{
	return((int) ((double) s_maxy - (y - w_miny) * yratio));
}

int WCS::WDIST(double dist)
{
	return(WXDIST(dist));
}

int WCS::WXDIST(double dist)
{
	return((int) (dist * xratio));
}

int WCS::WYDIST(double dist)
{
	return((int) (dist * yratio));
}


double WCS::WorldX(int screenx)
{
	return(w_minx + ((double)((double)screenx - (double)s_minx) / xratio));
}

double WCS::WorldY(int screeny)
{
//	return(w_miny + (((double)((double)s_maxy - 1.0) - (double)screeny) / yratio));
	return(w_miny + ((double)((double)s_maxy - (double)screeny) / yratio));
}
