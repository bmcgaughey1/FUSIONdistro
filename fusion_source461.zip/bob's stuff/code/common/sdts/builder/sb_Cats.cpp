//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//
// $Id: sb_Cats.cpp,v 1.4 1998/09/01 22:10:10 mcoletti Exp $
//

#include "builder/sb_Cats.h"



#include <iostream>
#include <strstream>

#include <limits.h>
#include <float.h>

#ifndef INCLUDED_SB_UTILS_H
#include "builder/sb_Utils.h"
#endif

#ifndef INCLUDED_SB_FOREIGNID_H
#include "builder/sb_ForeignID.h"
#endif

#ifndef INCLUDED_SC_RECORD_H
#include "container/sc_Record.h"
#endif

#ifndef INCLUDED_SC_FIELD_H
#include "container/sc_Field.h"
#endif

#ifndef INCLUDED_SC_SUBFIELD_H
#include "container/sc_Subfield.h"
#endif

#ifndef INCLUDED_SIO_8211CONVERTER_H
#include "io/sio_8211Converter.h"
#endif



static const char* _ident = "$Id: sb_Cats.cpp,v 1.4 1998/09/01 22:10:10 mcoletti Exp $";

// Strings and integers are initialized with these values; they are used
// to indicate whether a given module value has been assigned a value or not.

// (XXX I arbitrarily chose 0x4 as the sentinal value.  I hate ad hoc crap.)

static const string  UNVALUED_STRING(1, static_cast<string::value_type>(0x4) );

static const long    UNVALUED_LONG   = INT_MIN;

static const double  UNVALUED_DOUBLE = DBL_MAX;

struct sb_Cats_Imp
{
  string   _Name;
  string   _Type;
  string   _Domain;
  string   _Map;
  string   _Them;
  string   _AggregateObject;
  string   _AggregateObjectType;
  string   _Comment;


  sb_Cats_Imp()
    : 
    _Name( UNVALUED_STRING ),
    _Type( UNVALUED_STRING ),
    _Domain( UNVALUED_STRING ),
    _Map( UNVALUED_STRING ),
    _Them( UNVALUED_STRING ),
    _AggregateObject( UNVALUED_STRING ),
    _AggregateObjectType( UNVALUED_STRING ),
    _Comment( UNVALUED_STRING )
  {}

};


sb_Cats::sb_Cats()
  : _imp( new sb_Cats_Imp() )
{
  setMnemonic("CATS");
  setID( 1 );


  // insert static initializers

} // Cats ctor


sb_Cats::~sb_Cats()
{
  delete _imp;
} // Cats dtor




static sio_8211Converter_I converter_I; // XXX should define these in
static sio_8211Converter_A converter_A; // XXX sio_8211Converter.h
static sio_8211Converter_R converter_R;
static sio_8211Converter_C converter_C;

static sio_8211Schema _schema; // module specific schema

static
void
_build_schema( sio_8211Schema& schema )
{
  schema.clear();               // make sure we are starting with clean schema

  schema.push_back( sio_8211FieldFormat() );

  sio_8211FieldFormat& field_format = schema.back();

  field_format.setDataStructCode( sio_8211FieldFormat::vector );
  field_format.setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  field_format.setName( "Catalog/Spatial Domain" );
  field_format.setTag( "CATS" );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "MODN" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "RCID" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "NAME" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "TYPE" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "DOMN" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "MAP" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


//  field_format.push_back( sio_8211SubfieldFormat() );
//
//  field_format.back().setLabel( "THEM" );
//  field_format.back().setType( sio_8211SubfieldFormat::A );
//  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
//  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "AGOB" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "AGTP" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "COMT" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


} // _build_schema


static
bool
_ingest_record( sb_Cats& cats, sb_Cats_Imp &cats_imp, sc_Record const& record )
{

  // Make sure we have a record from an
  // External Spatial Reference module.

  sc_FieldCntr::const_iterator curfield;

  if ( ! sb_Utils::getFieldByMnem( record,"CATS",curfield) )
  {
#ifdef SDTSXX_DEBUG
    cerr << "sb_Cats::sb_Cats(sc_Record const&): "
         << "Not an catalog/spatial domain record.";
    cerr << endl;
#endif
    return false;
  }


  // We have a primary field from a  module. Start// picking it apart.

  sc_SubfieldCntr::const_iterator cursubfield;

  string tmp_str;
  long   tmp_int;


  // MODN
  if (sb_Utils::getSubfieldByMnem(*curfield,"MODN",cursubfield))
  {
    cursubfield->getA( tmp_str );
    cats.setMnemonic( tmp_str );
  }


  // RCID
  if (sb_Utils::getSubfieldByMnem(*curfield,"RCID",cursubfield))
  {
    cursubfield->getI( tmp_int );
    cats.setID( tmp_int );
  }


  // NAME
  if (sb_Utils::getSubfieldByMnem(*curfield,"NAME",cursubfield))
  {
    cursubfield->getA( cats_imp._Name);
  }
  else
  {
    return false;
  }


  // TYPE
  if (sb_Utils::getSubfieldByMnem(*curfield,"TYPE",cursubfield))
  {
    cursubfield->getA( cats_imp._Type);
  }
  else
  {
    return false;
  }


  // DOMN
  if (sb_Utils::getSubfieldByMnem(*curfield,"DOMN",cursubfield))
  {
    cursubfield->getA( cats_imp._Domain);
  }
  else
  {
    return false;
  }


  // MAP
  if (sb_Utils::getSubfieldByMnem(*curfield,"MAP",cursubfield))
  {
    cursubfield->getA( cats_imp._Map);
  }
  else
  {
    return false;
  }


  // THEM
//  if (sb_Utils::getSubfieldByMnem(*curfield,"THEM",cursubfield))
//  {
//    cursubfield->getA( cats_imp._Them);
//  }
//  else
//  {
//    return false;
//  }


  // AGOB
  if (sb_Utils::getSubfieldByMnem(*curfield,"AGOB",cursubfield))
  {
    cursubfield->getA( cats_imp._AggregateObject);
  }
  else
  {
    return false;
  }


  // AGTP
  if (sb_Utils::getSubfieldByMnem(*curfield,"AGTP",cursubfield))
  {
    cursubfield->getA( cats_imp._AggregateObjectType);
  }
  else
  {
    return false;
  }


  // COMT
  if (sb_Utils::getSubfieldByMnem(*curfield,"COMT",cursubfield))
  {
    cursubfield->getA( cats_imp._Comment);
  }
  else
  {
    return false;
  }


  return true;


} // _ingest_record




bool
sb_Cats::getName( string& val ) const
{
  if ( _imp->_Name == UNVALUED_STRING )
    return false;

  val = _imp->_Name;

  return true;
} // sb_Cats::getName


bool
sb_Cats::getType( string& val ) const
{
  if ( _imp->_Type == UNVALUED_STRING )
    return false;

  val = _imp->_Type;

  return true;
} // sb_Cats::getType


bool
sb_Cats::getDomain( string& val ) const
{
  if ( _imp->_Domain == UNVALUED_STRING )
    return false;

  val = _imp->_Domain;

  return true;
} // sb_Cats::getDomain


bool
sb_Cats::getMap( string& val ) const
{
  if ( _imp->_Map == UNVALUED_STRING )
    return false;

  val = _imp->_Map;

  return true;
} // sb_Cats::getMap


bool
sb_Cats::getThem( string& val ) const
{
  if ( _imp->_Them == UNVALUED_STRING )
    return false;

  val = _imp->_Them;

  return true;
} // sb_Cats::getThem


bool
sb_Cats::getAggregateObject( string& val ) const
{
  if ( _imp->_AggregateObject == UNVALUED_STRING )
    return false;

  val = _imp->_AggregateObject;

  return true;
} // sb_Cats::getAggregateObject


bool
sb_Cats::getAggregateObjectType( string& val ) const
{
  if ( _imp->_AggregateObjectType == UNVALUED_STRING )
    return false;

  val = _imp->_AggregateObjectType;

  return true;
} // sb_Cats::getAggregateObjectType


bool
sb_Cats::getComment( string& val ) const
{
  if ( _imp->_Comment == UNVALUED_STRING )
    return false;

  val = _imp->_Comment;

  return true;
} // sb_Cats::getComment


bool
sb_Cats::getSchema( sio_8211Schema& schema ) const
{
  // If the schema hasn't been
  // initialized, please do so.

  if ( _schema.empty() )
  {
    _build_schema( _schema );
  }

  if ( _schema.empty() )   // oops ... something screwed up
  {
    return false;
  }

  schema = _schema;

  return true;

} // sb_Cats::getSchema




bool
sb_Cats::getRecord( sc_Record & record ) const
{
  record.clear();               // start with a clean slate

  // first field, which contains module name and record number

  record.push_back( sc_Field() );

  record.back().setMnemonic( "CATS" );

  record.back().setName( "Catalog/Spatial Domain" );

  string tmp_str;

  getMnemonic( tmp_str );
  sb_Utils::add_subfield( record.back(), "MODN", tmp_str );
  sb_Utils::add_subfield( record.back(), "RCID", getID() );

  if ( getName( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"NAME", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "NAME", sc_Subfield::is_A );
  }


  if ( getType( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"TYPE", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "TYPE", sc_Subfield::is_A );
  }


  if ( getDomain( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"DOMN", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "DOMN", sc_Subfield::is_A );
  }


  if ( getMap( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"MAP", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "MAP", sc_Subfield::is_A );
  }


//  if ( getThem( tmp_str ) )
//  {
//    sb_Utils::add_subfield( record.back(),"THEM", tmp_str );
//  }
//  else
//  {
//    sb_Utils::add_empty_subfield( record.back(), "THEM", sc_Subfield::is_A );
//  }


  if ( getAggregateObject( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"AGOB", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "AGOB", sc_Subfield::is_A );
  }


  if ( getAggregateObjectType( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"AGTP", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "AGTP", sc_Subfield::is_A );
  }


  if ( getComment( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"COMT", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "COMT", sc_Subfield::is_A );
  }


  return true;


} // Cats::getRecord




bool
sb_Cats::setName( string const& val )
{
  _imp->_Name = val;

  return true;
} // sb_Cats::setName


bool
sb_Cats::setType( string const& val )
{
  _imp->_Type = val;

  return true;
} // sb_Cats::setType


bool
sb_Cats::setDomain( string const& val )
{
  _imp->_Domain = val;

  return true;
} // sb_Cats::setDomain


bool
sb_Cats::setMap( string const& val )
{
  _imp->_Map = val;

  return true;
} // sb_Cats::setMap


bool
sb_Cats::setThem( string const& val )
{
  _imp->_Them = val;

  return true;
} // sb_Cats::setThem


bool
sb_Cats::setAggregateObject( string const& val )
{
  _imp->_AggregateObject = val;

  return true;
} // sb_Cats::setAggregateObject


bool
sb_Cats::setAggregateObjectType( string const& val )
{
  _imp->_AggregateObjectType = val;

  return true;
} // sb_Cats::setAggregateObjectType


bool
sb_Cats::setComment( string const& val )
{
  _imp->_Comment = val;

  return true;
} // sb_Cats::setComment


bool
sb_Cats::setRecord( sc_Record const& record )
{
  return _ingest_record( *this, *_imp, record );
} // sb_Cats::setRecord




void
sb_Cats::unDefineName( )
{
  _imp->_Name = UNVALUED_STRING;
} // sb_Cats::unDefineName


void
sb_Cats::unDefineType( )
{
  _imp->_Type = UNVALUED_STRING;
} // sb_Cats::unDefineType


void
sb_Cats::unDefineDomain( )
{
  _imp->_Domain = UNVALUED_STRING;
} // sb_Cats::unDefineDomain


void
sb_Cats::unDefineMap( )
{
  _imp->_Map = UNVALUED_STRING;
} // sb_Cats::unDefineMap


void
sb_Cats::unDefineThem( )
{
  _imp->_Them = UNVALUED_STRING;
} // sb_Cats::unDefineThem


void
sb_Cats::unDefineAggregateObject( )
{
  _imp->_AggregateObject = UNVALUED_STRING;
} // sb_Cats::unDefineAggregateObject


void
sb_Cats::unDefineAggregateObjectType( )
{
  _imp->_AggregateObjectType = UNVALUED_STRING;
} // sb_Cats::unDefineAggregateObjectType


void
sb_Cats::unDefineComment( )
{
  _imp->_Comment = UNVALUED_STRING;
} // sb_Cats::unDefineComment


