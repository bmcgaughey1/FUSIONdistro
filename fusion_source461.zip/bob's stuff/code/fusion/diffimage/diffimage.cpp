// diffimage.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "math.h"
#include "diffimage.h"
#include "plansdtm.h"
#include "worldfile.h"
#include "image.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		if (argc < 6) {
			printf("Syntax: DiffImage SurfaceFile1 SurfaceFile2 OutputImageFile MinimumThreshold MaximumDifference\n");
			printf("   SurfaceFile1      PLANS format surface model file\n");
			printf("   SurfaceFile2      PLANS format terrain model file\n");
			printf("   OutputImageFile   BMP image output file\n");
			printf("   MinimumThreshold  Threshold for difference coloring...areas with lower difference are gray\n");
			printf("   MaximumDifference Maximum absolute difference...used to scale the color gradation\n");
		} 
		else {
			CString	m_Surface1FileName(argv[1]);
			CString	m_Surface2FileName(argv[2]);
			CString	m_OutputFileName(argv[3]);
			double m_MinimumThreshold = atof(argv[4]);
			double m_MaximumDifference = atof(argv[5]);

			int i, j;
			double elev1, elev2, elevdiff;
			BYTE r, g, b;

			// load surface models
			PlansDTM surface1(m_Surface1FileName, TRUE, FALSE);
			PlansDTM surface2(m_Surface2FileName, TRUE, FALSE);

			if (!surface1.IsValid() || !surface2.IsValid()) {
				printf("Can't open model files\n");
				return(1);
			}

			// check for equal size models and grid resolution
			if (surface1.Columns() != surface2.Columns()) {
				printf("DTMs not the same size\n");
				return(1);
			}
			if (surface1.Rows() != surface2.Rows()) {
				printf("DTMs not the same size\n");
				return(1);
			}
			if (surface1.ColumnSpacing() != surface2.ColumnSpacing()) {
				printf("DTMs not the same size\n");
				return(1);
			}
			if (surface1.PointSpacing() != surface2.PointSpacing()) {
				printf("DTMs not the same size\n");
				return(1);
			}

			// create image for output
			CImage img;
			CSize sz(surface1.Columns(), surface1.Rows());
			img.CreateImage(sz, 24);

			DWORD linewidth;
			unsigned char* offBits;

			// compute width of 1 scan line
			linewidth = (DWORD) ((((img.m_lpBMIH->biWidth * (DWORD) img.m_lpBMIH->biBitCount) + 31) & ~31) >> 3);

			// offset to the bits from start of DIB header
			offBits = img.m_lpImage;

			// step through models
			for (j = 0; j < surface1.Rows(); j ++) {
				for (i = 0; i < surface1.Columns(); i ++) {
					elev1 = surface1.GetGridElevation(i, j);
					elev2 = surface2.GetGridElevation(i, j);
					elevdiff = elev1 - elev2;

					if (fabs(elevdiff) <= m_MinimumThreshold) {
						r = g = b = 192;
					}
					else if (elev1 < elev2) {
						r = 192 + (int) ((fabs(elevdiff) / m_MaximumDifference) * 63.0);
						g = b = 63;
//						g = __max(0, (int) ((fabs(elevdiff) / m_MaximumDifference) * 192.0));
//						b = __max(0, (int) ((fabs(elevdiff) / m_MaximumDifference) * 192.0));
					}
					else {
						g = 192 + (int) ((fabs(elevdiff) / m_MaximumDifference) * 63.0);
						r = b = 63;
//						r = __max(0, (int) ((fabs(elevdiff) / m_MaximumDifference) * 192.0));
//						b = __max(0, (int) ((fabs(elevdiff) / m_MaximumDifference) * 192.0));
					}

					// set area with change higher than maximum level to blue
					if (fabs(elevdiff) > m_MaximumDifference) {
						r = g = 63;
						b = 255;
					}

					r = __min(255, r);
					r = __max(0, r);
					g = __min(255, g);
					g = __max(0, g);
					b = __min(255, b);
					b = __max(0, b);
					offBits[i * 3 + 2] = r;
					offBits[i * 3 + 1] = g;
					offBits[i * 3] = b;
				}
				offBits += linewidth;
			}

			// write image
			CFile file;
			if (file.Open(m_OutputFileName, CFile::modeCreate | CFile::modeWrite | CFile::typeBinary)) {
				img.Write(&file);
				file.Close();
			}

			// save world file
			CString WorldFileName = m_OutputFileName;
			WorldFileName += _T("w");
			CWorldFile world;
			world.m_Aterm = surface1.ColumnSpacing();
			world.m_Dterm = 0.0;
			world.m_Bterm = 0.0;
			world.m_Eterm = -surface1.PointSpacing();
			world.m_Cterm = surface1.OriginX() + surface1.ColumnSpacing() / 2.0;
			world.m_Fterm = (surface1.OriginY() + surface1.PointSpacing() * (double) (surface1.Rows() - 1)) - surface1.PointSpacing() / 2.0;

			world.WriteValues(WorldFileName);
		}
	}

	return nRetCode;
}


