// ASCIIGridFile.cpp: implementation of the CASCIIGridFile class.
//
// 6/10/2009
// Changed behavior in ConvertToPLANS to produce DTM files with float type elevations instead of double type. 
// This cuts the file size in half and still maintains 6 significant digits
//
// 3/1/2011
// Changed the storage format for reading in an ASCII raster file from double to float when converting to PLANS DTM format.
// The output can only be short or float so storing values as doubles didn't make any sense.
//
// 10/25/2012
// Changed the logic that reads the header to work with very small rasters. I was running into trouble with a file that was
// 2 rows by 3 columns where there were not 128 bytes from the middle of the header to the end of the file so the read that
// read lines from the header was failing. The change uses the feature of ReadRawBytes() to not report an error when fewer
// bytes are  read than requested. This was showing up in MergeRaster.
//
// 5/22/2013 Looked at the logic used to set the origin when converting to DTM format. The original logic was correct even though
// there seems to be some mismatch between the code and the comments.
//
// 1/15/2015 Added zoffset when converting to PLANS format DTM. This is used to do a crude vertical datum shift
//
// 11/28/2016 Added logic to do a better job parsing NAN values from input data when converting to PLANS DTM format.
// Previous logic was failing when it encountered "1.#QNAN" for values in the input ASCII file.
//
//	8/6/2018
//	Corrected a problem when determining the min/max values for X, Y & Z in data files. Variables for the max values were being initialized to a vary 
//	small positive number. This worked fine unless the coordinates were all negative. For negative coordinates, the maximum values reported were always 0.0.
//
//	For some programs, there was no problem but code was changed to provide consistent initial values when determining min/max values.
//
//	5/7/2020
//	Added logic to report an error when converting file to DTM format. Previous code failed if the
//	input or output files couldn't be opened but did not return an error
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "fusion.h"
#include "ASCIIGridFile.h"
#include "Plansdtm.h"
#include <float.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CASCIIGridFile::~CASCIIGridFile()
{
	DiscardValues();
}

CASCIIGridFile::CASCIIGridFile(LPCTSTR FileName) : CDataFile(FileName)
{
	m_HaveValuesLoaded = FALSE;
	m_HaveRowLoaded = FALSE;
	m_LLIsCenter = FALSE;
	m_HeaderLines = 0;
	m_Values = NULL;
	m_RowValues = NULL;
	m_Columns = m_Rows = 0;
	m_HeaderValid = ReadHeader();
}

BOOL CASCIIGridFile::ReadHeader()
{
	char* keywords[] = {"NCOLS", "NROWS", "XLLCORNER", "XLLCENTER", "YLLCORNER", "YLLCENTER", "CELLSIZE", "NODATA_VALUE"};

	m_HeaderValid = FALSE;

	// read header values
	Rewind();

	char buf[1024];
	int i;
	BOOL GoodLine;
	int keyword;
	long fp;
	int cnt = 0;
	m_NODATA = -9999.0;
	while (1) {
		// read chunk of file and look for \r or \n
		fp = GetPosition();
		GoodLine = FALSE;
		if (ReadRawBytes(buf, 128, TRUE)) {
			for (i = 0; i < 128; i ++) {
				if (buf[i] == '\r' || buf[i] == '\n') {
					GoodLine = TRUE;
					break;
				}
			}
		}

		// reset file position
		SetPosition(fp);

		// if we had a good line, look for header commands
		if (GoodLine) {
			// read line
			ReadASCIILine(buf);

			// look for keyword match
			_strupr(buf);
			keyword = -1;
			for (i = 0; i < 8; i ++) {
				if (strstr(buf, keywords[i])) {
					keyword = i;
					break;
				}
			}
			if (keyword >= 0 && keyword < 8) {
				if (keyword == 0)			// NCOLS
					sscanf(buf, "%*s %i", &m_Columns);
				else if (keyword == 1)		// NROWS
					sscanf(buf, "%*s %i", &m_Rows);
				else if (keyword == 2) {	// XLLCORNER
					sscanf(buf, "%*s %lf", &m_LLX);
					m_LLIsCenter = FALSE;
				}
				else if (keyword == 3) {	// XLLCENTER
					sscanf(buf, "%*s %lf", &m_LLX);
					m_LLIsCenter = TRUE;
				}
				else if (keyword == 4) {	// YLLCORNER
					sscanf(buf, "%*s %lf", &m_LLY);
					m_LLIsCenter = FALSE;
				}
				else if (keyword == 5) {	// YLLCENTER
					sscanf(buf, "%*s %lf", &m_LLY);
					m_LLIsCenter = TRUE;
				}
				else if (keyword == 6)		// CELLSIZE
					sscanf(buf, "%*s %lf", &m_CellSize);
				else if (keyword == 7)		// NODATA_VALUE
					sscanf(buf, "%*s %lf", &m_NODATA);

				cnt ++;
			}
			else
				break;
		}
		else
			break;
	}

	// must have at least 5 lines of header info (NCOLS, NROWS, XLLxxx, YLLxxx, CELLSIZE)...NODATA_VALUE is optional
	if (cnt >= 5)
		m_HeaderValid = TRUE;

	// save the number of header lines so we can move directly to data
	m_HeaderLines = cnt;

	// compute the true origin
	if (!m_LLIsCenter) {
		m_OriginX = m_LLX;
		m_OriginY = m_LLY;
	}
	else {
		m_OriginX = m_LLX - m_CellSize / 2.0;
		m_OriginY = m_LLY - m_CellSize / 2.0;
	}

	// set min/max values
	m_MaxVal = -DBL_MAX;
	m_MinVal = DBL_MAX;

	return(m_HeaderValid);
}

BOOL CASCIIGridFile::ConvertToPLANS(LPCSTR PlansDTMFileName, int XYUnits, int ZUnits, double XYFactor, double ZFactor, int Projection, int Zone, BOOL UseDoublePrecision, int HorizontalDatum, int VerticalDatum, double Zoffset, BOOL UseNANLogic)
{
	// XYUnits and ZUnits are the output units...don't know what the original units are and don't care
	// XYFactor and ZFactor are the conversion factors applied to units
	// Zoffset is added to the elevations
	// bottom line is that calling process needs to set up the correct units and any necessary conversion from original units

	BOOL LocalUseDouble = UseDoublePrecision;
	BOOL RetValue = FALSE;
	double ddat;

	if (m_HeaderValid) {
		char buf[256];
		int i, j;

		// read header...saved number of lines when header was read
		Rewind();
		for (i = 0; i < m_HeaderLines; i ++)
			ReadASCIILine(buf);

		// allocate space for data
		float** dat;
		dat = new float*[m_Rows];
		if (dat) {
			for (i = 0; i < m_Rows; i ++) {
				dat[i] = new float[m_Columns];

				if (!dat[i]) {
					for (j = i - 1; j >= 0; j --)
						delete [] dat[i];

					delete [] dat;
					dat = NULL;

					break;
				}
			}
		}

		if (dat) {
			// read data
			for (i = m_Rows - 1; i >= 0; i --) {
//				ReadASCIILine(buf);

				// parse
				for (j = 0; j < m_Columns; j ++) {
					// read next value from file
					if (UseNANLogic)
						ReadValueNAN(&ddat);
					else
						ReadValue(&ddat);

					dat[i][j] = (float) ddat;

//					if (j == 0)
//						dat[i][j] = atof(strtok(buf, " "));
//					else
//						dat[i][j] = atof(strtok(NULL, " "));
				}
			}

			// look through values and see if we need floating point values
			for (i = m_Rows - 1; i >= 0; i --) {
				for (j = 0; j < m_Columns; j ++) {
					if (dat[i][j] - (int) dat[i][j] > 0.01) {
						LocalUseDouble = TRUE;
						break;
					}
				}
			}

			// convert
			BIN_HEADER dtm;

			dtm.columns = m_Columns;
			dtm.points = m_Rows;
			dtm.column_spacing = m_CellSize * XYFactor;
			dtm.point_spacing = m_CellSize * XYFactor;
			// *************************************************************************************************************
			// made the change 5/22/2013 to !m_LLIsCenter as it seems like to code and comments didn't match
			// this affects all ground surfaces that we have converted from Arc grids to DTM format...don't know if this was really 
			// broken!!!!!!
			//
			// NOT BROKEN...the logic (if (m_LLIsCenter) {) is correct. If the origin in the ASCII file is the center of the cell,
			// then this is the correct origin for the DTM since we want the value for the cell located at the origin of the DTM.
			// If the origin of the ASCII file is the LL corner of the cell, we need to offset the origin so the data value is
			// located at the origin of the DTM. Note that the offset that is applied is up and right.
			// *************************************************************************************************************
			if (m_LLIsCenter) {
				// data point is at reported LL corner
				dtm.origin_x = m_LLX * XYFactor;
				dtm.origin_y = m_LLY * XYFactor;
			}
			else {
				// data point is at center of cell...need to offset from ll corner of cell
				dtm.origin_x = (m_LLX + (double) m_CellSize / 2.0) * XYFactor;
				dtm.origin_y = (m_LLY + (double) m_CellSize / 2.0) * XYFactor;
			}
			dtm.rotation = 0.0;
			if (Projection > 0) {
				if (LocalUseDouble) {
					if (HorizontalDatum >= 0 && VerticalDatum >= 0)
						dtm.version = 3.1f;
					else
						dtm.version = 3.0f;
				}
				else {
					if (HorizontalDatum >= 0 && VerticalDatum >= 0)
						dtm.version = 3.1f;
					else
						dtm.version = 2.0f;
				}
				dtm.coord_sys = (short) Projection;
				dtm.coord_zone = (short) Zone;
				dtm.horizontal_datum = (short) HorizontalDatum;
				dtm.vertical_datum = (short) VerticalDatum;
			}
			else {
				if (LocalUseDouble) {
					if (HorizontalDatum >= 0 && VerticalDatum >= 0)
						dtm.version = 3.1f;
					else
						dtm.version = 3.0f;
				}
				else
					dtm.version = 1.0f;
				dtm.coord_sys = 0;
				dtm.coord_zone = 0;
				dtm.horizontal_datum = (short) HorizontalDatum;
				dtm.vertical_datum = (short) VerticalDatum;
			}
			dtm.xy_units = XYUnits;
			dtm.z_units = ZUnits;
			if (LocalUseDouble)
				dtm.z_bytes = 2;
			else
				dtm.z_bytes = 0;
			dtm.max_z = dtm.min_z = 0.0;
			strcpy(dtm.name, "Model created from ASCII raster file");
			strcpy(dtm.signature, "PLANS-PC BINARY .DTM");

			short nodata = -1;
			float nodataf = -1.0;
			short elev;
			float elevf;
			FILE* f;
			f = fopen(PlansDTMFileName, "wb");
			if (f) {
				double minz = 150000.0;
				double maxz = -150000.0;

				// model is open
				fseek(f, 200l, SEEK_SET);

				for (j = 0; j < m_Columns; j ++) {
					for (i = 0; i <  m_Rows; i ++) {
						if (dat[i][j] != m_NODATA) {
							if (LocalUseDouble) {
								elevf = (float) (dat[i][j] * ZFactor + Zoffset);
								fwrite(&elevf, sizeof(float), 1, f);
							}
							else {
								elev = (short) (dat[i][j] * ZFactor + Zoffset);
								fwrite(&elev, sizeof(short), 1, f);
							}

							if (dat[i][j] < minz)
//							if (dat[i][j] < minz && dat[i][j] >= 0.0)
									minz = dat[i][j];
							if (dat[i][j] > maxz)
								maxz = dat[i][j];
						}
						else {
							if (LocalUseDouble)
								fwrite(&nodataf, sizeof(float), 1, f);
							else
								fwrite(&nodata, sizeof(short), 1, f);
						}
					}
				}

				// catch the case where there were no valid elevations in the entire model
				if (minz == 150000.0)
					minz = 0.0;

				if (maxz == -150000.0)
					maxz = 0.0;

				dtm.max_z = maxz * ZFactor + Zoffset;
				dtm.min_z = minz * ZFactor + Zoffset;

				// go back to beginning of file and write header
				fseek(f, 0, SEEK_SET);

				fwrite(&dtm.signature, sizeof(char), 21, f);
				fwrite(&dtm.name, sizeof(char), 61, f);
				fwrite(&dtm.version, sizeof(float), 1, f);
				fwrite(&dtm.origin_x, sizeof(double), 1, f);
				fwrite(&dtm.origin_y, sizeof(double), 1, f);
				fwrite(&dtm.min_z, sizeof(double), 1, f);
				fwrite(&dtm.max_z, sizeof(double), 1, f);
				fwrite(&dtm.rotation, sizeof(double), 1, f);
				fwrite(&dtm.column_spacing, sizeof(double), 1, f);
				fwrite(&dtm.point_spacing, sizeof(double), 1, f);
				fwrite(&dtm.columns, sizeof(long), 1, f);
				fwrite(&dtm.points, sizeof(long), 1, f);
				fwrite(&dtm.xy_units, sizeof(short), 1, f);
				fwrite(&dtm.z_units, sizeof(short), 1, f);
				fwrite(&dtm.z_bytes, sizeof(short), 1, f);
				fwrite(&dtm.coord_sys, sizeof(short), 1, f);
				fwrite(&dtm.coord_zone, sizeof(short), 1, f);
				fwrite(&dtm.horizontal_datum, sizeof(short), 1, f);
				fwrite(&dtm.vertical_datum, sizeof(short), 1, f);

				fclose(f);

				RetValue = TRUE;
			}
			else {
				// couldn't open output model...RetValue is already FALSE so nothing to do
			}

			// free memory
			for (i = 0; i < m_Rows; i ++)
				delete [] dat[i];
			delete [] dat;
		}
	}
	return(RetValue);
}

BOOL CASCIIGridFile::IsGoodFile()
{
	return(IsValid() && m_HeaderValid);
}

BOOL CASCIIGridFile::LoadValues()
{
	char buf[256];
	int i, j;

	if (!m_HeaderValid)
		return(FALSE);

	// get rid of values
	DiscardValues();

	// read header...saved number of lines when header was read
	Rewind();
	for (i = 0; i < m_HeaderLines; i ++)
		ReadASCIILine(buf);

	// allocate space for data
	m_Values = new double*[m_Rows];
	if (m_Values) {
		for (i = 0; i < m_Rows; i ++) {
			m_Values[i] = new double[m_Columns];

			if (!m_Values[i]) {
				for (j = i - 1; j >= 0; j --)
					delete [] m_Values[i];

				delete [] m_Values;
				m_Values = NULL;

				break;
			}
		}
	}

	if (m_Values) {
		// read data
		for (i = m_Rows - 1; i >= 0; i --) {
			// parse
			for (j = 0; j < m_Columns; j ++) {
				// read next value from file
				ReadValue(&m_Values[i][j]);
			}
		}
		m_HaveValuesLoaded = TRUE;

		// get min/max values
		m_MaxVal = -DBL_MAX;
		m_MinVal = DBL_MAX;
		for (j = 0; j < m_Columns; j ++) {
			for (i = 0; i <  m_Rows; i ++) {
				if (m_Values[i][j] != m_NODATA) {
					if (m_Values[i][j] > m_MaxVal)
						m_MaxVal = m_Values[i][j];
					if (m_Values[i][j] < m_MinVal)
						m_MinVal = m_Values[i][j];
				}
			}
		}
	}
	
	return(m_HaveValuesLoaded);
}

void CASCIIGridFile::DiscardValues()
{
	if (m_HaveValuesLoaded) {
		// free memory
		for (int i = 0; i < m_Rows; i ++)
			delete [] m_Values[i];
		delete [] m_Values;

		m_Values = NULL;

		m_HaveValuesLoaded = FALSE;

		m_MaxVal = -DBL_MAX;
		m_MinVal = DBL_MAX;
	}

	if (m_HaveRowLoaded) {
		delete [] m_RowValues;

		m_RowValues = NULL;

		m_HaveRowLoaded = FALSE;

		m_MaxVal = -DBL_MAX;
		m_MinVal = DBL_MAX;
	}
}

double CASCIIGridFile::ReadInternalValue(int row, int col)
{
	if (m_HaveValuesLoaded && row >= 0 && row < m_Rows && col >= 0 && col < m_Columns)
		return(m_Values[row][col]);

	return((double) m_NODATA);
}

BOOL CASCIIGridFile::LoadNextRow(void)
{
	char buf[256];
	int i, j;

	if (!m_HeaderValid)
		return(FALSE);

	// get rid of values...make sure we clear everything before setting up to read rows
	if (!m_HaveRowLoaded) {
		DiscardValues();

		// read header...saved	number of lines when header was read
		Rewind();	
		for (i = 0; i < m_HeaderLines; i ++)
			ReadASCIILine(buf);

		m_RowValues = new double[m_Columns];
	}

	if (m_RowValues) {
		// read data
		for (j = 0; j < m_Columns; j ++) {
			// read next value from file
			ReadValueWS(&m_RowValues[j]);
		}
		m_HaveRowLoaded = TRUE;

//		// get min/max values
//		m_MaxVal = -DBL_MAX;
//		m_MinVal = DBL_MAX;
//		for (j = 0; j < m_Columns; j ++) {
//			if (m_RowValues[j] != m_NODATA) {
//				if (m_RowValues[j] > m_MaxVal)
//					m_MaxVal = m_RowValues[j];
//				if (m_RowValues[j] < m_MinVal)
//					m_MinVal = m_RowValues[j];
//			}
//		}
	}
	
	return(m_HaveRowLoaded);
}
