// WaveformData.h: interface for the CWaveformData class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WAVEFORMDATA_H__9B9F2DCB_EF6E_4256_9E28_262E70CF532E__INCLUDED_)
#define AFX_WAVEFORMDATA_H__9B9F2DCB_EF6E_4256_9E28_262E70CF532E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define		TERRAPOINT		0
#define		OTHER			1

#ifdef _MSC_VER
#pragma pack(push)
#pragma pack(1)
#endif

typedef struct TWFHeaderStruct_1_0 {
	char Signature[4];
	unsigned short MajorVersion;
	unsigned short MinorVersion;
	unsigned short HeaderSize;
	unsigned int NumberOfWaveforms;
} TWF_HEADER_1_0;

typedef struct TWFDataBlockHeader {
	double UTCTime;
	float ScanAngle;
	unsigned short NumberOfLowRecords;
	unsigned short NumberOfHighRecords;
} TWF_DATABLOCK;

typedef struct TWFChanelRecord {
	float Range;
	unsigned short Intensity;
} TWF_CHANNELRECORD;

#ifdef _MSC_VER
#pragma pack(pop)
#endif

class CWaveformData  
{
public:
	void SkipWaveformData(TWF_DATABLOCK& Header);
	BOOL ReadWaveformLowData(TWF_DATABLOCK& Header, TWF_CHANNELRECORD* LowChannel);
	BOOL ReadWaveformHighData(TWF_DATABLOCK& Header, TWF_CHANNELRECORD* HighChannel);
	BOOL ReadWaveformHeader(TWF_DATABLOCK* Header);
	BOOL ReadWaveform(TWF_DATABLOCK& Header, TWF_CHANNELRECORD* LowChannel, TWF_CHANNELRECORD* HighChannel);
	unsigned int GetNumberOfWaveforms();
	void Rewind();
	CString m_FileName;
	BOOL Open(LPCTSTR FileName, int Format = 0);
	void Close();
	BOOL IsValid();
	CWaveformData();
	CWaveformData(LPCTSTR FileName, int Format = 0);
	virtual ~CWaveformData();

private:
	TWF_HEADER_1_0 m_Header;
	FILE* m_FileHandle;
	BOOL m_Valid;
};

#endif // !defined(AFX_WAVEFORMDATA_H__9B9F2DCB_EF6E_4256_9E28_262E70CF532E__INCLUDED_)
