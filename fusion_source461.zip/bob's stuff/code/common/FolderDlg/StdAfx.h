// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently

/////////////////////////////////////////////////////////////////////////////

#ifndef __FOLDERDLG_STDAFX_H__
#define __FOLDERDLG_STDAFX_H__

#if defined( _MSC_VER ) && ( _MSC_VER >= 1020 )
	#pragma once
#endif

/////////////////////////////////////////////////////////////////////////////

#ifndef		STRICT
	#define STRICT				// Strict type checking
#endif

#ifndef		VC_EXTRALEAN
	#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers
#endif

#ifndef		WINVER
	#define WINVER				0x0400
#endif

#ifndef		_WIN32_IE
	#define _WIN32_IE			0x0500
#endif

/////////////////////////////////////////////////////////////////////////////

#include < afxwin.h >			// MFC core and standard components
#include < afxext.h >			// MFC extensions
#include < afxdisp.h >			// MFC Automation classes
#include < afxdtctl.h >			// MFC support for Internet Explorer 4 Common Controls

#ifndef _AFX_NO_AFXCMN_SUPPORT
	#include < afxcmn.h >		// MFC support for Windows Common Controls
#endif

/////////////////////////////////////////////////////////////////////////////

#ifndef		CREATEPROCESS_MANIFEST_RESOURCE_ID
	#define CREATEPROCESS_MANIFEST_RESOURCE_ID		1 
#endif

#ifndef		RT_MANIFEST
	#define RT_MANIFEST								24
#endif

#ifndef		CS_DROPSHADOW
	#define CS_DROPSHADOW							0x00020000
#endif

/////////////////////////////////////////////////////////////////////////////

#ifndef		SAFE_DELETE
	#define SAFE_DELETE( p )	{ if( p ){ delete p; p = NULL; } }
#endif

#ifndef		SAFE_FREE
	#define SAFE_FREE( p )		{ if( p ){ free( (LPVOID)p ); p = NULL; } }
#endif

/////////////////////////////////////////////////////////////////////////////

// VC 7 or later add in the project properties (linker)
// shlwapi.dll;

#define _MSC_VER_60		1200
#define _MSC_VER_70		1300
#define _MSC_VER_71		1400

#if defined( _MSC_VER ) && ( _MSC_VER == _MSC_VER_60 ) && !defined( _DEBUG ) // VC6.0 release
	#pragma comment( lib, "Delayimp.lib" )
	#pragma comment( linker, "/IGNORE:4199"				)
	#pragma comment( linker, "/DelayLoad:shlwapi.dll"	)
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

/////////////////////////////////////////////////////////////////////////////
#endif // __FOLDERDLG_STDAFX_H__
/////////////////////////////////////////////////////////////////////////////
