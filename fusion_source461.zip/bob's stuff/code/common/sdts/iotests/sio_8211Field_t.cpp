//
// sio_8211Field_t.cpp
//
// $Id: sio_8211Field_t.cpp,v 1.7 1998/08/31 22:18:16 mcoletti Exp $
//

#include <cassert>

#include <memory.h>

#include <iostream>

#include <string>

#ifdef WIN32
using namespace std;
#endif

#include "io/sio_8211DirEntry.h"
#include "io/sio_8211Field.h"
#include "io/sio_8211DDRLeader.h"
#include "io/sio_8211Utils.h"
 

int 
main( int argc, char** argv )
{

  cout << argv[0] << " ... " << flush;

  {
    sio_8211Field field;

    // by default, a field should have no data, which naturally
    // has no length
    assert( field.getData() == 0 );
    assert( field.getDataLength() == 0 );

  }

  {
    // Now create a field that has a stated data length of 25
    long field_length = 25;
    sio_8211Field field( field_length );

    // Now insure that there isn't any data (because we didn't
    // add any data, but that the stated length is 25.
    assert( 0 == field.getData() );
    assert( field_length == field.getDataLength() );

    // Now copy over this field to make sure that its state
    // makes it over fine.   
    sio_8211Field another_field( field );

    assert( 0 == another_field.getData() );
    assert( field_length == another_field.getDataLength() );

  }
   
  { 
    // Now add bogus subfield data to the field

    sio_8211Field field;

    char field_data[4] = { 'f', 'o', 'o' };
    field_data[3] = sio_8211UnitTerminator;

    field.setData( field_data, 4 );

    // Now try and get it back -- they should be the same		
    char value[4];
    long position = 0;

    assert( true == field.getVariableSubfield( value, position) );
    assert( memcmp( field_data, value, 4 ) );

    // the position should be incremented to the 'start' of the next subfield
    assert( position == 4 );
   
  }

  {
    //  Test the ctor that takes a buffer argument.

    string buffData( "ABCDEFG" );
    buffData += sio_8211UnitTerminator;

    sio_Buffer buffer( buffData.c_str(), buffData.length() );
    sio_8211Field field( buffer );
		
    //  Now lets see if things match
    const char* buffDataOut = field.getData();
    long buffLengthOut = field.getDataLength();

    assert( 0 == memcmp( buffDataOut, 
			 buffData.c_str(), 
			 buffLengthOut ));

    assert( buffLengthOut == buffData.length() );
	
  }

  {
    // test getField
		
    sio_8211Field field;

    string data = "ABCDEFGH";

    field.setData( data.c_str(), data.length() );

    sio_Buffer buffer = field.getField();

    //  get buffer data from new buffer and test

    const char* buffData = buffer.data();
    long buffLength = buffer.length();
	
    assert( buffLength == data.length() );
    assert( 0 == memcmp( buffData, data.c_str(), data.length() ));
	
  }

  cout << "ok\n";

  return 0;

}


