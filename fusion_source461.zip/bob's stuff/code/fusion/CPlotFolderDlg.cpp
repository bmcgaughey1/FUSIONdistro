// CPlotFolderDlg.cpp : implementation file
//
// When I initially created this class, I set the base class incorrectly. I could not get the dialog to link to a button click.
// My solution was to create a new class with the correct base class and then copy all the code from the old class to the new class. I might 
// have missed some name changes so if there are references to names ending in "2", this is from the second class (which I tried to rename to drop
// the "2"). 
//
#include "stdafx.h"
#include "fusion.h"
#include "CPlotFolderDlg.h"


// CPlotFolderDlg dialog

IMPLEMENT_DYNAMIC(CPlotFolderDlg, CDialog)

CPlotFolderDlg::CPlotFolderDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_PLOTFOLDERDLG, pParent)
	, m_PlotFileFolder(_T(""))
	, m_PlotGroundFolder(_T(""))
{

}

CPlotFolderDlg::~CPlotFolderDlg()
{
}

void CPlotFolderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_PLOTFILEFOLDER, m_PlotFileFolder);
	DDX_Text(pDX, IDC_GROUNDFILEFOLDER, m_PlotGroundFolder);
}


BEGIN_MESSAGE_MAP(CPlotFolderDlg, CDialog)
	ON_BN_CLICKED(IDC_PLOTFILEFOLDERBROWSE, &CPlotFolderDlg::OnBnClickedPlotfilefolderbrowse)
	ON_BN_CLICKED(IDC_GROUNDFILEFOLDERBROWSE, &CPlotFolderDlg::OnBnClickedGroundfilefolderbrowse)
END_MESSAGE_MAP()


// CPlotFolderDlg message handlers


void CPlotFolderDlg::OnBnClickedPlotfilefolderbrowse()
{
	UpdateData();

	CString m_strFolderPath = _T("c:\\");
	CString m_strDisplayName;
	m_strDisplayName.Empty();

	CFolderDialog dlg(_T("Load plot files from:"), m_strFolderPath, this, BIF_NEWDIALOGSTYLE);

	if (!m_PlotFileFolder.IsEmpty())
		dlg.SetSelectedFolder(m_PlotFileFolder);

	if (dlg.DoModal() == IDOK) {
		m_PlotFileFolder = dlg.GetFolderPath();
	}

	UpdateData(FALSE);
}


void CPlotFolderDlg::OnBnClickedGroundfilefolderbrowse()
{
	UpdateData();

	CString m_strFolderPath = _T("c:\\");
	CString m_strDisplayName;
	m_strDisplayName.Empty();

	CFolderDialog dlg(_T("Load ground model files from:"), m_strFolderPath, this, BIF_NEWDIALOGSTYLE);

	if (!m_PlotGroundFolder.IsEmpty())
		dlg.SetSelectedFolder(m_PlotGroundFolder);

	if (dlg.DoModal() == IDOK) {
		m_PlotGroundFolder = dlg.GetFolderPath();
	}

	UpdateData(FALSE);
}
