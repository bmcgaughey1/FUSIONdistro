// pointset.cpp: implementation of the CPointSet class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "datafile.h"
#include "pointset.h"
#include "DataIndex.h"
#include "datafile.h"
#include "lidardata_laslib.h"
#include <io.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

int ComparePointRowColumn(const void *arg1, const void *arg2)
{
	// compare column
	if (((PS_POINT_INFO*) arg1)->Col < ((PS_POINT_INFO*) arg2)->Col)
		return(-1);
	else if (((PS_POINT_INFO*) arg1)->Col > ((PS_POINT_INFO*) arg2)->Col)
		return(1);
	else {
		// compare row
		if (((PS_POINT_INFO*) arg1)->Row < ((PS_POINT_INFO*) arg2)->Row)
			return(-1);
		else if (((PS_POINT_INFO*) arg1)->Row > ((PS_POINT_INFO*) arg2)->Row)
			return(1);
		else
			return(0);
	}
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPointSet::CPointSet()
{
	m_Valid = false;
	m_FileCount = 0;
	m_FileSpec.Empty();
	m_FileInfoList = NULL;
	m_Points = NULL;

	ResetFilters();
}

CPointSet::CPointSet(LPCTSTR FileSpec)
{
	m_Valid = false;
	m_FileCount = 0;
	m_FileSpec.Empty();
	m_FileInfoList = NULL;
	m_Points = NULL;
	
	ResetFilters();

	ExpandFileSpecToList(FileSpec);
	if (!CreateOverview())
		Empty();
}

CPointSet::~CPointSet()
{
	Empty();
}

void CPointSet::Empty()
{
	// remove list of files
	m_FileList.RemoveAll();

	if (m_FileInfoList)
		delete [] m_FileInfoList;

	m_FileInfoList = NULL;

	UnloadPoints();

	m_Valid = false;
}

void CPointSet::UnloadPoints()
{
	if (m_Points)
		delete [] m_Points;

	m_Points = NULL;
	m_PointsInMemory = 0;
}

int CPointSet::GetFileCount()
{
	return(m_FileCount);
}

__int64 CPointSet::GetPointsInMemory()
{
	return(m_PointsInMemory);
}

bool CPointSet::IsValid()
{
	return(m_Valid);
}

bool CPointSet::HaveValidSet()
{
	if (m_PointCount >= 0)
		return(true);

	return(false);
}

int CPointSet::ExpandFileSpecToList(LPCTSTR FileSpec)
{
	CString csTemp;

	// check for matching files
	m_FileCount = CountFilesMatchingSpec(FileSpec);

	if (m_FileCount) {
		// we have matching files...save FileSpec and build list of files
		m_FileSpec = FileSpec;
		m_FileList.RemoveAll();
		m_FileList.SetSize(m_FileCount);
		if (m_FileCount > 1 || (m_FileCount == 1 && m_FileSpec.FindOneOf("*?") >= 0)) {
			CFileFind finder;
			// multiple files or a single match to a wild card specifier
			BOOL bWorking = finder.FindFile(m_FileSpec);
			m_FileCount = 0;
			while (bWorking) {
				bWorking = finder.FindNextFile();
				csTemp = finder.GetFilePath();
				m_FileList.SetAt(m_FileCount, csTemp);
				m_FileCount ++;
			}
		}
		else {
			// see if we have a text file...if so, assume it contains a list of files to add
			CString csTemp = m_FileSpec;
			csTemp.MakeLower();
			if (csTemp.Find(".txt") >= 0) {
				// read strings, make sure you can access the file and add to file list
				char buf[2048];
				CDataFile dat(m_FileSpec);
				if (dat.IsValid()) {
					m_FileCount = 0;
					while (dat.ReadASCIILine(buf)) {
						if (_access(buf, 0) == 0) {
							m_FileList.Add(buf);
							m_FileCount ++;
						}
					}
					dat.Close();
				}
			}
			else {
				// only 1 file directly specified (no wild card characters)
				m_FileList.Add(m_FileSpec);
			}
		}
		m_Valid = true;
	}

	return(m_FileCount);
}

int CPointSet::CountFilesMatchingSpec(LPCSTR FileSpec)
{
	if (FileSpec[0] == '\0')
		return(0);

	CFileFind finder;
	int FileCount = 0;
	BOOL bWorking = finder.FindFile(FileSpec);
	while (bWorking) {
		bWorking = finder.FindNextFile();
		FileCount ++;
	}

	return(FileCount);
}

bool CPointSet::CreateOverview()
{
	if (!IsValid())
		return(false);

	// read point data files to get extent and point count

	// initialize
	m_OverallDataExtent.InitializeZ();
	m_OverallPointCount = 0;

	CLidarData ldat;
	CDataIndex Index;
	LIDARRETURN pt;

	// remove any existing file info
	if (m_FileInfoList)
		delete [] m_FileInfoList;

	// allocate memory for list of file info
	m_FileInfoList = new DATAFILEINFO[m_FileCount];
	if (m_FileInfoList) {
		// step through data files
		for (int i = 0; i < m_FileCount; i ++) {
			// initialize info for file
			m_FileInfoList[i].Extent.InitializeZ();
			m_FileInfoList[i].PointCount = 0;
			m_FileInfoList[i].Active = true;
			m_FileInfoList[i].FileName = m_FileList[i];

			// see if we have index files...read extent and number of points from index
			if (Index.Open(m_FileList[i])) {
				// update overall min/max
				m_OverallDataExtent.CompareExtentZ(Index.m_Header.MinX, Index.m_Header.MinY, Index.m_Header.MinZ, Index.m_Header.MaxX, Index.m_Header.MaxY, Index.m_Header.MaxZ);

				// update file min/max
				m_FileInfoList[i].Extent.SetAllZ(Index.m_Header.MinX, Index.m_Header.MinY, Index.m_Header.MinZ, Index.m_Header.MaxX, Index.m_Header.MaxY, Index.m_Header.MaxZ);

				// update point count
				m_FileInfoList[i].PointCount = Index.m_Header.TotalPointsIndexed;

				m_OverallPointCount += Index.m_Header.TotalPointsIndexed;

				Index.Close();
			}
			else {
				// open the point file
				ldat.Open(m_FileList[i]);
				if (ldat.IsValid()) {
					// see if file is LAS format... read extent and point cound from header
					if (ldat.GetFileFormat() == LASDATA) {
						if (ldat.m_HaveLASZIP_DLL) {
							// update overall min/max
							m_OverallDataExtent.CompareExtentZ(ldat.lasdll_header->min_x, ldat.lasdll_header->min_y, ldat.lasdll_header->min_z, ldat.lasdll_header->max_x, ldat.lasdll_header->max_y, ldat.lasdll_header->max_z);

							// update file min/max
							m_FileInfoList[i].Extent.CompareExtentZ(ldat.lasdll_header->min_x, ldat.lasdll_header->min_y, ldat.lasdll_header->min_z, ldat.lasdll_header->max_x, ldat.lasdll_header->max_y, ldat.lasdll_header->max_z);

							// update point count
							m_FileInfoList[i].PointCount = ldat.lasdll_header->number_of_point_records;

							m_OverallPointCount += ldat.lasdll_header->number_of_point_records;
						}
						else {
							// update overall min/max
							m_OverallDataExtent.CompareExtentZ(ldat.m_LASFile.Header.MinX, ldat.m_LASFile.Header.MinY, ldat.m_LASFile.Header.MinZ, ldat.m_LASFile.Header.MaxX, ldat.m_LASFile.Header.MaxY, ldat.m_LASFile.Header.MaxZ);

							// update file min/max
							m_FileInfoList[i].Extent.CompareExtentZ(ldat.m_LASFile.Header.MinX, ldat.m_LASFile.Header.MinY, ldat.m_LASFile.Header.MinZ, ldat.m_LASFile.Header.MaxX, ldat.m_LASFile.Header.MaxY, ldat.m_LASFile.Header.MaxZ);

							// update point count
							m_FileInfoList[i].PointCount = ldat.m_LASFile.Header.NumberOfPointRecords;

							m_OverallPointCount += ldat.m_LASFile.Header.NumberOfPointRecords;
						}
					}
					else {
						// no index and no header...read all points...relatively slow
						while (ldat.ReadNextRecord(&pt)) {
							// update file min/max
							m_FileInfoList[i].Extent.ComparePtZ(pt.X, pt.Y, pt.Elevation);

							m_FileInfoList[i].PointCount ++;
						}

						// update overall point count
						m_OverallPointCount += m_FileInfoList[i].PointCount;

						// update overall min/max
						m_OverallDataExtent.CompareExtentZ(m_FileInfoList[i].Extent);
					}
					ldat.Close();
				}
			}
		}
	}
	else {
		// couldn't create list of data files
		return(false);
	}

	return(true);
}


bool CPointSet::GetOverallExtent(CSpatialExtentZ& extent)
{
	if (!IsValid())
		return(false);

	extent = m_OverallDataExtent;

	return(true);
}

__int64 CPointSet::GetOverallPointCount()
{
	if (IsValid())
		return(m_OverallPointCount);

	return((__int64) -1);
}

bool CPointSet::GetFileInfo(int index, DATAFILEINFO &info)
{
	if (!IsValid() || index >= m_FileCount || index < 0)
		return(false);

	// get the info
	info.Active = m_FileInfoList[index].Active;
	info.Extent = m_FileInfoList[index].Extent;
	info.FileName = m_FileInfoList[index].FileName;
	info.PointCount = m_FileInfoList[index].PointCount;

	return(true);
}

void CPointSet::EnableAOIFilter(double minx, double miny, double maxx, double maxy)
{
	if (IsValid()) {
		m_AOI.Active = true;
		m_AOI.Extent.SetAll(minx, miny, maxx, maxy);

		// go through data files and turn off those outside the AOI
		for (int i = 0; i < m_FileCount; i ++) {
			m_FileInfoList[i].Active = m_AOI.Extent.DoesRectangleOverlap(m_FileInfoList[i].Extent);
		}

		m_PointCount = -1;
	}
}

void CPointSet::EnableReturnNumberFilter(int r1, int r2, int r3, int r4, int r5, int r6, int r7, int r8, int r9, int r10, int r11, int r12, int r13, int r14, int r15)
{
	if (IsValid()) {
		m_RN.Active = true;
		m_RN.ReturnsToKeep[0] = r1;
		m_RN.ReturnsToKeep[1] = r2;
		m_RN.ReturnsToKeep[2] = r3;
		m_RN.ReturnsToKeep[3] = r4;
		m_RN.ReturnsToKeep[4] = r5;
		m_RN.ReturnsToKeep[5] = r6;
		m_RN.ReturnsToKeep[6] = r7;
		m_RN.ReturnsToKeep[7] = r8;
		m_RN.ReturnsToKeep[8] = r9;
		m_RN.ReturnsToKeep[9] = r10;
		m_RN.ReturnsToKeep[10] = r11;
		m_RN.ReturnsToKeep[11] = r12;
		m_RN.ReturnsToKeep[12] = r13;
		m_RN.ReturnsToKeep[13] = r14;
		m_RN.ReturnsToKeep[14] = r15;

		m_PointCount = -1;
	}
}

void CPointSet::EnableClassFilter(int *classes, int numberofclasses)
{
	int i;

	if (IsValid()) {
		m_CLASS.Active = true;

		for (i = 0; i < numberofclasses; i ++)
			m_CLASS.ClassesToKeep[i] = 0;

		for (i = 0; i < numberofclasses; i ++) {
			m_CLASS.ClassesToKeep[i] = classes[i];
		}

		m_PointCount = -1;
	}
}

void CPointSet::ResetFilters()
{
	m_AOI.Active = false;
	m_RN.Active = false;
	m_CLASS.Active = false;

	m_PointCount = -1;

	// reset flags on files
	for (int i = 0; i < m_FileCount; i ++) {
		m_FileInfoList[i].Active = true;
	}

	IgnoreWithheldPoints();
}

void CPointSet::IncludeWithheldPoints()
{
	m_IgnoreWithheldPoints = false;
}

void CPointSet::IgnoreWithheldPoints()
{
	m_IgnoreWithheldPoints = true;
}

__int64 CPointSet::PrecountPointsInSet(bool UseIndex)
{
	CLidarData ldat;
	CDataIndex Index;
	LIDARRETURN pt;

	m_PointCount = 0;
	m_Extent.InitializeZ();

	if (IsValid()) {
		// see if we have any filters...if not, the subset will contain all points
		if (!m_AOI.Active && !m_RN.Active && !m_CLASS.Active) {
			m_PointCount = m_OverallPointCount;
		}
		else {
			// step through files
			for (int i = 0; i < m_FileCount; i ++) {
				if (m_FileInfoList[i].Active) {
					// open the point file...if AOI is active, the file overlaps the AOI
					ldat.Open(m_FileInfoList[i].FileName);
					if (ldat.IsValid()) {
						// see if we have index files...only an advantage when we have an active AOI
						if (UseIndex && Index.Open(m_FileInfoList[i].FileName) && m_AOI.Active) {
							long offset;

							// read points through the index using the AOI
							while ((offset = Index.JumpToNextPointInRange(m_AOI.Extent.m_MinX, m_AOI.Extent.m_MinY, m_AOI.Extent.m_MaxX, m_AOI.Extent.m_MaxX)) >= 0) {
								ldat.SetPosition(offset, SEEK_SET);
								ldat.ReadNextRecord(&pt);

								// check filters...AOI is aleady done
								if (m_RN.Active) {
									if (pt.ReturnNumber < 0 || pt.ReturnNumber > 15)
										continue;
									if (m_RN.ReturnsToKeep[pt.ReturnNumber - 1] == 0)
										continue;
								}

								if (m_CLASS.Active) {
									if (ldat.m_HaveLASZIP_DLL) {
										if (ldat.lasdll_point->classification >= 0 && ldat.lasdll_point->classification < 255) {
											if (m_CLASS.ClassesToKeep[ldat.lasdll_point->classification] == 0)
												continue;
										}
										else
											continue;
									}
									else {
										if (ldat.m_LASFile.PointRecord.Classification >= 0 && ldat.m_LASFile.PointRecord.Classification < 255) {
											if (m_CLASS.ClassesToKeep[ldat.m_LASFile.PointRecord.Classification] == 0)
												continue;
										}
										else
											continue;
									}
								}

								// count point
								m_PointCount ++;

								m_Extent.ComparePtZ(pt.X, pt.Y, pt.Elevation);
							}

							Index.Close();
						}
						else {
							// read all points and use filters
							while (ldat.ReadNextRecord(&pt)) {
								// check filters
								if (m_AOI.Active) {
									m_AOI.Extent.IsPointWithin(pt.X, pt.Y);
								}

								if (m_RN.Active) {
									if (pt.ReturnNumber < 0 || pt.ReturnNumber > 15)
										continue;
									if (m_RN.ReturnsToKeep[pt.ReturnNumber - 1] == 0)
										continue;
								}

								if (m_CLASS.Active) {
									if (ldat.m_HaveLASZIP_DLL) {
										if (ldat.lasdll_point->classification >= 0 && ldat.lasdll_point->classification < 255) {
											if (m_CLASS.ClassesToKeep[ldat.lasdll_point->classification] == 0)
												continue;
										}
										else
											continue;
									}
									else {
										if (ldat.m_LASFile.PointRecord.Classification >= 0 && ldat.m_LASFile.PointRecord.Classification < 255) {
											if (m_CLASS.ClassesToKeep[ldat.m_LASFile.PointRecord.Classification] == 0)
												continue;
										}
										else
											continue;
									}
								}

								// count point
								m_PointCount ++;

								m_Extent.ComparePtZ(pt.X, pt.Y, pt.Elevation);
							}
						}

						ldat.Close();

					}
				}
			}
		}
	}
	else 
		m_PointCount = -1;

	return(m_PointCount);
}

__int64 CPointSet::LoadPointsInSet(bool UseIndex)
{
	CLidarData ldat;
	CDataIndex Index;
	LIDARRETURN pt;

	m_PointsInMemory = 0;
	m_Extent.InitializeZ();

	if (IsValid()) {
		if (m_OverallPointCount <= 0) {
			m_PointsInMemory = 0;
		}
		else {
			// see if we have any filters...if not, the subset will contain all points
			if (!m_AOI.Active && !m_RN.Active && !m_CLASS.Active) {
				// read all points
				m_PointCount = m_OverallPointCount;
			}

			// if we have at least 1 active filter, we should have a subset count...if not, count points
			if (m_PointCount < 0) {
				PrecountPointsInSet(UseIndex);
			}

			if (m_PointCount >= 0) {
				// allocate memory and load points
				// get amount of available memory
				MEMORYSTATUS stat;
				GlobalMemoryStatus(&stat);
				unsigned __int64 ExpectedMemoryUsed = (sizeof(PS_POINT_INFO) * m_PointCount);

				// check available memory against number of points
				if (stat.dwAvailVirtual >= ExpectedMemoryUsed + 10000) {
					m_Points = new PS_POINT_INFO[(size_t) m_PointCount];
				}
				else {
					m_Points = NULL;
				}

				if (m_Points) {
					unsigned char Class;

					// step through files and read points matching filters
					for (int i = 0; i < m_FileCount; i ++) {
						if (m_FileInfoList[i].Active) {
							// open the point file...if AOI is active, the file overlaps the AOI
							ldat.Open(m_FileInfoList[i].FileName);
							if (ldat.IsValid()) {
								// see if we have index files...only an advantage when we have an active AOI
								if (UseIndex && Index.Open(m_FileInfoList[i].FileName) && m_AOI.Active) {
									long offset;

									// read points through the index using the AOI
									while ((offset = Index.JumpToNextPointInRange(m_AOI.Extent.m_MinX, m_AOI.Extent.m_MinY, m_AOI.Extent.m_MaxX, m_AOI.Extent.m_MaxX)) >= 0) {
										ldat.SetPosition(offset, SEEK_SET);
										ldat.ReadNextRecord(&pt);

										// check filters...AOI is aleady done
										if (m_RN.Active) {
											if (pt.ReturnNumber < 0 || pt.ReturnNumber > 15)
												continue;
											if (m_RN.ReturnsToKeep[pt.ReturnNumber - 1] == 0)
												continue;
										}

										if (m_CLASS.Active) {
											if (ldat.m_HaveLASZIP_DLL) {
												if (ldat.lasdll_point->classification >= 0 && ldat.lasdll_point->classification < 255) {
													Class = ldat.lasdll_point->classification;
												}
												else
													continue;
											}
											else {
												if (ldat.m_LASFile.PointRecord.Classification >= 0 && ldat.m_LASFile.PointRecord.Classification < 255) {
													Class = ldat.m_LASFile.PointRecord.Classification;
												}
												else
													continue;
											}
											if (m_CLASS.ClassesToKeep[Class] == 0)
												continue;
										}

										// save point to memory
										m_Points[m_PointsInMemory].X = pt.X;
										m_Points[m_PointsInMemory].Y = pt.Y;
										m_Points[m_PointsInMemory].Elevation = pt.Elevation;
										m_Points[m_PointsInMemory].Return = pt.ReturnNumber;
										m_Points[m_PointsInMemory].Class = Class;
										m_Points[m_PointsInMemory].Status = 0;

										// count point
										m_PointsInMemory ++;

										m_Extent.ComparePtZ(pt.X, pt.Y, pt.Elevation);
									}

									Index.Close();
								}
								else {
									// read all points and use filters
									while (ldat.ReadNextRecord(&pt)) {
										// check filters
										if (m_AOI.Active) {
											m_AOI.Extent.IsPointWithin(pt.X, pt.Y);
										}

										if (m_RN.Active) {
											if (pt.ReturnNumber < 0 || pt.ReturnNumber > 15)
												continue;
											if (m_RN.ReturnsToKeep[pt.ReturnNumber - 1] == 0)
												continue;
										}

										if (m_CLASS.Active) {
											if (ldat.m_HaveLASZIP_DLL) {
												if (ldat.lasdll_point->classification >= 0 && ldat.lasdll_point->classification < 255) {
													Class = ldat.lasdll_point->classification;
												}
												else
													continue;
											}
											else {
												if (ldat.m_LASFile.PointRecord.Classification >= 0 && ldat.m_LASFile.PointRecord.Classification < 255) {
													Class = ldat.m_LASFile.PointRecord.Classification;
												}
												else
													continue;
											}
											if (m_CLASS.ClassesToKeep[Class] == 0)
												continue;
										}

										// save point to memory
										m_Points[m_PointsInMemory].X = pt.X;
										m_Points[m_PointsInMemory].Y = pt.Y;
										m_Points[m_PointsInMemory].Elevation = pt.Elevation;
										m_Points[m_PointsInMemory].Return = pt.ReturnNumber;
										m_Points[m_PointsInMemory].Class = Class;
										m_Points[m_PointsInMemory].Status = 0;

										// count point
										m_PointsInMemory ++;

										m_Extent.ComparePtZ(pt.X, pt.Y, pt.Elevation);
									}
								}

								ldat.Close();

							}
						}
					}
				}
			}
		}
	}
	else 
		m_PointsInMemory = -1;

	return(m_PointsInMemory);
}


bool CPointSet::Optimize(int IntendedUse)
{
	// rearrange the points in the subset based on the intended use

	if (!IsValid())
		return(false);

	if (!m_PointsInMemory)
		return(false);

	if (IntendedUse == PROXIMITY) {
		// rearrange points to facilitate finding the points close to a given point
		for (__int64 i = 0; i < m_PointsInMemory; i ++) {
			// compute row and column...may want to eventually use a lower resolution XY coordinate relative to the cell corner
			m_Points[i].Col = (unsigned int) (m_Points[i].X - m_Extent.m_MinX / 25.5);
			m_Points[i].Row = (unsigned int) (m_Points[i].Y - m_Extent.m_MinY / 25.5);

			// sort by column and row values
			qsort(m_Points, (size_t) m_PointsInMemory, sizeof(PS_POINT_INFO), ComparePointRowColumn);
		}
	}

	return(false);
}

__int64 CPointSet::RetrieveProximitySubset(PS_POINT_INFO *pts, __int64 maxpts, __int64 focalpt, double radius)
{
	_int64 PointsInSubset = 0;

	if (!IsValid())
		return(0);

	if (!m_PointsInMemory)
		return(0);

	// assumes pts array has enough room for maxpts points
	// focalpt is the index for the reference point


	// get the starting cell from the focalpt
	int focal_col = m_Points[focalpt].Col;
	int focal_row = m_Points[focalpt].Row;

	// figure out how far (in cells) we need to look
	int cell_radius = (int) ((radius + 25.5 / 2.0) / 25.5);

	// figure out subgrid LL corner, width and height
	int LL_col = focal_col - cell_radius;
	int LL_row = focal_row - cell_radius;

	// read points until we get to the LL cell

	// ??? how do we limit the return set to the maxpts closest points to focalpt???


	// return the actual number of points in the subset
	return(PointsInSubset);
}
