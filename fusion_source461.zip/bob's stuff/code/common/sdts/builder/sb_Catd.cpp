//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//
// $Id: sb_Catd.cpp,v 1.4 1998/09/01 22:10:09 mcoletti Exp $
//

#include "builder/sb_Catd.h"



#include <iostream>
#include <strstream>

#include <limits.h>
#include <float.h>

#ifndef INCLUDED_SB_UTILS_H
#include "builder/sb_Utils.h"
#endif

#ifndef INCLUDED_SB_FOREIGNID_H
#include "builder/sb_ForeignID.h"
#endif

#ifndef INCLUDED_SC_RECORD_H
#include "container/sc_Record.h"
#endif

#ifndef INCLUDED_SC_FIELD_H
#include "container/sc_Field.h"
#endif

#ifndef INCLUDED_SC_SUBFIELD_H
#include "container/sc_Subfield.h"
#endif

#ifndef INCLUDED_SIO_8211CONVERTER_H
#include "io/sio_8211Converter.h"
#endif



static const char* _ident = "$Id: sb_Catd.cpp,v 1.4 1998/09/01 22:10:09 mcoletti Exp $";

// Strings and integers are initialized with these values; they are used
// to indicate whether a given module value has been assigned a value or not.

// (XXX I arbitrarily chose 0x4 as the sentinal value.  I hate ad hoc crap.)

static const string  UNVALUED_STRING(1, static_cast<string::value_type>(0x4) );

static const long    UNVALUED_LONG   = INT_MIN;

static const double  UNVALUED_DOUBLE = DBL_MAX;

struct sb_Catd_Imp
{
  string   _Name;
  string   _Type;
  string   _Volume;
  string   _File;
  string   _Record;
  string   _External;
  string   _ModuleVersion;
  string   _Comment;


  sb_Catd_Imp()
    : 
    _Name( UNVALUED_STRING ),
    _Type( UNVALUED_STRING ),
    _Volume( UNVALUED_STRING ),
    _File( UNVALUED_STRING ),
    _Record( UNVALUED_STRING ),
    _External( UNVALUED_STRING ),
    _ModuleVersion( UNVALUED_STRING ),
    _Comment( UNVALUED_STRING )
  {}

};


sb_Catd::sb_Catd()
  : _imp( new sb_Catd_Imp() )
{
  setMnemonic("CATD");
  setID( 1 );


  // insert static initializers

} // Catd ctor


sb_Catd::~sb_Catd()
{
  delete _imp;
} // Catd dtor




static sio_8211Converter_I converter_I; // XXX should define these in
static sio_8211Converter_A converter_A; // XXX sio_8211Converter.h
static sio_8211Converter_R converter_R;
static sio_8211Converter_C converter_C;

static sio_8211Schema _schema; // module specific schema

static
void
_build_schema( sio_8211Schema& schema )
{
  schema.clear();               // make sure we are starting with clean schema

  schema.push_back( sio_8211FieldFormat() );

  sio_8211FieldFormat& field_format = schema.back();

  field_format.setDataStructCode( sio_8211FieldFormat::vector );
  field_format.setDataTypeCode( sio_8211FieldFormat::mixed_data_type );
  field_format.setName( "Catalog/Directory" );
  field_format.setTag( "CATD" );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "MODN" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "RCID" );
  field_format.back().setType( sio_8211SubfieldFormat::I );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_I );

  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "NAME" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "TYPE" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


//  field_format.push_back( sio_8211SubfieldFormat() );

//  field_format.back().setLabel( "VOLM" );
//  field_format.back().setType( sio_8211SubfieldFormat::A );
//  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
//  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "FILE" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


//  field_format.push_back( sio_8211SubfieldFormat() );
//
//  field_format.back().setLabel( "RECD" );
//  field_format.back().setType( sio_8211SubfieldFormat::A );
//  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
//  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "EXTR" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


  field_format.push_back( sio_8211SubfieldFormat() );

  field_format.back().setLabel( "MVER" );
  field_format.back().setType( sio_8211SubfieldFormat::A );
  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
  field_format.back().setConverter( &converter_A );


//  field_format.push_back( sio_8211SubfieldFormat() );
//
//  field_format.back().setLabel( "COMT" );
//  field_format.back().setType( sio_8211SubfieldFormat::A );
//  field_format.back().setFormat( sio_8211SubfieldFormat::variable );
//  field_format.back().setConverter( &converter_A );


} // _build_schema


static
bool
_ingest_record( sb_Catd& catd, sb_Catd_Imp &catd_imp, sc_Record const& record )
{

  // Make sure we have a record from an
  // External Spatial Reference module.

  sc_FieldCntr::const_iterator curfield;

  if ( ! sb_Utils::getFieldByMnem( record,"CATD",curfield) )
  {
#ifdef SDTSXX_DEBUG
    cerr << "sb_Catd::sb_Catd(sc_Record const&): "
         << "Not an catalog/directory record.";
    cerr << endl;
#endif
    return false;
  }


  // We have a primary field from a  module. Start// picking it apart.

  sc_SubfieldCntr::const_iterator cursubfield;

  string tmp_str;
  long   tmp_int;


  // MODN
  if (sb_Utils::getSubfieldByMnem(*curfield,"MODN",cursubfield))
  {
    cursubfield->getA( tmp_str );
    catd.setMnemonic( tmp_str );
  }


  // RCID
  if (sb_Utils::getSubfieldByMnem(*curfield,"RCID",cursubfield))
  {
    cursubfield->getI( tmp_int );
    catd.setID( tmp_int );
  }


  // NAME
  if (sb_Utils::getSubfieldByMnem(*curfield,"NAME",cursubfield))
  {
    cursubfield->getA( catd_imp._Name);
  }
  else
  {
    return false;
  }


  // TYPE
  if (sb_Utils::getSubfieldByMnem(*curfield,"TYPE",cursubfield))
  {
    cursubfield->getA( catd_imp._Type);
  }
  else
  {
    return false;
  }


  // VOLM
//  if (sb_Utils::getSubfieldByMnem(*curfield,"VOLM",cursubfield))
//  {
//    cursubfield->getA( catd_imp._Volume);
//  }
//  else
//  {
//    return false;
//  }


  // FILE
  if (sb_Utils::getSubfieldByMnem(*curfield,"FILE",cursubfield))
  {
    cursubfield->getA( catd_imp._File);
  }
  else
  {
    return false;
  }


  // RECD
//  if (sb_Utils::getSubfieldByMnem(*curfield,"RECD",cursubfield))
//  {
//    cursubfield->getA( catd_imp._Record);
//  }
//  else
//  {
//    return false;
//  }


  // EXTR
  if (sb_Utils::getSubfieldByMnem(*curfield,"EXTR",cursubfield))
  {
    cursubfield->getA( catd_imp._External);
  }
  else
  {
    return false;
  }


  // MVER
  if (sb_Utils::getSubfieldByMnem(*curfield,"MVER",cursubfield))
  {
    cursubfield->getA( catd_imp._ModuleVersion);
  }
  else
  {
    return false;
  }


  // COMT
//  if (sb_Utils::getSubfieldByMnem(*curfield,"COMT",cursubfield))
//  {
//    cursubfield->getA( catd_imp._Comment);
//  }
//  else
//  {
//    return false;
//  }


  return true;


} // _ingest_record




bool
sb_Catd::getName( string& val ) const
{
  if ( _imp->_Name == UNVALUED_STRING )
    return false;

  val = _imp->_Name;

  return true;
} // sb_Catd::getName


bool
sb_Catd::getType( string& val ) const
{
  if ( _imp->_Type == UNVALUED_STRING )
    return false;

  val = _imp->_Type;

  return true;
} // sb_Catd::getType


bool
sb_Catd::getVolume( string& val ) const
{
  if ( _imp->_Volume == UNVALUED_STRING )
    return false;

  val = _imp->_Volume;

  return true;
} // sb_Catd::getVolume


bool
sb_Catd::getFile( string& val ) const
{
  if ( _imp->_File == UNVALUED_STRING )
    return false;

  val = _imp->_File;

  return true;
} // sb_Catd::getFile


bool
sb_Catd::getRecord( string& val ) const
{
  if ( _imp->_Record == UNVALUED_STRING )
    return false;

  val = _imp->_Record;

  return true;
} // sb_Catd::getRecord


bool
sb_Catd::getExternal( string& val ) const
{
  if ( _imp->_External == UNVALUED_STRING )
    return false;

  val = _imp->_External;

  return true;
} // sb_Catd::getExternal


bool
sb_Catd::getModuleVersion( string& val ) const
{
  if ( _imp->_ModuleVersion == UNVALUED_STRING )
    return false;

  val = _imp->_ModuleVersion;

  return true;
} // sb_Catd::getModuleVersion


bool
sb_Catd::getComment( string& val ) const
{
  if ( _imp->_Comment == UNVALUED_STRING )
    return false;

  val = _imp->_Comment;

  return true;
} // sb_Catd::getComment


bool
sb_Catd::getSchema( sio_8211Schema& schema ) const
{
  // If the schema hasn't been
  // initialized, please do so.

  if ( _schema.empty() )
  {
    _build_schema( _schema );
  }

  if ( _schema.empty() )   // oops ... something screwed up
  {
    return false;
  }

  schema = _schema;

  return true;

} // sb_Catd::getSchema




bool
sb_Catd::getRecord( sc_Record & record ) const
{
  record.clear();               // start with a clean slate

  // first field, which contains module name and record number

  record.push_back( sc_Field() );

  record.back().setMnemonic( "CATD" );

  record.back().setName( "Catalog/Directory" );

  string tmp_str;

  getMnemonic( tmp_str );
  sb_Utils::add_subfield( record.back(), "MODN", tmp_str );
  sb_Utils::add_subfield( record.back(), "RCID", getID() );

  if ( getName( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"NAME", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "NAME", sc_Subfield::is_A );
  }


  if ( getType( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"TYPE", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "TYPE", sc_Subfield::is_A );
  }

/*
  if ( getVolume( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"VOLM", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "VOLM", sc_Subfield::is_A );
  }
*/

  if ( getFile( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"FILE", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "FILE", sc_Subfield::is_A );
  }

/*
  if ( getRecord( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"RECD", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "RECD", sc_Subfield::is_A );
  }
*/

  if ( getExternal( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"EXTR", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "EXTR", sc_Subfield::is_A );
  }


  if ( getModuleVersion( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"MVER", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "MVER", sc_Subfield::is_A );
  }

/*
  if ( getComment( tmp_str ) )
  {
    sb_Utils::add_subfield( record.back(),"COMT", tmp_str );
  }
  else
  {
    sb_Utils::add_empty_subfield( record.back(), "COMT", sc_Subfield::is_A );
  }
*/

  return true;


} // Catd::getRecord




bool
sb_Catd::setName( string const& val )
{
  _imp->_Name = val;

  return true;
} // sb_Catd::setName


bool
sb_Catd::setType( string const& val )
{
  _imp->_Type = val;

  return true;
} // sb_Catd::setType


bool
sb_Catd::setVolume( string const& val )
{
  _imp->_Volume = val;

  return true;
} // sb_Catd::setVolume


bool
sb_Catd::setFile( string const& val )
{
  _imp->_File = val;

  return true;
} // sb_Catd::setFile


bool
sb_Catd::setRecord( string const& val )
{
  _imp->_Record = val;

  return true;
} // sb_Catd::setRecord


bool
sb_Catd::setExternal( string const& val )
{
  _imp->_External = val;

  return true;
} // sb_Catd::setExternal


bool
sb_Catd::setModuleVersion( string const& val )
{
  _imp->_ModuleVersion = val;

  return true;
} // sb_Catd::setModuleVersion


bool
sb_Catd::setComment( string const& val )
{
  _imp->_Comment = val;

  return true;
} // sb_Catd::setComment


bool
sb_Catd::setRecord( sc_Record const& record )
{
  return _ingest_record( *this, *_imp, record );
} // sb_Catd::setRecord




void
sb_Catd::unDefineName( )
{
  _imp->_Name = UNVALUED_STRING;
} // sb_Catd::unDefineName


void
sb_Catd::unDefineType( )
{
  _imp->_Type = UNVALUED_STRING;
} // sb_Catd::unDefineType


void
sb_Catd::unDefineVolume( )
{
  _imp->_Volume = UNVALUED_STRING;
} // sb_Catd::unDefineVolume


void
sb_Catd::unDefineFile( )
{
  _imp->_File = UNVALUED_STRING;
} // sb_Catd::unDefineFile


void
sb_Catd::unDefineRecord( )
{
  _imp->_Record = UNVALUED_STRING;
} // sb_Catd::unDefineRecord


void
sb_Catd::unDefineExternal( )
{
  _imp->_External = UNVALUED_STRING;
} // sb_Catd::unDefineExternal


void
sb_Catd::unDefineModuleVersion( )
{
  _imp->_ModuleVersion = UNVALUED_STRING;
} // sb_Catd::unDefineModuleVersion


void
sb_Catd::unDefineComment( )
{
  _imp->_Comment = UNVALUED_STRING;
} // sb_Catd::unDefineComment


