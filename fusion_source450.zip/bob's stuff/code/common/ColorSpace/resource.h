//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ColorSpace.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_COLORSTYPE                  129
#define IDD_DIALOG_COLORS               130
#define IDB_BITMAP1                     130
#define IDB_BITMAP_HSB                  132
#define IDB_BITMAP_HSB_PAL              130
#define IDB_BITMAP_RGB                  133
#define IDB_BITMAP_RGB_PAL              131
#define IDC_STATIC_RGB_RECT             1000
#define IDC_STATIC_HSB_RECT             1001
#define IDC_EDIT_RED                    1002
#define IDC_SPIN_RED                    1003
#define IDC_EDIT_GREEN                  1004
#define IDC_SPIN_GREEN                  1005
#define IDC_EDIT_BLUE                   1006
#define IDC_SPIN_BLUE                   1007
#define IDC_STATIC_OLD                  1008
#define IDC_STATIC_NEW                  1009
#define IDC_EDIT_HUE                    1010
#define IDC_SPIN_HUE                    1011
#define IDC_EDIT_SAT                    1012
#define IDC_SPIN_SAT                    1013
#define IDC_EDIT_VAL                    1014
#define IDC_SPIN_VAL                    1015
#define ID_VIEW_COLORSPACE              32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
