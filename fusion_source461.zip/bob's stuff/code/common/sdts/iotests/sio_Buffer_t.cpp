//
// sio_8211Buffer_t.cpp
//

#include <cassert>
#include <memory.h>

#include <iostream>


#ifdef WIN32
using namespace std;
#endif

#include "io/sio_Buffer.h"


char text[] = "0123456789";


void
copy_test( sio_Buffer buffer )
{
   // should be the same as the original text
   assert( strlen(text) == buffer.length() );

   // should be identical to the original string
   assert ( 0 == memcmp( text, buffer.data(), strlen(text) ) );

}


int
main(int argc, char** argv)
{
   cout << argv[0] << " ... " << flush;

   sio_Buffer buffer;


   assert( buffer.addData( text, strlen(text) ) );


   // the data in the buffer should be identical to the string we used
   // to add data to it in the first place
   assert ( 0 == memcmp( text, buffer.data(), strlen(text) ) );

   // and the length should be identical
   assert ( strlen(text) == buffer.length() );


   // now add more data  
   assert( buffer.addData( text, strlen(text) ) );


   // it should be twice as big
   assert( strlen(text) * 2 == buffer.length() );

   // and the second half should be identical to the original string
   assert ( 0 == memcmp( text, buffer.data() + strlen(text), strlen(text) ) );


   // now blow the buffer away
   assert ( buffer.reset() );


   // the length should be zero
   assert ( 0 == buffer.length() );



   // now add data again
   assert( buffer.addData( text, strlen(text) ) );


   // again, it should be the same as the original text
   assert( strlen(text) == buffer.length() );

   // and it should be identical to the original string
   assert ( 0 == memcmp( text, buffer.data(), strlen(text) ) );


   copy_test( buffer );


   cout << "ok" << endl;

   return 0;
}
