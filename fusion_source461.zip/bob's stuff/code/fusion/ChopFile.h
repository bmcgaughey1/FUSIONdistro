#if !defined(AFX_CHOPFILE_H__B745C852_54D0_4E06_9384_7200210392FA__INCLUDED_)
#define AFX_CHOPFILE_H__B745C852_54D0_4E06_9384_7200210392FA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ChopFile.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CChopFile dialog

class CChopFile : public CDialog
{
// Construction
public:
	CChopFile(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CChopFile)
	enum { IDD = IDD_CHOPFILE };
	CString	m_InputFileName;
	CString	m_OutputFileName;
	int		m_Lines;
	int		m_SkipLines;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChopFile)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CChopFile)
	afx_msg void OnBrowse();
	afx_msg void OnOutbrowse();
	afx_msg void OnProcess();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void UpdateButtons(void);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHOPFILE_H__B745C852_54D0_4E06_9384_7200210392FA__INCLUDED_)
