
/* testfld.c */

/*
  this file demonstrate read and write the entire field,
  the output.DDF shall be (hopefully) the same as input.DDF 
*/ 


#include "stc123.h"

int clos_fils(FILE * fin, FILE * fout)
{

   if (!end123file(&fin))  printf("%s\n","Unable to close input file");
   if (!end123file(&fout)) printf("%s\n","Unable to close output file");
   return(1);
}

int main(void)
{
  char cstrng[5000];	
  FILE *fpin, *fpout;
  char fnin[100], fnout[100];
  char ccs[4];
  char ice;
  char leadid;
  char tag[10];
  int option;
  int prv_stat = 3;
  int status = -1;
  long bytlen;
  long int_level;

   /* input file name */
  printf("%s\n","Enter input file name:");
  scanf("%s",fnin);
   
  /* open input file */
  if (!beg123file(fnin,'R',&int_level,&ice,ccs,&fpin)) 
  {
    printf("%s\n","Unable to open input file; processing terminated");
    exit(1);
  }

  /* output file name */
  printf("%s\n","Enter output file name:");
  scanf ("%s",fnout);

   /* open output file */
  if (!beg123file(fnout,'W',&int_level,&ice,ccs,&fpout)) 
  {
    printf("%s\n","Unable to open output file; processing terminated");
    if (!end123file(&fpin)) printf("%s\n","Unable to close input file");
    exit(1);
  }
  
  
  /* -- read and write data descriptive record by field  -- */


  while (status != 3 && status != 4) 
  {
    /* call rd123ddfld() for input file */
    if (!rd123ddfld(fpin,tag,cstrng,&status)) 
    {
      printf("%s%d\n","Unable to read DDR field; STATUS = ",status);
      if (clos_fils(fpin,fpout)) exit(1);
    }         
      
    /* if previous read status indicates end of record 
       set write option to start of record 
       else if read status is end of field 
       set write option to start of field 
       else set write option to read status */

    if (prv_stat == 3)
      option = 2;
    else if (status == 5)
      option = 6;
    else
      option = status;

      /* set previous read status to read status */
    prv_stat = status;

    /* call wr123ddfld() for output file */
    if (!wr123ddfld(fpout,tag,cstrng,option)) 
    {
      printf("%s%d\n","Unable to write DDR field; OPTION = ",option); 
      if (clos_fils(fpin,fpout)) exit(1);
    }
  } 
   
  /* to end a data descriptive record */
  if (!end123ddrec(fpout)) 
  {
    printf("%s\n","Unable to end Data Descriptive Record");
    if (clos_fils(fpin,fpout)) exit(1);
  } 

  /* ---  end of reading and writing data descriptive fields --- */
  
  /* ------ read and write data record by field -------  */


  status = -1;			/* reinitialize read status */
  
  /* call beg123rec() for output file */
  if (!beg123rec(fpout)) 
  {
    printf("%s\n","Unable to begin output Data Record");  
    if (clos_fils(fpin,fpout)) exit(1);
  }

  /* while not eof */
  while (status != 4) 
  {
    status = -1;		/* reset read status */
    prv_stat = 3;		/* initialize previous to end of record */
      
    /* while not end of and not end of file */
    while (status != 3 && status != 4) 
    {
      /* read field for current data record */
      if (!rd123fld(fpin,tag,&leadid,cstrng,&bytlen,&status)) 
      {
	printf("%s%d\n","Unable to read DR field; STATUS = ",status);
	if (clos_fils(fpin,fpout)) exit(1);
      }

      /* if previous read status is end of record 
	 set write option to start of record 
	 else set write option to read status */

      if (prv_stat == 3) 
	option = 2;
      else
	option = status;
      
      prv_stat = status;	/* set previous read status to read status */

      /* write field for current data record */
      if (!wr123fld(fpout,tag,leadid,cstrng,bytlen,option)) 
      {
	printf("%s%d\n","Unable to write DR field; OPTION = ",option);
	if (clos_fils(fpin,fpout)) exit(1);
      }
      
    }  /* done with current record */
  } /* done with all the record */
   

  /* call end123rec() for output file */
  if (!end123rec(fpout)) 
  {
    printf("%s\n","Unable to end Data Record");
    if (clos_fils(fpin,fpout)) exit(1);
  }
   
  /* close all the files */
  clos_fils(fpin,fpout);
   
  return(1);

}
