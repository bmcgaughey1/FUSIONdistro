#if !defined(AFX_ASCIIIMPORTDLG_H__65549F19_785C_4FBC_B16A_1CC0FF18AC6B__INCLUDED_)
#define AFX_ASCIIIMPORTDLG_H__65549F19_785C_4FBC_B16A_1CC0FF18AC6B__INCLUDED_

#include "ListCtrlEx.h"	// Added by ClassView
#include "DlgResizeHelper.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ASCIIImportDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CASCIIImportDlg dialog

class CASCIIImportDlg : public CDialog
{
// Construction
public:
	CFont m_DataFont;
	CDlgResizeHelper m_resizeHelper;
	void HighlightStartingRow();
	int UpdateColumnLists(LPCTSTR FileName);
	void DisplayParsedColumns();
	void DisplayRawDataFromFile(LPCTSTR FileName);
	CListCtrlEx m_RawFileLines;
	CListCtrlEx m_ParsedResult;
	BOOL WriteConfiguration(LPCTSTR FileName);
	BOOL ReadConfiguration(LPCTSTR FileName);
	void UpdateControls();
	CASCIIImportDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CASCIIImportDlg)
	enum { IDD = IDD_ASCII_IMPORT_DLG };
	int		m_StartingRow;
	BOOL	m_UseTab;
	BOOL	m_UseSpace;
	BOOL	m_UseComma;
	BOOL	m_UseOther;
	CString	m_OtherDelimiter;
	CString	m_OutputFileName;
	CString	m_InputFileName;
	int		m_Field_X;
	int		m_Field_Y;
	int		m_Field_Elevation;
	int		m_Field_PulseNumber;
	int		m_Field_ReturnNumber;
	int		m_Field_Intensity;
	int		m_Field_ReturnsPerPulse;
	int		m_Field_ScanAngle;
	BOOL	m_MergeDelimiters;
	BOOL	m_CreateIndex;
	BOOL	m_IgnoreNegativeReturns;
	BOOL	m_ImportSelectedReturns;
	CString	m_ReturnsToImport;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CASCIIImportDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CASCIIImportDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnInputBrowse();
	afx_msg void OnOutputBrowse();
	afx_msg void OnLoadConfiguration();
	afx_msg void OnSaveConfiguration();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnImport();
	afx_msg void OnUpdateParsedResults();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnNeedControlUpdate();
	afx_msg void OnDblclkFilecontents(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickFilecontents(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int ParseValuesFromDataLine(LPTSTR buf, LPCTSTR delimiter, double* values);
public:
	afx_msg void OnDeltaposStartingrowSpin(NMHDR *pNMHDR, LRESULT *pResult);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ASCIIIMPORTDLG_H__65549F19_785C_4FBC_B16A_1CC0FF18AC6B__INCLUDED_)
