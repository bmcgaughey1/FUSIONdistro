/////////////////////////////////////////////////////////////////////////////
// FolderDlgDlg.h : header file

#ifndef __FOLDERDLG_DIALOG_H__
#define __FOLDERDLG_DIALOG_H__

#if defined( _MSC_VER ) && ( _MSC_VER >= 1020 )
	#pragma once
#endif

#include "HyperLink.h"

/////////////////////////////////////////////////////////////////////////////
// CDemoDlg dialog

class CDemoDlg : public CDialog
{
public: // Construction

	CDemoDlg( IN CWnd* pParent = NULL );	// standard constructor
	virtual ~CDemoDlg( VOID );

public:
	BOOL	CreateToolTips( VOID );
	VOID	SetItemIcon( IN LPCTSTR pszPath );

public: // Dialog Data

	//{{AFX_DATA(CDemoDlg)
	enum { IDD = IDD_FOLDERDLG_DIALOG };
	CToolTipCtrl*	m_pToolTip;
	CEdit			m_wndFilter;
	CEdit			m_wndRoot;
	CEdit			m_wndPath;
	CEdit			m_wndName;
	CStatic			m_wndIcon;
	CHyperLink		m_wndLink;
	CButton			m_wndChkFilter;
	CButton			m_wndBtnBrwsRoot;
	CButton			m_wndBtnDelRoot;	
	CButton			m_wndBtnBrwsPath;
	CButton			m_wndBtnDelPath;
	BOOL			m_bFilter;
	CString			m_strPath;
	CString			m_strName;
	CString			m_strRoot;
	CString			m_strFilter;
	//}}AFX_DATA

	
	//{{AFX_VIRTUAL(CDemoDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual VOID DoDataExchange( IN CDataExchange* pDX );	// DDX/DDV support
	//}}AFX_VIRTUAL

protected: // Implementation

	HICON	m_hIcon;

protected: // Generated message map functions

	//{{AFX_MSG(CDemoDlg)
	virtual BOOL	OnInitDialog( VOID );	
	afx_msg VOID	OnPaint( VOID );
	afx_msg HCURSOR OnQueryDragIcon( VOID );
	afx_msg VOID	OnCmdBrwsRoot( VOID );
	afx_msg VOID	OnCmdBrwsPath( VOID );
	afx_msg VOID	OnCmdDelRoot( VOID );
	afx_msg VOID	OnCmdDelPath( VOID );
	afx_msg VOID	OnChkFilter( VOID );
	//}}AFX_MSG

protected:
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // __FOLDERDLG_DIALOG_H__
/////////////////////////////////////////////////////////////////////////////
