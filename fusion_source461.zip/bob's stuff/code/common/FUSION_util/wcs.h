// wcs.h
// definition of world coordinate system class 
//////////////////////////////////////////////////////////////////////////////////////
#if !defined(WCS__INCLUDED_)
#define WCS__INCLUDED_

class WCS {

public:
	double WorldY(int screeny);
	double WorldX(int screenx);
	WCS();
	~WCS();

	// variables
	BOOL		valid;

	// world coords
	double w_minx;
	double w_miny;
	double w_maxx;
	double w_maxy;

	// screen coords
	int s_minx;
	int s_miny;
	int s_maxx;
	int s_maxy;

	// functions
	void Scale(int left, int top, int right, int bottom, double minx, double miny, double maxx, double maxy);
	void Scale(CDC *dc, double minx, double miny, double maxx, double maxy);
	void IsoAdjust(CDC *dc);
	void IsoAdjust(int aspectx, int aspecty);

	int WX(double x);
	int WY(double y);
	int WDIST(double dist);
	int WXDIST(double dist);
	int WYDIST(double dist);

	// scaling ratios
	double xratio;
	double yratio;

private:

};

#endif // !defined(WCS__INCLUDED_)
