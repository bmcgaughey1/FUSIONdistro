// WaveformData.cpp: implementation of the CWaveformData class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "WaveformData.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CWaveformData::CWaveformData(LPCTSTR FileName, int Format)
{
	m_FileHandle = NULL;
	m_FileName.Empty();
	m_Valid = FALSE;

	Open(FileName, Format);
}

CWaveformData::CWaveformData()
{
	m_FileHandle = NULL;
	m_FileName.Empty();
	m_Valid = FALSE;
}

CWaveformData::~CWaveformData()
{
	Close();
}

BOOL CWaveformData::IsValid()
{
	return(m_Valid);
}

void CWaveformData::Close()
{
	if (m_Valid) {
		fclose(m_FileHandle);

		m_FileHandle = NULL;
		m_FileName.Empty();
		m_Valid = FALSE;
	}

}

BOOL CWaveformData::Open(LPCTSTR FileName, int Format)
{
	if (m_Valid)
		Close();

	m_FileHandle = fopen(FileName, "rb");
	if (m_FileHandle) {
		if (Format == TERRAPOINT) {
			// read header...make sure we have the correct format
			if (fread(&m_Header, sizeof (TWF_HEADER_1_0), 1, m_FileHandle) == 1) {
				if (m_Header.Signature[0] == 'T' && m_Header.Signature[1] == 'W' && m_Header.Signature[2] == 'F' && m_Header.Signature[3] == 'f') {
					m_Valid = TRUE;
					m_FileName = _T(FileName);

					// seek to start of waveforms
					Rewind();
				}
			}
		}
	}

	return(m_Valid);
}

void CWaveformData::Rewind()
{
	if (m_Valid && m_FileHandle)
		fseek(m_FileHandle, m_Header.HeaderSize, SEEK_SET);
}

unsigned int CWaveformData::GetNumberOfWaveforms()
{
	if (m_Valid)
		return(m_Header.NumberOfWaveforms);

	return(0);
}

BOOL CWaveformData::ReadWaveform(TWF_DATABLOCK &Header, TWF_CHANNELRECORD *LowChannel, TWF_CHANNELRECORD *HighChannel)
{
	if (!m_Valid)
		return(FALSE);

	// read the header
	if (ReadWaveformHeader(&Header)) {
		if (ReadWaveformLowData(Header, LowChannel)) {
			if (ReadWaveformHighData(Header, HighChannel))
				return(TRUE);
		}
	}

	return(FALSE);
}

BOOL CWaveformData::ReadWaveformHeader(TWF_DATABLOCK *Header)
{
	if (m_Valid) {
		// read the header
		if (fread(Header, sizeof(TWF_DATABLOCK), 1, m_FileHandle) == 1)
			return(TRUE);
	}

	return(FALSE);
}

BOOL CWaveformData::ReadWaveformLowData(TWF_DATABLOCK &Header, TWF_CHANNELRECORD *LowChannel)
{
	if (m_Valid && Header.NumberOfLowRecords) {
		if (fread(LowChannel, sizeof(TWF_CHANNELRECORD), Header.NumberOfLowRecords, m_FileHandle) == Header.NumberOfLowRecords)
			return(TRUE);
	}

	return(FALSE);
}

BOOL CWaveformData::ReadWaveformHighData(TWF_DATABLOCK &Header, TWF_CHANNELRECORD *HighChannel)
{
	if (m_Valid && Header.NumberOfHighRecords) {
		if (fread(HighChannel, sizeof(TWF_CHANNELRECORD), Header.NumberOfHighRecords, m_FileHandle) == Header.NumberOfHighRecords)
			return(TRUE);
	}

	return(FALSE);
}

void CWaveformData::SkipWaveformData(TWF_DATABLOCK &Header)
{
	if (m_Valid) {
		fseek(m_FileHandle, (Header.NumberOfLowRecords + Header.NumberOfHighRecords) * sizeof(TWF_CHANNELRECORD), SEEK_CUR);
	}
}
