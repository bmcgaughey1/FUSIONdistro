//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//
// sc_Field.cpp: implementation of the sc_Field class.
//


#include "container/sc_Field.h"

#include <iterator>
#include <algorithm>


static const char* _ident = "$Id: sc_Field.cpp,v 1.7 1998/10/13 14:05:40 mcoletti Exp $";


sc_Field::sc_Field()
{
}

sc_Field::sc_Field( string const& name, string const& mnemonic )
  : _mnemonic( mnemonic ), _name( name )
{
}

sc_Field::~sc_Field()
{
}


string const&
sc_Field::getName() const
{
   return _name;
}


string const&
sc_Field::getMnemonic() const
{
   return _mnemonic;
}


string const&
sc_Field::setName(string const& name)
{
   return _name = name;
}


string const&
sc_Field::setMnemonic(string const& mnem)
{
   return _mnemonic = mnem;
}


ostream&
operator<<( ostream& os, sc_Field const& field )
{
  os << field.getMnemonic() << " : " << field.getName() << "\n";

  ostream_iterator<sc_Subfield> os_itr( os, "\n" );

  copy( field.begin(), field.end(), os_itr );

  return os;
}
