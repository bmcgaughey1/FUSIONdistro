// ChopFile.cpp : implementation file
//

#include "stdafx.h"
#include "fusion.h"
#include "ChopFile.h"
#include "datafile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChopFile dialog


CChopFile::CChopFile(CWnd* pParent /*=NULL*/)
	: CDialog(CChopFile::IDD, pParent)
{
	//{{AFX_DATA_INIT(CChopFile)
	m_InputFileName = _T("");
	m_OutputFileName = _T("");
	m_Lines = 1000;
	m_SkipLines = 0;
	//}}AFX_DATA_INIT
}


void CChopFile::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChopFile)
	DDX_Text(pDX, IDC_FILENAME, m_InputFileName);
	DDX_Text(pDX, IDC_OUTFILENAME, m_OutputFileName);
	DDX_Text(pDX, IDC_LINES, m_Lines);
	DDX_Text(pDX, IDC_SKIPLINES, m_SkipLines);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CChopFile, CDialog)
	//{{AFX_MSG_MAP(CChopFile)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_BN_CLICKED(IDC_OUTBROWSE, OnOutbrowse)
	ON_BN_CLICKED(IDC_PROCESS, OnProcess)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChopFile message handlers

void CChopFile::OnBrowse() 
{
	UpdateData();
	
	CString csFilter;
	CString csExt;

	// load strings that specify the file types for the file...open dialog
	csFilter.LoadString(IDS_DATAFILEFILTER);
	csExt.LoadString(IDS_DATAFILEEXT);

	// create an instance of the file...open dialog
	CFileDialog fd(TRUE, csExt, NULL, OFN_HIDEREADONLY, csFilter, (CWnd*) this);

	// use the file...open dialog to get an image file name
	if (fd.DoModal() == IDOK) {
		// retrieve the name for the file...open dialog
		m_InputFileName = fd.GetPathName();
		UpdateData(FALSE);

		UpdateButtons();
	}
}

void CChopFile::OnOutbrowse() 
{
	UpdateData();
	
	CString csFilter;
	CString csExt;

	// load strings that specify the file types for the file...open dialog
	csFilter.LoadString(IDS_DATAFILEFILTER);
	csExt.LoadString(IDS_DATAFILEEXT);

	// create an instance of the file...open dialog
	CFileDialog fd(FALSE, csExt, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, csFilter, (CWnd*) this);

	// use the file...open dialog to get an image file name
	if (fd.DoModal() == IDOK) {
		// retrieve the name for the file...open dialog
		m_OutputFileName = fd.GetPathName();
		UpdateData(FALSE);

		UpdateButtons();
	}
}

void CChopFile::OnProcess() 
{
	UpdateData();

	CDataFile dat(m_InputFileName);
	if (dat.IsValid()) {
		AfxGetApp()->BeginWaitCursor();

		FILE* f = fopen(m_OutputFileName, "wb");
		if (f) {
			int cnt = 0;
			char buf[4096];
//			char* c;
			while (cnt < m_SkipLines + m_Lines) {
				if (!dat.ReadASCIILine(buf, TRUE))
					break;

				if (cnt >= m_SkipLines) {
//					// get rid of "-" on longitude
//					c = strstr(buf, "-123");
//					if (c)
//						*c = ' ';

					fprintf(f, "%s\r\n", buf);
				}

				cnt ++;
			}
			fclose(f);
		}
		dat.Close();
	}
	AfxGetApp()->EndWaitCursor();
}

void CChopFile::UpdateButtons()
{
	if (!m_InputFileName.IsEmpty() && !m_OutputFileName.IsEmpty())
		GetDlgItem(IDC_PROCESS)->EnableWindow();
	else
		GetDlgItem(IDC_PROCESS)->EnableWindow(FALSE);
}
