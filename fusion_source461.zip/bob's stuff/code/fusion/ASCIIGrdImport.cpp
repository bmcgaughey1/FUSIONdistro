// ASCIIGrdImport.cpp : implementation file
//

#include "stdafx.h"
#include "fusion.h"
#include "ASCIIGrdImport.h"
#include "ASCIIGridFile.h"
#include "filespec.h"
#include "Plansdtm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CASCIIGrdImport dialog


CASCIIGrdImport::CASCIIGrdImport(CWnd* pParent /*=NULL*/)
	: CDialog(CASCIIGrdImport::IDD, pParent)
{
	//{{AFX_DATA_INIT(CASCIIGrdImport)
	m_InputFileName = _T("");
	m_OutputFileName = _T("");
	m_PlanimetricIn = 0;
	m_PlanimetricOut = 0;
	m_ElevationIn = 0;
	m_ElevationOut = 0;
	m_Projection = 0;
	m_ProjectionZone = 0;
	//}}AFX_DATA_INIT
}


void CASCIIGrdImport::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CASCIIGrdImport)
	DDX_Text(pDX, IDC_IMPORT_INPUTFILE, m_InputFileName);
	DDX_Text(pDX, IDC_IMPORT_OUTPUTFILE, m_OutputFileName);
	DDX_Radio(pDX, IDC_IN_XY_FEET, m_PlanimetricIn);
	DDX_Radio(pDX, IDC_OUT_XY_FEET, m_PlanimetricOut);
	DDX_Radio(pDX, IDC_IN_Z_FEET, m_ElevationIn);
	DDX_Radio(pDX, IDC_OUT_Z_FEET, m_ElevationOut);
	DDX_Radio(pDX, IDC_PROJECTIONUNKNOWN, m_Projection);
	DDX_Text(pDX, IDC_PROJECTIONZONE, m_ProjectionZone);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CASCIIGrdImport, CDialog)
	//{{AFX_MSG_MAP(CASCIIGrdImport)
	ON_BN_CLICKED(IDC_IMPORT, OnImport)
	ON_BN_CLICKED(IDC_IMPORT_INPUTBROWSE, OnImportInputbrowse)
	ON_BN_CLICKED(IDC_IMPORT_OUTPUTBROWSE, OnImportOutputbrowse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CASCIIGrdImport message handlers

BOOL CASCIIGrdImport::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	PostMessage(WM_COMMAND, IDC_IMPORT_INPUTBROWSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CASCIIGrdImport::OnImport() 
{
	UpdateData();

	char* units[] = {"F", "M"};
	char* projections[] = {"?", "U", "S"};
	CString Status;

	CEdit* edit = (CEdit*) GetDlgItem(IDC_STATUS);
	edit->SetWindowText("");
	
	GetDlgItem(IDC_IMPORT)->EnableWindow(FALSE);

	GetDlgItem(IDC_PROGRESSLABEL)->SetWindowText("ASCII raster terrain model import progress");

	// do the import
	CASCIIGridFile grd(m_InputFileName);
	if (grd.IsGoodFile()) {
		// set up conversion factors
		double XYFactor = 1.0;
		double ZFactor = 1.0;

		if (m_PlanimetricIn != m_PlanimetricOut) {
			if (m_PlanimetricIn == 0)
				XYFactor = 0.34048;
			else
				XYFactor = 3.28084;
		}
		if (m_ElevationIn != m_ElevationOut) {
			if (m_ElevationIn == 0)
				ZFactor = 0.34048;
			else
				ZFactor = 3.28084;
		}

		BOOL retcode = grd.ConvertToPLANS(m_OutputFileName, m_PlanimetricOut, m_ElevationOut, XYFactor, ZFactor, m_Projection, m_ProjectionZone);

		if (retcode) {
			Status.Format("ASCII raster file %s successfully converted to PLANS DTM format\r\n", m_InputFileName);
		}
		else {
			Status.Format("Error during conversion...\r\nIs output file name valid?\r\nIs there sufficient disk space for output file?\r\n");
		}
		AddToStatusText(edit, Status);
	}
	else {
		// bad input file
		Status.Format("Unable to open input file %s\r\nAre you sure this is a valid ASCII raster file?\r\n", m_InputFileName);
		AddToStatusText(edit, Status);
	}

	GetDlgItem(IDC_IMPORT)->EnableWindow();
}

void CASCIIGrdImport::OnImportInputbrowse() 
{
	// get dialog strings
	CString csFilter;
	CString csExt;

	csFilter.LoadString(IDS_ASCIIGRDFILEFILTER);
	csExt.LoadString(IDS_ASCIIGRDFILEEXT);

	CFileDialog fd(TRUE, csExt, NULL, OFN_HIDEREADONLY, csFilter, GetParent());
	char szInitialDir[_MAX_PATH];
	if (GetCurrentDirectory(_MAX_PATH, szInitialDir))
		fd.m_ofn.lpstrInitialDir = szInitialDir;

	if (fd.DoModal() == IDOK) {
		m_InputFileName = fd.GetPathName();

		// construct output name
		CFileSpec fs(m_InputFileName);

		fs.SetExt(".dtm");
		m_OutputFileName = fs.GetFullSpec();

		UpdateData(FALSE);
	}

	// enable/disable extract button
	if (!m_InputFileName.IsEmpty() && !m_OutputFileName.IsEmpty())
		GetDlgItem(IDC_IMPORT)->EnableWindow();
	else
		GetDlgItem(IDC_IMPORT)->EnableWindow(FALSE);
}

void CASCIIGrdImport::OnImportOutputbrowse() 
{
	// get dialog strings
	CString csFilter;
	CString csExt;

	csFilter.LoadString(IDS_TERRAINFILEFILTER);
	csExt.LoadString(IDS_TERRAINFILEEXT);

	CFileDialog fd(FALSE, csExt, NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, csFilter, GetParent());
	char szInitialDir[_MAX_PATH];
	if (GetCurrentDirectory(_MAX_PATH, szInitialDir))
		fd.m_ofn.lpstrInitialDir = szInitialDir;

	if (fd.DoModal() == IDOK) {
		m_OutputFileName = fd.GetPathName();

		UpdateData(FALSE);
	}
	if (!m_InputFileName.IsEmpty() && !m_OutputFileName.IsEmpty())
		GetDlgItem(IDC_IMPORT)->EnableWindow();
	else
		GetDlgItem(IDC_IMPORT)->EnableWindow(FALSE);
}

void CASCIIGrdImport::AddToStatusText(CEdit* EditCtrl, LPCTSTR Text)
{
	int Length = EditCtrl->GetWindowTextLength();
	EditCtrl->SetSel(Length, Length);

	EditCtrl->ReplaceSel(Text);

	// scroll so last line is visible
	EditCtrl->LineScroll(EditCtrl->GetLineCount());
}
