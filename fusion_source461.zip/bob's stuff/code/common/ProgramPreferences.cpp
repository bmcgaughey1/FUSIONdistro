// ProgramPreferences.cpp: implementation of the CProgramPreferences class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ProgramPreferences.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProgramPreferences::CProgramPreferences()
{
	m_Section = _T("Preferences");
}

CProgramPreferences::~CProgramPreferences()
{

}

CString CProgramPreferences::GetSectionName()
{
	return(m_Section);
}

void CProgramPreferences::SetSectionName(LPCTSTR szSection)
{
	// change the section name
	m_Section = _T(szSection);
}

int CProgramPreferences::GetPreference(LPCTSTR szKey, int DefaultValue)
{
	return(AfxGetApp()->GetProfileInt(m_Section, szKey, DefaultValue));
}

double CProgramPreferences::GetPreference(LPCTSTR szKey, double DefaultValue)
{
	CString temp = AfxGetApp()->GetProfileString(m_Section, szKey, "");
	if (temp.IsEmpty())
		return(DefaultValue);
	else
		return(atof(temp));
}

CString CProgramPreferences::GetPreference(LPCTSTR szKey, LPCTSTR DefaultValue)
{
	return(AfxGetApp()->GetProfileString(m_Section, szKey, DefaultValue));
}

int CProgramPreferences::GetPreference(int Key, int DefaultValue)
{
	CString temp;
	temp.LoadString(Key);

	return(GetPreference(temp, DefaultValue));
}

double CProgramPreferences::GetPreference(int Key, double DefaultValue)
{
	CString temp;
	temp.LoadString(Key);

	return(GetPreference(temp, DefaultValue));
}

CString CProgramPreferences::GetPreference(int Key, LPCTSTR DefaultValue)
{
	CString temp;
	temp.LoadString(Key);

	return(GetPreference(temp, DefaultValue));
}

void CProgramPreferences::SetPreference(LPCTSTR szKey, int Value)
{
	AfxGetApp()->WriteProfileInt(m_Section, szKey, Value);
}

void CProgramPreferences::SetPreference(LPCTSTR szKey, double Value, int Digits)
{
	CString temp;
	temp.Format("%.*lf", Digits, Value);
	AfxGetApp()->WriteProfileString(m_Section, szKey, temp);
}

void CProgramPreferences::SetPreference(LPCTSTR szKey, LPCTSTR Value)
{
	AfxGetApp()->WriteProfileString(m_Section, szKey, Value);
}

void CProgramPreferences::SetPreference(int Key, int Value)
{
	CString temp;
	temp.LoadString(Key);
	SetPreference(temp, Value);
}

void CProgramPreferences::SetPreference(int Key, double Value, int Digits)
{
	CString temp;
	temp.LoadString(Key);
	SetPreference(temp, Value, Digits);
}

void CProgramPreferences::SetPreference(int Key, LPCTSTR Value)
{
	CString temp;
	temp.LoadString(Key);
	SetPreference(temp, Value);
}
