#if !defined(AFX_DATALIMITSDLG_H__A3223F6B_B9B2_4608_BC8B_F5C04B1D5CA0__INCLUDED_)
#define AFX_DATALIMITSDLG_H__A3223F6B_B9B2_4608_BC8B_F5C04B1D5CA0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DataLimitsDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataLimitsDlg dialog

class CDataLimitsDlg : public CDialog
{
// Construction
public:
	int m_BigBin;
	CDataLimitsDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataLimitsDlg)
	enum { IDD = IDD_DATALIMITSDLG };
	CProgressCtrl	m_Bin1;
	CProgressCtrl	m_Bin2;
	CProgressCtrl	m_Bin3;
	CProgressCtrl	m_Bin4;
	CProgressCtrl	m_Bin5;
	CProgressCtrl	m_Bin6;
	CProgressCtrl	m_Bin7;
	CProgressCtrl	m_Bin8;
	CProgressCtrl	m_Bin9;
	CProgressCtrl	m_Bin10;
	CProgressCtrl	m_Bin11;
	CProgressCtrl	m_Bin12;
	CProgressCtrl	m_Bin13;
	CProgressCtrl	m_Bin14;
	CProgressCtrl	m_Bin15;
	CProgressCtrl	m_Bin16;
	double	m_MaxIntensity;
	double	m_MaxX;
	double	m_MaxY;
	double	m_MaxZ;
	double	m_MinIntensity;
	double	m_MinX;
	double	m_MinY;
	double	m_MinZ;
	CString	m_BinLabel1;
	CString	m_BinLabel2;
	CString	m_BinLabel3;
	CString	m_BinLabel4;
	CString	m_BinLabel5;
	CString	m_BinLabel6;
	CString	m_BinLabel7;
	CString	m_BinLabel8;
	CString	m_BinLabel9;
	CString	m_BinLabel10;
	CString	m_BinLabel11;
	CString	m_BinLabel12;
	CString	m_BinLabel13;
	CString	m_BinLabel14;
	CString	m_BinLabel15;
	CString	m_BinLabel16;
	int	m_BinCount1;
	int	m_BinCount2;
	int	m_BinCount3;
	int	m_BinCount4;
	int	m_BinCount5;
	int	m_BinCount6;
	int	m_BinCount7;
	int	m_BinCount8;
	int	m_BinCount9;
	int	m_BinCount10;
	int	m_BinCount11;
	int	m_BinCount12;
	int	m_BinCount13;
	int	m_BinCount14;
	int	m_BinCount15;
	int	m_BinCount16;
	//}}AFX_DATA

	int* m_Bins;
	int m_MaxBin;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataLimitsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataLimitsDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DATALIMITSDLG_H__A3223F6B_B9B2_4608_BC8B_F5C04B1D5CA0__INCLUDED_)
