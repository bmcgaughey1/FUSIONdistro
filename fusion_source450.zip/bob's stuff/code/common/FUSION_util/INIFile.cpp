//////////////////////////////////////////////////////////////////////
//
//	Module:	INIFile.cpp
//
//	Description:
//
//	Class to provide access to INI format files.  In most cases, these
//	INI files will not be used for program settings but rather for
//	data storage.
//
//	Read/Write functions are provided for most data types.  
//	Specification of the INI file section and key can be done using
//	strings from the string table by providing the string IDs or by
//	passing strings containing the section and key names.  You cannot
//	however, mix the use of string IDs and strings.
//
//	This class uses the old API functions:
//		GetPrivateProfileString()
//		WritePrivateProfileString()
//	If support for these functions is removed from the windows API,
//	in favor of forced use of the registry, replacements will have to 
//	be written.
//
//	Author:	Robert J. Mcgaughey
//
//	Creation date:	5/9/99
//
//	Revisions:
//
//	12/22/2004
//		The original design of this class was flawed in that many
//		of the functions used CString types rather that more flexible
//		LPCTSTR types. All of the functions that used CStrings for section
//		and key tags were modified to use LPCTSTR types
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "INIFile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CINIFile::CINIFile(LPCTSTR csFileName)
{
	m_FileName = _T(csFileName);
}

CINIFile::CINIFile()
{
	m_FileName = _T("");
}

CINIFile::~CINIFile()
{
	// flush the cache version...maybe
	::WritePrivateProfileString(NULL, NULL, NULL, (LPCTSTR) m_FileName);
}

// -------------------------------------------------------------------------------------------------
// write settings
// -------------------------------------------------------------------------------------------------
void CINIFile::WriteSetting(int section, int key, CString csStr)
{
	CString csSection;
	CString csKey;

	csSection.LoadString(section);
	csKey.LoadString(key);
	::WritePrivateProfileString((LPCTSTR) csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(int section, int key, int intval)
{
	CString csSection;
	CString csKey;
	CString csStr;

	csSection.LoadString(section);
	csKey.LoadString(key);
	csStr.Format("%i", intval);
	::WritePrivateProfileString((LPCTSTR) csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(int section, int key, DWORD longval)
{
	CString csSection;
	CString csKey;
	CString csStr;

	csSection.LoadString(section);
	csKey.LoadString(key);
	csStr.Format("%li", longval);
	::WritePrivateProfileString((LPCTSTR) csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(int section, int key, double dblval)
{
	CString csSection;
	CString csKey;
	CString csStr;

	csSection.LoadString(section);
	csKey.LoadString(key);
	csStr.Format("%.8lf", dblval);
	::WritePrivateProfileString((LPCTSTR) csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(int section, int key, LPCTSTR lpszStr)
{
	CString csSection;
	CString csKey;

	csSection.LoadString(section);
	csKey.LoadString(key);
	::WritePrivateProfileString((LPCTSTR) csSection, (LPCTSTR) csKey, lpszStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(int section, LPCTSTR csKey, CString csStr)
{
	CString csSection;

	csSection.LoadString(section);
	::WritePrivateProfileString((LPCTSTR) csSection, csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(int section, LPCTSTR csKey, int intval)
{
	CString csSection;
	CString csStr;

	csSection.LoadString(section);
	csStr.Format("%i", intval);
	::WritePrivateProfileString((LPCTSTR) csSection, csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(int section, LPCTSTR csKey, DWORD longval)
{
	CString csSection;
	CString csStr;

	csSection.LoadString(section);
	csStr.Format("%li", longval);
	::WritePrivateProfileString((LPCTSTR) csSection, csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(int section, LPCTSTR csKey, double dblval)
{
	CString csSection;
	CString csStr;

	csSection.LoadString(section);
	csStr.Format("%.8lf", dblval);
	::WritePrivateProfileString((LPCTSTR) csSection, csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(int section, LPCTSTR csKey, LPCTSTR lpszStr)
{
	CString csSection;

	csSection.LoadString(section);
	::WritePrivateProfileString((LPCTSTR) csSection, csKey, lpszStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(LPCTSTR csSection, int key, CString csStr)
{
	CString csKey;

	csKey.LoadString(key);
	::WritePrivateProfileString(csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(LPCTSTR csSection, int key, int intval)
{
	CString csKey;
	CString csStr;

	csKey.LoadString(key);
	csStr.Format("%i", intval);
	::WritePrivateProfileString(csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(LPCTSTR csSection, int key, DWORD longval)
{
	CString csKey;
	CString csStr;

	csKey.LoadString(key);
	csStr.Format("%li", longval);
	::WritePrivateProfileString(csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(LPCTSTR csSection, int key, double dblval)
{
	CString csKey;
	CString csStr;

	csKey.LoadString(key);
	csStr.Format("%.8lf", dblval);
	::WritePrivateProfileString(csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(LPCTSTR csSection, int key, LPCTSTR lpszStr)
{
	CString csKey;

	csKey.LoadString(key);
	::WritePrivateProfileString(csSection, (LPCTSTR) csKey, lpszStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(LPCTSTR csSection, LPCTSTR csKey, CString csStr)
{
	::WritePrivateProfileString(csSection, csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(LPCTSTR csSection, LPCTSTR csKey, int intval)
{
	CString csStr;

	csStr.Format("%i", intval);
	::WritePrivateProfileString(csSection, csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(LPCTSTR csSection, LPCTSTR csKey, DWORD longval)
{
	CString csStr;

	csStr.Format("%li", longval);
	::WritePrivateProfileString(csSection, csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(LPCTSTR csSection, LPCTSTR csKey, double dblval)
{
	CString csStr;

	csStr.Format("%.8lf", dblval);
	::WritePrivateProfileString(csSection, csKey, (LPCTSTR) csStr, (LPCTSTR) m_FileName);
}

void CINIFile::WriteSetting(LPCTSTR csSection, LPCTSTR csKey, LPCTSTR lpszStr)
{
	::WritePrivateProfileString(csSection, csKey, lpszStr, (LPCTSTR) m_FileName);
}

// -------------------------------------------------------------------------------------------------
// read settings
// -------------------------------------------------------------------------------------------------
void CINIFile::ReadSetting(int section, int key, CString& csStr, LPCTSTR defStr)
{
	CString csSection;
	CString csKey;
	char ts[513];

	csSection.LoadString(section);
	csKey.LoadString(key);
	::GetPrivateProfileString((LPCTSTR) csSection, (LPCTSTR) csKey, defStr, ts, 512, (LPCTSTR) m_FileName);
	csStr = _T(ts);
}

int CINIFile::ReadSetting(int section, int key, int defval)
{
	CString csSection;
	CString csKey;
	CString csStr;
	char ts[513];

	csSection.LoadString(section);
	csKey.LoadString(key);
	csStr.Format("%i", defval);
	::GetPrivateProfileString((LPCTSTR) csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, ts, 512, (LPCTSTR) m_FileName);
	return(atoi(ts));
}

DWORD CINIFile::ReadSetting(int section, int key, DWORD defval)
{
	CString csSection;
	CString csKey;
	CString csStr;
	char ts[513];

	csSection.LoadString(section);
	csKey.LoadString(key);
	csStr.Format("%li", defval);
	::GetPrivateProfileString((LPCTSTR) csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, ts, 512, (LPCTSTR) m_FileName);
	return((DWORD) atol(ts));
}

double CINIFile::ReadSetting(int section, int key, double defval)
{
	CString csSection;
	CString csKey;
	CString csStr;
	char ts[513];

	csSection.LoadString(section);
	csKey.LoadString(key);
	csStr.Format("%lf", defval);
	::GetPrivateProfileString((LPCTSTR) csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, ts, 512, (LPCTSTR) m_FileName);
	return(atof(ts));
}

void CINIFile::ReadSetting(int section, int key, LPSTR lpszStr, int maxlen, LPCTSTR defStr)
{
	CString csSection;
	CString csKey;

	csSection.LoadString(section);
	csKey.LoadString(key);
	::GetPrivateProfileString((LPCTSTR) csSection, (LPCTSTR) csKey, defStr, lpszStr, maxlen, (LPCTSTR) m_FileName);
}

void CINIFile::ReadSetting(int section, LPCTSTR csKey, CString& csStr, LPCTSTR defStr)
{
	CString csSection;
	char ts[513];

	csSection.LoadString(section);
	::GetPrivateProfileString((LPCTSTR) csSection, csKey, defStr, ts, 512, (LPCTSTR) m_FileName);
	csStr = _T(ts);
}

int CINIFile::ReadSetting(int section, LPCTSTR csKey, int defval)
{
	CString csSection;
	CString csStr;
	char ts[513];

	csSection.LoadString(section);
	csStr.Format("%i", defval);
	::GetPrivateProfileString((LPCTSTR) csSection, csKey, (LPCTSTR) csStr, ts, 512, (LPCTSTR) m_FileName);
	return(atoi(ts));
}

DWORD CINIFile::ReadSetting(int section, LPCTSTR csKey, DWORD defval)
{
	CString csSection;
	CString csStr;
	char ts[513];

	csSection.LoadString(section);
	csStr.Format("%li", defval);
	::GetPrivateProfileString((LPCTSTR) csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, ts, 512, (LPCTSTR) m_FileName);
	return((DWORD) atol(ts));
}

double CINIFile::ReadSetting(int section, LPCTSTR csKey, double defval)
{
	CString csSection;
	CString csStr;
	char ts[513];

	csSection.LoadString(section);
	csStr.Format("%lf", defval);
	::GetPrivateProfileString((LPCTSTR) csSection, csKey, (LPCTSTR) csStr, ts, 512, (LPCTSTR) m_FileName);
	return(atof(ts));
}

void CINIFile::ReadSetting(int section, LPCTSTR csKey, LPSTR lpszStr, int maxlen, LPCTSTR defStr)
{
	CString csSection;

	csSection.LoadString(section);
	::GetPrivateProfileString((LPCTSTR) csSection, csKey, defStr, lpszStr, maxlen, (LPCTSTR) m_FileName);
}

void CINIFile::ReadSetting(LPCTSTR csSection, int key, CString& csStr, LPCTSTR defStr)
{
	CString csKey;
	char ts[513];

	csKey.LoadString(key);
	::GetPrivateProfileString(csSection, (LPCTSTR) csKey, defStr, ts, 512, (LPCTSTR) m_FileName);
	csStr = _T(ts);
}

int CINIFile::ReadSetting(LPCTSTR csSection, int key, int defval)
{
	CString csKey;
	CString csStr;
	char ts[513];

	csKey.LoadString(key);
	csStr.Format("%i", defval);
	::GetPrivateProfileString(csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, ts, 512, (LPCTSTR) m_FileName);
	return(atoi(ts));
}

DWORD CINIFile::ReadSetting(LPCTSTR csSection, int key, DWORD defval)
{
	CString csKey;
	CString csStr;
	char ts[513];

	csKey.LoadString(key);
	csStr.Format("%li", defval);
	::GetPrivateProfileString(csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, ts, 512, (LPCTSTR) m_FileName);
	return((DWORD) atol(ts));
}

double CINIFile::ReadSetting(LPCTSTR csSection, int key, double defval)
{
	CString csKey;
	CString csStr;
	char ts[513];

	csKey.LoadString(key);
	csStr.Format("%lf", defval);
	::GetPrivateProfileString(csSection, (LPCTSTR) csKey, (LPCTSTR) csStr, ts, 512, (LPCTSTR) m_FileName);
	return(atof(ts));
}

void CINIFile::ReadSetting(LPCTSTR csSection, int key, LPSTR lpszStr, int maxlen, LPCTSTR defStr)
{
	CString csKey;

	csKey.LoadString(key);
	::GetPrivateProfileString(csSection, (LPCTSTR) csKey, defStr, lpszStr, maxlen, (LPCTSTR) m_FileName);
}

void CINIFile::ReadSetting(LPCTSTR csSection, LPCTSTR csKey, CString& csStr, LPCTSTR defStr)
{
	char ts[513];

	::GetPrivateProfileString(csSection, csKey, defStr, ts, 512, (LPCTSTR) m_FileName);
	csStr = _T(ts);
}

int CINIFile::ReadSetting(LPCTSTR csSection, LPCTSTR csKey, int defval)
{
	CString csStr;
	char ts[513];

	csStr.Format("%i", defval);
	::GetPrivateProfileString(csSection, csKey, (LPCTSTR) csStr, ts, 512, (LPCTSTR) m_FileName);
	return(atoi(ts));
}

DWORD CINIFile::ReadSetting(LPCTSTR csSection, LPCTSTR csKey, DWORD defval)
{
	CString csStr;
	char ts[513];

	csStr.Format("%li", defval);
	::GetPrivateProfileString(csSection, csKey, (LPCTSTR) csStr, ts, 512, (LPCTSTR) m_FileName);
	return((DWORD) atol(ts));
}

double CINIFile::ReadSetting(LPCTSTR csSection, LPCTSTR csKey, double defval)
{
	CString csStr;
	char ts[513];

	csStr.Format("%lf", defval);
	::GetPrivateProfileString(csSection, csKey, (LPCTSTR) csStr, ts, 512, (LPCTSTR) m_FileName);
	return(atof(ts));
}

void CINIFile::ReadSetting(LPCTSTR csSection, LPCTSTR csKey, LPSTR lpszStr, int maxlen, LPCTSTR defStr)
{
	::GetPrivateProfileString(csSection, csKey, defStr, lpszStr, maxlen, (LPCTSTR) m_FileName);
}

// -------------------------------------------------------------------------------------------------
// section deletion
// -------------------------------------------------------------------------------------------------
void CINIFile::DeleteSection(int section)
{
	CString csSection;

	csSection.LoadString(section);
	DeleteSection((LPCTSTR) csSection);
}

void CINIFile::DeleteSection(LPCTSTR szSection)
{
	::WritePrivateProfileString(szSection, NULL, NULL, (LPCTSTR) m_FileName);
}

// -------------------------------------------------------------------------------------------------
// key deletion
// -------------------------------------------------------------------------------------------------

void CINIFile::DeleteKey(int section, int key)
{
	CString csSection;
	CString csKey;

	csSection.LoadString(section);
	csKey.LoadString(key);

	DeleteKey((LPCTSTR) csSection, (LPCTSTR) csKey);
}

void CINIFile::DeleteKey(LPCTSTR szSection, LPCTSTR szKey)
{
	::WritePrivateProfileString(szSection, szKey, NULL, (LPCTSTR) m_FileName);
}

void CINIFile::SetFileName(LPCTSTR FileName)
{
	m_FileName = _T(FileName);
}
