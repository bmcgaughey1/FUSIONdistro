#ifndef INCLUDED_SB_UTILS_H
#define INCLUDED_SB_UTILS_H


#ifdef WIN32
#pragma warning( disable : 4786 )
#endif


#ifndef INCLUDED_SC_RECORD_H
#include "container/sc_Record.h"
#endif

#ifndef INCLUDED_SC_FIELD_H
#include "container/sc_Field.h"
#endif

#ifndef INCLUDED_SC_SUBFIELD_H
#include "container/sc_Subfield.h"
#endif

#include <set>

// Several useful utility functions for use with the sb_* layer classes.

class sb_Utils
{
  // This class is not meant to be instantiated. It just serves as a namespace
  // for the utility functions.

 public:

  static
    bool getFieldByMnem(sc_Record const& rec,
                        string const& mnemonic,
                        sc_Record::const_iterator& thefield);
  // Searches 'rec' for the first field with a mnemonic matching 'mnemonic'.
  // If found, sets 'thefield' to point it and returns true. Returns false
  // if not found.

  static
    bool getSubfieldByMnem(sc_Field const& field,
                           string const& mnemonic,
                           sc_Field::const_iterator& thesubf);
  // Searches 'field' for the first subfield with a mnemonic matching 'mnemonic'.
  // If found, sets 'thesubf' to point to it and returns true. Returns false
  // if not found.

  static
    bool getSubfieldByName(sc_Field const& field,
                           string const& name,
                           sc_Field::const_iterator& thesubf);
  // Searches 'field' for the first subfield with a name matching 'name'.
  // If found, sets 'thesubf' to point to it and returns true. Returns false
  // if not found.

  static
    bool getDoubleFromSubfield(sc_SubfieldCntr::const_iterator const& subf,
                               double& dataOut );
  // Tries to convert a subfield into a double.
  // If it succeeds returns True, else False.
  // Place the convert value into the dataTo passed in parameter


  /// XXX Should sc_Field have an addSubfield that does this instead?
    static void add_subfield( sc_Field& field, string const& mnemonic, string const& value );

    static void add_subfield( sc_Field& field, string const& mnemonic, int value );

    static void add_subfield( sc_Field& field, string const& mnemonic, long value );

    static void add_subfield( sc_Field& field, string const& mnemonic, double value );

				// for adding empty subfields

    static void add_empty_subfield( sc_Field& field, string const& mnemonic, sc_Subfield::SubfieldType type );


    // Will return true if the char value in ``str'' is within the set of 
    // characters found in ``values''.
    static bool valid_domain( string const & str, string const & domain_values );
    static bool valid_domain( string const & str, set<string> const & domain_values );
    static bool valid_domain( long val, set<long> const& domain_values );

 private:

  //      SfUtils() {}   // Prevent construction of this class.
  // I think the above should be sb_Utils() {}
  sb_Utils() {}

};


#endif  // INCLUDED_SB_UTILS_H

