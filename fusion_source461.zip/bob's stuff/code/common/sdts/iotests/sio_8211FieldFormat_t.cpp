//
// sio_8211FieldFormat_t.cpp
//
// XXX obviously this needs to be fleshed out
// 

#ifdef HAVE_ISO_HEADESR
#include <iostream>
#include <fstream>
#else
#include <iostream.h>
#include <fstream.h>
#endif


#ifdef WIN32
using namespace std;
#pragma warning(disable:4786)
#endif

#include "io/sio_8211FieldFormat.h"


int
main(int argc, char** argv)
{
  cout << argv[0] << " ... " << flush;

  sio_8211FieldFormat field_format;

  // XXX Add get/set type tests

  cout << "ok\n";

  return 0;

}
