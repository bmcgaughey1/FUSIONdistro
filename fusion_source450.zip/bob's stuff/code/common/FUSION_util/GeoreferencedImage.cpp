// GeoreferencedImage.cpp: implementation of the CGeoreferencedImage class.
//
//////////////////////////////////////////////////////////////////////
//
// 2/23/2022 changed the logic in MapGeoToImage() when called with int imgx,imgy
// there was code commented out that seems to have been correct. Not sure why
// I made changes but they were only made to one version of the function.
//
// Problems with alignment in IntensityImage rpomted the change. the blending operation
// was not procuding images that matched the intermediate images (shifted to the north).
//
#include "stdafx.h"
#include "math.h"
#include "GeoreferencedImage.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGeoreferencedImage::CGeoreferencedImage()
{
	m_ImageIsValid = FALSE;
	m_GeoInfoIsValid = FALSE;

	m_GEO_ULX = m_GEO_ULY = m_GEO_LRX = m_GEO_LRY = 0.0;

	//for (int i = 0; i < (DUMMY_SIZE - 1); i++) {
	//	dummy1[i] = 49;		// "1"
	//	dummy2[i] = 50;		// "2"
	//}
	//dummy1[DUMMY_SIZE - 1] = 0;
	//dummy2[DUMMY_SIZE - 1] = 0;
}

CGeoreferencedImage::~CGeoreferencedImage()
{
	m_ImageIsValid = FALSE;
	m_GeoInfoIsValid = FALSE;

	Empty();
}

BOOL CGeoreferencedImage::ReadImage(LPCTSTR szFileName, BOOL CreatePalette, BOOL ShowProgress, int ColorOption)
{
	m_ImageIsValid = CImage::ReadImage(szFileName, CreatePalette, ShowProgress);

	m_ImageSize = GetDimensions();

	m_GeoInfoIsValid = m_GeoreferenceInfo.FindAndRead(szFileName);

	// calculate location of corners
	m_GEO_ULX = m_GeoreferenceInfo.m_Cterm - m_GeoreferenceInfo.m_Aterm / 2.0;
	m_GEO_ULY = m_GeoreferenceInfo.m_Fterm - m_GeoreferenceInfo.m_Eterm / 2.0;		// Eterm is usually (-)
	m_GEO_LRX = m_GEO_ULX + m_GeoreferenceInfo.m_Aterm * (double) m_ImageSize.cx;
	m_GEO_LRY = m_GEO_ULY + m_GeoreferenceInfo.m_Eterm * (double) m_ImageSize.cy;

	return(m_ImageIsValid && m_GeoInfoIsValid);
}

void CGeoreferencedImage::MapGeoToImage(double geox, double geoy, int &imgx, int &imgy, BOOL RoundDown)
{
	if (RoundDown) {
		imgx = (int) floor(((geox - (m_GeoreferenceInfo.m_Cterm - (m_GeoreferenceInfo.m_Aterm / 2.0))) / m_GeoreferenceInfo.m_Aterm));
		if (m_lpBMIH->biHeight > 0) {
			// bottom up
//			imgy = (int)floor(((geoy - (m_GeoreferenceInfo.m_Fterm - (m_GeoreferenceInfo.m_Eterm / 2.0))) / fabs(m_GeoreferenceInfo.m_Eterm)));
			imgy = (int)ceil(((geoy - (m_GeoreferenceInfo.m_Fterm - (m_GeoreferenceInfo.m_Eterm / 2.0))) / fabs(m_GeoreferenceInfo.m_Eterm)));
		}
		else {
			// top down
//			imgy = (int)ceil(((geoy - (m_GeoreferenceInfo.m_Fterm - (m_GeoreferenceInfo.m_Eterm / 2.0))) / fabs(m_GeoreferenceInfo.m_Eterm)));
			imgy = (int)floor(((geoy - (m_GeoreferenceInfo.m_Fterm - (m_GeoreferenceInfo.m_Eterm / 2.0))) / fabs(m_GeoreferenceInfo.m_Eterm)));
		}
	}
	else {
		imgx = (int) ceil(((geox - (m_GeoreferenceInfo.m_Cterm - (m_GeoreferenceInfo.m_Aterm / 2.0))) / m_GeoreferenceInfo.m_Aterm));
		if (m_lpBMIH->biHeight > 0) {
			// bottom up
//			imgy = (int)ceil(((geoy - (m_GeoreferenceInfo.m_Fterm - (m_GeoreferenceInfo.m_Eterm / 2.0))) / fabs(m_GeoreferenceInfo.m_Eterm)));
			imgy = (int)floor(((geoy - (m_GeoreferenceInfo.m_Fterm - (m_GeoreferenceInfo.m_Eterm / 2.0))) / fabs(m_GeoreferenceInfo.m_Eterm)));
		}
		else {
			// top down
//			imgy = (int)floor(((geoy - (m_GeoreferenceInfo.m_Fterm - (m_GeoreferenceInfo.m_Eterm / 2.0))) / fabs(m_GeoreferenceInfo.m_Eterm)));
			imgy = (int)ceil(((geoy - (m_GeoreferenceInfo.m_Fterm - (m_GeoreferenceInfo.m_Eterm / 2.0))) / fabs(m_GeoreferenceInfo.m_Eterm)));
		}
	}

	// georeference info is top down...adjust imgy if image is bottom up
	if (m_lpBMIH->biHeight > 0)
		imgy = (int) (m_ImageSize.cy - 1) + imgy;
}

void CGeoreferencedImage::MapGeoToImage(double geox, double geoy, long &imgx, long &imgy, BOOL RoundDown)
{
	if (RoundDown) {
		imgx = (long) floor(((geox - (m_GeoreferenceInfo.m_Cterm - (m_GeoreferenceInfo.m_Aterm / 2.0))) / m_GeoreferenceInfo.m_Aterm));
		if (m_lpBMIH->biHeight > 0)
			imgy = (long) ceil(((geoy - (m_GeoreferenceInfo.m_Fterm - (m_GeoreferenceInfo.m_Eterm / 2.0))) / fabs(m_GeoreferenceInfo.m_Eterm)));
		else
			imgy = (long) floor(((geoy - (m_GeoreferenceInfo.m_Fterm - (m_GeoreferenceInfo.m_Eterm / 2.0))) / fabs(m_GeoreferenceInfo.m_Eterm)));
	}
	else {
		imgx = (long) ceil(((geox - (m_GeoreferenceInfo.m_Cterm - (m_GeoreferenceInfo.m_Aterm / 2.0))) / m_GeoreferenceInfo.m_Aterm));
		if (m_lpBMIH->biHeight > 0)
			imgy = (long) floor(((geoy - (m_GeoreferenceInfo.m_Fterm - (m_GeoreferenceInfo.m_Eterm / 2.0))) / fabs(m_GeoreferenceInfo.m_Eterm)));
		else
			imgy = (long) ceil(((geoy - (m_GeoreferenceInfo.m_Fterm - (m_GeoreferenceInfo.m_Eterm / 2.0))) / fabs(m_GeoreferenceInfo.m_Eterm)));
	}

	// georeference info is top down...adjust imgy if image is bottom up
	if (m_lpBMIH->biHeight > 0)
		imgy = (long) (m_ImageSize.cy - 1) + imgy;
}

void CGeoreferencedImage::MapImageToGeo(int imgx, int imgy, double &geox, double &geoy)
{
	// georeference info is top down...adjust imgy if image is bottom up
	if (m_lpBMIH->biHeight > 0)
		imgy = (int) (m_ImageSize.cy - 1) - imgy;

	geox = m_GeoreferenceInfo.m_Aterm * (double) imgx + m_GeoreferenceInfo.m_Bterm * (double) imgy + m_GeoreferenceInfo.m_Cterm;
	geoy = m_GeoreferenceInfo.m_Dterm * (double) imgx + m_GeoreferenceInfo.m_Eterm * (double) imgy + m_GeoreferenceInfo.m_Fterm;
}

void CGeoreferencedImage::MapImageToGeo(long imgx, long imgy, double &geox, double &geoy)
{
	// georeference info is top down...adjust imgy if image is bottom up
	if (m_lpBMIH->biHeight > 0)
		imgy = (long) (m_ImageSize.cy - 1) - imgy;

	geox = m_GeoreferenceInfo.m_Aterm * (double) imgx + m_GeoreferenceInfo.m_Bterm * (double) imgy + m_GeoreferenceInfo.m_Cterm;
	geoy = m_GeoreferenceInfo.m_Dterm * (double) imgx + m_GeoreferenceInfo.m_Eterm * (double) imgy + m_GeoreferenceInfo.m_Fterm;
}

void CGeoreferencedImage::MapImageToGeo(double imgx, double imgy, double &geox, double &geoy)
{
	// georeference info is top down...adjust imgy if image is bottom up
	if (m_lpBMIH->biHeight > 0)
		imgy = ((double) m_ImageSize.cy - 1.0) - imgy;

	geox = m_GeoreferenceInfo.m_Aterm * imgx + m_GeoreferenceInfo.m_Bterm * imgy + m_GeoreferenceInfo.m_Cterm;
	geoy = m_GeoreferenceInfo.m_Dterm * imgx + m_GeoreferenceInfo.m_Eterm * imgy + m_GeoreferenceInfo.m_Fterm;
}

BOOL CGeoreferencedImage::CropImage(double llx, double lly, double urx, double ury, LPCTSTR FileName)
{
	// map LL and UR corner to image coordinates
	int illx, illy, iurx, iury;
	MapGeoToImage(llx, lly, illx, illy, TRUE);
	MapGeoToImage(urx, ury, iurx, iury);

	// figure out UL point to start cropping
	CPoint llcroppt(illx, illy);
	CPoint urcroppt(iurx, iury);

	// swap y values if image is top down
	if (m_lpBMIH->biHeight < 0) {
		llcroppt.y = iury;
		urcroppt.y = illy;
	}

	if (illx < 0)
		llcroppt.x = 0;
	if (illy < 0)
		llcroppt.y = 0;

	// unlikely...
	if (illx >= m_ImageSize.cx)
		llcroppt.x = m_ImageSize.cx - 1;
	if (illy >= m_ImageSize.cy)
		llcroppt.y = m_ImageSize.cy - 1;

	if (iurx >= m_ImageSize.cx)
		urcroppt.x = m_ImageSize.cx - 1;
	if (iury >= m_ImageSize.cy)
		urcroppt.y = m_ImageSize.cy - 1;

	// unlikely...
	if (iurx < 0)
		urcroppt.x = 0;
	if (iury < 0)
		urcroppt.y = 0;

	// scale for image display size
	CSize sz(urcroppt.x - llcroppt.x + 1, abs(urcroppt.y - llcroppt.y) + 1);
	
	// check for area out of image
//	if (sz.cx == 0 || sz.cy == 0) {
	if (urcroppt.x - llcroppt.x == 0 || abs(urcroppt.y - llcroppt.y) == 0) {		// changed to correctly detect bad image 6/12/2007
		// delete image file since it will not contain the correct image if it exists
		DeleteFile(FileName);
	
		return(FALSE);
	}

	CImage NewImage;
	NewImage.Empty();
//	NewImage.CreateImage(sz, m_lpBMIH->biBitCount);
	// use 24-bit image so we don't have to worry about actual color depth of source image...cropped images will always be 24-bit
	NewImage.CreateImage(sz, 24);

	// create memory context
	CDC memdc;
	memdc.CreateCompatibleDC(NULL);
	memdc.SetMapMode(MM_TEXT);

	HBITMAP oldbm = (HBITMAP) ::SelectObject(memdc.GetSafeHdc(), NewImage.m_hBitmap);

	CPoint opt(0, 0);
	DrawPart(&memdc, opt, sz, llcroppt, sz);

	::SelectObject(memdc.GetSafeHdc(), oldbm);
	memdc.DeleteDC();

	CFile file;
	if (file.Open(FileName, CFile::modeCreate | CFile::modeWrite | CFile::typeBinary)) {
		NewImage.Write(&file);
		file.Close();
	}

	// get the actual coords for the new, cropped image
	// offset to get location of center of UL pixel and set pixel height to negative of y-scale
	double ulx, uly;
	if (m_lpBMIH->biHeight < 0) {
		// if top down image, llcroppt actually contains ul corner
		MapImageToGeo(llcroppt.x, llcroppt.y, ulx, uly);
	}
	else {
		// if bottom up image, need to get ul corner
		MapImageToGeo(llcroppt.x, urcroppt.y, ulx, uly);

		// adjust to top of pixel...+ is used since Eterm is negative for bottom up image
//		uly += m_GeoreferenceInfo.m_Eterm;
	}

	// offset to center of cell
//	ulx += m_GeoreferenceInfo.m_Aterm / 2.0;
//	uly += m_GeoreferenceInfo.m_Eterm / 2.0;

	// write world file for new image
	CString WorldFileName = FileName;
	WorldFileName += _T("w");
	FILE* f = fopen(WorldFileName, "wt");
	if (f) {
		fprintf(f, "%lf\n", m_GeoreferenceInfo.m_Aterm);
		fprintf(f, "%lf\n", 0.0);
		fprintf(f, "%lf\n", 0.0);
		fprintf(f, "%lf\n", -1.0 * fabs(m_GeoreferenceInfo.m_Eterm));
		fprintf(f, "%lf\n", ulx);
		fprintf(f, "%lf\n", uly);

		fclose(f);
	}

	return(TRUE);
}


BOOL CGeoreferencedImage::IsValid()
{
	// TODO: Add your implementation code here.
	return(CImage::IsValid() && m_GeoInfoIsValid);
}
