/*****************************************************************************
*
*  imprtdem.h
*
*     header file for imprtdem.c...constant and structure definitions
*
*****************************************************************************/

#define	TRUE				1
#define	FALSE				0

#define	FEET				0
#define	METERS			1
#define	OTHER				2

#define	FEETTOMETERS	0.3048
#define	METERSTOFEET	3.280839895

typedef struct {
	double origin_x;
	double origin_y;
	double rotation;
	double column_spacing;
	double point_spacing;
	long columns;
	long points;
	short xy_units;
	short z_units;
} ASCII_HEADER;

#ifndef BIN_HEADER_DEFINED
typedef struct {
	char signature[21];
	char name[61];
	float version;
	double origin_x;
	double origin_y;
	double min_z;
	double max_z;
	double rotation;
	double column_spacing;
	double point_spacing;
	long columns;
	long points;
	short xy_units;
	short z_units;
	short z_bytes;
	short coord_sys;
	short coord_zone;
} BIN_HEADER;
#define BIN_HEADER_DEFINED
#endif

/* if wxycoord structure is not defined, define it...normally in graph.h */
#ifndef _WXYCOORD_DEFINED
struct _wxycoord {
	double wx;  /* window x coordinate */
	double wy;  /* window y coordinate */
};
#define _WXYCOORD_DEFINED
#endif

typedef struct {
	char quad_name[41];		/* file name */
/* present but not read */
	char process_code;		/* process code */
	char sec_ind[4];			/* sectional indicator */
	char mc_origin[5];		/* MC origin code (mapping center) */
/* */
	int level_code;			/* DEM level code */
	int elev_pattern;			/* code defining elevation pattern (regular or random */
	int coord_sys;				/* code defining ground planimetric reference system */
	int coord_zone;			/* code defining zone in ground planimetric reference system */
	double map_proj[15];		/* array of map projection parameters */
	int plan_units;			/* code defining unit of measure for XY data */
	int elev_units;			/* code defining unit of measure for Z data */
	int poly_sides;			/* number of sides in the bounding polygon */
	double corners[8];		/* array of corner coordinates...clockwise from southwest */
	double min_elev;			/* minimum elevation in the model */
	double max_elev;			/* maximum elevation in the model */
	double rotation;			/* counterclockwise angle from XY reference system to DEM local reference system */
	int elev_accuracy;		/* accuracy code for elevations */
	float resolve[3];			/* array of DEM spatial resolution parameters */
	int prof_rows;				/* number of rows of profiles in DEM */
	int prof_cols;				/* number of columns of profiles in DEM */
/* -v-v-v-v-v-v-v-v-v-v-v-v-v new format parameters */
	int max_ci;					/* largest primary contour interval */
	int max_ci_units;			/* source contour interval units */
	int min_ci;					/* smallest or only primary contour intreval */
	int min_ci_units;			/* source contour interval units */
	char source_date[5];		/* data source date YYMM format */
	char inspect_date[5];	/* data inspection/revision date YYMM */
	char inspect_flag;		/* inspection/revision flag 'I' or 'R' */
	char data_valid;			/* data validation flag */
	char void_flag;			/* suspect and void area flag */
	char vertical_dat;		/* vertical datum */
	char horiz_dat;			/* horizontal datum */
	int data_edition;			/* data edition */
} TYPE_A;

typedef struct {
	int row_id;					/* row identification...usually 1 */
	int col_id;					/* column identification...profile number */
	int no_points;				/* number of data points in this profile */
	int no_cols;				/* number of columns in this profile...always 1 */
	double prof_x;				/* X of the first elevation in profile */
	double prof_y;				/* Y of the first elevation in profile */
	double local_elev;		/* elevation of local datum for the profile */
	double min_elev;			/* minimum elevation in the profile */
	double max_elev;			/* maximum elevation in the profile */
	int *elev_array;			/* pointer to array or elevations */
} TYPE_B;

typedef struct {
	int flag1;					/* flag indicating availability of statistics in element 2 */
	int abs_rmse[3];			/* RMSE of DEM's datum relative to absolute datum */
	long abs_sample;			/* sample size used to determine abs_rmse */
	int flag2;					/* flag indicating availability of statistics in element 5 */
	int rel_rmse[3];			/* RMSE of DEM's datum relative to file's datum */
	long rel_sample;			/* sample size used to determine rel_rmse */
} TYPE_C;

void print_dem_header(char *hdr_file);
int check_usgs_fmt(void);
int read_usgs_head(ASCII_HEADER *dtm);

void scan_for_dtm_envelope(TYPE_A *record, struct _wxycoord *min, struct _wxycoord *max, long *pts);

void print_status_message(char *message);
void print_error_message(char *message);
void print_debug_message(char *message);

void set_usgs_desc_name(char *buf);
int reformat_usgs(ASCII_HEADER *dtm, BIN_HEADER *bin);

