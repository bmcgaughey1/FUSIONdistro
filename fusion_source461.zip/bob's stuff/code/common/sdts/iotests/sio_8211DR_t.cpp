//
// sio_8211DR_t.cpp
//
// Exercises the DR class.
//

#include <cassert>
#include <algorithm>
#include <functional>


#include <iostream>
#include <strstream>

#ifdef WIN32
#include <xutility>  // for min()
using namespace std;
#pragma warning(disable:4786)
#else
#include <utility>   // for min()
#endif

#include "io/sio_8211DR.h"
#include "io/sio_8211Field.h"


// comparison operator for sio_8211DirEntry
class DirEntriesEqual
{
public:

  bool operator()( sio_8211DirEntry const& left, sio_8211DirEntry const& right )
    {
      return left.getFieldLength() == right.getFieldLength() &&
	left.getPosition() == right.getPosition() &&
	left.getTag() == right.getTag();
    }
}; // binary predicate class DirEntriesEqual




// comparison operator for sio_8211Field
//
// Note that since the read in DDR will have the field terminators
// stripped (because we don't bother to store them, the comparisons
// have to be a bit lenient.  That is, we allow for lengths to differ by 
// one character (presumably the missing field terminator), and then do
// a strict binary comparison that doesn't include the field terminator.
//
class FieldsEqual
{
public:

  bool operator()( sio_8211Field const& left, sio_8211Field const& right )
    {
      return left.getDataLength() - right.getDataLength() < 2 &&
	0 == memcmp( left.getData(), right.getData(), 
#ifdef WIN32
		     _cpp_min(left.getDataLength(),right.getDataLength()) );
#else
      min(left.getDataLength(),right.getDataLength()) );
#endif
}
}; // binary predicate class FieldEqual



int 
main(int argc, char** argv)
{
cout << argv[0] << " ... " << flush;
   	
// create a DDR from scratch
sio_8211DR first_dr, second_dr;
sio_8211Field first_field;
first_field.setData( "BOGUS", 5 );
first_dr.addField( "0001", first_field );

//  Check contents of DRLeader.  
const sio_8211DRLeader * const first_dr_leader =
dynamic_cast<const sio_8211DRLeader*>(&(first_dr.getLeader()));

const sio_8211DRLeader * const second_dr_leader =
dynamic_cast<const sio_8211DRLeader*>(&(second_dr.getLeader()));

assert( first_dr_leader->getRecordLength() == 0 );
assert( first_dr_leader->getLeaderIdentifier() == 'D' );
assert( first_dr_leader->getBaseAddrOfFieldArea() == 0 );
assert( first_dr_leader->getSizeOfFieldLengthField() == 1 );
assert( first_dr_leader->getSizeOfFieldPosField() == 1 );
assert( first_dr_leader->getSizeOfFieldTagField() == 4 );

//  XXX Presently, there is not test for the contents of
//  XXX the DR directory or fieldArea.  These tests may
//  XXX need to be added, but they might be overkill.

//  Now exercise << and >> operators.

// blat first_dr out to a temporary string stream
strstream ss;
ss << first_dr;

// and blat it out to a second DDR
ss >> second_dr;

// start comparing the two DDR's; they should both be the same

// first the leader
assert( first_dr_leader && second_dr_leader ); // insure we have valid leaders

assert( first_dr_leader->getRecordLength() == 
second_dr_leader->getRecordLength() );

assert( first_dr_leader->getLeaderIdentifier() == 
second_dr_leader->getLeaderIdentifier() );

assert( first_dr_leader->getBaseAddrOfFieldArea() == 
second_dr_leader->getBaseAddrOfFieldArea() );

assert( first_dr_leader->getSizeOfFieldLengthField() == 
second_dr_leader->getSizeOfFieldLengthField() );

assert( first_dr_leader->getSizeOfFieldPosField() == 
second_dr_leader->getSizeOfFieldPosField() );

assert( first_dr_leader->getSizeOfFieldTagField() == 
second_dr_leader->getSizeOfFieldTagField() );

// then the directories
assert( equal( first_dr.getDirectory().begin(), first_dr.getDirectory().end(),
  second_dr.getDirectory().begin(), DirEntriesEqual() ) );

// then the field area
assert( equal( first_dr.getFieldArea().begin(), first_dr.getFieldArea().end(),
  second_dr.getFieldArea().begin(), FieldsEqual() ) );


cout << "ok" << endl;

return 0;
}

