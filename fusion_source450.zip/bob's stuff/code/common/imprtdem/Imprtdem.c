/*****************************************************************************
 *
 *	imprtdem.c
 *
 *		command line options:
 *
 *			IMPRTDEM source dest [/Xunits] [/Zunits] [/Q]
 *
 *				source		name of source file (USGS DEM format)
 *				dest			file name for MDSD format DTM
 *
 *			optional:
 *				/Hunits		desired horizontal (XY) units (feet or meters)
 *				/Xunits		desired elevation units (feet or meters)
 *				/Q				quiet mode...no screen output
 *
 *		example
 *
 *			IMPRTDEM SIOUXON.DEM SIOUXON.DTM /XFEET /ZFEET
 *
 *			converts SIOUXON.DEM file to PLANS format and stores resulting
 *			DTM in SIOUXON.DTM.  Horizontal units will be converted to FEET.
 *			Elevation units will be converted to FEET.  Output file, SIOUXON.DTM
 *			will be in current directory.
 *
 *  Revision History:
 *
 * Version 2.1  2007/01/29  RJM
 * added support for floating point model creation to better convert files that used scaling of
 * elevations values to increase elevation precision. If scale factor for elevations in the A record
 * is < 1.0, a floating point model is created
 *
 * Version 2.0	1999/11/19	RJM
 * conversion to win32 console app
 *
 * Version 1.7  1994/07/12  18:45:46  RJM
 * more cleanup
 *
 * Version 1.6  1994/07/12  18:35:45  RJM
 * Further cleanup...still learning RCS
 *
 * Version 1.5  1994/07/12  18:21:50  RJM
 * rearranged RCS stuff
 *
 *
 ****************************************************************************/
#include		<windows.h>
#include		<stdio.h>
#include		<stdlib.h>
#include		<string.h>
#include		<dos.h>
#include		<io.h>
#include		<conio.h>
#include		<ctype.h>
#include		<errno.h>

#include		"imprtdem.h"

/* constant definitions */
#define	PROGRAM_VERSION		2.1

/* data typing...structures */

/* function prototypes */
void initialize_program(void);
int bad_command_line(int argc, char *argv[]);
int verify_disk_space(BIN_HEADER *bin);
void usage(void);
void quit_program(int exit_flag);
int fill_bin_header(ASCII_HEADER *dtm, BIN_HEADER *bin);
int write_bin_header(BIN_HEADER *bin);
int update_bin_header(BIN_HEADER *bin);
int check_dem_units(TYPE_A *a_rec);
int read_next_name(FILE *lf, char *name);
void make_hdr_file_name(char *dtm, char *hdr);
void set_conversion_factor(TYPE_A *a_rec, BIN_HEADER *bin);
void print_status_summary(void);
int verify_file(char *name);
int set_dem_names(char *name);
void make_dtm_file_name(char *dtm, char *hdr);
void print_logfile_message(char *message);

/* data typing...variables */
int		dbg_messages;			/* flag to control output of debugging messages */
int		quiet;					/* flag to control status messages to screen */
int		unit_verify;			/* flag to control correction of DEM units */
int		use_list;				/* flag to control use of a list file */
int		detailed_help;			/* flag to control display of detailed help info */
int		simple_status;			/* flag to control use of simple status messages */

int		dest_xy_units = 0;		/* desired xy output units */
int		dest_z_units = 0;		/* desired z output units */
int		input_xy_units = 0;		/* input xy output units */
int		input_z_units = 0;		/* input z output units */

long		read_line_count;		/* lines read in read_line() */

char		source_dtm[_MAX_PATH];		/* source file name */
char		dest_dtm[_MAX_PATH];			/* destination file name */
char		hdr_name[_MAX_PATH];			/* file name for DEM header info */
char		list_file[_MAX_PATH];		/* list file name */

double	xy_factor = 1.0;				/* conversion factor for XY units */
double	z_factor = 1.0;				/* conversion factor for Z (elevation) units */

ASCII_HEADER	asc_head;
BIN_HEADER		bin_head;

TYPE_A type_a_record;
TYPE_B type_b_record;

char		bin_desc_name[61];

char		*unit_names[] = {
				{"FEET  "},
				{"METERS"}
			};

FILE *logfile;

/* PROGRAM CODE */
void main(int argc, char *argv[])
{
	int key;
	FILE *lf;
	char ts[144];
	char tfile_name[_MAX_PATH];

	/* initialize program environment */
	initialize_program();

	/* verify command line parameters */
	if (bad_command_line(argc, argv))
		usage();

	/* if using list of files, open list file */
	if (use_list) {
		lf = fopen(list_file, "rt");

		if (lf == (FILE *) NULL) {
			sprintf(ts, "Cannot open list file: %s", list_file);
			print_error_message(ts);
			exit(1);
		}

		read_line_count = 0l;

		/* open logfile file */
		logfile = fopen("IMPRTDEM.logfile", "wt");
	}

	do {
		/* if using list file, read first next name and set up source and dest */
		if (use_list) {
			if (read_next_name(lf, tfile_name)) {
				fclose(lf);
				use_list = FALSE;
				fclose(logfile);

				print_status_message("See IMPRTDEM.LOG for error information\n");

				break;
			}

			if (verify_file(tfile_name)) {
				sprintf(ts, "Cannot find file: %s in line %li of list file", tfile_name, read_line_count);
				print_error_message(ts);
				print_logfile_message(ts);

				print_status_message("See IMPRTDEM.LOG for error information\n");

				continue;
			}

			if (set_dem_names(tfile_name)) {
				sprintf(ts, "Cannot create source and destination file name using %s as a base");
				print_error_message(ts);
				print_logfile_message(ts);

				print_status_message("See IMPRTDEM.LOG for error information\n");

				continue;
			}

			/* should now have source and destination file names */
			sprintf(ts, "Processing DEM file: %s to create %s\n", source_dtm, dest_dtm);
			print_status_message(ts);

			sprintf(ts, "%s...processing to create %s...", source_dtm, dest_dtm);
			print_logfile_message(ts);
		}

		/* verify and read USGS header */
		if (read_usgs_head(&asc_head)) {
			print_error_message("Cannot read USGS DEM file header");
			exit(1);
		}

		/* check units...if units are missing, prompt for units */
		if (check_dem_units(&type_a_record)) {
			if (unit_verify) {
				/* ask for correct units for source DEM */
				if (type_a_record.plan_units != 1 && type_a_record.plan_units != 2) {
					print_status_message("Planimetric measurement units for source USGS DEM file? [F]eet or [M]eters\r");
					while (1) {
						key = getch();
						if (key == 0)
							key = 256 + getch();

						if (toupper(key) == 'F') {
							type_a_record.plan_units = 1;
							break;
						}
						else if (toupper(key) == 'M') {
							type_a_record.plan_units = 2;
							break;
						}
					}
					print_status_message("                                                                            \r");
				}

				/* check elevation units...must be 1 or 2 */
				if (type_a_record.elev_units != 1 && type_a_record.elev_units != 2) {
					print_status_message("Elevation measurement units for source USGS DEM file? [F]eet or [M]eters");
					while (1) {
						key = getch();
						if (key == 0)
							key = 256 + getch();

						if (toupper(key) == 'F') {
							type_a_record.elev_units = 1;
							break;
						}
						else if (toupper(key) == 'M') {
							type_a_record.elev_units = 2;
							break;
						}
					}
					print_status_message("                                                                            \r");
				}

	/*			print_status_message("Planimetric and elevation units assumed to be feet\n");
				type_a_record.plan_units = 1;
				type_a_record.elev_units = 1;
	*/		}
			else {
				type_a_record.plan_units = input_xy_units;
				type_a_record.elev_units = input_z_units;
			}
		}

		/* set up PLANS binary header */
		set_usgs_desc_name(bin_desc_name);
		fill_bin_header(&asc_head, &bin_head);

		/* set up unit conversions */
		set_conversion_factor(&type_a_record, &bin_head);

		/* check disk space for PLANS dtm file */
//		if (verify_disk_space(&bin_head)) {
//			print_error_message("Not enough disk space for destination file");
//			exit(1);
//		}

		/* print the usgs header to a file... */
		/* same name as destination but .HDR extension */
		make_hdr_file_name(dest_dtm, hdr_name);
		print_dem_header(hdr_name);

		/* print status report */
		print_status_summary();

		/* convert */
		write_bin_header(&bin_head);

		reformat_usgs(&asc_head, &bin_head);

		update_bin_header(&bin_head);

		print_status_message("Format conversion complete\n\n");

		if (use_list)
			print_logfile_message("Done\n");
	}
	while (use_list);

	exit(0);
}

/*==========================================================================*/
/*==========================================================================*/

void print_status_summary(void)
{
	char ts[144];

	sprintf(ts, "Source USGS DEM file: %s\n", source_dtm);
	print_status_message(ts);
	sprintf(ts, "Destination DTM file: %s\n", dest_dtm);
	print_status_message(ts);
	sprintf(ts, "USGS DEM header information written to: %s\n\n", hdr_name);
	print_status_message(ts);
	sprintf(ts, "Source USGS DEM units...planimetric: %s  elevation: %s\n",
				unit_names[type_a_record.plan_units - 1], unit_names[type_a_record.elev_units - 1]);
	print_status_message(ts);
	sprintf(ts, "Destination DTM units...planimetric: %s  elevation: %s\n\n",
				unit_names[bin_head.xy_units], unit_names[bin_head.z_units]);
	print_status_message(ts);
}

void print_logfile_message(char *message)
{
	if (logfile != (FILE *) NULL)
		fprintf(logfile, "%s", message);
	else
		print_status_message(message);
}

void print_status_message(char *message)
{
	if (!quiet)
		fprintf(stdout, "%s", message);
}

void print_debug_message(char *message)
{
	if (dbg_messages)
		fprintf(stdout, "%s\n", message);
}

void print_error_message(char *message)
{
	fprintf(stdout, "ERROR: %s\n", message);
}

void usage(void)
{
	fprintf(stdout, "IMPRTDEM usage:\n");
	fprintf(stdout, "   IMPRTDEM source dest [/Xunits] [/Zunits] [/Q]\n");
	fprintf(stdout, "   source   name of source USGS DEM data file\n");
	fprintf(stdout, "   dest     name of reformatted DTM data file\n");
	fprintf(stdout, "   /Xunits  desired units of measurement for planimetric (XY) data\n");
	fprintf(stdout, "   /Zunits  desired units of measurement for elevation (Z) data\n");
	fprintf(stdout, "   /Eunits  input units for elevation (Z) data...only used if \n");
	fprintf(stdout, "            unit flag is missing in input file\n");
	fprintf(stdout, "   /Punits  input units for planimetricn (XY) data...only used if \n");
	fprintf(stdout, "            unit flag is missing in input file\n");
	fprintf(stdout, "   /Q       suppress all output to the screen\n");
	fprintf(stdout, "   /V       prompt for units if missing in input file\n");
	fprintf(stdout, "-OR-\n");
	fprintf(stdout, "   IMPRTDEM @list [/Xunits] [/Zunits] [/Q]\n");
	fprintf(stdout, "   @list    name of a text file containing a list of USGS DEM data files.\n");
	fprintf(stdout, "            List file should be arranged with one file per line\n");
	fprintf(stdout, "            Converted files will be stored in files with the extension .DTM\n");
	fprintf(stdout, "Notes:\n");
	fprintf(stdout, "   - unit choices are FEET or METERS or F or M\n");
	fprintf(stdout, "   - source and destination file names must be different\n");
	fprintf(stdout, "   - existing destination file will be overwritten\n");

	quit_program(1);
}

void quit_program(int exit_arg)
{
	exit(exit_arg);
}

void initialize_program(void)
{
	char ts[256];

	dbg_messages = TRUE;
	unit_verify = FALSE;
	simple_status = FALSE;
	input_xy_units = 1;
	input_z_units = 1;

	use_list = FALSE;

	quiet = FALSE;

	detailed_help = FALSE;

	/* print opening message */
	sprintf(ts, "\nUSGS DEM Import Utility -- Version %.2lf\n\n", PROGRAM_VERSION);

	print_status_message(ts);
}

/*==========================================================================*/

int bad_command_line(int argc, char *argv[])
{
	/**************************************************************************
	*
	*  function name:		bad_command_line()
	*
	*  description:		Validates command line parameters.  Expects a minimum
	*							of 2 parameters...source and destination file names.
	*
	*							Optional parameters specify unit conversions, if any.
	*
	*  return value:		Returns 0 if command line is OK, 1 otherwise.
	*
	**************************************************************************/

	int i;
	int err = 0;
	char ts[256];
	char *c;

	if (argc < 2)
		return(1);

	/* check first argument for "@" */
	if (argc < 3 && argv[1][0] != '@')
		return(1);

	if (argv[1][0] == '@') {
		/* copy list file name */
		strcpy(list_file, &argv[1][1]);

		/* check for existence of list file */
		if (access(list_file, 0)) {
			sprintf(ts, "List file not found: %s", list_file);
			print_error_message(ts);
			err = 1;
		}

		/* set flag */
		use_list = TRUE;
	}
	else {
		/* read source and destination file names */
		strcpy(source_dtm, argv[1]);
		strcpy(dest_dtm, argv[2]);

		// replace quotation marks
		if (argv[1][0] == '\"')
			strcpy(source_dtm, &argv[1][1]);

		if (argv[2][0] == '\"')
			strcpy(dest_dtm, &argv[2][1]);

		c = source_dtm;
		while (*c != '\0') {
			if (*c == '\"')
				*c = ' ';
			c ++;
		}

		c = dest_dtm;
		while (*c != '\0') {
			if (*c == '\"')
				*c = ' ';
			c ++;
		}

		strlwr(source_dtm);
		strlwr(dest_dtm);

		/* check for existence of source file */
		if (access(source_dtm, 0)) {
			sprintf(ts, "Source file not found: %s", source_dtm);
			print_error_message(ts);
			err = 1;
		}
		else {		/* can the file be opened for read? */
			if (access(source_dtm, 4)) {
				sprintf(ts, "Source file found but not available for read access.\n Source file: %s", source_dtm);
				print_error_message(ts);
				err = 1;
			}
		}

		/* check for existence of destination file */
		if (!access(dest_dtm, 0)) {
			sprintf(ts, "Destination file will be overwritten: %s\n\n", dest_dtm);
			print_status_message(ts);
		}

		/* destination and source cannot be the same... */
		if (!strcmp(source_dtm, dest_dtm)) {
			print_error_message("Source file name and destination file name cannot be the same");
			err = 1;
		}
	}

	/* process command line parameters */
   for (i = use_list ? 2 : 3; i < argc; i ++) {
		if (argv[i][0] == '-' || argv[i][0] == '/') {
			switch (argv[i][1]) {
				case 'x':			/* horizontal units */
				case 'X':
					strupr(argv[i]);
					if (argv[i][2] == 'F')
						dest_xy_units = 1;
					else if (argv[i][2] == 'M')
						dest_xy_units = 2;
					else {
						sprintf(ts, "Bad command line argument: %s", argv[i]);
						print_error_message(ts);
						err = 1;
					}
					break;
				case 'z':			/* elevation units */
				case 'Z':
					strupr(argv[i]);
					if (argv[i][2] == 'F')
						dest_z_units = 1;
					else if (argv[i][2] == 'M')
						dest_z_units = 2;
					else {
						sprintf(ts, "Bad command line argument: %s", argv[i]);
						print_error_message(ts);
						err = 1;
					}
					break;
				case 'p':			/* horizontal units for input file */
				case 'P':
					strupr(argv[i]);
					if (argv[i][2] == 'F')
						input_xy_units = 1;
					else if (argv[i][2] == 'M')
						input_xy_units = 2;
					else {
						sprintf(ts, "Bad command line argument: %s", argv[i]);
						print_error_message(ts);
						err = 1;
					}
					break;
				case 'e':			/* elevation units for input file */
				case 'E':
					strupr(argv[i]);
					if (argv[i][2] == 'F')
						input_z_units = 1;
					else if (argv[i][2] == 'M')
						input_z_units = 2;
					else {
						sprintf(ts, "Bad command line argument: %s", argv[i]);
						print_error_message(ts);
						err = 1;
					}
					break;
				case 's':			/* simple status mode...no counters in status info */
				case 'S':
					simple_status = TRUE;
					break;
				case 'q':			/* quiet mode...no screen output...except errors */
				case 'Q':
					quiet = TRUE;
					break;
				case 'v':			/* quiet mode...no screen output...except errors */
				case 'V':
					unit_verify = TRUE;
					break;
				case '?':			/* help */
				case 'h':
				case 'H':
					detailed_help = TRUE;
					err = 1;
					break;
				default:
					sprintf(ts, "Bad command line argument: %s", argv[i]);
					print_error_message(ts);
					err = 1;
					break;
			}
		}
		else {
			print_error_message("Bad command line");
			err = 1;
		}
   }

	return(err);
}

int fill_bin_header(ASCII_HEADER *dtm, BIN_HEADER *bin)
{
	strcpy(bin->signature, "PLANS-PC BINARY .DTM");
	strcpy(bin->name, bin_desc_name);
	bin->version =        (float) 2;
	bin->origin_x =       dtm->origin_x * xy_factor;
	bin->origin_y =       dtm->origin_y * xy_factor;
	bin->min_z =          (double) 0;
	bin->max_z =          (double) 0;
	bin->rotation =       dtm->rotation;
	bin->column_spacing = dtm->column_spacing * xy_factor;
	bin->point_spacing =  dtm->point_spacing * xy_factor;
	bin->columns =        dtm->columns;
	bin->points =         dtm->points;
	bin->z_bytes =        (short) 0;
	// see if elevations are scaled to obtain higher precision
	if (type_a_record.resolve[2] < 1.0)
		bin->z_bytes =        (short) 2;

	bin->xy_units = 		 type_a_record.plan_units - 1;
	bin->z_units = 		 type_a_record.elev_units - 1;

	bin->coord_sys = 		 type_a_record.coord_sys;
	bin->coord_zone =		 type_a_record.coord_zone;

	if (dest_xy_units)
		bin->xy_units = dest_xy_units - 1;

	if (dest_z_units)
		bin->z_units = dest_z_units - 1;

	return(0);
}

int write_bin_header(BIN_HEADER *bin)
{
	FILE *file;
	unsigned int noitems = 0;

	if ((file = fopen(dest_dtm, "wb")) == NULL)
		return(1);

	// model is open
	noitems += fwrite(&bin->signature, sizeof(char), 21, file);
	noitems += fwrite(&bin->name, sizeof(char), 61, file);
	noitems += fwrite(&bin->version, sizeof(float), 1, file);
	noitems += fwrite(&bin->origin_x, sizeof(double), 1, file);
	noitems += fwrite(&bin->origin_y, sizeof(double), 1, file);
	noitems += fwrite(&bin->min_z, sizeof(double), 1, file);
	noitems += fwrite(&bin->max_z, sizeof(double), 1, file);
	noitems += fwrite(&bin->rotation, sizeof(double), 1, file);
	noitems += fwrite(&bin->column_spacing, sizeof(double), 1, file);
	noitems += fwrite(&bin->point_spacing, sizeof(double), 1, file);
	noitems += fwrite(&bin->columns, sizeof(long), 1, file);
	noitems += fwrite(&bin->points, sizeof(long), 1, file);
	noitems += fwrite(&bin->xy_units, sizeof(short), 1, file);
	noitems += fwrite(&bin->z_units, sizeof(short), 1, file);
	noitems += fwrite(&bin->z_bytes, sizeof(short), 1, file);
	noitems += fwrite(&bin->coord_sys, sizeof(short), 1, file);
	noitems += fwrite(&bin->coord_zone, sizeof(short), 1, file);

	if (noitems != 97) {
		fclose(file);
		remove(dest_dtm);
		return(1);
	}

	fclose(file);
	return(0);
}

int update_bin_header(BIN_HEADER *bin)
{
	FILE *file;
	unsigned int noitems = 0;

	if ((file = fopen(dest_dtm, "rb+")) == NULL)
		return(1);

	// model is open
	noitems += fwrite(&bin->signature, sizeof(char), 21, file);
	noitems += fwrite(&bin->name, sizeof(char), 61, file);
	noitems += fwrite(&bin->version, sizeof(float), 1, file);
	noitems += fwrite(&bin->origin_x, sizeof(double), 1, file);
	noitems += fwrite(&bin->origin_y, sizeof(double), 1, file);
	noitems += fwrite(&bin->min_z, sizeof(double), 1, file);
	noitems += fwrite(&bin->max_z, sizeof(double), 1, file);
	noitems += fwrite(&bin->rotation, sizeof(double), 1, file);
	noitems += fwrite(&bin->column_spacing, sizeof(double), 1, file);
	noitems += fwrite(&bin->point_spacing, sizeof(double), 1, file);
	noitems += fwrite(&bin->columns, sizeof(long), 1, file);
	noitems += fwrite(&bin->points, sizeof(long), 1, file);
	noitems += fwrite(&bin->xy_units, sizeof(short), 1, file);
	noitems += fwrite(&bin->z_units, sizeof(short), 1, file);
	noitems += fwrite(&bin->z_bytes, sizeof(short), 1, file);
	noitems += fwrite(&bin->coord_sys, sizeof(short), 1, file);
	noitems += fwrite(&bin->coord_zone, sizeof(short), 1, file);

	if (noitems != 97) {
		fclose(file);
		unlink(dest_dtm);
		return(1);
	}

	fclose(file);
	return(0);
}

int verify_disk_space(BIN_HEADER *bin)
{
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	char dest_copy[144];
	char path[_MAX_PATH];
	DWORD avail_clusters, sectors_per_cluster, bytes_per_sector, total_clusters;
	double required_space;
	double avail_space;

	strcpy(dest_copy, dest_dtm);

	_splitpath(dest_copy, drive, dir, fname, ext);
	sprintf(path, "%s%s", drive, dir);
	GetDiskFreeSpace(path, &sectors_per_cluster, &bytes_per_sector, &avail_clusters, &total_clusters);

	required_space = (double) (bin->columns * bin->points);
	switch (bin->z_bytes) {
		case 0:
			required_space += required_space;
			break;
		case 1:
			required_space = required_space * 4.0;
			break;
		case 2:
			required_space = required_space * 6.0;
			break;
		case 3:
			required_space = required_space * 8.0;
			break;
	}

	required_space += 200.0;           /* add the header */

	avail_space = (double) avail_clusters * (double) sectors_per_cluster * (double) bytes_per_sector;

	if (required_space > avail_space)
		return(1);

	return(0);
}

void set_conversion_factor(TYPE_A *a_rec, BIN_HEADER *bin)
{
	/* note:  for DEM...1 = feet, 2 = meters */
	/*        for DTM...0 = feet, 1 = meters */

	/* planimetric */
	if ((a_rec->plan_units - 1) != bin->xy_units) {
		if (a_rec->plan_units == 1 && bin->xy_units == 1) {
			xy_factor = FEETTOMETERS;
		}
		else if (a_rec->plan_units == 2 && bin->xy_units == 0) {
			xy_factor = METERSTOFEET;
		}
	}

	/* elevation */
	if ((a_rec->elev_units - 1) != bin->z_units) {
		if (a_rec->elev_units == 1 && bin->z_units == 1) {
			z_factor = FEETTOMETERS;
		}
		else if (a_rec->elev_units == 2 && bin->z_units == 0) {
			z_factor = METERSTOFEET;
		}
	}

	/* convert units in header */
	bin->origin_x = bin->origin_x * xy_factor;
	bin->origin_y = bin->origin_y * xy_factor;
	bin->column_spacing = bin->column_spacing * xy_factor;
	bin->point_spacing = bin->point_spacing * xy_factor;
}

int check_dem_units(TYPE_A *a_rec)
{
	/* check planimetric units...must be 1 or 2 */
	if (a_rec->plan_units != 1 && a_rec->plan_units != 2) {
		print_error_message("Planimetric units must be either feet (code = 1) or meters (code = 2)");
		return(1);
	}

	/* check elevation units...must be 1 or 2 */
	if (a_rec->elev_units != 1 && a_rec->elev_units != 2) {
		print_error_message("Elevation units must be either feet (code = 1) or meters (code = 2)");
		return(1);
	}

	return(0);
}

void make_hdr_file_name(char *dtm, char *hdr)
{
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	char dest_copy[_MAX_PATH];

	strcpy(dest_copy, dtm);

	_splitpath(dest_copy, drive, dir, fname, ext);

	_makepath(hdr, drive, dir, fname, ".HDR");
}

int read_line(FILE *f, char *buffer)
{
	/* reads the next line from the specified file into buffer */
	/* skips over comments...;, %, or ! in first character */

	int error;

	do {
		while (1) {
			error = fscanf(f, "%[^\r\n]", buffer);
			if (error) {
				break;
			}
			else {
				/* read the linefeed */
				fgetc(f);
			}
		}

		/* check for end of file or other error */
		if (error == EOF)
			return(1);

		/* read the linefeed */
		fgetc(f);

		/* increment line count */
		read_line_count ++;
	} while (buffer[0] == ';' || buffer[0] == '%' || buffer[0] == '!'
			 || buffer[0] == (char)255);

	return(0);
}

int read_next_name(FILE *lf, char *name)
{
	return(read_line(lf, name));
}

int verify_file(char *name)
{
	if (access(name, 0))
		return(1);

	return(0);
}

int set_dem_names(char *name)
{
	int err = 0;
	char ts[144];

	strcpy(source_dtm, name);
	strupr(source_dtm);

	/* change extension to DTM */
	make_dtm_file_name(source_dtm, dest_dtm);
	strupr(dest_dtm);

	/* check for existence of source file */
	if (access(source_dtm, 0)) {
		sprintf(ts, "Source file not found: %s", source_dtm);
		print_error_message(ts);
		err = 1;
	}
	else {		/* can the file be opened for read? */
		if (access(source_dtm, 4)) {
			sprintf(ts, "Source file found but not available for read access.\n Source file: %s", source_dtm);
			print_error_message(ts);
			err = 1;
		}
	}

	/* check for existence of destination file */
	if (!access(dest_dtm, 0)) {
		sprintf(ts, "Destination file will be overwritten: %s\n\n", dest_dtm);
		print_status_message(ts);
	}

	/* destination and source cannot be the same... */
	if (!strcmp(source_dtm, dest_dtm)) {
		print_error_message("Source file name and destination file name cannot be the same");
		err = 1;
	}

	return(err);
}

void make_dtm_file_name(char *dtm, char *hdr)
{
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	char dest_copy[_MAX_PATH];

	strcpy(dest_copy, dtm);

	_splitpath(dest_copy, drive, dir, fname, ext);

	_makepath(hdr, drive, dir, fname, ".DTM");
}

