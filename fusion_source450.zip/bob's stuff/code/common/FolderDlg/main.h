/////////////////////////////////////////////////////////////////////////////
// FolderDlg.h : main header file for the FOLDERDLG application

#ifndef __FOLDERDLG_MAIN_H__
#define __FOLDERDLG_MAIN_H__

#if defined( _MSC_VER ) && ( _MSC_VER >= 1020 )
	#pragma once
#endif

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CFolderDlgApp:
// See FolderDlg.cpp for the implementation of this class

class CDemoApp : public CWinApp
{
public:
	CDemoApp( VOID );

public: // Overrides
	
	//{{AFX_VIRTUAL(CDemoApp)
	virtual BOOL InitInstance( VOID );
	//}}AFX_VIRTUAL

public: // Implementation

	//{{AFX_MSG(CDemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		// DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG

public:
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // __FOLDERDLG_MAIN_H__
/////////////////////////////////////////////////////////////////////////////
