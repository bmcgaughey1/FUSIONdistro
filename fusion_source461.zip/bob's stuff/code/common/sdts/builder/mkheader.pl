#!/usr/local/bin/perl -w
#
# usage: 
#     file of "module name" followed by lines of
#     "long name", mnemonic, type vectors
#

# get module name first

$hash = "#";
$at   = "@";

$_ = <> || die("no file man");
chop;

m/(^[A-Za-z]+)/;

$module_name = $1;


# read all the function types, which will be defined with the following
# format:
#
# long name<ws>mnemonic<ws>type

$long_name = "";
$mnemonic  = "";
$type      = "";

@facet     = ();


while ( <> ) {
    ( $long_name, $mnemonic, $type ) = split;

    #print $long_name, " ", $mnemonic, " ", $type, "\n";

    push @facet, [ $long_name, $mnemonic, $type ];
}



print <<EOT;
//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//
// \$Id\$
//
EOT

format  =
@ifndef INCLUDED_SB_@<<<_H
$hash, uc($module_name)
@define INCLUDED_SB_@<<<_H
$hash, uc($module_name)

.

write;                          # blat out sentinal

print <<EOT;
#ifdef HAVE_ISO_HEADERS
#include <list>
#else
#include <list.h>
#endif

#include <string>

#ifndef SB_MODULE_H
#include "builder/sb_Module.h"
#endif


#ifndef INCLUDED_SIO8211FIELDFORMAT_H
#include "io/sio_8211FieldFormat.h"
#endif

class  sb_ForeignID;
class  sc_Record;

EOT


format CLASS_START =

// This class provides a convenient access to @<<< records.  It provides
uc($module_name)
// members to access or set various module field and subfield values.
// It also provides a mechanism for populating an object of this class with
// values found in a valid sc_Record of this module, and for filling a
// sc_Record with the contents of a sb_@<<< object.
$module_name


struct sb_@<<<_Imp;
          $module_name

class sb_@<<< : public sb_Module
         $module_name
{
 public:

  sb_@<<<();
     $module_name

.

$~ = CLASS_START;

write;

print "~sb_", $module_name, "();\n\n";

print <<GETCOMMENT;

// Use these members to get subfield/field values.  Pass in an appropriate
// type to receive the value.  These members will return false if the 
// corresponding value is not set.  (It may not be set because a value 
// was not assigned to it, or because you previously tried to assign 
// an invalid value.)  Otherwise they will return true.

GETCOMMENT



foreach $i ( @facet ) {
                                # first the long name function

    print "bool get", $i->[0], "( ";

    if ( $i->[2] eq "A" ) {
        print "string&";
    }
    elsif ( $i->[2] eq "I" ) {
        print "long&";
    }
    elsif ( $i->[2] eq "R" ) {
        print "double&";
    }
    elsif ( $i->[2] eq "C" ) {
        print "string&";
    }
    else {
        print "bogus value ", $i->[2], "\n";
        exit( -1 );
    }

    print " val ) const;\n";

                                # then the short name synonym

    print "bool get", $i->[1], "( ";


    if ( $i->[2] eq "A" ) {
        print "string&";
    }
    elsif ( $i->[2] eq "I" ) {
        print "long&";
    }
    elsif ( $i->[2] eq "R" ) {
        print "double&";
    }
    elsif ( $i->[2] eq "C" ) {
        print "string&";
    }
    else {
        print "bogus value ", $i->[2], "\n";
        exit( -1 );
    }

    print " val ) const { return get", $i->[0], "( val ); }\n\n";

}

                                # now print some sb_Module required members

print "// sdts++\n\n";

print "// fill the given record based on the builder's object field/subfield\n";
print "// values -- return false if in a wedged state. (E.g., a mandatory\n";
print "// field isn't set or was assigned a value outside its proper\n";
print "// domain.\n\n";
 
print "bool getRecord( sc_Record& val ) const;\n\n\n";


print "// fills the given schema with one appropriate for ", uc($module_name);
print "\n// modules; returns false if unable to create the schema for some\n";
print "// bizarre reason.  (Like maybe running out of memory.)  Note that\n";
print "// an sio_Writer instance will need a schema generated from this\n";
print "// member.\n\n";

print "bool getSchema( sio_8211Schema& schema ) const;\n\n\n";


print "// set the object with values found in the record; if not a valid\n";
print "// ", uc($module_name), " record, this will return false\n\n";
print "bool setRecord( sc_Record const& val );\n\n";



# now add all the set*() functions

print <<SETCOMMENT;

// Use these members to set subfield/field values.  Pass in an appropriate
// value for the particular subfield/field to be set to.  They will return
// false if you try to assign a value outside the domain of the given 
// subfield/field.  (Note that this is not too pedantic; for example, we
// do not check to see if a conditionally mandatory or optional field has
// been set.)

SETCOMMENT

foreach $i ( @facet ) {
                                # first the long name function

    print "bool set", $i->[0], "( ";

    if ( $i->[2] eq "A" ) {
        print "string const&";
    }
    elsif ( $i->[2] eq "I" ) {
        print "long";
    }
    elsif ( $i->[2] eq "R" ) {
        print "double";
    }
    elsif ( $i->[2] eq "C" ) {
        print "string const&";
    }
    else {
        print "bogus value ", $i->[2], "\n";
        exit( -1 );
    }

    print " val );\n";

                                # then the short name synonym

    print "bool set", $i->[1], "( ";


    if ( $i->[2] eq "A" ) {
        print "string const&";
    }
    elsif ( $i->[2] eq "I" ) {
        print "long";
    }
    elsif ( $i->[2] eq "R" ) {
        print "double";
    }
    elsif ( $i->[2] eq "C" ) {
        print "string const&";
    }
    else {
        print "bogus value ", $i->[2], "\n";
        exit( -1 );
    }

    print " val ) { return set", $i->[0], "( val ); }\n\n";

}



print <<UNDEFCOMMENT;

// Since builder objects will be frequently 'recycled' (i.e., used for
// more than one record), it might be convenient to 'unset' a previously
// assigned value.  So:

UNDEFCOMMENT



# now add the functions to undefine already defined values

foreach $i ( @facet ) {
                                # first the long name function

    print "void unDefine", $i->[0], "( );\n";

                                # then the short name synonym

    print "void unDefine", $i->[1], "( ) { unDefine", 
          $i->[0], "( ); }\n\n";

}


format TRAILER =


 private:
      
  sb_@<<<(sb_@<<< const& right); // NOT NEEDED
$module_name, $module_name
  sb_@<<< const& operator=(sb_@<<< const& right); // NOT NEEDED
$module_name, $module_name


  sb_@<<<_Imp* _imp;
$module_name

}; // sb_@<<<
$module_name


@endif // INCLUDED_SB_@<<<_H
$hash, uc($module_name)

.

$~ = TRAILER;
write;

# done!
