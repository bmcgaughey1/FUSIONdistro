// TileMaster.cpp: implementation of the CTileMaster class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TileMaster.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTileMaster::CTileMaster()
{
	Initialize();
}

CTileMaster::~CTileMaster()
{

}

void CTileMaster::Destroy()
{
	if (m_OverviewValid)
		DestroyOverview();

	Initialize();
}

void CTileMaster::Initialize()
{
	m_ErrorCode = 0;

	m_Valid = FALSE;
	m_OverviewValid = FALSE;
	m_UseGround = FALSE;
	m_UseMask = FALSE;
	m_UseDensity = FALSE;

	m_DataFileSpec.Empty();
	m_GroundFileSpec.Empty();
	m_MaskFileSpec.Empty();
	m_DensityFileSpec.Empty();

	m_DataFileCount = m_GroundFileCount = m_MaskFileCount = m_DensityFileCount = 0;

	m_DataFileInfoList = NULL;
	m_GroundModelHeaderList = NULL;
}

BOOL CTileMaster::CreateOverview()
{
	int i;

	// get rid of existing info...if any
	DestroyOverview();

	// check for components...must have data
	if (m_DataFileSpec.IsEmpty())
		return(FALSE);

	// scan data to get overall extent and build data file coverage info
	m_DataFileCount = ExpandFileSpecToList(m_DataFileSpec, m_DataFileList);
	if (m_DataFileCount) {
		m_OverviewMaxX = -FLT_MAX;
		m_OverviewMinX = FLT_MAX;
		m_OverviewMaxY = -FLT_MAX;
		m_OverviewMinY = FLT_MAX;
		m_OverviewMaxZ = -FLT_MAX;
		m_OverviewMinZ = FLT_MAX;

		m_OverviewPointCount = 0;

		CDataIndex Index;
		LIDARRETURN pt;

		if (m_DataFileInfoList)
			delete [] m_DataFileInfoList;

		m_DataFileInfoList = new DATAFILEINFO[m_DataFileCount];
		if (m_DataFileInfoList) {
			// go through data files
			for (i = 0; i < m_DataFileCount; i ++) {
				// initialize file info
				m_DataFileInfoList[i].MinX = FLT_MAX;
				m_DataFileInfoList[i].MinY = FLT_MAX;
				m_DataFileInfoList[i].MinZ = FLT_MAX;
				m_DataFileInfoList[i].MaxX = -FLT_MAX;
				m_DataFileInfoList[i].MaxY = -FLT_MAX;
				m_DataFileInfoList[i].MaxZ = -FLT_MAX;
				m_DataFileInfoList[i].Points = 0;
				m_DataFileInfoList[i].FileName = m_DataFileList[i];

				if (Index.Open(m_DataFileList[i])) {
					// update overall min/max
					m_OverviewMinX = min(Index.m_Header.MinX, m_OverviewMinX);
					m_OverviewMinY = min(Index.m_Header.MinY, m_OverviewMinY);
					m_OverviewMinZ = min(Index.m_Header.MinZ, m_OverviewMinZ);
					m_OverviewMaxX = max(Index.m_Header.MaxX, m_OverviewMaxX);
					m_OverviewMaxY = max(Index.m_Header.MaxY, m_OverviewMaxY);
					m_OverviewMaxZ = max(Index.m_Header.MaxZ, m_OverviewMaxZ);

					// update file min/max
					m_DataFileInfoList[i].MinX = Index.m_Header.MinX;
					m_DataFileInfoList[i].MinY = Index.m_Header.MinY;
					m_DataFileInfoList[i].MinZ = Index.m_Header.MinZ;
					m_DataFileInfoList[i].MaxX = Index.m_Header.MaxX;
					m_DataFileInfoList[i].MaxY = Index.m_Header.MaxY;
					m_DataFileInfoList[i].MaxZ = Index.m_Header.MaxZ;
					m_DataFileInfoList[i].Points = Index.m_Header.TotalPointsIndexed;

					m_OverviewPointCount += Index.m_Header.TotalPointsIndexed;

					Index.Close();
				}
				else {
					ldat.Open(m_DataFileList[i]);
					if (ldat.IsValid()) {
						m_DataFileInfoList[i].Points = 0;

						// see if file is LAS format
						if (ldat.GetFileFormat() == LASDATA) {
							// update overall min/max
							m_OverviewMinX = min(ldat.m_LASFile.Header.MinX, m_OverviewMinX);
							m_OverviewMinY = min(ldat.m_LASFile.Header.MinY, m_OverviewMinY);
							m_OverviewMinZ = min(ldat.m_LASFile.Header.MinZ, m_OverviewMinZ);
							m_OverviewMaxX = max(ldat.m_LASFile.Header.MaxX, m_OverviewMaxX);
							m_OverviewMaxY = max(ldat.m_LASFile.Header.MaxY, m_OverviewMaxY);
							m_OverviewMaxZ = max(ldat.m_LASFile.Header.MaxZ, m_OverviewMaxZ);

							// update file min/max
							m_DataFileInfoList[i].MinX = ldat.m_LASFile.Header.MinX;
							m_DataFileInfoList[i].MinY = ldat.m_LASFile.Header.MinY;
							m_DataFileInfoList[i].MinZ = ldat.m_LASFile.Header.MinZ;
							m_DataFileInfoList[i].MaxX = ldat.m_LASFile.Header.MaxX;
							m_DataFileInfoList[i].MaxY = ldat.m_LASFile.Header.MaxY;
							m_DataFileInfoList[i].MaxZ = ldat.m_LASFile.Header.MaxZ;
							m_DataFileInfoList[i].Points = ldat.m_LASFile.Header.NumberOfPointRecords;

							m_OverviewPointCount += ldat.m_LASFile.Header.NumberOfPointRecords;
						}
						else {
							while (ldat.ReadNextRecord(&pt)) {
								// update file min/max
								m_DataFileInfoList[i].MinX = min(pt.X, m_DataFileInfoList[i].MinX);
								m_DataFileInfoList[i].MinY = min(pt.Y, m_DataFileInfoList[i].MinY);
								m_DataFileInfoList[i].MinZ = min(pt.Z, m_DataFileInfoList[i].MinZ);
								m_DataFileInfoList[i].MaxX = min(pt.X, m_DataFileInfoList[i].MaxX);
								m_DataFileInfoList[i].MaxY = min(pt.Y, m_DataFileInfoList[i].MaxY);
								m_DataFileInfoList[i].MaxZ = min(pt.Z, m_DataFileInfoList[i].MaxZ);
								m_DataFileInfoList[i].Points ++;

								m_OverviewPointCount ++;
							}

							// update overall min/max
							m_OverviewMinX = min(m_DataFileInfoList[i].MinX, m_OverviewMinX);
							m_OverviewMinY = min(m_DataFileInfoList[i].MinY, m_OverviewMinY);
							m_OverviewMinZ = min(m_DataFileInfoList[i].MinZ, m_OverviewMinZ);
							m_OverviewMaxX = max(m_DataFileInfoList[i].MaxX, m_OverviewMaxX);
							m_OverviewMaxY = max(m_DataFileInfoList[i].MaxY, m_OverviewMaxY);
							m_OverviewMaxZ = max(m_DataFileInfoList[i].MaxZ, m_OverviewMaxZ);
						}
						ldat.Close();
					}
				}
			}
		}
		else {
			// couldn't create list of data files
			return(FALSE);
		}
	}
	else
		return(FALSE);			// must have data files

	// look at ground models
	if (m_UseGround) {
		m_GroundFileCount = ExpandFileSpecToList(m_GroundFileSpec, m_GroundFileList);
		if (m_GroundFileCount) {
			m_GroundModelHeaderList = new PlansDTM[m_GroundFileCount];
			if (m_GroundModelHeaderList) {
				// read all model headers...DTMs will be set up for patch access but file is not left open
				for (i = 0; i < m_GroundFileCount; i ++) {
					m_GroundModelHeaderList[i].LoadElevations(m_GroundFileList[i]);		// default is patch access
				}
			}
		}
		else {
			// no files
			m_UseGround = FALSE;
		}
	}

	// look at the mask
	if (m_UseMask) {
		m_MaskFileCount = ExpandFileSpecToList(m_MaskFileSpec, m_MaskFileList);
		if (m_MaskFileCount) {
		}
		else {
			// no files
			m_UseMask = FALSE;
		}
	}

	// look at the density layer
	if (m_UseDensity) {
		m_DensityFileCount = ExpandFileSpecToList(m_DensityFileSpec, m_DensityFileList);
		if (m_DensityFileCount) {
			m_DensityHeaderList = new PlansDTM[m_DensityFileCount];
			if (m_DensityHeaderList) {
				// read all model headers...DTM format is used for density information in Catalog
				for (i = 0; i < m_DensityFileCount; i ++) {
					m_DensityHeaderList[i].LoadElevations(m_DensityFileList[i]);		// default is patch access
				}
			}
		}
		else {
			// no files
			m_UseDensity = FALSE;
		}
	}

	m_OverviewValid = TRUE;
	return(m_OverviewValid);
}

BOOL CTileMaster::IsValid()
{
	return(m_Valid && m_OverviewValid);
}

BOOL CTileMaster::IsOverviewValid()
{
	return(m_OverviewValid);
}

void CTileMaster::DestroyOverview()
{
	if (m_DataFileInfoList) {
		delete [] m_DataFileInfoList;
		m_DataFileInfoList = NULL;
	}

	if (m_GroundModelHeaderList) {
		delete [] m_GroundModelHeaderList;
		m_GroundModelHeaderList = NULL;
	}

	m_OverviewValid = FALSE;
}

BOOL CTileMaster::FormTile(double MinX, double MinY, double MaxX, double MaxY, double BufferX, double BufferY)
{
	if (!IsValid())
		return(FALSE);

	// count points within requested area

	// allocate memory for simple point list...use origin and scale XY??

	// load list

	m_TileMinX = MinX;
	m_TileMinY = MinY;
	m_TileMaxX = MaxX;
	m_TileMaxY = MaxY;
	m_TileBufferX = BufferX;
	m_TileBufferY = BufferY;
}

void CTileMaster::AddData(LPCTSTR FileSpec)
{
	m_DataFileSpec = FileSpec;
}

void CTileMaster::AddDensity(LPCTSTR FileSpec)
{
	m_DensityFileSpec = FileSpec;
	m_UseDensity = TRUE;
}

void CTileMaster::AddGround(LPCTSTR FileSpec)
{
	m_GroundFileSpec = FileSpec;
	m_UseGround = TRUE;
}

void CTileMaster::AddMask(LPCTSTR FileSpec)
{
	m_MaskFileSpec = FileSpec;
	m_UseMask = TRUE;
}

int CTileMaster::CountFilesMatchingSpec(LPCSTR FileSpec)
{
	if (FileSpec[0] == '\0')
		return(0);

	CFileFind finder;
	int FileCount = 0;
	BOOL bWorking = finder.FindFile(FileSpec);
	while (bWorking) {
		bWorking = finder.FindNextFile();
		FileCount ++;
	}

	return(FileCount);
}

int CTileMaster::ExpandFileSpecToList(CString FileSpec, CStringArray& FileList)
{
	int Count = CountFilesMatchingSpec(FileSpec);

	if (Count) {
		FileList.RemoveAll();
		FileList.SetSize(Count);
		if (Count > 1 || (Count == 1 && FileSpec.FindOneOf("*?") >= 0)) {
			CFileFind finder;
			// multiple files or a single match to a wild card specifier
			BOOL bWorking = finder.FindFile(FileSpec);
			while (bWorking) {
				bWorking = finder.FindNextFile();
				FileList.Add(finder.GetFilePath());
			}
		}
		else {
			// only 1 file directly specified (no wild card characters)
			FileList.Add(FileSpec);
		}
	}

	return(Count);
}

int CTileMaster::IsError()
{
	return(m_ErrorCode > 0);
}

int CTileMaster::GetError()
{
	return(m_ErrorCode);
}

BOOL CTileMaster::RectanglesIntersect(double MinX1, double MinY1, double MaxX1, double MaxY1, double MinX2, double MinY2, double MaxX2, double MaxY2)
{
	// test to see if the rectangles defined by the corners overlap
	if (MinX1 > MaxX2)
		return(FALSE);
	if (MaxX1 < MinX2)
		return(FALSE);
	if (MinY1 > MaxY2)
		return(FALSE);
	if (MaxY1 < MinY2)
		return(FALSE);

	return(TRUE);
}
