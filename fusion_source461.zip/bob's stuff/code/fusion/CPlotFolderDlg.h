#pragma once
#include "afxdialogex.h"


// CPlotFolderDlg dialog

class CPlotFolderDlg : public CDialog
{
	DECLARE_DYNAMIC(CPlotFolderDlg)

public:
	CPlotFolderDlg(CWnd* pParent = nullptr);   // standard constructor
	virtual ~CPlotFolderDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PLOTFOLDERDLG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CString m_PlotFileFolder;
	CString m_PlotGroundFolder;
	afx_msg void OnBnClickedPlotfilefolderbrowse();
	afx_msg void OnBnClickedGroundfilefolderbrowse();
};
