//
// This file is part of the SDTS++ toolkit, written by the U.S.
// Geological Survey.  It is experimental software, written to support
// USGS research and cartographic data production.
// 
// SDTS++ is public domain software.  It may be freely copied,
// distributed, and modified.  The USGS welcomes user feedback, but makes
// no committment to any level of support for this code.  See the SDTS
// web site at http://mcmcweb.er.usgs.gov/sdts for more information,
// including points of contact.
//


#include "container/sc_Module.h"


#include <iterator>
#include <algorithm>



sc_Module::sc_Module()
{
}



sc_Module::~sc_Module()
{
}


ostream&
operator<<( ostream& os, sc_Module const& module )
{
  ostream_iterator<sc_Record> os_itr( os, "\n" );

  copy( module.begin(), module.end(), os_itr );

  return os;
}
